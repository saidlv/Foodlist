module.exports = {
	root: true,
	parser: '@typescript-eslint/parser',
	//plugins: ['@typescript-eslint'],
	extends: [
		'@react-native-community',
	],
	rules: {
		'prettier': "off",
		'prettier/prettier': "off",
		'quotes': "off",
		'semi': "off",
		'eqeqeq': "off",
		'keyword-spacing': 0,
		'@typescript-eslint/no-unused-vars': "warn",
		'react-hooks/exhaustive-deps': "warn",
	}
};
