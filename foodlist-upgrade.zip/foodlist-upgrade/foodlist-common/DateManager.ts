import { Day } from "@Models/Day";
import { StringDate } from "@Models/StringDate";
import { RawTime, Time } from "@Models/Time";
import moment from "moment";
import 'moment/locale/it';
import { TranslationFunction } from "./Translations";
import { toUpperLowerCase } from "./utils";

export const MINIMUM_AGE_ALLOWED = 13
export const DATE_FORMAT = 'L'
export const HOUR_FORMAT = "HH:mm"
export const HOUR_FORMAT_WITH_SECONDS = 'HH:mm:ss';
export const SERVER_DATE_FORMAT = 'YYYY-MM-DD'
export const SERVER_DATETIME_FORMAT = 'YYYY-MM-DD HH:mm'
export const HUMAN_DATE_FORMAT = "D MMMM YYYY"
export const HUMAN_DATETIME_FORMAT = "D MMMM - HH:mm"
export const HUMAN_DATE_FORMAT_WITH_WEEKDAY = "dddd D MMMM YYYY"
export const SHORT_HUMAN_FORMAT = "D MMM YY - HH:mm"
export const RECEIPT_DATE_FORMAT = "D MMM"
export const RECEIPT_DATETIME_FORMAT = "D MMM HH:mm"
export const TIME_FIRST_FORMAT = "HH:mm - dddd D MMM"

export const weekdays = () => {
	const res = moment.weekdays()
	//su moment la domenica è il primo giorno della settimana
	return (res.splice(1, 7).concat(res)).map(item => toUpperLowerCase(item))
}

export const dayFromServerDate = (date: string) => {
	return moment(date, SERVER_DATETIME_FORMAT).format(SERVER_DATE_FORMAT)
}

/** arrotonda per eccesso ai 5 minuti più vicini */
export const roundedTime = (time: moment.Moment, roundTo = 5) => {
	const _time = time.clone()
	const ecc = _time.get("minutes") % roundTo
	if(ecc > 0) {
		_time.add(5 - ecc, "minutes")
	}
	return _time
}

export const printDay = (day: moment.Moment, translate: TranslationFunction, format = HUMAN_DATE_FORMAT) => {
	if(momentIsToday(day)) {
		return translate("todayOnly")
	}
	if(momentIsToday(day.clone().subtract(1, "day"))) {
		return translate("tomorrowOnly")
	}
	return day.format(format)
}

export const shortOrderDate = (date: moment.Moment, translate: TranslationFunction) => {
	const time = formatMomentTime(date)
	return translate("hourOfWeekday", {
		hour: time,
		weekday: printDay(date, translate, "dddd").toLowerCase(),
	})
}

export const isPastDay = (date: moment.Moment) => {
	return date.format(SERVER_DATE_FORMAT) <= yesterdayServerDate()
}

/**
 * Use this only if you need to ignore the timezone
 */
export const extractServerDate = (date: string | null | undefined) => {
	if(!date) return
	return moment(date, SERVER_DATE_FORMAT).format(SERVER_DATE_FORMAT)
}

export const toServerFormat = (date: moment.Moment) => {
	return moment(date).format(SERVER_DATE_FORMAT)
}

export const getMoment = (not_utc: string) => {
	return moment(not_utc, SERVER_DATETIME_FORMAT)
}

export const todayDay = () => {
	return moment().format(SERVER_DATE_FORMAT)
}

export const todayDate = () => moment(new Date())
export const todayHour = () => todayDate().format(HOUR_FORMAT);

export const utcBasedOnServer = (date: moment.Moment) => {
	if(process.env.API_URL?.includes("https://foodlist.eu")) return date.utc()
	else return date
}

export const yesterdayServerDate = () => {
	return todayDate().subtract(1, "day").format(SERVER_DATE_FORMAT)
}

export const getDayIndex = (date: StringDate) => {
	return (moment(date, SERVER_DATE_FORMAT).day() + 6) % 7
}

export const getDayIndexFromMoment = (date: moment.Moment) => {
	return (date.day() + 6) % 7
}

export const momentDifference = (first: moment.Moment, second: moment.Moment, unit: moment.unitOfTime.Diff = "minutes") => {
	return first.diff(second, unit)
}

//Ritorna di "quanto tempo fa" è isoDate
export const getDiffStringFromNow = (isoDate: string, translate: TranslationFunction): string => {
	if(Math.abs(moment(isoDate).diff(moment(), "seconds")) < 2) {
		return translate("now").toLowerCase()
	} else {
		return moment(isoDate).fromNow()
	}
}

export const maximumDateDatePicker = (): Date => {
	const todayDate = moment(new Date())
	return new Date(todayDate.subtract(MINIMUM_AGE_ALLOWED, 'years').toISOString())
}

export const fromDateToMoment = (date: Date) => {
	return moment(date)
}

export const humanDate = (date: string | moment.Moment) => {
	return moment(date).format(HUMAN_DATE_FORMAT)
}
export const humanDateWithWeekday = (date: string) => {
	return moment(date).format(HUMAN_DATE_FORMAT_WITH_WEEKDAY)
}
export const humanDateTime = (date: string | moment.Moment) => {
	return moment(date).format(HUMAN_DATE_FORMAT) + " " + moment(date).format(HOUR_FORMAT)
}

export const setTimeInDate = (date: Date, time_string: string) => {
	let splittedTo = time_string.split(':');
	date.setHours(parseInt(splittedTo[0]))
	date.setMinutes(parseInt(splittedTo[1]))
	const limit = fromDateToMoment(date)
	return limit
}

export const dateWithTime = (date: moment.Moment, time: moment.Moment) => {
	return date.clone().set("hours", time.get("hours")).set("minutes", time.get("minutes")).set("seconds", time.get("seconds"))
}

// ------- DA STRINGA A MOMENT DATE
// Il withSeconds è riferito al formato della stringa in input
export const getMomentTime = (item: string, withSeconds?: boolean) => {
	let format = withSeconds ? HOUR_FORMAT_WITH_SECONDS : HOUR_FORMAT
	return moment(item, format)
}

export const getMomentDate = (item: string, format: string = DATE_FORMAT) => {
	return moment(item, format)
}
// ------- DA STRINGA A MOMENT DATE
//
// ------- FORMATTAZIONE
export const formatDateWithoutInputFormat = (item: string) => {
	return moment(item).format(DATE_FORMAT)
}
export const formatDate = (item: string) => {
	return moment(item).format(DATE_FORMAT)
}

export const formatTimeWithoutInputFormat = (item: string) => {
	return moment(item).format(HOUR_FORMAT)
}

export const formatMomentTime = (time: moment.Moment) => {
	return time.format(HOUR_FORMAT)
}

export const formatDateTime = (item: string) => {
	return moment(item).format(DATE_FORMAT + " - " + HOUR_FORMAT)
}

//Ritorna la stringa dell'orario in formato ${HOUR_FORMAT}
export const formatTime = (time: string): string => {
	return formatMomentTime(moment(time, HOUR_FORMAT))
}

export const formatTimeFromIsoDate = (isoDate: string) => {
	return formatMomentTime(moment(isoDate))
}

export const getTimeString = (time?: Date | string | null): string => {
	if (!time) {
		return ''
	}

	let d = new Date(time)
	if (isNaN(d.getTime())) {
		d = moment(time, HOUR_FORMAT).toDate()
	}

	let formatted = moment(d).format(HOUR_FORMAT)
	return formatted
}
// ------- FORMATTAZIONE

export const isToday = (item: string): boolean => {
	let todayDate = moment(new Date())
	let todayDay = todayDate.format('dddd');
	return item.toLowerCase() == todayDay.toLowerCase()
}

export const isSameDay = (d1: moment.Moment, d2: moment.Moment) => {
	return d1.format(SERVER_DATE_FORMAT) == d2.format(SERVER_DATE_FORMAT)
}

export const momentIsToday = (date: moment.Moment) => {
	return date.format(SERVER_DATE_FORMAT) == moment().format(SERVER_DATE_FORMAT)
}

export const getWeekday = (dayIndex: number) => {
	return weekdays()[dayIndex]
}

export const isTodayByIndex = (dayIndex: number): boolean => {
	return isToday(getWeekday(dayIndex))
}

export const todayIndex = () => {
	let todayDay = moment(new Date()).format('dddd');
	
	return weekdays().map(day => day.toLowerCase()).indexOf(todayDay.toLowerCase())
}

export const emptyWeek = (): {
	day: string,
	times: Time[],
	isToday: boolean
}[] => {
	return weekdays().map(item => {
		return {
			day: item,
			times: [],
			isToday: isToday(item)
		}
	})
}

//Riceve in input times che sono come li ritorna il server. 
//Ritorna un array di 7 elementi che raggruppa gli orari nei vari giorni della settimana
export const formatWeekTimes = (times: RawTime[]): Day[] => {
	return times.reduce((accumulator, item) => {
		const index = parseInt(item.day) - 1

		if (index >= 0 && index < 7 && !item.disabled) {
			const from = formatTime(item.from)
			const to = formatTime(item.to)

			let timeToAdd: Time = {
				timeString: from + " - " + to,
				from,
				to,
			}

			accumulator[index]?.times.push(timeToAdd)
		}
		return accumulator
	}, emptyWeek())
}