import { DeliveryRouteTime, DeliveryRoute, DeliveryRouteDay } from "@Models/DeliveryRoute"
import moment from "moment"
import { HOUR_FORMAT, dateWithTime, SERVER_DATE_FORMAT } from "./DateManager"
import { BookingDay } from "@Models/BookingDay"
import { BookingHour, EnhancedBookingHour } from "@Models/BookingHour"

export const reduceBookings = (items?: (BookingDay | DeliveryRouteDay)[]) => {
	return (items || []).reduce<(BookingDay | DeliveryRouteDay)[]>((acc, item) => {
		if(item.enabled) {
			const hours = (item.hours || [] as (BookingHour | DeliveryRouteTime)[]).filter(hour => hour.enabled)
			if(hours.length > 0) {
				acc.push({
					...item,
					hours: hours,
				})
			}
		}
		return acc
	}, [])
}

export const reduceOrderRoutes = (items?: DeliveryRoute[]) => {
	return (items || []).reduce<DeliveryRoute[]>((acc, item) => {
		if(item.enabled) {
			const days = reduceBookings(item.days)
			if(days.length > 0) {
				acc.push(item)
			}
		}
		return acc
	}, [])
}

export const preprocessBookingTime = (range: BookingHour, for_date: moment.Moment): EnhancedBookingHour => {
	const { from, to, min_minutes_before, free_seats } = range
	let _from = moment(from, HOUR_FORMAT)
	const time = moment().add(min_minutes_before ?? 0, "minutes")
	const selectedTime = dateWithTime(for_date, _from)
	if(selectedTime.isBefore(time)) {
		_from = time.add(15 - (time.get("minutes") % 15), "minutes")
	}
	const _to = moment(to, HOUR_FORMAT)
	const diff = _to.diff(_from, "minutes")
	const num_options = diff/15 + 1

	return {
		...range,
		num_hours: num_options,
		start_from: _from,
		can_order: (free_seats || 0) > 0 && moment(range.last_close_bookings, SERVER_DATE_FORMAT).format(SERVER_DATE_FORMAT) != for_date.format(SERVER_DATE_FORMAT),
	}
}

export const filterBookingDayHours = (day: BookingDay | undefined, for_date: moment.Moment) => {
	if(!day) {
		return day
	} else {
		return {
			...day,
			hours: (day.hours || []).reduce<(BookingHour & { can_order: boolean })[]>((acc, val) => {
				//TODO: max_days_before forse va gestito diversamente
				if(val.enabled && for_date.diff(moment(), "days") < val.max_days_before) {
					const range = preprocessBookingTime(val, for_date)
					if(range.num_hours > 0) {
						acc.push(range)
					}
				}
				return acc
			}, [])
		}
	}
}