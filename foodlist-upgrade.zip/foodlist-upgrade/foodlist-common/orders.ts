import { dateWithTime, extractServerDate, formatMomentTime, getMoment, HUMAN_DATE_FORMAT, SERVER_DATE_FORMAT, todayDate } from "./DateManager";
import { DeliveryRoute, DeliveryRouteTime, DisplayableDeliveryDay, DisplayableDeliveryRoute } from "@Models/DeliveryRoute";
import { TimeRange } from "@Models/TimeRange";
import moment from "moment";
import { momentFromDateAndTime } from "./utils";
import { Dish } from "@Models/Dish";
import { TranslationFunction } from "./Translations";
import { MenuSection } from "@Models/MenuSection";
import { MenuSection as ServerMenuSection } from "@Models/Menu";
import { PurchaseRestriction, RestrictionsState } from "@Models/PurchaseRestriction";
import { Order, OrderStatus } from "@Models/Order";

export const printOrderStatus = (status_id: OrderStatus | undefined, isTakeaway: boolean, translate: TranslationFunction) => {
	if(status_id == OrderStatus.Accepted) {
		return translate("orderAccepted")
	}
	if(status_id == OrderStatus.Delivering) {
		return translate(isTakeaway ? "orderReady" : "orderDelivering")
	}
	if(status_id == OrderStatus.Rejected) {
		return translate("orderRejected")
	}
	if(status_id == OrderStatus.Delivered) {
		return translate(isTakeaway ? "orderCompleted" : "orderDelivered")
	}
	return translate("waitingConfirm")
}

export const getTimeOptionsFromDisplayable = (day: DisplayableDeliveryDay) => {
	return getTimeOptions(day.time_span || 15, day.show_range, day.time_range, day.min_minutes_before || 15, day.time.from, day.time.to, day.date, moment())
}

export const toDisplayableDeliveryRoute = (item: DeliveryRoute, days: DisplayableDeliveryDay[]): DisplayableDeliveryRoute => {
	return {
		id: item.id,
		name: item.name,
		description: item.description,
		days,
		isTakeaway: item.take_away,
		price: item.price ?? 0,
		minPrice: item.min_price ?? 0
	}
}

export const toDisplayableDeliveryDay = (item: DeliveryRouteTime, section: DeliveryRoute): DisplayableDeliveryDay => {
	return {
		...section,
		...item,
		time: item,
		min_minutes_before: item.min_minutes_before || section.min_minutes_before || 15,
		weekday: null, //TODO: fix weekday
		dayIndex: null, //TODO: fix dayIndex
		orderClosed: null, //TODO: fix orderClosed
	}
}

export const getTimeOptions = (
	time_span: number,
	show_range: boolean,
	time_range: number,
	min_minutes_before: number,
	start_time_str: string,
	end_time_str: string,
	/**
	 * Used to check if available with min_minutes_before but only when current_time provided.
	 **/
	order_date?: moment.Moment,
	/** if set checks min_minutes_before */
	current_time?: moment.Moment
) => {
	const _time_range = show_range ? time_range : 0
	const _start_time = moment(start_time_str, "HH:mm")
	const _end_time = moment(end_time_str, "HH:mm")

	if(!order_date && !!current_time) {
		console.warn("current_time provided and order_date not set. Check your code, this is definitely a bug!")
	}
	const orderDate = order_date || moment()
	const start_time = momentFromDateAndTime(orderDate, _start_time)
	const end_time = momentFromDateAndTime(orderDate, _end_time)

	const options: TimeRange[] = []

	let current = start_time.clone()
	while (true) {
		const end = current.clone()
		end.add(_time_range, "minutes")
		if (!current_time || current.diff(current_time, "minutes") > min_minutes_before) {
			options.push({
				start: current.format("HH:mm"),
				end: show_range ? end.format("HH:mm") : undefined
			})
		}
		current.add(time_span || 15, "minutes")
		if (end >= end_time || current > end_time) {
			break;
		}
	}
	return options
}

export const getLastAvailableRange = (day: DisplayableDeliveryDay) => {
	const options = getTimeOptions(day.time_span || 15, day.show_range, day.time_range, day.min_minutes_before || 15, day.time.from, day.time.to, day.date)
	return options[options.length - 1]
}

export const isNowInside = (day: DisplayableDeliveryDay) => {
	const from = dateWithTime(day.date, moment(day.time.from, "HH:mm"))
	from.subtract(day.min_minutes_before, "minutes")
	const to = dateWithTime(day.date, moment(day.time.to, "HH:mm"))
	to.subtract(day.min_minutes_before, "minutes")
	// "to" dovrebbe considerare anche "limit" e "limit_days_before" (ordina entro) ma in realtà viene disabilitata la selezione della fascia quindi non è indispensabile
	const now = todayDate()
	return now >= from && now <= to
}

export const addAsSoonAsPossible = (day: DisplayableDeliveryDay | null | undefined, items: TimeRange[]) => {

	if (!day) return []

	let ranges: TimeRange[] = []
	if (items.length && isNowInside(day)) {
		const firstRange = items[0]
		const asSoonAsPossible: TimeRange = { as_soon_as_possible: true, ...firstRange, min_minutes_before: day.min_minutes_before }
		ranges = [asSoonAsPossible].concat(items)
	} else {
		ranges = items
	}

	return ranges
}


export const dateIsContained = (restriction: PurchaseRestriction, _date: moment.Moment) => {
	const date = _date.format(SERVER_DATE_FORMAT)
	const from = moment(restriction.from).format(SERVER_DATE_FORMAT)
	const to = moment(restriction.to).format(SERVER_DATE_FORMAT)

	return (!restriction.from || date >= from) && (!restriction.to || date <= to)
}

export const isSoldOut = (item: Dish | MenuSection | ServerMenuSection, date: moment.Moment) => {
	return extractServerDate(item.last_sold_out) == date.format(SERVER_DATE_FORMAT)
}

export type DishOrderableResult = {
	from?: moment.Moment
	to?: moment.Moment
	disabledForToday?: boolean
} | null
/**
 * Checks if a dish is purchasable based on purchase_restrictions, NOT the purchasable field
 * @param dish 
 * @param date 
 */
export const itemOrderable = (item: Dish | MenuSection | ServerMenuSection, _date: moment.Moment | string, skipSoldOut?: boolean): [boolean, DishOrderableResult] => {
	const date = moment(_date)

	if (!skipSoldOut && isSoldOut(item, date)) {
		return [false, {
			disabledForToday: true
		}]
	}

	const { purchase_restrictions_state, purchase_restrictions } = item
	if (purchase_restrictions_state == RestrictionsState.Inactive || !purchase_restrictions) return [true, null]


	if (purchase_restrictions_state == RestrictionsState.PurchasableOnly) {
		//Purchasable restrictions active
		let firstAvailable: PurchaseRestriction | null = null
		for (const restriction of purchase_restrictions) {
			if (restriction.purchasable) {
				if (dateIsContained(restriction, date)) {
					return [true, null]
				} else if (firstAvailable) {
					if (restriction.from < firstAvailable.from) {
						firstAvailable = restriction
					}
				} else {
					firstAvailable = restriction
				}
			}
		}
		return [false, {
			from: firstAvailable?.from ? moment(firstAvailable.from) : undefined,
			to: firstAvailable?.to ? moment(firstAvailable.to) : undefined
		}]
	} else {
		//Not Purchasable restrictions active
		for (const restriction of purchase_restrictions) {
			if (restriction.purchasable == false && dateIsContained(restriction, date)) {
				return [false, {
					from: restriction.to ? moment(restriction.to).clone().add(1, "day") : undefined
				}]
			}
		}
		return [true, null]
	}
}

export const getManagerOrderableString = (item: Dish | MenuSection | ServerMenuSection, translate: TranslationFunction) => {
	//const result = ""

	if (item.purchase_restrictions_state == RestrictionsState.Inactive) return ""
	const purchasable = item.purchase_restrictions_state == RestrictionsState.PurchasableOnly
	const restrictions = (item.purchase_restrictions || []).filter(res => res.purchasable == purchasable)
	//TODO: utilizzare solo le restrizioni che hanno effetto oggi e nel futuro
	//TODO: gestire restrictions senza FROM e senza TO
	if (restrictions.length > 0) {
		const str = translate(purchasable ? "available" : "notAvailable") + ": " + restrictions.map(res => printRestrictionRange(res, translate, "D MMMM").toLowerCase()).join(", ")
		return str
	} else if (purchasable) {
		return translate("notAvailable")
	}
	/* if(restriction) {
	//purchase_restrictions.forEach((restriction) => {
		const from = moment(restriction.from).format(HUMAN_DATE_FORMAT)
		const to = moment(restriction.to).format(HUMAN_DATE_FORMAT)

		if(!restriction.purchasable) {
			if(from == to) {
				return translate("notAvailableSingle", { date: from })
			}
			return translate("notAvailableFromTo", { from, to })
		} else {
			if(from == to) {
				return translate("availableSingle", { date: from })
			}
			return translate("availableFromTo", { from, to })
		}
	} */
	return ""
	//})
}

export const getOrderableDishes = (sections: MenuSection[], date: moment.Moment) => {
	return (sections || []).reduce<Dish[]>((acc, section) => {
		if (isItemOrderable(section, date)) {
			(section.dishes || []).forEach((dish => {
				if (isItemOrderable(dish, date)) {
					acc.push(dish)
				}
			}))
		}
		return acc
	}, [])
}

export const notOrderableString = (result: DishOrderableResult, translate: TranslationFunction): string => {
	if (result?.disabledForToday) {
		return translate("soldOut")
	}
	if (result?.from) {
		const FORMAT = "D MMMM"
		const from = result.from.format(FORMAT)
		if (result.to) {
			const to = result.to.format(FORMAT)
			if (!result.from) {
				return translate("notAvailable")
			} else if (from == to) {
				return translate("availableSingle", { date: from })
			}
			return translate("availableFromTo", { from, to })
		} else return translate("availableFrom", { from })
	}
	return translate("notAvailable")
}

export const printRestrictionRange = (item: PurchaseRestriction, translate: TranslationFunction, dateFormat = HUMAN_DATE_FORMAT) => {
	const from = item.from ? moment(item.from).format(dateFormat) : null
	const to = item.to ? moment(item.to).format(dateFormat) : null

	if (from) {
		if (to) {
			if (to != from) {
				return translate("rangeFromTo", { from, to })
			} else {
				return from
			}
		} else {
			return translate("rangeFrom", { from })
		}
	} else if (to) {
		return translate("rangeTo", { to })
	}
	return ""
}

/**
 * Checks if a dish is purchasable based on purchase_restrictions, NOT the purchasable field
 * @param dish 
 * @param date 
 */
export const isItemOrderable = (item: Dish | MenuSection | ServerMenuSection, date: moment.Moment | string, skipSoldOut?: boolean) => {
	const [orderable, limits] = itemOrderable(item, date, skipSoldOut)
	/* if(limits) {
		console.log("Piatto disponibile dal " + limits.from + " al " + limits.to + ": " + orderable)
	} */
	return orderable
}

export const isDishOrderable = (item: Dish, date: moment.Moment | string) => {
	return isItemOrderable(item, date)
}

export const dishOrderable = (item: Dish, date: moment.Moment | string) => {
	return itemOrderable(item, date)
}

export const printOrderDate = (order: Order) => {
	return getMoment(order.for_date).format("dddd D MMMM")
}

export const printOrderTime = (order: Order, translate: TranslationFunction) => {
	const requestedDate = getMoment(order.for_date)
	const start = formatMomentTime(requestedDate)
	if(order.as_soon_as_possible) {
		return translate("soonAsPossible") + ` (~${start})`
	}
	if(order.time_range > 0) {
		const endTime = requestedDate.clone().add(order.time_range, "minutes")
		return `${start} - ${formatMomentTime(endTime)}`
	}
	return start
}

export const stripeErrorMessage = (code: string, decline_code: string) => {
	if(code == "cancelled" || code == "payment_intent_authentication_failure") {
		return "Autenticazione fallita o annullata dall'utente"
	}
	if (code == 'payment_intent_unexpected_state') {
		return "Pagamento non autorizzato"
	} else {
		const code = decline_code

		switch (code) {
			case 'insufficient_funds':
				return "La carta utilizzata non ha credito sufficiente per completare il pagamento"
			case 'generic_decline':
				return "La carta è stata rifiutata"
			case 'expired_card':
				return "La carta è scaduta"
			case 'incorrect_cvc':
				return "Codice di sicurezza errato"
			case 'invalid_cvc':
				return "Codice di sicurezza non valido"
			case 'incorrect_number':
				return "Numero della carta errato"
			case 'invalid_expiry_month':
				return "Mese di scadenza invalido"
			case 'invalid_expiry_year':
				return "Anno di scadenza invalido"
			default:
				return "Errore sconosciuto"
		}
	}
}