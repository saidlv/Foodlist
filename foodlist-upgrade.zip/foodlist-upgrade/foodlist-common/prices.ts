import { Coupon } from "@Models/Coupon"
import { DeliveryRoute } from "@Models/DeliveryRoute"
import { Discount } from "@Models/Discount"
import { ItemsMap } from "@Models/ItemsMap"
import { MenuDish } from "@Models/MenuSection"
import { Order } from "@Models/Order"
import { OrderInfo } from "@Models/OrderInfo"
import { OrderItem } from "@Models/OrderItem"
import { OrderRow } from "@Models/OrderRow"
import moment from "moment"
import { toNumber } from "./utils"

export const sumPrice = <T extends { price?: number }>(items: T[]) => {
	return items.reduce((acc, item) => {
		return acc + (item.price || 0)
	}, 0)
}

export const formatDecimal = (num: number | string | null | undefined, decimals: number, alwaysDecimals?: boolean) => {
	if(typeof num == "string") {
		num = parseFloat(num)
	}
	if (num || alwaysDecimals) {
		num = num ?? 0
		let digits = decimals
		if (!alwaysDecimals && num % 1 == 0) {
			digits = 0
		}
		return num.toFixed(digits).replace(".", ",")
	}
	return ""
}

export const formatPrice = (price?: number | null, alwaysDecimals?: boolean, withoutCurrency: boolean = false): string => {
	const priceStr = formatDecimal(price, 2, alwaysDecimals)
	if(priceStr) {
		return priceStr + (withoutCurrency ? "" : "€")
		//return price.toLocaleString(currentLocale(true), { maximumFractionDigits: digits, minimumFractionDigits: digits }) + (withoutCurrency ? "" : "€")
	}
	return ""
}

export const getDiscount = (price: number, discount: Discount, quantity?: number) => {
	const { percentage, amount} = discount
	if(percentage) {
		return price * amount / 100
	} else {
		return amount * (quantity || 1)
	}
}

const applyDiscounts = (price: number, disc: Discount[], order: OrderInfo | null, quantity?: number, forMenu?: boolean) => {
	const discounts = getDeliverySectionDiscounts(disc || [], order, forMenu)
	let res = price
	if(res) {
		discounts.forEach(disc => {
			res -= getDiscount(price, disc, quantity)
		})
	}
	return res
}

export const getDiscountedPrice = (item: MenuDish, order: OrderInfo) => {
	let price = item.price ?? 0
	if(price) {
		return applyDiscounts(price, item.discounts || [], order)
	}
	return price
}

export const getMenuDiscountedPrice = (item: MenuDish) => {
	 return (item.price ? applyDiscounts(item.price, item.discounts || [], null, 1, true) : item.price)
}

export const getOrderItemPriceWithoutDiscount = (item: OrderItem, customQuantity?: number) => {
	const optionsCost = (item.options || []).reduce((acc, option) => {
		acc += sumPrice(option.values || []) * (option.quantity || 1)
		return acc
	}, 0)
	return (customQuantity ?? item.quantity) * ((item.dish?.price ?? 0) + optionsCost)
}

export const getOrderItemPrice = (item: OrderItem, customQuantity: number, order: OrderInfo) => {
	const basePrice = getOrderItemPriceWithoutDiscount(item, customQuantity)
	return applyDiscounts(basePrice, item.dish?.discounts || [], order, customQuantity)
}

export const getOrderRowPriceWithoutDiscount = (item: OrderRow, customQta?: number) => {
	const optionsCost = (item.user_options || []).reduce((acc, option) => {
		acc += option.price * (option.quantity || 1)
		return acc
	}, 0)
	return (customQta || item.quantity) * (toNumber(item.price ?? 0) + optionsCost)
}

const SERVER_DATE_FORMAT = "YYYY-MM-DD"
export const getDeliverySectionDiscounts = (discounts: Discount[], order: OrderInfo | null, forMenu?: boolean) => {
	if(!order && !forMenu) console.warn("orderInfo not provided and not forOrders")
	const delivery_id = order?.delivery.id ?? -1
	return discounts.filter(item => {
		//const time = order.hour?.start ?? formatMomentTime(moment()) //TODO: controllare per il "prima possibile"
		//const selectedDate = dateWithTime(order.day.date, getMomentTime(time))
		const orderDate = order ? order.day.date.format(SERVER_DATE_FORMAT) : moment().format(SERVER_DATE_FORMAT)
		const from = moment(item.from).format(SERVER_DATE_FORMAT)
		const to = moment(item.to).format(SERVER_DATE_FORMAT)
		if(from <= orderDate && to >= orderDate) {
			if(forMenu) return item.displayable_on_menu
			else return (item.sections || []).indexOf(delivery_id) != -1
		}
		return false
	})
}

export const getActiveDiscount = (
	subtotal: number,
	restaurantDiscounts: Discount[],
	/** warn: null is allowed only because of OrderHistory */
	order: OrderInfo | null
): Discount | null => {
	let currentDiscount: Discount | null = null
	let currentMin = -1
	const discounts = order ? getDeliverySectionDiscounts(restaurantDiscounts, order) : restaurantDiscounts
	discounts.forEach(item => {
		if(subtotal >= item.minimum_required && item.minimum_required > currentMin) {
			currentDiscount = item
			currentMin = item.minimum_required
		}
	})
	return currentDiscount
}

export const getCartDiscount = (subtotal: number, restaurantDiscounts: Discount[], /** warn: null is allowed only because of OrderHistory */ order: OrderInfo | null) => {
	const discount = getActiveDiscount(subtotal, restaurantDiscounts, order)
	if(discount) {
		return getDiscount(subtotal, discount)
	}
	return 0
}

export const getOrderRowPrice = (item: OrderRow) => {
	const price = getOrderRowPriceWithoutDiscount(item); 
	let result = price;//DO NOT REMOVE THIS SEMICOLON
	(item.used_discounts || []).forEach((discount) => {
		result -= getDiscount(price, discount, item.quantity)
	})
	return result
}

/**
 * 
 * @param orderItems 
 * @param restaurant_id se gli elementi sono già filtrati passare -1
 */
export const getOrderAccumulators = (orderItems: OrderItem[] | undefined, order: OrderInfo) => {
	const results = (orderItems || []).reduce((acc, item) => {
		const num = acc[0] += item.quantity
		const amount = acc[1] += getOrderItemPrice(item, item.quantity, order)
		return [num, amount]
	}, [0, 0])
	return {
		count: results[0],
		amount: results[1]
	}
}

export const printDiscount = (item: { percentage: boolean, amount: number }) => {
	return item.percentage ? item.amount + "%" : formatPrice(item.amount)
}

export const getCouponAmount = (basePrice: number, order: OrderInfo) => {
	const { coupon } = order
	if(coupon) {
		if(coupon.minimum_required <= basePrice) {
			if(coupon.percentage) {
				return coupon.amount * basePrice / 100
			} else {
				return coupon.amount
			}
		}
	}
	return 0
}

export const getFinalPrice = (orderItems: OrderItem[] | undefined, order: OrderInfo, cartDiscounts: Discount[]) => {
	const { amount, count } = getOrderAccumulators(orderItems, order)
	const discount = getCartDiscount(amount, cartDiscounts, order)
	const couponBasePrice = amount - discount
	const couponAmount = getCouponAmount(couponBasePrice, order) 
	const deliveryPrice = order.delivery.price
	return {
		finalPrice: couponBasePrice + deliveryPrice - couponAmount,
		subtotal: amount,
		discount,
		deliveryPrice,
		couponAmount,
		itemsCount: count,
		couponMissingAmount: Math.max((order.coupon?.minimum_required || 0) - couponBasePrice, 0),
	}
}

export type PPDiscount = {
	discount: Discount,
	/** if undefined is valid for everything */
	deliverySections?: DeliveryRoute[]
	//timeValidityString: string
}
export const preprocessDiscounts = (discounts: Discount[], deliverySections: ItemsMap<DeliveryRoute>): any[] => {
	const results: PPDiscount[] = []
	discounts.forEach(discount => {
		const sections: DeliveryRoute[] = [];
		(discount.sections || []).forEach(section_id => {
			const section = deliverySections[section_id]
			if(section) {
				sections.push(section)
			}
		})
		if(sections.length > 0) { //se non è valido per nessuna sezione non lo mostro
			const res: PPDiscount = {
				discount,
			}
			if(sections.length < Object.keys(deliverySections).length) {
				res.deliverySections = sections
			}
			results.push(res)
		}
	})
	return results
}

export const printCouponDescription = (coupon: Coupon) => {
	return printDiscount(coupon) + " di sconto" + (coupon.minimum_required ? ` su un ordine di almeno ${formatPrice(coupon.minimum_required, false)}` : "")
}

export const orderSubTotal = (order: Order) => {
	const orderRows = order.order_rows;
	return orderRows.reduce((total, item) => {
		return total + getOrderRowPrice(item)
	}, 0)
}

export const orderTotal = (order: Order) => {
	const subtotal = orderSubTotal(order)
	const cartDiscount = getCartDiscount(subtotal, order.used_discounts || [], null)
	return subtotal + (order.delivery_price ?? 0) - cartDiscount - (order.coupon_discount || 0)
}

export const orderDishCount = (orderRows: OrderRow[]) => {
	return orderRows.reduce((count, item) => {
		return count + item.quantity
	}, 0)
}