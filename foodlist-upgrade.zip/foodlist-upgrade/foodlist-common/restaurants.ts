

export const extractNameFromHref = (href: string, siteOnly?: boolean) => {
	let str = href
	if(str.indexOf("://") != -1) {
		str = str.split("://")[1] ?? ""
	}
	str = str.split("/")[0] ?? ""
	const parts = str.split(".")
	const keep = parts.splice(-2, siteOnly ? 1 : 2).join(".")
	return keep
}