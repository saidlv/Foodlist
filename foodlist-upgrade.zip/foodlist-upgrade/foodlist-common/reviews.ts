import { OrderRow } from "@Models/OrderRow"
import { DishReview, OrderReview } from "@Models/Review"

export const getDishReviewRating = (review: DishReview | null | undefined) => {
	//const { review } = item
	//const review = item.review
	if(review) {
		return ((review.rating || 1) + (review.price_rating || 1)) / 2
	}
	return 0
}

export const getOrderReviewRating = (review: OrderReview | null | undefined) => {
	if(review) {
		return (review.rating_service + review.rating_punctuality) / 2
	}
	return 0
}