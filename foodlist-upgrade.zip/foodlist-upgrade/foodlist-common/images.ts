
type MapType = { [index: string]: string[] | undefined }
const imagesMap: MapType = {

	"bevande": ["bevande.jpg"],
	"colazione e brunch": ["colazione.jpg"],
	"cinese": ["cinese.jpg"],
	"giapponese": ["giapponese.jpg"],
	"dolci": ["dolci.jpg"],
	"gelato e yogurt": ["gelato.jpg"],
	"hamburger": ["hamburger-1.jpg", "hamburger-2.jpg", "hamburger-3.jpg", "hamburger-4.jpg", "hamburger-5.jpg"],
	"healthy": ["healthy.jpg"],
	"indiano": ["indiano.jpg"],
	"insalate": ["insalate.jpg"],
	"italiano": ["italiana.jpg", "italiana-2.jpg", "italiana-3.jpg", "italiana-4.jpg", "italiana-5.jpg", "italiana-6.jpg"],
	"kebab": ["kebab.jpg"],
	"pasta e riso": ["pasta-e-riso.jpg"],
	"piadina": ["piadina.jpg"],
	"pizza": ["pizza.jpg", "pizza-2.jpg", "pizza-3.jpg", "pizza-4.jpg"],
	"barbecue": ["barbecue.jpg", "barbecue-2.jpg", "barbecue-3.jpg"],
	"poke": ["poke.jpg"],
	"pesce": ["pesce.jpg", "pesce-2.jpg"],
	"sandwich": ["sandwich.jpg", "sandwich-2.jpg", "sandwich-3.jpg"],
	"sushi": ["sushi.jpg"],
	"default": ["default.jpg", "default-2.jpg"],
}

const getCategoryImage = (category: string, id: number) => {
	const images = imagesMap[category] || []
	const length = images.length
	if(length > 0) {
		if(length == 1) {
			return images[0]
		}
		const index = id % length
		return images[index]
	}
}

export const getCategoryDefaultImage = (categories: string[] | null | undefined, id: number) => {
	for(const item of categories || []) {
		const category = item.toLowerCase()
		const image = getCategoryImage(category, id)
		if(image) {
			return image
		}
	}
	return getCategoryImage("default", id)!
}
