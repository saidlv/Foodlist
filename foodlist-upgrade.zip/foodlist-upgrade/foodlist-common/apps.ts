import { ItemsMap } from "foodlist-common/Models/ItemsMap"

export type AppInfo = {
	id?: number
	ids?: number[]
	path: string
	link: string
}

export const apps: AppInfo[] = [{
	ids: [],
	path: "foodlist",
	link: "http://onelink.to/kfw7cg",
}, {
	id: 38404,
	path: "fratellipanza",
	link: "http://onelink.to/me9nd2"
}, {
	id: 432335,
	path: "starbox",
	link: "http://onelink.to/c4y6qz"
}, {
	id: 37941,
	path: "allevolte",
	link: "http://onelink.to/6snyga"
}, {
	id: 36560,
	path: "fred",
	link: "http://onelink.to/xj2h9e"
}, {
	id: 36552,
	path: "officinadelgusto",
	link: "http://onelink.to/vfexp6"
}, {
	id: 38783,
	path: "europizza",
	link: "http://onelink.to/wtjf7t"
}, {
	id: 163231,
	path: "cortiletto",
	link: "http://onelink.to/yr8b3g"
}, {
	id: 36133,
	path: "biffi",
	link: "http://onelink.to/gf4njv"
}, {
	id: 432336,
	path: "lume",
	link: "http://onelink.to/qsnjfy"
}, {
	id: 36135,
	path: "vesuvio",
	link: "http://onelink.to/dw5wdv"
}, {
	ids: [37049, 69780],
	path: "hanami",
	link: "http://onelink.to/9ckptc"
}]

export const mappedApps = apps.reduce<ItemsMap<AppInfo>>((acc, item) => {
	if(item.id) {
		acc[item.id.toString()] = item
	}
	if(item.ids) {
		item.ids.forEach(id => {
			acc[id] = item
		})
	}
	return acc
}, {})
