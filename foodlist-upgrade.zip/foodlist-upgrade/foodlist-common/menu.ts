import { Dish } from "@Models/Dish"
import { DishLink } from "@Models/DishOptions"
import { ItemsMap } from "@Models/ItemsMap"
import { DishOptionBeforeRequest } from "@Models/OrderItem"

export { getSectionName, filterSection, filterSectionName } from "./utils"

export const optionsValid = (values: ItemsMap<DishOptionBeforeRequest>, options: DishLink[]) => {
	for(const option of options) {
		const optVal = values[option.option_id ?? 0]?.values || []
		if(option.min_values > optVal.length) {
			return false
		}
	}
	return true
}

export const initialCanSubmit = (dish: Dish) => {
	return (dish.options_link || []).length == 0 || optionsValid({}, dish.options_link)
}

export const getDishSectionName = (dish: Dish | null | undefined) => {
	return dish?.section?.label_it
}