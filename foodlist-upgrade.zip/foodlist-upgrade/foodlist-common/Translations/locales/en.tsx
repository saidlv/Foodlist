export default {
	/* greeting: 'Hi!',

	login: "Login",
	register: "Sign up",
	pickADate: "Pick a date",
	cancel: "Cancel",
	confirm: "Confirm", */
};