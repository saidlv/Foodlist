export default {
	showCart: "Warenkorb anzeigen",
}