import it from "./locales/it"

export type I18nKey = keyof typeof it

export type TranslationFunction = (key: I18nKey, params?: {
	[key: string]: string | number
}) => string