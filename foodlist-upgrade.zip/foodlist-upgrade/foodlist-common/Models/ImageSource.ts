//import { ImageURISource } from 'react-native'
import { Source } from 'react-native-fast-image'

export type ImageSource = Source | number /* number | ImageURISource | ImageURISource[] */