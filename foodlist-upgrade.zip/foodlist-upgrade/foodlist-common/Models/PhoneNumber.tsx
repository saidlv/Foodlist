export type PhoneNumber = string //It's a string because only the hash is passed
