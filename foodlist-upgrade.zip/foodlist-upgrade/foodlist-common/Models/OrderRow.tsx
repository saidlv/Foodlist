import { Discount } from "./Discount";
import { Dish } from "./Dish";
import { Photo } from "./Photo";
import { DishReview } from "./Review";

export type UserOption = {
	description?: string
	id?: number
	option_label: string
	order_dish_id?: number
	price: number
	quantity: number
	value_label: string
}

export type OrderRow = {
	id?: number,
	quantity: number,
	price: number,
	dish_id: number,
	dish_section_name?: string
	dish_section_ordering?: number
	dish_name?: string
	/** @deprecated
	 * use dish_name and dish_section_name
	 * */
	dish?: Dish,
	notes?: string,
	created_at?: string,
	updated_at?: string,
	user_options?: UserOption[],
	used_discounts?: Discount[]

	review?: DishReview | null
}
