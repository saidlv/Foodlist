import { ImageSource } from './ImageSource'

export type CountryModel = {
	key: number,
	image: number | ImageSource,
	label: string,
	dialCode: string,
	iso2: string,
	description?: string
	/**
	 * nation priority to distinguish the main country (with priority 0) from smallest ones with the same country code (like Italy and Vatican City)
	 */
	priority: number
}
