export type Photo = {
	fullUrl?: string
	thumbUrl?: string
	fileName?: string
}
