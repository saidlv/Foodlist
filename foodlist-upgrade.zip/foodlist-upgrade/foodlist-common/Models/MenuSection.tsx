import { Discount } from "./Discount";
import { Dish } from "./Dish";
import { PurchaseRestriction, RestrictionsState } from "./PurchaseRestriction";
import { MenuSection as ServerMenuSection } from "./Menu"

export type MenuSectionOrdering = {
	id: number
	order: number
	section_id: number
	menu_id: number
	section: ServerMenuSection
}

export type MenuDish = Dish & {
	discounts?: Discount[]
}

export type MenuSection = {
	id: number
	name: string
	dishes: MenuDish[]
	purchase_restrictions?: PurchaseRestriction[]
	purchase_restrictions_state: RestrictionsState
	last_sold_out?: string
}