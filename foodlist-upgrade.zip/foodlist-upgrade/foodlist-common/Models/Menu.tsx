import { Restaurant } from "./Restaurant";
import { Dish } from './Dish'
import { MenuDiscounts } from "./Discount";
import { PurchaseRestriction, RestrictionsState } from "./PurchaseRestriction";

export type MenuSection = {
	id: number
	label_it: string
	dishes?: Dish[]
	purchase_restrictions?: PurchaseRestriction[]
	purchase_restrictions_state: RestrictionsState
	last_sold_out?: string
}

export type Menu = {
	id?: number,
	name?: string,
	restaurant_id?: number,
	restaurant?: Restaurant,
	pdf?: string
	ordered: {
		section_id: number
		section: MenuSection
	}[],
	discounts?: MenuDiscounts
}
