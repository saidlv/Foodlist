import { BookingHour } from "./BookingHour";
import { OrphanBookings } from "./OrphanBookings";
import { DeliveryRouteTime } from "./DeliveryRoute";
import { Order } from "./Order";

export type CalendarDay = {
	day: string
	hours: BookingHour[]
	orphan_bookings: OrphanBookings[]
}

export type CalendarDeliveryDay = {
	day: string
	hours: DeliveryRouteTime[]
	orphan_orders: Order[]
}