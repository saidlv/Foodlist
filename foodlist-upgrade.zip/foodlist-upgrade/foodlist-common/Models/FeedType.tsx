export type FeedType = "DISH" | "RESTAURANT"

export type FeedTypePrefix = "restaurants" | "dishes"

export type FeedTypeAnalytics = "restaurant" | "dish"
