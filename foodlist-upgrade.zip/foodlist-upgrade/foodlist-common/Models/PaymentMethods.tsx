export type PaymentMethods = "HandledByRestaurant" | "PayPal" | "CreditCard"
export enum PaymentMethodsId {
	Cash = 1,
	PayPal = 7,
	Card = 5
}