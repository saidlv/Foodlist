import { Coupon } from "./Coupon";
import { DisplayableDeliveryRoute, DisplayableDeliveryDay } from "./DeliveryRoute";
import { TimeRange } from "./TimeRange";
import { UserAddress } from "./UserAddress";

export type OrderInfo = {
	delivery: DisplayableDeliveryRoute
	day: DisplayableDeliveryDay
	hour?: TimeRange | null
	address?: UserAddress
	name: string
	coupon?: Coupon | null
}
