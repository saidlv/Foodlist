import { Photo } from "./Photo";
import { RawTime } from "./Time";
import { PaymentMethod } from "./PaymentMethod";
import { RestaurantCategory } from "./Category";
import { RestaurantStyle } from "./RestaurantStyle";
import { Occasion } from "./Occasion";
import { FoodPreference } from "./FoodPreference";
import { DishType } from "./DishType";
import { DeliveryRoute, DeliveryRouteDay } from "./DeliveryRoute";
import { BookingDay } from "./BookingDay";
import { RestaurantEmail } from "./RestaurantEmail";
import { MenuDiscounts } from "./Discount";
import { TimeRange } from "./TimeRange";
import moment from "moment";
import { Dish } from "./Dish";

export type Restaurant = {
	photos: Array<Photo>,
	id: number,
	name: string,
	proposed_name: string,
	full_address: string | null,
	address: string,
	house_number: string,
	city: string,
	cap: string,
	latitude: number,
	longitude: number,
	phone: string,
	phones?: string[]
	email: string,
	emails: RestaurantEmail[],
	website: string,
	description: string,
	take_away: boolean,
	delivery: boolean,
	for_kids: boolean,
	accepts_reservations: boolean,
	free_wifi: boolean,
	for_breakfast: boolean,
	dogs_allowed: boolean,
	handled: boolean,
	status_id: number,
	is_favourite: boolean,
	foodlist_rating?: number,
	dish_types?: DishType[],
	review_photos: Photo[],
	review_photo: Photo,
	written_logo?: Photo,
	g_photo?: Photo,
	reviews_count?: number,
	closed: boolean,
	restaurant_hours?: RawTime[],
	restaurant_categories?: RestaurantCategory[],
	restaurant_categories_string?: string,
	restaurant_payment_methods?: PaymentMethod[],
	restaurant_styles?: RestaurantStyle[],
	restaurant_occasions?: Occasion[],
	food_preferences?: FoodPreference[],
	services?: string[],
	distance?: number,
	delivery_sections: DeliveryRoute[] 
	booking_days: BookingDay[]

	menus?: {
		id: number
		pdf?: string
		name: string
	}[]

	google_rating?: string
	tripadvisor_rating?: string
	the_fork_rating?: string
	facebook_rating?: string

	google_number?: number
	tripadvisor_number?: number
	the_fork_number?: number
	facebook_number?: number

	google_link?: string
	tripadvisor_link?: string
	the_fork_link?: string
	facebook_link?: string

	foodlist_score?: number
	total_reviews_count?: number

	g_menu?: string[]
	g_bookings?: string[]
	g_orders?: string[]


	order_time_range: number
	order_time_span: number
	order_min_minutes_before: number

	discounts?: MenuDiscounts

	orders_permission?: boolean
	bookings_permission?: boolean

	available_delivery_sections?: DeliveryRoute[]
	available_booking_days?: BookingDay

	/**
	 * 2: FoodList
	 * 1: external platform
	 * 0: nothing
	 */
	bookings_platform_available?: 0 | 1 | 2
	/**
	 * 2: FoodList
	 * 1: external platform
	 * 0: nothing
	 */
	orders_platform_available?: 0 | 1 | 2

	forwarding?: boolean

	/** applied with preprocessRestaurantsForSearch */
	firstOrder?: TimeRange & { date: moment.Moment }
	/** applied with preprocessRestaurantsForSearch */
	sortableFirstDate?: string
	/** applied with preprocessRestaurantsForSearch */
	sortableMinMinutesBefore?: number
	/** applied with preprocessRestaurantsForSearch */
	firstOfExternalServices?: boolean
	/** applied with preprocessRestaurantsForSearch */
	firstOfPreorder?: boolean
	/** applied with preprocessRestaurantsForSearch */
	firstOfForwarding?: boolean
	/** applied with preprocessRestaurantsForSearch */
	firstForwardingPreorder?: boolean
	/** when searching, best 5 dishes */
	dishes?: Dish[]
}
