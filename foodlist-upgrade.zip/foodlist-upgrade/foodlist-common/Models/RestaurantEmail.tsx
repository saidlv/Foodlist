export type RestaurantEmail = {
  id: number
  email: string
  contact: boolean
  orders: boolean
  bookings: boolean
  created_at: string
  updated_at: string
  restaurant_id: number
}