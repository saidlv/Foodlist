import { PrintableItem } from "./PrintableItem";

export type DishRestriction = PrintableItem
