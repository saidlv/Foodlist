import { User } from "./User";
import { Review } from "./Review";

export type Comment = {
	id: number,
	content: string,
	created_at: Date,
	updated_at: Date
	review_id: number
	user_id: number,
	user: User,
	review_dish?: Review,
	review_restaurant?: Review
}
