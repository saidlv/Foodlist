import { Restaurant } from './Restaurant'
import { User } from './User'

export type BookingInfo = {
	id: number
	progressive?: number

	user_id: number
	ref_name: string
	for_date: string
	booking_options: {
		id: number, //id opzione
		value: number //id valore
	}[]
	people: number
	notes?: string

	/** only when received from server */
	restaurant?: Restaurant
	created_at?: string
	user?: User
	user_options?: {
		option_label: string
		option_value: string
	}[]

	ref_phone?: string
}
