import { HOUR_FORMAT, HOUR_FORMAT_WITH_SECONDS } from "@FoodListCommon/DateManager"
import { TranslationFunction } from "@FoodListCommon/Translations"
import moment from "moment"

export type TimeRange = {
	start: string,
	end?: string
	as_soon_as_possible?: boolean
	/** used as expected time */
	min_minutes_before?: number
}

export const expectedTimeString = (minutes: number) => {
	return ("~" + minutes + " min")
}

export const printTimeRange = (range: TimeRange | null | undefined) => {
	if(!range) return ""
	if(range.as_soon_as_possible) return "Appena possibile" + (range.min_minutes_before ? (" " + expectedTimeString(range.min_minutes_before)) : "")
	if(range.end) {
		return range.start + " - " + range.end
	}
	return range.start
}

export const getTime = (full_time: string) => {
	return moment(full_time, HOUR_FORMAT_WITH_SECONDS).format(HOUR_FORMAT)
}

export const printRange = (from: string, to: string | null | undefined) => {
	const _from = getTime(from)
	if(to) {
		const _to = getTime(to)
		return _from + " - " + _to
	}
	return _from
}

export const printRangeWithFromTo = (from: string, to: string, translateFun: TranslationFunction) => {
	const _from = getTime(from)
	const _to = getTime(to)
	return translateFun("fromTo", { from: _from, to: _to })
}