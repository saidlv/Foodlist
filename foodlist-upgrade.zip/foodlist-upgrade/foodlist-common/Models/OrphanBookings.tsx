import { Booking } from "./Booking";

export type OrphanBookings = {
	id?: number
	name: string
	bookings: Booking[]
}