export type ReviewRestType = "all" | "service" | "location" | "quality" | "price"
export type ReviewProfileType = "all" | "restaurants" | "dishes"
export type ReviewType = ReviewProfileType | ReviewRestType