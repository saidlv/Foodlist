export type Methods = "POST" | "GET" | "PUT" | "DELETE"
