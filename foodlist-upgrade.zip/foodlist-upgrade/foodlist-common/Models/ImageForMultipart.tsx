/* Risposta del picker */
export type ImageForMultipart = {
	uri: string,
	fileName: string,
	type: string
}

/* Risposta dopo il parsing con RNFetchBlob */
export type ImageForMultipartRNBlob = {
	name: string,
	filename: string,
	type: string,
	data: string,
}
