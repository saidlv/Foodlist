export type Address = {
	city: string,
	cap: string,
	address: string,
	house_number: string
}