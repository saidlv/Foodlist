export type Location = {
	latitude: number,
	longitude: number
	fromMap?: boolean
}
