export type UserAddress = {
	id: number,
	name: string, //nome assegnato all'indirizzo
	doorbell_name: string, //nome sul campanello
	address: string,
	house_number: string,
	intern: string,
	stairway: string,
	plan: string,
	city: string,
	cap: string,
	phone: string,
	default?: boolean,
	notes: string,
	created_at: string,
	updated_at: string
	latitude?: number
	longitude?: number
}
