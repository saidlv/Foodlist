import { ReviewType } from "./ReviewType";

export type ReviewsListActions = {
	callbackShouldReload: () => void,
	filterCallback: (type: ReviewType, rating: string) => void,
}
