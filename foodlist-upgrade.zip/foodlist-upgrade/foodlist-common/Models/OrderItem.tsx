import { Dish } from "./Dish";
import { OptionValue } from "./DishOptions";
import { MenuDish } from "./MenuSection";

export type DishOptionForRequest = {
	/** Id dell'opzione */
	id: number,
	/** Id del valore */
	values: number[]
	quantity?: number
}

export type DishOptionBeforeRequest = {
	id: number
	quantity?: number
	option_label: string
	values: OptionValue[]
}

export type OrderItem = {
	dish_id?: number,
	dish?: MenuDish
	quantity: number
	notes?: string
	local_id: number
	restaurant_id: number

	options?: DishOptionBeforeRequest[]
}

export type OrderItemForRequest = {
	dish_id?: number,
	quantity: number
	notes?: string
	options?: DishOptionForRequest[]
}