import { User } from './User'

type CommonNetworkTypes = {
	ignore?: boolean
	cached?: boolean
}

export type RequestResponse<T> = {
	data: (T & CommonNetworkTypes) | null,
	status: number,
	success: boolean,
	//user?: User,
	error?: string,
	default_error?: string
}

export type ServerResponse<T> = {
	response: T,
	error_code?: number
}

export type RequestResponseS<T> = RequestResponse<ServerResponse<T> | null>