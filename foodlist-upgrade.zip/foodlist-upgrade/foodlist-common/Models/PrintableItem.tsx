export interface PrintableItem {
	id: number
	label_it: string
	opposite?: boolean //TODO: probably not the best place
}
