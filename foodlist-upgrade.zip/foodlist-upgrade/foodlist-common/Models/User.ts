import { UserLevel } from "./UserLevel";
import { Photo } from "./Photo";
import { ReviewDistribution } from "./Review";
import { UserAddress } from "./UserAddress";
import { StripeCard } from "./StripeCard";

export type User = {
	id: number,
	email?: string,
	first_name?: string,
	last_name?: string,
	username: string,
	phone?: string,
	photo?: Photo | null,
	points?: number,
	country_code?: string,
	created_at?: string,
	updated_at?: string,
	date_of_birth?: string | null,
	gender?: string | number | null,
	password?: string,
	user_level_id?: number,
	verified?: boolean,
	user_level?: UserLevel,
	following_user?: boolean,
	is_followed?: boolean,
	addresses?: UserAddress[],
	reviews_distribution?: ReviewDistribution,

	following?: number,
	followers?: number,

	follower?: User,
	reviews_count?: number,
	stripe_cards?: StripeCard[],
}