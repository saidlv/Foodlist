export type ApiFilters = {
	latitude?: number,
	longitude?: number,
	name?: string,
	populate?: boolean,
	order_by?: string,
	max_price?: number,
	min_rating?: number,
	open_now?: boolean,
	take_away?: boolean,
	delivery?: boolean,
	for_kids?: boolean,
	reservations?: boolean,
	free_wifi?: boolean,
	for_breakfast?: boolean,
	dogs_allowed?: boolean,

}
