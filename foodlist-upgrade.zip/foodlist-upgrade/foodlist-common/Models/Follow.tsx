import { User } from "./User";

export type Follow = {
	id: number,
	follower_id: string,
	following_id: string,
	follower?: User,
	following?: User,
	updated_at?: string,
	created_at?: string
}
