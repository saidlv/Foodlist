import { Restaurant } from "./Restaurant";
import { User } from "./User";
import { UserBookingOption } from "./UserBookingOption";

export enum BookingStatus {
	Pending = 1,
	Accepted = 2,
	Rejected = 3,
	Canceled = 4,
	NotPresented = 5,
	Accommodated = 6,
	Completed = 7
}

export type Booking = {
	id: number,
	people: number
	/**
	 * **Not** UTC date, read with getMoment()
	 */
	for_date: string
	progressive: number
	notes?: string
	by_restaurant: boolean
	hour_name: string
	ref_name: string
	ref_phone: string
	user_id: number
	restaurant_id: number
	user_options?: UserBookingOption[]
	restaurant?: Restaurant,
	user?: User,
	hour_id?: number

	status_id: BookingStatus
	reject_reason?: string
	restaurant_notes?: string
}