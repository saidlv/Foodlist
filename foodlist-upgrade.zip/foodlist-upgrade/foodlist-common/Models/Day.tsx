import { Time } from "./Time";

export type Day = {
	day: string,
	isToday: boolean,
	times: Time[]
}
