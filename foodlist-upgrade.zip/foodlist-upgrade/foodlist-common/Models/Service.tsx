export type Service = {
	id: number,
	label_it: string,
  /*
   * key used inside the app to reference a service
   */
	key: string,
  /*
   * key used by server to reference a service
   */
	infoKey: string,
}