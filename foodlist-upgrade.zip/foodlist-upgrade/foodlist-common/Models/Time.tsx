export type Time = {
	timeString: string,
	from: string,
	to: string,
	isNow?: boolean
}

//Formato degli orari ritornati dal server
export type RawTime = {
	id: number,
	from: string,
	to: string,
	day: string,
	restaurant_id: number
	disabled?: boolean
}
