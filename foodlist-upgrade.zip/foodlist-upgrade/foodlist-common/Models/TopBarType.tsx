export type TopBarType = "Info" | "Auth" | "Comment" | "Modal"
