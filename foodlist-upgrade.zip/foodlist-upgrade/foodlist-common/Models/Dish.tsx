import { Menu } from "./Menu";
import { DishType } from "./DishType";
import { Photo } from "./Photo";
import { DishRestriction } from "./DishRestriction";
import { DishCategory } from "./Category";
import { FoodPreference } from "./FoodPreference";
import { DishLink, DishOption } from "./DishOptions";
import { Restaurant } from "./Restaurant";
import { PurchaseRestriction, RestrictionsState } from "./PurchaseRestriction";

export type DishOptionLink = (DishLink & {
	option?: DishOption
})

export type Dish = {
	id: number,
	name: string,
	available: boolean,
	proposed_name: string,
	priority: number,
	description: string,
	price?: number,
	proposed_price: number,
	created_at: Date,
	updated_at: Date,
	menu: Menu,
	dish_type: DishType,
	is_favourite?: boolean,
	reviews_rating?: number,
	photos?: Photo[],
	review_photo?: Photo,
	reviews_count?: number,
	review_photos?: Photo[],
	distance?: number, //not sure if exists
	dish_type_id?: number,
	dish_categories?: DishCategory[],
	dish_restrictions?: DishRestriction[],
	food_preferences?: FoodPreference[],
	purchasable?: boolean
	options_link: DishOptionLink[]
	purchase_restrictions?: PurchaseRestriction[]
	purchase_restrictions_state: RestrictionsState
	section?: {
		id: number
		label_it: string
		orderings?: {
			id: number,
			section_id: number,
			menu_id: number,
			order: number,
			menu?: {
				restaurant?: Restaurant
			}
		}[]
	}
	last_sold_out?: string
}
