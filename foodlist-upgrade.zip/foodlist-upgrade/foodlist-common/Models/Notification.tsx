import { User } from "./User"
import { Like } from "./Like"
import { Comment } from "./Comment"
import { Review } from "./Review"

export type NotificationType = "dish_review_like" | "dish_review_comment" | "dish_review_status" | "restaurant_review_like" |
	"restaurant_review_comment" | "restaurant_review_status" | "follower"

export type PostStatus = {
	id: number,
	label: string,
}

type CommonNotificationFields = {
	id: number,
	title: string,
	body: string,
	//type: NotificationType,
	pushable: boolean,
	created_at: string,
	updated_at: string,
	read_at: Date,
	user_id: number,
}

type DishReviewComment = {
	type: "dish_review_comment",
	review_id: number,
	comment_id: number,
	review_dish_comment: Comment
}

type RestaurantReviewComment = {
	type: "restaurant_review_comment",
	review_id: number,
	comment_id: number,
	review_restaurant_comment: Comment,
}

type DishReviewLike = {
	type: "dish_review_like",
	review_id: number,
	like_id: number,
	review_dish_like: Like
}

type RestaurantReviewLike = {
	type: "restaurant_review_like",
	review_id: number,
	like_id: number,
	review_restaurant_like: Like
}

type DishReviewStatus = {
	type: "dish_review_status",
	review_id: number,
	post_status_id: number,
	post_status: PostStatus,
	review_dish: Review,
}

type RestaurantReviewStatus = {
	type: "restaurant_review_status",
	review_id: number,
	post_status_id: number,
	post_status: PostStatus,
	review_restaurant: Review,
}

export type FollowerNotification = {
	type: "follower",
	follower_id: number,
	follower: User,
	user: User
}

export type UserOrderNotification = {
	type: "order_accepted" | "order_rejected" | "order_delivering" | "order_updated"
	order_id: number
}

export type Notification = CommonNotificationFields &
	(DishReviewComment | RestaurantReviewComment | DishReviewLike | RestaurantReviewLike | DishReviewStatus | RestaurantReviewStatus | FollowerNotification | UserOrderNotification)
