import { Dish } from './Dish'

export type Discount = {
  id: number
  name?: string
  amount: number
  percentage: boolean
  from: string
  to: string
  minimum_required: number
  foodlist: boolean
  created_at: string
  updated_at: string
  restaurant_id?: number
  dish_id?: number
	dish?: Dish
	/** if null is valid for every section */
	sections: number[] | null
	/** if true show the discount also for restaurant menu */
	displayable_on_menu: boolean
}

export type MenuDiscounts = {
	dish_discounts?: Discount[],
	restaurant_discounts?: Discount[]
}