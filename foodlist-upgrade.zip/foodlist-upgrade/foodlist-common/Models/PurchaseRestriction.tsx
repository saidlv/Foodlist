import { DeliveryRoute } from "./DeliveryRoute";
import { Dish } from "./Dish";
import { MenuSection } from "./Menu";

/**
 * Se c'è almeno una PurchaseRestriction con "purchasable" TRUE vengono esclusi tutti i giorni eccetto quelli indicati nelle restriction con purchasable TRUE, escludendo tutte quelle con purchasable a FALSE
 * Se tutte le PurchaseRestriction hanno campo "purchasable" FALSE i piatti sono disponibili per tutti i giorni tranne in quelli indicati
 */
export type PurchaseRestriction = {
	id?: number
	/** attualmente gli orari vengono ignorati e considera la data indicata a partire dalle 00:00 */
	from: moment.Moment | string | null
	/** attualmente gli orari vengono ignorati e considera la data indicata fino alle 23:59 */
	to: moment.Moment | string | null
	created_at?: string
	/** Se TRUE nel periodo indicato il piatto è disponibile, se FALSE non è disponibile */
	purchasable: boolean
	dish_id?: number
	dish?: Dish
	section_id?: number
	section?: MenuSection
	delivery_sections: (DeliveryRoute)[]

	//Cose che servono in locale
	new?: boolean
	local_id?: number
}

export enum RestrictionsState {
	Inactive = 0,
	NotPurchasableOnly = -1,
	PurchasableOnly = 1
}