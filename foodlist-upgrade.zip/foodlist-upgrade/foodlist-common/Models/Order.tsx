import { UserAddress } from "./UserAddress"
import { User } from "./User"
import { OrderRow } from "./OrderRow"
import { Restaurant } from "./Restaurant"
import { DeliveryRoute } from "./DeliveryRoute"
import { Discount } from "./Discount"
import { OrderReview } from "./Review"

export enum OrderType {
	Delivery = 1,
	Takeaway = 0
}

export enum OrderStatus {
	Pending = 1,
	Accepted = 2,
	Rejected = 3,
	Delivering = 4,
	Delivered = 5
}

export type Order = {
	progressive: number
	id?: number,
	/** not utc, read with DateManager.getMoment */
	for_date: string,
	order_type: OrderType,
	notes?: string,
	created_at?: string,
	updated_at?: string,
	user_address_id: number,
	user_address?: UserAddress,
	restaurant_id: number,
	user_id?: number,
	user?: User,
	status_id?: OrderStatus,
	order_rows: OrderRow[],
	restaurant?: Restaurant,
	ref_name?: string
	/** not utc, read with DateManager.getMoment */
	delivery_time?: string
	delivery_section: DeliveryRoute
	delivery_price?: number
	payment_method_id: number
	time_range: number
	used_discounts?: Discount[]
	as_soon_as_possible: boolean
	ref_phone: string
	/** UTC date, read with moment(accepted_date) */
	accepted_date?: string
	/** UTC date, read with moment(in_delivery_date) */
	in_delivery_date?: string
	/** UTC date, read with moment(completed_date) */
	completed_date?: string

	reject_reason?: string

	new_client: boolean
	usual_client: boolean

	doorbell_name?: string
	address?: string
	house_number?: string
	city?: string
	cap?: string
	address_notes?: string

	review?: OrderReview

	paid?: boolean

	delivery_section_name?: string
	coupon_id?: number
	coupon_name?: string
	coupon_discount?: number
	nonce?: string
	forward_ref?: string
}
