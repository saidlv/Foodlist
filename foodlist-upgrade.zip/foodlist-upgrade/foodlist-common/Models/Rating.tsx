export type Rating = {

	rating?: number,
	roundedRating?: number,
	serviceRating: number,
	qualityRating: number,
	locationRating: number,
	priceRating: number,

}

export type RatingForRequest = {
	rating_service: number,
	//rating_quality: number,
	rating_location?: number,
	//rating_price: number,
	rating_punctuality?: number,

	from_home: boolean
	order_id?: number
	delta_time?: number
}
