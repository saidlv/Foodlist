export type Empty = {
	[index: string]: undefined
}
