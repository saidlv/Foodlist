export type City = {
	latitude: number
	longitude: number
	id: number
	region_name_long: string
	region_name: string
	parent_region_name_long: string
	postcode: string
	province: string
}
