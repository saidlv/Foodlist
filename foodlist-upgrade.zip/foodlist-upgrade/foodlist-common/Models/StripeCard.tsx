export type CardBrand = "amex" | "cartes_bancaires" | "diners_club" | "discover" | "jcb" | "mastercard" | "visa" | "unionpay"

export type StripeCard = {
	id: string,
	card: {
		last4: string,
		brand: CardBrand,
		country: string,
		exp_month: number,
		exp_year: number,
	}
}