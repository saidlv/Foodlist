import { User } from "./User";

export type CouponData = {
	id?: number
	name: string
	description: string
	amount: number
	percentage: boolean
	from: string | null
	to: string | null
	minimum_required: number
	by_foodlist: boolean,
	by_admin?: boolean
}

export type Coupon = CouponData & {
	user_id: number
	user?: User
}