export type NewDish = {
	name: string
	price: string
	category: string
}
