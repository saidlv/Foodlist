import { PrintableItem } from "./PrintableItem";

export type UserLevel = PrintableItem & {
	from: number,
	to: number
}
