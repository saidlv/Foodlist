/**
 * To read all values you can use getMapValues or mapToArray from @FoodListCommon/utils
 */
export type ItemsMap<T> = {
	[index: string]: T | undefined
}

export const mapByKey = <T extends {}>(options: T[], key: keyof T): ItemsMap<T> => {
	return options.reduce<ItemsMap<T>>((accumulator, item) => {
		const _key = item[key]
		if (_key !== null && _key !== undefined) {
			// @ts-ignore
			accumulator[_key?.toString()] = item
		}
		return accumulator
	}, {})
}

export const groupByKey = <T extends {}>(
	options: T[],
	/** key or value extractor */
	key: (string & keyof T) | ((option: T) => string)
): ItemsMap<T[]> => {
	return options.reduce<ItemsMap<T[]>>((acc, item) => {
		let _key
		if(typeof key == "function") {
			_key = key(item)
		} else {
			// @ts-ignore
			_key = item[key]?.toString()
		} 
		if(_key !== null && _key !== undefined) {
			if(!acc[_key]) {
				acc[_key] = []
			}
			// @ts-ignore
			acc[_key].push(item)
		}
		return acc
	}, {})
}

export const arrayGroupByKey =  <T extends {}>(
	options: T[],
	/** key or value extractor */
	groupKey: (string & keyof T) | ((option: T) => string)
): { key: string, items: T[] }[] => {
	const res = groupByKey(options, groupKey)
	return Object.keys(res).map(key => ({
		key,
		items: res[key] || [],
	}))
}
