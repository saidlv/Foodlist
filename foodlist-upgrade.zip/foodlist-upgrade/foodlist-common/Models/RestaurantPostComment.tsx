import { User } from "./User";

export type RestaurantPostComment = {
	id: number,
	created_at: string,
	updated_at: string,
	restaurant_post_id: number,
	user_id: number,
	user: User
}
