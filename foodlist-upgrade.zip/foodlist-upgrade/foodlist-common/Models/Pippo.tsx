export type Pippo = any
