import { PrintableItem } from "./PrintableItem";

export type Occasion = PrintableItem
