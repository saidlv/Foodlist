import { PrintableItem } from "./PrintableItem";

export type RestaurantStyle = PrintableItem