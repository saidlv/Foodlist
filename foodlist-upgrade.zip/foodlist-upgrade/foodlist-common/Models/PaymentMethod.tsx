import { PrintableItem } from "./PrintableItem";

export type PaymentMethod = PrintableItem

export const PaymentType = {
	PayPal: 7,
	Cash: 1
}