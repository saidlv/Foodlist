export type BookingOption = {
	id: number
	label_it: string
	values: BookingOptionValue[]
}

export type LocalBookingOption = {
	id?: number
	local_id: string
	label_it: string
	values: BookingOptionValue[]
}

export type BookingOptionValue = {
	id: number
	value: string
}

export type NewBookingOptionValue = { local_id?: string } & (BookingOptionValue | {
	id?: number
	local_id: string
	value: string
})

export type NewBookingOption = Omit<(LocalBookingOption | BookingOption), "values"> & {
	id?: number
	values: NewBookingOptionValue[]
	local_id?: string
}