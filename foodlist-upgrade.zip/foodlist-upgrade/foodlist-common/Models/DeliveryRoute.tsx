import { City } from "./City"
import { StringDate } from "./StringDate"

export type DeliveryRouteTime = {
	id: number,
	limit?: string | null //time
	limit_days_before?: number 
	from: StringDate //date 11:00:00
	to: StringDate //date 13:00:00
	enabled: boolean
	was_enabled: boolean
	name?: string
	last_close_order?: StringDate //date
	min_minutes_before?: number
}

export type DeliveryRouteDay = {
	day: number // 0..6
	enabled: boolean
	hours: DeliveryRouteTime[]
	min_minutes_before?: number
}

export type DeliveryRoute = {
	id?: number,
	name: string
	max_days_before: number,
	description: string
	enabled: boolean
	active: boolean
	take_away?: boolean
	days: DeliveryRouteDay[]
	price?: number
	min_price?: number
	time_range?: number
	time_span?: number
	show_range: boolean
	min_minutes_before?: number
	radius?: number
	cities?: City[]
	caps?: (number | string)[]
}

export type DisplayableDeliveryDay = {
	weekday: string,
	dayIndex: number,
	name?: string
	time: DeliveryRouteTime
	orderClosed: boolean
	date: moment.Moment
	time_range: number
	time_span: number
	show_range: boolean
	min_minutes_before: number
}

export type DisplayableDeliveryRoute = {
	id?: number,
	name: string
	description: string
	isTakeaway?: boolean
	days: DisplayableDeliveryDay[]
	isActiveToday?: boolean
	price: number
	minPrice: number
}

export type DisplayableRoutes = {
	takeaway: DisplayableDeliveryRoute[],
	delivery: DisplayableDeliveryRoute[],
	allRoutes: DisplayableDeliveryRoute[]
}