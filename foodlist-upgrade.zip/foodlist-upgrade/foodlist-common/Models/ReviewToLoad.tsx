import { FeedType } from "./FeedType";

export type ReviewToLoad = {
	id: number
	feed_type: FeedType
	dish?: {
		id: number
	}
	restaurant?: {
		id: number
	}
}
