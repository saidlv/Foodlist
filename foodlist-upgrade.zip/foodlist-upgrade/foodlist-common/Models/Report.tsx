import { Restaurant } from "./Restaurant";

export type Report = {
	id: number
	document: string
	restaurant_id: number
	created_at: string
	updated_at: string
	paid: boolean
	restaurant?: Restaurant
}