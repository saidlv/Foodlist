import { Dish } from "./Dish";
import { Restaurant } from "./Restaurant";

export type Favourite = {
	id: number,
	created_at: string,
	updated_at: string,
	dish_id?: number,
	restaurant_id?: number,
	user_id: number,
	dish?: Dish,
	restaurant?: Restaurant,
}
