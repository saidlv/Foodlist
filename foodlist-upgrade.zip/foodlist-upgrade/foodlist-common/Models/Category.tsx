import { PrintableItem } from "./PrintableItem"

export type Category = PrintableItem

export type DishCategory = Category

export type RestaurantCategory = Category & {
	ethnic?: boolean
}

export type GenericCategory = DishCategory | RestaurantCategory
