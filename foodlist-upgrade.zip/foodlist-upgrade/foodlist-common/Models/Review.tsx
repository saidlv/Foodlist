import { Like } from "./Like";
import { Comment } from "./Comment";
import { ImageSource } from "./ImageSource";
import { User } from "./User";
import { Dish } from "./Dish";
import { Restaurant } from './Restaurant';
import { Photo } from "./Photo";
import { FeedType } from "./FeedType";
import { DishType } from "./DishType";
import { ImageForMultipart } from "./ImageForMultipart";
import { ReviewToLoad } from "./ReviewToLoad";

export enum ReviewStatus {
	Pending = 1,
	Approved = 2,
	Rejected = 3,
}

export type Review = {
	id: number,
	user_id: number,
	userImage?: Photo,
	name?: string,
	content: string,
	rating: number,
	rating_service?: number,
	/** @deprecated */
	rating_quality?: number,
	rating_location: number,
	/** @deprecated */
	rating_price?: number,
	rating_punctuality?: number,
	delta_time?: number

	feed_type: FeedType,
	likes: Array<Like>,
	comments: Array<Comment>,
	thumbReviewImage?: ImageSource,
	reviewImage?: ImageSource,
	isDish: boolean,
	user: User,
	dish_id: number,
	restaurant_id: number,
	full_address: string,
	distance?: number,
	dish?: Dish,
	restaurant?: Restaurant,
	price?: number,
	photos?: Photo[]

	order_id?: number
	booking_id?: number
	post_status_id: ReviewStatus
	content_updated_at: string,
	created_at: string,
	updated_at: string,

	previous_approved?: boolean
}

export type DishReview = {
	content?: string
	price_rating: number | null
	rating: number
	photos?: Photo[]

	id: number
	dish_id: number
	order_row_id?: number

	//server fields
	content_updated_at?: string,
	created_at?: string,

	likes?: Array<Like>,
	comments?: Array<Comment>,
}

export type OrderReview = {
	content?: string
	rating_service: number,
	rating_punctuality: number,
	from_home: boolean,
	delta_time: number,
	//photos?: Photo[]

	id: number
	order_id: number

	//server fields
	content_updated_at?: string,
	created_at?: string,
}

export const isFullReview = (review: Review | ReviewToLoad): boolean => {
	return 'content' in review;
}

export type SuggestReview = {
	dishName: string,
	category: string,
	price: string,
	rating_quality: number,
	rating_price: number,
	content: string,
	restaurant_id: number
	photo: ImageForMultipart | null
}

export type ReviewDistribution = { //Il server lo ritorna così come oggetto, non come array
	1: number,
	2: number,
	3: number,
	4: number,
	5: number
}
