export type DishType = {
	id?: number,
	name?: string,
	label_it?: string,
}