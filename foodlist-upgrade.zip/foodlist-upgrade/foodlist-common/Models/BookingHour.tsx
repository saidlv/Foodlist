import { Booking } from "./Booking";

export type BookingHour = {
	id: number
	name: string
	from: string
	to: string
	max_people: number
	last_close_bookings?: string | null
	enabled: boolean
	min_minutes_before?: number
	description?: string
	max_days_before: number
	max_table?: number
	day_id: number
	real_from?: string
	real_to?: string
	free_seats?: number
	bookings?: Booking
}

export type EnhancedBookingHour = (BookingHour & {
	num_hours: number,
	start_from: moment.Moment,
	can_order: boolean
})
