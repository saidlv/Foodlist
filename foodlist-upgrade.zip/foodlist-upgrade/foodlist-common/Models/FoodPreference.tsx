import { PrintableItem } from "./PrintableItem";

export type FoodPreference = PrintableItem & {
	filter_only_negative: boolean,
	key: string,
	opposite_label_it: string,
}
