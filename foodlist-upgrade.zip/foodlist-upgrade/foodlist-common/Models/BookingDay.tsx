import { BookingHour } from "./BookingHour";

export type BookingDay = {
	id: number
	day: number,
	enabled: boolean,
	created_at: string
	updated_at: string,
	restaurant_id: number
	hours?: BookingHour[]
}