import { User } from "./User";
import { Review } from "./Review";

export type Like = {
	id: number,
	review_id: number,
	user_id: number,
	user: User,
	following_user: boolean,
	review_dish?: Review,
	review_restaurant?: Review
}

export type RestaurantPostLike = {
	id: number,
	created_at: string,
	updated_at: string,
	restaurant_post_id: number,
	user_id: number,
	user: User,
	following_user: boolean
}
