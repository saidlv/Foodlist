import { Photo } from "./Photo"

export type OptionValue = {
	label: string
	description?: string
	multiple?: boolean
	/** default 0 */
	price?: number
	photo?: Photo
	id?: number
	option_id?: number
}

export type DishLink = {
	id?: number
	dish_id: number
	option_id: number
	max_values: number
	min_values: number
}

export type DishData = {
	dish_data?: {
		name: string
		section_name: string
	}
}

export type DishOption = {
	label: string
	description?: string
	values: OptionValue[]
	id: number
	dish_links: (DishLink & DishData)[]
}