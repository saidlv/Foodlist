import { Photo } from "./Photo";

export type RestaurantPost = {
	id: number,
	content: string,
	photo: Photo,
	created_at: string,
	updated_at: string,
	restaurant_id: number,	
}
