/**
 * The type obtained accepts the keys of Item that extends the type FilterType
 * 
 * For example:
 * type Item = { name: string, id: number, pippo: string }
 * FilteredKeys<Item, string> = "name" | "pippo"
 */
export type FilteredKeys<Item, FilterType> = {
	[Key in keyof Item]: Item[Key] extends FilterType ? Key : never
}[keyof Item]