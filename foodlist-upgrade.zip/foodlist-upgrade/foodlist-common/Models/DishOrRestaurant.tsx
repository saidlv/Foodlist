import { Restaurant } from "./Restaurant";
import { Dish } from "./Dish";

export type DishOrRestaurant = {
	restaurant?: Restaurant
	dish?: Dish
} & ({
	restaurant: Restaurant
} | {
	dish: Dish
})