const colors = {
	foodlist: "#FF6907",
	darkFoodlist: "#CD5405",
	red: '#d1202f',
	greyIcon: "#7c7c7c",
	greyText: '#9b9b9b',
	greyTextSubMenu: '#bababa',
	greyInfoText: '#7c7c7c',
	greyBorder: '#eaeaea',
	greyArrow: '#b6b6b6',
	devilGrey: "#666",
	starColor: '#F5A623',
	lipstick: "#d1202f",
	darkRed: "rgb(176,30,44)",
	white: "#ffffff",
	blackOverlay: "rgba(0, 0, 0, 0.82)",
	overlayColor: "rgba(0, 0, 0, 0.2)",
	link: "#0e1b37",
	shadowColor: "#00000020",
	separator: "#ebebeb",
	transparent: "#ffffff00",
	black: "#000000",
	dark: "#111111",
	blackText: '#0e1b37',
	lightGrey: '#f1f3f5',
	lighterGrey: '#f4f6f8',
	darkGreyText: '#4a4a4a',
	darkGreyBorder: '#dddfe1',
	timesGreyBorder: '#ebebeb',
	orangeBar: '#ef9118',
	yellow: "#edcd00",
	green: '#7ed321',
	darkGreen: '#509000',
	inactiveGrey: '#e5e5e5',
	greyBox: 'rgba(236, 236, 236, 0.35)',
	darkBlue: "#19487C",
	blueMenu: '#276fbf',
	/**
	 * Returns the given color with the alpha specified
	 * @param color hex color without alpha
	 * @param alpha decimal value in range 0 1
	 */
	withAlpha: (color: string, alpha: number) => {
		return color.concat(hexAlpha(alpha))
	}
}

let hexAlpha = (alpha: number): string => {
	return ('00' + Math.round(255 * alpha).toString(16)).substr(-2)
}

export default colors