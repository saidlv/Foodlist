import { BookingHour } from "@Models/BookingHour"
import { DeliveryRoute, DisplayableDeliveryDay } from "@Models/DeliveryRoute"
import { Restaurant } from "@Models/Restaurant"
import { TimeRange } from "@Models/TimeRange"
import moment from "moment"
import { momentDifference, SERVER_DATE_FORMAT, todayIndex } from "./DateManager"
import { LocalizedOrderFunctions } from "./OrderHelper"
import { getTimeOptionsFromDisplayable } from "./orders"
import { TranslationFunction } from "./Translations"
import { compareValues, toFixed } from "./utils"

export const getFirstTimeRange = (displayableDays: DisplayableDeliveryDay[] | undefined): [TimeRange | null, DisplayableDeliveryDay | null] => {
	//let first: TimeRange | null = null
	for(const displayableDay of displayableDays || []) {
		const options =  getTimeOptionsFromDisplayable(displayableDay)
		//console.log(displayableDay.name, options[0])
		if(options.length >= 1) {
			return [options[0], displayableDay]
		}
	}
	return [null, null]
}

/**
 * 
 * @param item
 * @param translateFunc i18n function, on
 */
export const getDisplayInfos = (item: Restaurant, translateFunc: TranslationFunction): {
	section?: DeliveryRoute | null,
	displayableDays?: DisplayableDeliveryDay[],
	date: moment.Moment,
	booking?: BookingHour | null
} => {
	const section = item.available_delivery_sections?.[0] as DeliveryRoute | null
	//console.log("section", section, item)
	//console.log(item.name, item.available_delivery_sections)
	const day = section?.days?.[0]
	const hours = day?.hours || []

	const orderHelper = new LocalizedOrderFunctions(translateFunc)
	const displayableDays = (day && section) ? hours.map((_, index) => orderHelper.getDisplayableDay(day, section, undefined, index)) : undefined

	const bookings = item.available_booking_days
	const booking = bookings?.hours?.[0] || null

	const dayIndex = day?.day || bookings?.day || 0
	//console.log("todayIndex", todayIndex(), dayIndex)
	const date = moment().add((7 + dayIndex - todayIndex()) % 7 , "days") 
	return {section, displayableDays, date, booking}
}

/**
 * This method adds to restaurants the fields (sortableFirstDate and sortableMinMinutesBefore) that can be used to sort them by first available time
 * @param items restaurants to fill
 * @returns original items in the original order (you can use the original array)
 */
export const preprocessRestaurantsForSearch = (items: Restaurant[]) => {
	for(let item of items) {
		const { displayableDays, date, booking } = getDisplayInfos(item, () => "") //getDisplayInfos uses translate only for the weekday field of displayableDays, which is not important here
		if(displayableDays) {
			const [first, orderDay] = getFirstTimeRange(displayableDays)
			if(first) {
				item.sortableFirstDate = date.format(SERVER_DATE_FORMAT) + " " + first?.start
				item.sortableMinMinutesBefore = orderDay?.min_minutes_before
			}
		} else if(booking) {
			item.sortableFirstDate = date.format(SERVER_DATE_FORMAT) + " " + booking.from
		}
	}
	return items
}

/**
 * Sort restaurant using fields added by preprocessRestaurantsForSearch
 * Make sure to call that method before this one
 */
const sortList = (list: Restaurant[], forwardingOnly?: boolean) => {
	return list.sort((a, b) => {
		return compareValues(a.forwarding, b.forwarding) || (forwardingOnly ? 0 : (compareValues(a.sortableFirstDate, b.sortableFirstDate) || compareValues(a.sortableMinMinutesBefore, b.sortableMinMinutesBefore)))
	})
}
/**
 * Sorts foodlist items and separates into "available now (foodlist)", "available now (forwarding)", "preorder (foodlist)", "preorder (forwarding)".
 * Adds **firstOfForwarding**, **firstOfPreorder** and **firstForwardingPreorder** fields to the first applicable items (if present)
 */
const sortOrderItems = (items: Restaurant[], { sortByTime, delayMinutes }: Options) => {
	let { activeItems, preorderItems } = items.reduce((acc, item) => {
		const currentSearchTime = moment().add(delayMinutes || 0, "minutes")
		const diff = momentDifference(moment(item.sortableFirstDate), currentSearchTime, "minutes")
		//console.log("diff", item.sortableFirstDate, diff)
		if(!!item.sortableFirstDate && diff < 120) {
			acc.activeItems.push(item)
		} else {
			acc.preorderItems.push(item)
		}
		return acc
	}, { activeItems: [] as Restaurant[], preorderItems: [] as Restaurant[] })

	activeItems = sortList(activeItems, !sortByTime)
	const firstForwarding = activeItems.find(item => item.forwarding)
	if(firstForwarding) {
		firstForwarding.firstOfForwarding = true
	}
	preorderItems = sortList(preorderItems, !sortByTime)

	const preorderFirst = preorderItems[0]
	if(preorderFirst) {
		preorderFirst.firstOfPreorder = true
	}

	const firstForwardingPreorder = preorderItems.find(item => item.forwarding)
	if(firstForwardingPreorder) {
		firstForwardingPreorder.firstForwardingPreorder = true
		firstForwardingPreorder.firstOfPreorder = false
	}

	return activeItems.concat(preorderItems)
}

const sortFoodListItems = (items: Restaurant[], options: Options) => {
	if(options.forBookings) {
		if(options.sortByTime) {
			return sortList(items)
		} else {
			return items
		}
	} else {
		return sortOrderItems(items, options)
	}
}

type Options = {
	/**
	 * set to true if searchMode = "bookings"
	 */
	forBookings: boolean

	/**
	 * if true sort by first available inside each section, if false original order will be maintained
	 */
	sortByTime: boolean

	/**
	 * Use this param to set the delay to use when comparing order dates with current time (if the timezone is different)
	 */
	delayMinutes?: number
}
/**
 * This function process restaurants to separate into different sections: available now, preorder, external services.
 * The result is a single array sorted by section.
 *
 * To find the first element of a section this function adds the fields  **firstOfForwarding**, **firstOfPreorder**, **firstForwardingPreorder** and **firstOfExternalServices**.
 * @param data restaurants to sort/preprocess
 * @param options additional options
*/
export const sortAndPProRestaurants = (data: Restaurant[] | undefined, options: Options): Restaurant[] => {
	let items = data || []
	const firstExternal = items.findIndex(item => {
		if(item.orders_platform_available != 2 && item.bookings_platform_available != 2) {
			return true
		}
		return false
	})
	if(firstExternal == -1) {
		const pre = preprocessRestaurantsForSearch(items)
		return sortFoodListItems(pre, options)
	} else {
		const foodlistItems = items.slice(0, firstExternal)
		const externalItems = items.slice(firstExternal)
		if(externalItems[0]) {
			externalItems[0].firstOfExternalServices = true
		}
		const pre = preprocessRestaurantsForSearch(foodlistItems)
		return sortFoodListItems(pre, options).concat(externalItems)
	}
}
