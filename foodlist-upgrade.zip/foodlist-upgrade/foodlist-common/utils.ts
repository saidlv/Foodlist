import { Dish } from "@Models/Dish"
import { ItemsMap } from "@Models/ItemsMap"
import { MenuSection } from '@FoodListCommon/Models/MenuSection'
import { MenuSection as ServerMenuSection } from '@FoodListCommon/Models/Menu'
export { default as colors } from "./colors"

export const removeItem = <T extends {}> (items: T[], item: T) => {
	const _items = items.concat()
	const index = _items.indexOf(item)
	if(index >= 0) {
		_items.splice(index, 1)
	}
	return _items
}

export const removeItemByKey = <T extends {}> (items: T[], key: keyof T, value: any) => {
	const _items = items.concat()
	const index = _items.findIndex(item => item[key] == value)
	if(index >= 0) {
		_items.splice(index, 1)
	}
	return _items
}

export const removeItemById = <T extends { id: number }> (items: T[], id: number) => {
	return removeItemByKey(items, "id", id)
}

export const momentFromDateAndTime = (date: moment.Moment, time: moment.Moment) => {
	const _moment = date.clone()
	_moment.set("hours", time.hours())
	_moment.set("minutes", time.minutes())
	return _moment
}

export const buildArray = <T extends object>(size: number, constructFunc: (index: number) => T): T[] => {
	return Array(size).fill(0).map((_, index) => constructFunc(index))
}

export const compareValues = <T> (first: T, second: T) => {
	if(first < second) {
		return -1
	}
	if(first > second) {
		return 1
	}
	return 0
}

export const safeParse = (stringified: string | null | undefined) => {
	let parsed
	try {
		parsed = stringified ? JSON.parse(stringified) : {}
	} catch {
		parsed = {}
	}
	return parsed
}
export const normalize = (str: string | null | undefined) => {
	return (str || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim()
}

export const toUpperLowerCase = (item: string) => {
	if(!item) return ""
	if(item.length == 0) return ""
	return item[0].toUpperCase() + item.substr(1)
}

export const mapToArray = <T>(map: ItemsMap<T>) => {
	return Object.keys(map).map(key => ({
		key,
		value: map[key]
	})) as {
		key: string,
		value: T
	}[]
}

export const getMapValues = <T>(map: ItemsMap<T>) => {
	return Object.values(map) as T[]
}

export const joinArrays = <T>(array: T[][]) => {
	return ([] as T[]).concat(...array)
}

export const joinMappedArrays = <T>(map: ItemsMap<T[]>) => {
	return joinArrays(getMapValues(map))
}

/**
 * 
 * WARN: last array can have different size
 * @param items 
 * @param numPerGroup 
 */
export const groupItems = <T>(items: T[], numPerGroup: number) => {
	return items.reduce<T[][]>((acc, item, index) => {
		if(index % numPerGroup == 0) {
			acc.push([
				item
			])
		} else {
			const currentArray = acc[acc.length - 1]
			currentArray.push(item)
		}
		return acc
	}, [])
}

export const marryItems = <T>(items: T[]) => {
	return groupItems(items, 2)
}

const dishFilter = (searchKeys: string[], dish: Dish, sectionName: string) => {
	const dishName = dish.name.toLowerCase()
	const dishDescription = (dish.description || "").toLowerCase()
	for(const key of searchKeys) {
		if(!dishName.includes(key) && !dishDescription.includes(key) && !sectionName.includes(key)) {
			return false
		}
	}
	return true
}

export const getSectionName = (section: MenuSection | ServerMenuSection) => {
	if("name" in section) {
		return section.name || ""
	} else {
		return section.label_it || ""
	}
}

export const filterSectionName = (section: MenuSection | ServerMenuSection, searchText: string) => {
	const searchKeys = (searchText || "").toLowerCase().split(" ")
	const sectionName = getSectionName(section).toLowerCase()

	for(const key of searchKeys) {
		if(!sectionName.includes(key)) {
			return false
		}
	}
	return true
}

export const filterSection = (section: MenuSection | ServerMenuSection, searchText: string) => {
	if(!searchText) return section.dishes || []
	const searchKeys = (searchText || "").toLowerCase().split(" ")
	const sectionName = getSectionName(section).toLowerCase()

	const dishes = filterSectionName(section, searchText) ? section.dishes : (section.dishes || []).filter((dish) => {
		return dishFilter(searchKeys, dish, sectionName)
	})
	return dishes || []
}

export const toNumber = (value: string | number | null | undefined) => {
	if(!value) return 0
	if(typeof value == "number") return value
	return parseFloat(value) || 0
}

export const toFixed = (num?: number, digits = 2) => {
	if(num === undefined) return undefined
	let str = num.toString()
	let toAdd = digits - str.length
	while(toAdd > 0) {
		str = "0" + str
		toAdd--
	}
	return str
}

export const limitStringLength = (text: string | null | undefined, maxLength: number) => {
	if(!text) return ""
	if(text.length > maxLength) {
		return text.substring(0, maxLength - 3).trim() + "..."
	}
	return text
}

export const resolveHref = (...params: string[]) => {
	return params.map((sub, index) => {
		let str = sub.toString()
		if(str.length > 0) {
			if(str[0] == "/" && index > 0) {
				str = str.substring(1)
			}
			if(str[str.length - 1] == "/") {
				str = str.substring(0, str.length - 1)
			}
		}
		return str
	}).join("/")
}

/**
 * Convert input text to decimal value
 */
export const toDecimal = (text: string | null | undefined) => {
	return parseFloat((text || "").replace(",", "."))
}

export const parsePrice = (text: string | null | undefined) => {
	const fixed = toDecimal(text).toFixed(2)
	return parseFloat(fixed)
}
