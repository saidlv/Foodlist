import { DeliveryRouteDay, DisplayableDeliveryDay, DeliveryRoute, DeliveryRouteTime } from "@Models/DeliveryRoute"
import { formatTime, isToday, todayIndex, getWeekday, todayDate, setTimeInDate, DATE_FORMAT, formatMomentTime, HOUR_FORMAT, SERVER_DATETIME_FORMAT, getMomentDate, getMoment, weekdays } from "./DateManager"
import { StringDate } from "@Models/StringDate"
import { Any } from "@Models/Any"
import moment from "moment"
import { deepCopy } from "./"
import { Restaurant } from "@Models/Restaurant"
import { getLastAvailableRange } from "@FoodListCommon/orders"
import { SectionHour } from "@FoodListCommon/sections-formatter"
import { Order, OrderStatus } from "@Models/Order"
import { I18nKey, TranslationFunction } from "./Translations"
import { OrderItem } from "@AppModels/OrderItem"


export const timeMinutesRange = 30

//TODO: gestire le cose dopo la mezzanotte

export const isSimpleOrderRow = (item: OrderItem) => {
	return !item.notes && (!item.options || item.options.length == 0)
}

const orderFromToday = (week: Any[]) => {
	const _todayIndex = todayIndex()
	return (week.splice(_todayIndex, 7)).concat(week)
}

export const firstAvailable = (item: DisplayableDeliveryDay) => {
	const now = todayDate()
	const currentStartRange = setTimeInDate(new Date(), item.time.from)
	while (now > currentStartRange) {
		currentStartRange.add(timeMinutesRange, 'minutes')
	}
	return currentStartRange
}

export const preprocessDays = (days: DeliveryRouteDay[]) => {
	const week: DeliveryRouteDay[] = []
	for (let i = 0; i < 7; i++) {
		week.push({
			day: i,
			enabled: true,
			hours: []
		})
	}
	days.forEach(item => {
		const day = week[item.day]
		if (item.enabled) {
			day.hours = item.hours.filter(hour => {
				return hour.enabled
			})
		}
	})

	const ordered: DeliveryRouteDay[] = orderFromToday(week)
	//Per gestire dopo la mezzanotte aggiungere al giorno attuale la fasca oraria del giorno precedente che supera la mezzanotte e gestire limit ecc.
	return ordered
}

export const isClosed = (date: moment.Moment, last_close_order: StringDate | undefined) => {
	if (last_close_order) {
		return moment(last_close_order).format(DATE_FORMAT) == date.format(DATE_FORMAT)
	}
	return false;
}

export const hasEnded = (item: DisplayableDeliveryDay) => {
	if (item.time.to < item.time.from) return false;

	const itemTime = new Date()
	const endTime = setTimeInDate(itemTime, item.time.to)

	const now = todayDate()
	return endTime <= now
}

export const shouldShow = (item: DisplayableDeliveryDay) => {
	const weekday = getWeekday(item.dayIndex)
	if (isToday(weekday)) {
		return !hasEnded(item)
	}
	return true
}

const getWeekdayAfterMod = (index: number) => {
	return weekdays()[absIndex(index)]
}

const absIndex = (index: number) => {
	return (index + 7) % 7
}

/**
 * @param index week day index
 * @returns the date of the first occurence of the given weekday starting from today
 */
const getDate = (index: number) => {
	const days = deepCopy(weekdays())
	const day = days[absIndex(index)]
	const ordered = orderFromToday(days)
	const addDays = ordered.indexOf(day)
	return moment(new Date()).add(addDays, "days")
}

const limitToMaxTime = (endHour: string, minutes_before: number) => {
	return formatMomentTime(moment(endHour, HOUR_FORMAT).subtract(minutes_before, "minutes"))
}

export const getOrderLimits = (item: DisplayableDeliveryDay) => {
	const lastAvailable = getLastAvailableRange(item)
	const limitDate = item.date.clone().subtract(item.time.limit_days_before ?? 0, "days").toDate()
	let limitTime = item.time.limit || lastAvailable.start
	const with_limit = setTimeInDate(limitDate, limitTime)
	const with_before = setTimeInDate(item.date.toDate(), lastAvailable.start).subtract(item.min_minutes_before, "minutes")

	return {
		with_limit,
		with_before
	}
}

export const tooLate = (item: DisplayableDeliveryDay) => {
	const limits = getOrderLimits(item)
	//console.log(limits, limits.with_limit.format(SERVER_DATETIME_FORMAT), limits.with_before.format(SERVER_DATETIME_FORMAT))

	const now = todayDate()

	return now >= limits.with_before || now > limits.with_limit
}

const isInsideHour = (date: moment.Moment, hour: SectionHour) => {
	const from = getMomentDate(hour.hour.from, HOUR_FORMAT)
	const to = getMomentDate(hour.hour.to, HOUR_FORMAT)

	const min_minutes_before = hour.sectionMinMinutesBefore //TODO: Prendere quello vero
	from.subtract(min_minutes_before, 'minutes')

	if (date >= from && date <= to) {
		return true
	} else {
		return false
	}
}

export const startingDeliveryHours = (hours: SectionHour[]) => {
	const now = todayDate()
	const starting: SectionHour[] = []
	hours.map((hour) => {
		if (isInsideHour(now, hour)) {
			starting.push(hour)
		}
	})

	return starting
}

export const needsToChoose = (order: Order, hours: SectionHour[]) => {
	let blocked = false

	hours = startingDeliveryHours(hours) //Ottengo solo quelle che stanno per cominciare
	hours.map((hour) => {
		if(order.status_id == OrderStatus.Pending && order.delivery_section_id == hour.sectionId && isInsideHour(getMoment(order.for_date), hour)) {
			const needToChooseRange = hour.sectionMinMinutesBefore + 15
			if(getMoment(order.for_date).subtract(needToChooseRange, "minutes").isBefore(moment())) {
				blocked = true
			}
		}
	})

	return blocked
}


/**
 * @class LocalizedOrderFunctions
 * 
 * @description Questa classe racchiude tutte le funzioni che necessitano di traduzioni
 */
export class LocalizedOrderFunctions {
	private translate: TranslationFunction

	constructor(translate: TranslationFunction) {
		this.translate = translate
	}

	printableWeekday = (index: number, date: moment.Moment) => {
		const weekday = weekdays()[index]
		const weekday_and_date = weekday + " " + date.format("D MMMM")
		if (isToday(weekday)) {

			return this.translate("today", { weekday: weekday_and_date.toLowerCase() })
		} else if (isToday(getWeekdayAfterMod(index - 1))) {
			return this.translate("tomorrow", { weekday: weekday_and_date.toLowerCase() })
		}
		return weekday_and_date
	}

	orderBeforeString = (day: DisplayableDeliveryDay) => {
		return this.getOrderBeforeString(null, day.dayIndex, day)
	}

	/**
	 * @deprecated use orderBeforeString
	 */
	getOrderBeforeString = (time: DeliveryRouteTime, dayIndex: number, day: DisplayableDeliveryDay) => {
		const limits = getOrderLimits(day)
		const limit = moment.min([limits.with_before, limits.with_limit])
		const hour = limit.format(HOUR_FORMAT)
		const weekday = limit.format("dddd")
		//console.log(weekday, getWeekdayAfterMod(dayIndex))
		if (weekday.toLowerCase() == getWeekdayAfterMod(dayIndex).toLowerCase()) {
			return this.translate("orderByTimeOfWeekday", { hour, weekday: weekday.toLowerCase() })
		} else {
			//se days_before è oggi
			if (isToday(weekday)) {
				return this.translate("orderByTimeOfToday", { hour })
			} else if (isToday(limit.clone().subtract(1, "day").format("dddd"))) {
				return this.translate("orderByTimeOfDayBefore", { hour })
			} else {
				return this.translate("orderByTimeOfWeekday", { hour, weekday: weekday.toLowerCase() })
			}
		}
	}

	getGenericOrderBeforeString = (time: DeliveryRouteTime, dayIndex: number) => {
		const { limit, limit_days_before } = time
		if (limit) {
			const hour = moment(limit, HOUR_FORMAT).format(HOUR_FORMAT)
			if (limit_days_before && limit_days_before > 0) {
				if (limit_days_before == 1) {
					return this.translate("orderByTimeOfDayBefore", { hour })
				} else {
					const limit_day_index = (7 + dayIndex - limit_days_before) % 7
					return this.translate("orderByTimeOfWeekday", {
						hour,
						weekday: getWeekday(limit_day_index).toLowerCase()
					})
				}
			} else {
				return this.translate("orderBefore", { hour })
			}
		}
		return ""
	}

	getDisplayableDay = (item: DeliveryRouteDay, route: DeliveryRoute, restaurant: Restaurant | undefined, index: number, defaultName?: string): DisplayableDeliveryDay => {
		const date = getDate(item.day)
	
		const time_span = route.time_span || restaurant?.order_time_span || 15
		const show_range = route.show_range
		const time_range = show_range ? (route.time_range || restaurant?.order_time_range || 30) : 0
		const min_minutes_before = item.hours[index].min_minutes_before || item.min_minutes_before || route.min_minutes_before || restaurant?.order_min_minutes_before || 30
		return {
			weekday: this.printableWeekday(item.day, date),
			date: date,
			dayIndex: item.day,
			name: item.hours[index].name || defaultName,
			time: item.hours[index],
			orderClosed: isClosed(date, item.hours[index].last_close_order),
			time_range,
			time_span,
			show_range,
			min_minutes_before
		}
	}

	getAvailableOrderServices = (route: DeliveryRoute) => {
		return this.processDays(null, route)
	}

	processDays = (days: DeliveryRouteDay[] | null, route: DeliveryRoute, restaurant?: Restaurant): DisplayableDeliveryDay[] => {
		const _days = days || preprocessDays(route.days)
		return _days.reduce<DisplayableDeliveryDay[]>((acc, item, index) => {
	
			const now = todayDate()
	
			let startOrders = todayDate()
			const offset = index//item.day - getDayIndexFromMoment(now)
			startOrders.add(offset - route.max_days_before, 'days')
			startOrders = setTimeInDate(startOrders.toDate(), '00:00')
			if (now >= startOrders) {
				if (item.hours.length == 1) {
					const val = this.getDisplayableDay(item, route, restaurant, 0)
					if (shouldShow(val)) {
						acc.push(val)
					}
				} else if (item.hours.length == 2) {
					const lunch = this.getDisplayableDay(item, route, restaurant, 0, this.translate("lunch"))
					if (shouldShow(lunch)) {
						acc.push(lunch)
					}
					const dinner = this.getDisplayableDay(item, route, restaurant, 1, this.translate("dinner"))
					if (shouldShow(dinner)) {
						acc.push(dinner)
					}
				} else {
					return acc.concat(item.hours.reduce<DisplayableDeliveryDay[]>((acc, hour, index) => {
						const day = this.getDisplayableDay(item, route, restaurant, index, formatTime(hour.from) + " - " + formatTime(hour.to))
						if (shouldShow(day)) {
							acc.push(day)
						}
						return acc
					}, []))
				}
			}
			return acc
		}, [])
	}
}