import { ItemsMap, groupByKey as _groupByKey, mapByKey as _mapByKey } from "@Models/ItemsMap"


export const deepCopy = <T extends {} | []>(obj: T): T => {
	return JSON.parse(JSON.stringify(obj))
}

export const mapByKey = _mapByKey

export const mapById = <T extends { id?: number }>(options: T[]): ItemsMap<T> => {
	return mapByKey(options, "id")
}

export const join = <T>(array: (T[] | undefined)[]) => {
	return array.reduce<T[]>((acc, items) => {
		return acc.concat(items || [])
	}, [])
}

export const groupByKey = _groupByKey