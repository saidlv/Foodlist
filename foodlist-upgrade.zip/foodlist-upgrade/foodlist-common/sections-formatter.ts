import { DeliveryRoute, DeliveryRouteDay, DeliveryRouteTime } from "./Models/DeliveryRoute";
import { BookingHour } from "./Models/BookingHour";
import { ItemsMap, groupByKey } from "./Models/ItemsMap";
import { BookingDay } from "./Models/BookingDay";
import { buildArray, compareValues } from "./utils";
import { preprocessDays } from "@FoodListCommon/OrderHelper";

export type CommonTime = Partial<DeliveryRouteTime & BookingHour>
export type CommonDay = Partial<DeliveryRouteDay & BookingDay>

export type TimeSection<T = CommonTime> = {
	name: string
	description?: string
	all: T
	days: T[] // 7 days, 0 => monday, 6 => sunday
	local_id: number
}

export type SectionHour = {
	sectionId: number
	sectionName: string
	sectionMinMinutesBefore: number,
	hour: DeliveryRouteTime
}

const getDaysOfSection = (section: number, days: CommonDay[]): CommonTime[] => {
	return days.map(day => {
		return day.hours?.[section] ?? ({
			enabled: false,
			from: "00:00",
			to: "00:00"
		} as unknown as DeliveryRouteTime)
	})
}

const getMaxKey = (mappedValues: ItemsMap<number> | undefined): string | undefined => {
	const max = {
		key: "",
		count: 0
	}
	const data = mappedValues ?? {}
	Object.keys(data).forEach(key => {
		const count = data[key] ?? 0
		if(count > max.count) {
			max.key = key
			max.count = count
		}
	})
	if(max.key == "false") return undefined
	return max.key
}

const getIntegerKey = (mappedValues: ItemsMap<number>): number | undefined => {
	const val = parseInt(getMaxKey(mappedValues) ?? "")
	if(isNaN(val)) return
	return val
}

const getMostFrequentValues = (days: CommonTime[], isBooking: boolean, isOrders: boolean = true): CommonTime => {
	const map = Object.keys(days[0]).reduce<ItemsMap<ItemsMap<number>>>((acc, key) => {
		acc[key] = {}
		return acc
	}, {})
	days.forEach(day => {
		Object.keys(day).forEach(key => {
			const val = (day[key] ?? "false").toString()
			if(!map[key]) {
				map[key] = {}
			}
			if(map[key]?.[val]) {
				// @ts-ignore
				map[key][val]++
			} else {
				// @ts-ignore
				map[key][val] = 1
			}
		})
	})
	const res: CommonTime = {
		enabled: (getMaxKey(map.enabled) == "true"),
		from: getMaxKey(map.from),
		to: getMaxKey(map.to),
	}
	if(isBooking) {
		res.max_people = getIntegerKey(map.max_people ?? {})
		res.min_minutes_before = getIntegerKey(map.min_minutes_before ?? {})
		res.max_table = getIntegerKey(map.max_table ?? {})
		res.max_days_before = getIntegerKey(map.max_days_before ?? {})
	} else if(isOrders) {
		res.limit = getMaxKey(map.limit ?? {})
		res.limit_days_before = getIntegerKey(map.limit_days_before ?? {})
	}
	return res
}

export const sectionsFromServerDays = (days: CommonDay[], isBooking = true): TimeSection[] => {
	const grouped = days.reduce<ItemsMap<CommonTime[]>>((acc, day, index) => {
		acc[index] = day.hours
		return acc
	}, {})
	const [maxLength, items] = getMaxLength(grouped)
	return buildArray(maxLength, index => {
		const item = items[index]
		const sectionDays = getDaysOfSection(index, days)
		return {
			local_id: index,
			name: item.name ?? "",
			description: item.description,
			all: getMostFrequentValues(sectionDays, isBooking),
			days: sectionDays
		}
	}).sort((first, second) => compareValues(first.all.from, second.all.from))
}

export const sectionsToServerDays = (sections: TimeSection[]) => {
	return buildArray(7, index => ({
		day: index,
		enabled: true,
		hours: sections.map(section => {
			return {
				...section.days[index],
				name: section.name,
				description: section.description
			}
		})
	}))
}

type RestaurantHour = {
	day: string //"1" to "7"
	from: string //"11:00"
	to: string //"14:00"
	disabled: boolean
}

const restHoursOfSection = (sectionIndex: number, groupedHours: ItemsMap<RestaurantHour[]>): CommonTime[] => {
	return buildArray(7, index => {
		const times = groupedHours[(index + 1).toString()]
		const time = times?.[sectionIndex]
		if(time) {
			return {
				enabled: !time.disabled,
				from: time.from,
				to: time.to
			}
		}
		return {
			enabled: false,
			from: "00:00",
			to: "00:00"
		}
	})
}

const getMaxLength = <T>(map: ItemsMap<T[]>) => {
	return Object.values(map).reduce<[number, T[]]>((acc, _item) => {
		const item = _item || []
		if(item.length > acc[0]) {
			return [item.length, item]
		}
		return acc
	}, [0, []])
}

export const sectionsFromRestaurantHours = (hour: RestaurantHour[]) => {
	const grouped = groupByKey(hour, "day")
	const [maxLength] = getMaxLength(grouped) //in this case maxKey is an array
	console.warn("Internal", grouped, maxLength)
	return buildArray(maxLength, index => {
		const days = restHoursOfSection(index, grouped)
		const val: TimeSection = {
			name: "",
			days,
			all: getMostFrequentValues(days, false, false),
			local_id: index
		}
		return val
	})
}

export const sectionsToRestaurantHours = (sections: TimeSection[]) => {
	return sections.reduce<RestaurantHour[]>((acc, section) => {
		for(const dayIndex in section.days) {
			const day = section.days[dayIndex]
			acc.push({
				disabled: !day.enabled,
				day: (parseInt(dayIndex) + 1).toString(),
				from: day.from ?? "",
				to: day.to ?? ""
			})
		}
		return acc
	}, [])
}

export const todaySectionsFromDeliveryRoutes = (routes: DeliveryRoute[]) => {
	let all: SectionHour[] = []
	routes.forEach(route => {
		const today = preprocessDays(route.days)[0]
		today.hours.forEach(hour => {
			all.push({
				sectionId: route.id!,
				sectionMinMinutesBefore: route.min_minutes_before!,
				sectionName: route.name,
				hour
			})
		})
	})
	return all
}