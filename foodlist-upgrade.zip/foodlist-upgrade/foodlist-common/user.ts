import { UserAddress } from "@Models/UserAddress"

export const formatUserAddress = (item: UserAddress) => {
	return item.address + ' ' + item.house_number + ', ' + item.city 
}