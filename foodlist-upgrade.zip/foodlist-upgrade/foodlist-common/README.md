# FoodList Common

This repository contains common classes that can be used in both React (webapp) and ReactNative (mobile apps).

To use Models you need to add an alias `@Models` inside your project.

- in `tsconfig.json` add the following line inside `"compilerOptions" -> "paths"`

```
"@Models/*": ["./node_modules/foodlist-common/Models/*"]`
```

- in `.babelrc` add the following configuration:

```
{
	"plugins": [
		[
			"module-resolver",
			{
				"root": [
					"./"
				],
				"alias": {
					"@Models": "./node_modules/foodlist-common/Models"
				}
			}
		]
	]
}
```