import React from 'react';
import { AppRegistry } from 'react-native';
import { name as appName } from './app.json';
import App from "./App.web"
import materialIcons from 'react-native-vector-icons/Fonts/MaterialIcons.ttf';
import materialCommunityIcons from 'react-native-vector-icons/Fonts/MaterialCommunityIcons.ttf';
import foodlistIconfont from '@FoodListCore/Iconfont/Font/FoodList-Iconfont.ttf'

AppRegistry.registerComponent(appName, () => App)

AppRegistry.runApplication(appName, {
	rootTag: document.getElementById('root'),
});

const iconFontStyles = `@font-face {
  src: url(${materialIcons});
  font-family: MaterialIcons;
}
@font-face {
	src: url(${materialCommunityIcons});
	font-family: MaterialCommunityIcons;
}
@font-face {
	src: url(${foodlistIconfont});
	font-family: FoodList-Iconfont;
}
`;

// Create stylesheet
const style = document.createElement('style');
style.type = 'text/css';
if (style.styleSheet) {
  style.styleSheet.cssText = iconFontStyles;
} else {
  style.appendChild(document.createTextNode(iconFontStyles));
}

// Inject stylesheet
document.head.appendChild(style);