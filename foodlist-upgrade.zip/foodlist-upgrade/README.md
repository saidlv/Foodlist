
# Configurazione del progetto in development

In development vengono clonati foodlist-core e foodlist-common all'interno della root del progetto per semplificare lo sviluppo.\
Sono configurati degli script di npm per semplificare la configurazione iniziale e l'update.

### config-dev
```bash
npm run config-dev
```
Clona automaticamente le repository nelle cartelle corrette (potrebbe essere richiesta l'autenticazione su gitlab).\
Da eseguire solo la prima volta!

### pull-dev
```bash
npm run pull-dev
```

Aggiorna tutte le repository automaticamente.\
Eseguire quando ci sono nuove modifiche fatte da altri. Se ci sono modifiche in locale è molto probabile che dia errore.


## Varianti -full

Si possono utilizzare anche le varianti `config-dev-full` e `pull-dev-full` che installano anche le dipendenze npm e i pods.
```bash
npm run config-dev-full
```
```bash
npm run pull-dev-full
```

In alternativa se sono già stati eseguiti i comandi *"non full"* c'è il comando `ip` che installa dipendenze npm e pods:
```bash
npm run ip
```