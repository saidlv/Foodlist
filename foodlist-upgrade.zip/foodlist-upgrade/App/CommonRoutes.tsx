import React from 'react'
import { createStackNavigator } from "@react-navigation/stack"

import FilterOptionPage from '@Pages/Search/FilterOptionPage'
import FastReviewPage from '@Pages/Review/FastReview/'
import SelectDishPage from '@Pages/SelectDishPage/'
import ProfilePage from '@Pages/ProfilePage'
import NotificationsPage from '@Pages/NotificationsPage'
import ReviewDetail from '@Pages/ReviewDetail'
import ImproveProfilePage from '@Pages/ImproveProfile'
import ImproveAddressPage from '@Pages/ImproveProfile/AddressPage'
import InsertTimesPage from '@Pages/ImproveProfile/InsertTimes'
import UserListPage from '@Pages/UserListPage'
import ReviewsListLoadMore from '@Pages/ReviewsListLoadMore'
import { CommonParamList } from "@RouteParams/Common"
import { iconNamed } from "@Global/GlobalProps"
import { SHARE_ACTIONS, share } from "@Services/ShareManager"
import ReviewDetailManager from "@Network/ReviewDetailManager"
import SuggestContacts from '@Pages/SuggestContacts'
import { translate, I18nKey } from './I18n'
import CoreRoutes from "@FoodListCore/Flows/Restaurant/routes"
import { SideBarGlobals } from './TabBarPages'
import NewSearchPage from './Pages/NewSearchPage'
import NewRestaurant from './Components/NewRestaurant'
import OrderDetailPage from '@FoodListCore/Pages/OrderDetailPage'
import { getStatusBarHeight } from 'react-native-status-bar-height'
import { colors } from '@FoodListCommon/utils'
import ReviewOrder from '@FoodListCore/Pages/ReviewOrderPage'
import { Platform } from 'react-native'
import BookingHistoryDetail from '@FoodListCore/Pages/BookingHistoryDetailPage'

export const menuHeaderLeft = () => ({
	headerLeft: () => iconNamed('sidebar', () => { SideBarGlobals.sidebarRef?.openMenu(true) }, 13)
})

const Stack = createStackNavigator<CommonParamList>()

const _CoreRoutes = CoreRoutes(/* (dishes) => {
	return (
		<DishList items={dishes} hideDescription scrollable />
	)
} */)

export const CommonRoutes = () => (
	<>
	<Stack.Screen
		key={30}
		name="NewSearch"
		component={NewSearchPage}
		options={({ route }) => {
			if(route.params?.selectRestaurant) {
				return {
					headerTitle: translate("selectRestaurant"),
				}
			}
			return {
				title: "",
				headerTitle: (props) => (<></>),
				headerStyle: {
					height: getStatusBarHeight(true),
					backgroundColor: colors.foodlist,
					borderBottomWidth: 0,
					elevation: 0,
					shadowColor: 'transparent',
				}
			}
		}}
	/>
	<Stack.Screen
		key={31}
		name="NewRestaurant"
		component={NewRestaurant}
		options={({ route }) => {
			return {
				headerShown: Platform.OS === "web",
			}
		}}
	/>
	<Stack.Screen
		key={12}
		name="SuggestContacts"
		component={SuggestContacts}
		options={({ route }) => {
			let isAfterRegistration = route.params?.isAfterRegistration
			return {
				headerRight: () => null,
				headerTitle: translate("findYourFriends")
			}
		}}
	/>
	<Stack.Screen
		key={13}
		name="ProfilePage"
		component={ProfilePage}
		options={({ navigation, route }) => {
			const { user_id, headerTitle, userToShare } = route.params || {}
			if (user_id != null) {
				return {
					title: userToShare?.username ?? translate("userProfile"),
					headerTitle: headerTitle ?? "",
					/* headerRight: userToShare ? () => iconNamed("share-2", () => {
						//console.log(route.params)
						if (route.params?.userToShare) {
							share(SHARE_ACTIONS.USER, { id: userToShare?.id ?? 0, text: userToShare?.username ?? "" })
						}
					}) : undefined */
				}
			} else {
				return {
					title: translate("userProfile"),
					headerTitle: headerTitle ?? "",
					headerLeft: menuHeaderLeft().headerLeft
				}
			}
		}}
	/>

	<Stack.Screen
		key={15}
		name="ReviewDetail"
		component={ReviewDetail}
		options={({ route }) => {
			const { data } = route.params
			return {
				headerTitle: translate("review"),
				/* headerRight: () => iconNamed("share-2", () => {
					const review = data
					const isRestaurant = ReviewDetailManager.isRestaurant(review)
					const action = ReviewDetailManager.isRestaurant(review) ? SHARE_ACTIONS.REVIEW_RESTAURANT : SHARE_ACTIONS.REVIEW_DISH
					let itemId: number
					if (isRestaurant) {
						itemId = review.restaurant!.id
					} else {
						itemId = review.dish!.id;
					}
					//console.log('Item id della review',itemId);
					share(action, { id: review.id + '_' + itemId, text: translate("lookThisReview") })
				}, 16), */
			}
		}}
	/>
	<Stack.Screen
		key={16}
		name="Notifications"
		component={NotificationsPage}
		options={({ navigation }) => ({
			headerRight: () => null,
			headerTitle: translate("notifications"),
		})}
	/>
	<Stack.Screen
		key={17}
		name="UserListPage"
		component={UserListPage}
		options={({ route }) => {
			const { likes, followers } = route.params
			let title: string
			if(likes) {
				title = translate("likedByTitle")
			} else if(followers) {
				title = translate("followers")
			} else {
				title = translate("following")
			}
			return {
				headerTitle: title
			}
		}}
	/>
	<Stack.Screen
		key={20}
		name="ImproveProfile"
		component={ImproveProfilePage}
		options={({ navigation }) => ({
			headerTitle: translate("suggestModify"),
			headerRight: () => null,
			gestureEnabled: false
			//gesturesEnabled: !navigation.getParam("blockSwipe", false)
		})}
	/>
	<Stack.Screen
		key={21}
		name="ImproveAddress"
		component={ImproveAddressPage}
		options={({ navigation }) => ({
			headerTitle: translate("insertAddress"),
			headerRight: () => null
		})}
	/>
	<Stack.Screen
		key={22}
		name="InsertTimes"
		component={InsertTimesPage}
		options={({ navigation }) => ({
			headerTitle: translate("insertTimes"),
			headerRight: () => null
		})}
	/>
	<Stack.Screen
		key={23}
		name="FilterOptionPage"
		component={FilterOptionPage}
		options={({ route, navigation }) => ({
			headerTitle: route.params.title ?? "",
			headerRight: () => null
		})}
	/>
	<Stack.Screen
		key={24}
		name="ReviewsListLoadMorePage"
		component={ReviewsListLoadMore}
		options={{
			headerTitle: translate("reviews")
		}}
	/>
	<Stack.Screen
		key={25}
		name="FastReview"
		component={FastReviewPage}
		options={({ navigation, route }) => {
			return {
				headerTitle: translate(route.params?.isEdit ? "editReview" : "leaveReview"),
				headerRight: () => null,
				gestureEnabled: false
				//gesturesEnabled: !navigation.getParam("blockSwipe", false)
			}
		}}
	/>
	<Stack.Screen
		key={26}
		name="SelectDish"
		component={SelectDishPage}
		options={({ navigation }) => ({
			headerTitle: translate("leaveReview"),
			headerRight: () => null,
		})}
	/>
	<Stack.Screen
		key={27}
		name="NotificationOrderDetail"
		component={OrderDetailPage}
		options={{
			headerTitle: translate("orderDetail"),
		}}
	/>
	<Stack.Screen
		key={28}
		name="NotificationBookingDetail"
		component={BookingHistoryDetail}
		options={{
			headerTitle: translate("bookingDetail"),
		}}
	/>
	<Stack.Screen
		name="NotificationReviewOrder"
		component={ReviewOrder}
		options={{
			headerTitle: translate("review"),
		}}
	/>
	{_CoreRoutes()}
	</>
)
