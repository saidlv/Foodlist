import { CommonParamList } from '@App/RouteParams/Common';
import { getCurrentLocation } from '@FoodListCore/Services/LocationManager';
import { SERVER_DATETIME_FORMAT } from '@FoodListCommon/DateManager';
import { alert, showError } from '@FoodListCore/Global/GlobalProps';
import { getCurrentUser } from '@FoodListCore/Redux/ReduxHelper';
import { Location } from '@Models/Location';
import { UserAddress } from '@Models/UserAddress';
import { NavigationProp } from '@react-navigation/native';
import React from 'react';
import OrderOnlineView, { OrderOnlineViewActions } from './view';

type Props = {
	navigation: NavigationProp<CommonParamList, any>
}

export type State = {
	isDelivery: boolean
	isBookTable: boolean
	selectedAddress?: UserAddress | null
	pickerVisible?: boolean
	/** null means now */
	selectedTime: moment.Moment | null
	selectAddressVisible?: boolean
	mode: "orders" | "bookings" | "all"
	loadingPosition?: boolean
	positionSelected?: boolean
	positionFromMap?: boolean
}

class OrderOnlinePage extends React.PureComponent<Props, State> {
	position?: Location
	constructor(props: Props) {
		super(props)
		const params = props.route?.params
		const address = getCurrentUser()?.addresses?.[0]
		this.state = {
			isDelivery: true,
			selectedTime: null,
			mode: params?.bookings ? "bookings" : params?.orders ? "orders" : "all",
			isBookTable: params?.bookings || false,
			selectedAddress: address,
			positionSelected: !address,
		}
	}

	actions: OrderOnlineViewActions = {
		orderTypeChanged: (isDelivery, isBookTable) => {
			this.setState({ isDelivery, isBookTable })
		},
		showChangeAddress: (selectAddressVisible) => {
			this.setState({ selectAddressVisible })
		},
		changeTime: (selectedTime) => {
			this.setState({ selectedTime, pickerVisible: false })
		},
		showChangeTime: (pickerVisible) => {
			this.setState({ pickerVisible })
		},
		onSearch: async () => {
			const { selectedTime, selectedAddress, isDelivery, isBookTable, positionSelected } = this.state
			try {
				if(positionSelected && !this.position) {
					this.setState({
						loadingPosition: true
					})
					this.position = await getCurrentLocation(true)
				}
				this.props.navigation.navigate("NewSearch", {
					address: selectedAddress,
					address_id: selectedAddress?.id,
					mode: isBookTable ? "booking" : isDelivery ? "delivery" : "takeaway",
					for_date: selectedTime?.format(SERVER_DATETIME_FORMAT),
					position: this.position
				})
			} catch(err) {
				alert("Impossibile ottenere la tua posizione", "Attiva la geolocalizzazione o inserisci un indirizzo manualmente")
			} finally {
				this.setState({
					loadingPosition: false
				})
			}
		},
		selectAddressActions: {
			onAddressSelected: (selectedAddress) => {
				this.position = undefined
				this.setState({ selectedAddress, selectAddressVisible: false, positionSelected: false })
			},
			onPositionSelected: (position, fromMap) => {
				//console.log("posizione", position)
				this.position = position
				this.setState({
					selectAddressVisible: false,
					selectedAddress: null,
					positionSelected: true,
					positionFromMap: fromMap
				})
			},
			close: () => {
				this.setState({
					selectAddressVisible: false
				})
			}
		}
	};

	render() {
		return (
			<OrderOnlineView
				actions={this.actions}
				state={this.state}
			/>
		);
	}
}

export default OrderOnlinePage;
