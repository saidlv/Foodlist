import React from 'react';
import { State } from './';
import { colors } from '@Global/GlobalProps';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import RadioHandler from '@FoodListCore/Components/RadioHandler';
import Icon, { MaterialCommunityIcon, MaterialIcon, MaterialIconName } from '@FoodListCore/Iconfont/FoodListIconfont';
import { translate } from '@App/I18n';
import { ScrollView } from 'react-native-gesture-handler';
import { margins } from '@FoodListCore/Global/GlobalProps';
import Line from '@FoodListCore/Components/Line';
import FormActionButton from '@FoodListCore/Components/FormActionButton';
import TimeIcon from '@FoodListCore/Components/TimeIcon';
import moment from 'moment';
import { HUMAN_DATETIME_FORMAT } from '@FoodListCommon/DateManager';
import DatetimePickerPopup from '@App/Components/DatetimePickerPopup';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import SelectAddress, { SelectAddressActions } from '@FoodListCore/Components/SelectAddress';
import AddressInfos from '@FoodListCore/Components/AddressInfos';

export interface OrderOnlineViewActions {
	orderTypeChanged: (isDelivery: boolean, isBookTable: boolean) => void
	showChangeAddress: (visible: boolean) => void
	selectAddressActions: SelectAddressActions
	changeTime: (time: moment.Moment | null) => void
	showChangeTime: (show: boolean) => void
	onSearch: () => void
}

type Props = {
	actions: OrderOnlineViewActions
	state: Readonly<State>
}

const OrderOnlineView = (props: Readonly<Props>) => {
	const { state, actions } = props
	const address = state.selectedAddress
	return (
		<>
		<ScrollView style={{ backgroundColor: colors.greyBackground }}>
			<Text>{}</Text>
			{state.mode == "bookings" ? (
				<></>
			) : (
			<RadioHandler<{ id: number, icon: MaterialIconName, label: string }>
				values={[{
					id: 0,
					icon: "delivery-dining",
					label: translate("delivery")
				}, {
					id: 1,
					icon: "storefront",
					label: translate("takeYourself")
				}, ...(state.mode == "all" ? [{
					id: 2,
					icon: "calendar-today",
					label: translate("bookTable")
				}] : [])
				]}
				selectedValue={state.isDelivery ? "0" : state.isBookTable ? "2" : "1"}
				actions={{
					valueSelected: (value) => {
						actions.orderTypeChanged(value == "0", value == "2")
					},
					cellProps: (item) => {
						return {
							reversed: true,
							customContent: (
								<View style={styles.row}>
									<MaterialIcon size={20} color={colors.foodlist} name={item.icon} />
									<Text style={{ marginLeft: 10, fontSize: 16 }}>{item.label}</Text>
								</View>
							)
						}
					}
				}}
			/>
			)}

			<Text style={{ padding: margins.pagePadding, fontSize: 16, paddingBottom: 10 }}>{state.isDelivery && state.mode != "bookings" ? "Consegna a" : "Nei pressi di"}:</Text>
			<Line />
			<TouchableRipple
				style={[styles.row, { padding: margins.pagePadding, backgroundColor: colors.white }]}
				onPress={() => actions.showChangeAddress(true)}
			>
				{state.loadingPosition ? (
					<ActivityIndicator />
				) : (
					<MaterialCommunityIcon name="map-marker-outline" size={22} color={colors.greyInfoText} />
				)}
				<View style={{ paddingHorizontal: 10, flex: 1 }}>
					{address ? (
						<AddressInfos
							address={address}
						/>
					) : (
						<Text>{translate(state.positionFromMap ? "positionFromMap" : "currentPosition")}</Text>
					)}
				</View>
				<Text style={{ color: colors.blueMenu, fontWeight: "bold" }}>
					{translate("change")}
				</Text>
			</TouchableRipple>
			<Line />
			<TouchableRipple
				style={[styles.row, { padding: margins.pagePadding, backgroundColor: colors.white }]}
				onPress={() => actions.showChangeTime(true)}
			>
				<TimeIcon
					time={state.selectedTime || moment()}
					size={20}
					outline
					color={colors.greyInfoText}
				/>
				<View style={{ paddingHorizontal: 10, flex: 1 }}>
					{state.selectedTime ? (
						<Text>{state.selectedTime.format(HUMAN_DATETIME_FORMAT)}</Text>
					) : (
						<Text>{translate("now")}</Text>
					)}
				</View>
				<Text style={{ color: colors.blueMenu, fontWeight: "bold" }}>
					{translate("change")}
				</Text>
			</TouchableRipple>
			<Line />
		</ScrollView>
		<View style={{ paddingHorizontal: margins.pagePadding, paddingBottom: 10 }}>
			<FormActionButton
				title={translate("confirm")}
				noPadding
				full
				onPress={actions.onSearch}
			/>
			<DatetimePickerPopup
				visible={state.pickerVisible || false}
				onDateChanged={(date) => {
					actions.changeTime(date)
				}}
				onClose={() => actions.showChangeTime(false)}
			/> 
		</View>

		{/* <BottomSheetModal
			snapPoints={["50%", "80%"]}
		>
			
		</BottomSheetModal> */}
		{state.selectAddressVisible && (
			<SelectAddress
				actions={actions.selectAddressActions}
			/>
		)}
		
		{/* <DateTimePicker
			isVisible={state.pickerVisible}
			mode="datetime"
			minimumDate={new Date()}
			onCancel={() => actions.showChangeTime(false)}
			onConfirm={(date) => {
				actions.changeTime(moment(date))
			}}
		/> */}
		
		</>
	);
};

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		alignItems: "center"
	},
});

export default OrderOnlineView;
