import React from 'react';
import 'react-native';


it('renders LoginView view', () => {
	//expect(renderer.create(<LoginView />)).toMatchSnapshot(); //TODO: add LoginView props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<LoginView pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<LoginView pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
