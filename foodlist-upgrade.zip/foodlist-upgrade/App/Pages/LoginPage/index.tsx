import React, { useState } from 'react';
import { AuthNavigation, AuthParamList } from '@App/RouteParams/Auth';
import LoginAuth from "@FoodListCore/Pages/LoginPage"
import SplashPageContainer from '../SplashPageContainer';
import FirebaseMessaging from '@App/Services/FirebaseMessaging';
import FirebaseAnalytics from '@App/Services/FirebaseAnalytics';
import LoadingView from '@FoodListCore/Components/LoadingView';
import { StatusBar } from 'react-native';

type Props = {
	navigation: AuthNavigation<"LoginPage">	
}

const LoginPage = (props: Props) => {
	StatusBar.setHidden(false)
	const { navigation } = props
	const [loading, setLoading] = useState(false)
	return (
		<>
		<LoginAuth
			/* @ts-ignore */
			navigation={navigation}
			customShowNextPage={(user, skipLogin, dismissLogin) => {
				const isRegistration = !user && !skipLogin
				if(skipLogin) {
					setLoading(true)
				}
				let resetToPage: {
					name: keyof AuthParamList,
					params: any
				}
				
				if(isRegistration) {
					resetToPage = {
						name: "EditProfile",
						params: {
							isAfterRegistration: true
						}
					}
				} else {
					resetToPage = {
						name: "TabBarPage",
						params: {}
					}
				}

				//console.log("SplashPageContainer boia")
				SplashPageContainer.loadData()
				.then(() => {
					if(!skipLogin) {
						FirebaseMessaging.linkToken();
						FirebaseAnalytics.initUser();
						SplashPageContainer.handleNotifications(true, navigation, true)
					} else {
						FirebaseAnalytics.skippedLogin();
					}
					dismissLogin?.()
					setLoading(false)
					navigation.reset({
						index: 0,
						routes: [
							resetToPage
						]
					})
				})
			}}
		/>
			<LoadingView visible={loading} />
		</>
	)
}


export default LoginPage;
