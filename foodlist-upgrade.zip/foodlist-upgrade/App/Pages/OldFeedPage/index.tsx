import React, { Component } from 'react';
import FeedManager, { GetFeedListResponse } from '@Network/FeedManager';
import FeedPage, { FeedActions } from './View';
import { connect } from 'react-redux';
import { User } from '@Models/User';
import { Review } from '@Models/Review';
import { alert } from '@Global/GlobalProps';
import { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import { ReduxState } from '@Redux/StateFormat';
import { ListParams } from '@Models/ListParams';
import { RequestResponse } from '@Models/RequestResponse';
import { StackNavigationProp } from '@react-navigation/stack';
import { SearchParamList } from '@RouteParams/Search';
import { Pluto } from '@Models/Pluto';
import requestAuth from '@FoodListCore/Flows/RequestAuth';
import { translate } from '@App/I18n';

type PageProps = {
	navigation: StackNavigationProp<Pluto, Pluto>
	user?: User
}

type PageState = {
	data: Review[],
	refresh: boolean,
	loading: boolean
}

class FeedListController extends React.PureComponent<PageProps, PageState> {
	constructor(props: PageProps) {
		super(props)
		this.state = {
			data: [],
			refresh: false,
			loading: false
		}
		//console.log("User", props.user)
	}

	listRef?: LoadMoreListType<Review>

	componentDidMount() {
		this.props.navigation.addListener("focus", this.pageWillFocus);
	}

	componentWillUnmount() {
		this.props.navigation.removeListener("focus", this.pageWillFocus)
	}

	load = () => {
		this.setState({
			loading: true
		})
		const scope = this;
		this.getRequest().then((response) => {
			scope.onResponse(response)
		}).catch(error => alert("Errore", error))
	}

	pageWillFocus = () => {
		//console.log('Feed page focus', this.listRef);
		this.listRef?.reload(true);
	}

	getRequest = (params?: ListParams) => {
		//console.log('Params', params)
		let manager = new FeedManager()
		return manager.getList(params)
	}

	onResponse = (body: RequestResponse<GetFeedListResponse>) => {
		this.setState({
			refresh: true,
			data: body.data?.response || [],
			loading: false
		})
	}

	showPage = <T extends keyof SearchParamList> (page: T, params?: SearchParamList[T]) => {
		this.props.navigation.push(page, params)
	}

	writeReview = () => {
		if(requestAuth(this.props.navigation, true)) {
			this.showPage("FastReview")
		}
	}

	actions: FeedActions = {
		request: this.getRequest,
		listRef: (ref) => {
			this.listRef = ref
		},
		showPage: this.showPage,
		writeReview: this.writeReview,
		onResponse: this.onResponse,
		showRestaurants: (orders: boolean) => {
			if(orders) {
				this.showPage("FoodListOrderOnline", {
					orders: true
				})
			} else {
				this.showPage("FoodListOrderOnline", {
					bookings: true
				})
				/* this.showPage("SearchPage", {
					showOrderOnline: orders,
					showBookings: !orders,
					title: translate(orders ? "orderOnline" : "bookTable")
				}) */
			}
		},
		refresh: () => {
			this.listRef?.reload()
		}
	}

	render() {
		return (
			<FeedPage
				data={this.state.data}
				user={this.props.user}

				actions={this.actions}
			/>
		)
	}
}

export default connect((state: ReduxState) => {
	return {
		user: state.currentUser
	}
})(FeedListController)
