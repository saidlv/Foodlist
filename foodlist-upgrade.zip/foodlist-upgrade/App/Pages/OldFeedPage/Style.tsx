import { margins } from '@FoodListCore/Global/GlobalProps';
import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		backgroundColor: colors.greyBackground,
		height: "100%"
	},
	header: {
		backgroundColor: colors.white,
		shadowOffset: {
			width: 0,
			height: 5
		},
		shadowOpacity: 0.5
	},
	reviewButton: {
		flexDirection: 'row',
		paddingHorizontal: 25,
		paddingVertical: 15,
		alignItems: 'center',
	},
	button: {
		flex: 1,
		borderTopWidth: 2,
		borderLeftWidth: 1,
		borderRightWidth: 1,
		borderColor: colors.greyBackground,
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 10
	},
	list: {
		paddingVertical: 10,
	}
})