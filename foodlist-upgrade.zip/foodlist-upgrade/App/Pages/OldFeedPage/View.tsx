import React from 'react';
import { colors, length } from '@Global/GlobalProps';
import { StatusBar, Text, View } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './Style';
import SplashScreen from 'react-native-splash-screen';
import FeedItem from "@Components/FeedItem"
import LoadMoreList, { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import ProfileImage from '@Components/ProfileImage';
import ScrollViewBounceFix from '@Components/ScrollViewBounceFix'
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { User } from '@Models/User';
import { Review } from '@Models/Review';
import FeedItemMap from '@Components/FeedItem/map'
import { RequestResponse } from '@Models/RequestResponse';
import { GetFeedListResponse } from '@Network/FeedManager';
import { SearchParamList } from '@RouteParams/Search';
import { translate } from '@App/I18n';
import { userLogged } from '@FoodListCore/Redux/ReduxHelper';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import InlineButton from '@FoodListCore/Components/InlineButton';
import { margins } from '@FoodListCore/Global/GlobalProps';

export type FeedActions = {
	showPage: (page: keyof SearchParamList) => void
	onResponse: (body: RequestResponse<GetFeedListResponse>) => void
	listRef: (ref: LoadMoreListType<Review>) => void
	request: () => Promise<RequestResponse<GetFeedListResponse>>
	writeReview: () => void
	showRestaurants: (orders: boolean) => void
	refresh: () => void
}

type ViewProps = {
	user?: User
	data: Review[]

	actions: FeedActions
}

type ViewState = {
	hasData: boolean
}

class FeedList extends React.PureComponent<ViewProps, ViewState> {
	state: ViewState = {
		hasData: false
	}

	actions: FeedActions
	constructor(props: ViewProps) {
		super(props)
		this.actions = props.actions
	}

	onResponse(body: RequestResponse<GetFeedListResponse>) {
		this.actions.onResponse(body)
	}

	componentDidMount() {
		SplashScreen.hide();
		StatusBar.setHidden(false)
	}

	hasData = () => {
		return length(this.props.data) > 0
	}
	mapFeeds = () => {
		if (this.hasData()) {
			return this.props.data.map(FeedItemMap);
		}
		return []
	}
	render() {
		const { actions } = this
		if(!userLogged()) {
			return (
				<View style={{justifyContent: "center", alignItems: "center", height: "100%"}}>
					<Text>Non sei loggato</Text>
				</View>
			)
		}
		let headerComponent = (
			<>
			<View style={[CommonStyle.shadow, styles.header]}>
				<ScrollViewBounceFix color={colors.white} />
				<TouchableRipple onPress={actions.writeReview} style={styles.reviewButton}>
					<ProfileImage source={this.props.user?.photo ?? undefined} customSize={42} />
					<View style={{ flexDirection: 'column', marginHorizontal: 15, justifyContent: 'space-between', alignSelf: 'center' }}>
						<Text style={{ color: colors.greyText, fontSize: 16 }}>{translate("writeReviewDots")}</Text>
					</View>
				</TouchableRipple>
				{/* <View style={{ flexDirection: 'row' }}>
					<TouchableRipple onPress={() => actions.showPage("SuggestContacts")} style={styles.button}>
						<Text style={{ color: colors.blueMenu, fontSize: 14, fontWeight: '500', textAlign: 'center' }}><Icon name="user" />&nbsp; {translate("findYourFriends")}</Text>
					</TouchableRipple>
					<TouchableRipple onPress={() => actions.showPage("MapPage")} style={styles.button}>
						<Text style={{ color: colors.red, fontSize: 14, fontWeight: '500', textAlign: 'center' }}><Icon name="position" />&nbsp; {translate("inSurroundings")}</Text>
					</TouchableRipple>
				</View> */}
			</View>
			{/*
				<View style={{
					marginHorizontal: margins.pagePadding,
					marginVertical: 10,
					borderRadius: 8,
					overflow: "hidden",
					borderColor: colors.greyBorder,
					borderWidth: 1,
					flex: 0,
					flexDirection: "column"
				}}>
					<InlineButton
						icon="shopping-cart"
						title={translate("orderOnline")}
						onPress={() => actions.showRestaurants(true)}
					/>
					<InlineButton
						hideBorder={true}
						icon="calendar"
						title={translate("bookTable")}
						onPress={() => actions.showRestaurants(false)}
					/>
				</View>
			*/}
			</>
		)
		return (
			<View style={styles.container}>
				{headerComponent}
				<LoadMoreList<Review>
					request={actions.request}
					onEndReachedThreshold={4}
					listRef={actions.listRef}
					extraData={this.props}
					//ListHeaderComponent={headerComponent}
					noDataComponent={(
						<View style={{ alignItems: 'center' }}>
							<Text style={{ color: colors.greyInfoText, fontSize: 16, textAlign: 'center', marginHorizontal: margins.pagePadding, lineHeight: 22 }}>
								{translate("followYourFriendsMessage")}
							</Text>
							<TouchableOpacity onPress={() => actions.showPage("SuggestContacts")}>
								<Text style={{ fontSize: 16, marginTop: 12, fontWeight: 'bold', color: colors.blueMenu }}>{translate("findYourFriends")}</Text>
							</TouchableOpacity>
						</View>
					)}
					contentContainerStyle={styles.list}
					hasData={(hasData) => {
						this.setState({
							hasData: hasData
						})
					}}
					renderItem={({ item }) =>
						<FeedItem
							key={item.id + "_" + item.updated_at}
							item={FeedItemMap(item)}
							showDetail={true}
							callbackShouldReload={actions.refresh}
						/>
					} />
			</View>
		);
	}
}

export default FeedList
