import React from 'react';
import { colors, when, isDefined } from '@Global/GlobalProps';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import PickPhoto from '@FoodListCore/Components/PickPhoto'
import LoadingView from '@Components/LoadingView'
import { Text, TextInput, Keyboard, View, SafeAreaView } from 'react-native';
import styles from './Style';
import FormActionButton from '@Components/FormActionButton'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import SegmentedControl from '@FoodListCore/Components/SegmentedControl';
import AutoLoadingView from '@FoodListCore/Components/AutoLoadingView'
import globalStyles from '@FoodListCore/Global/CommonStuff/PageStyle';
import { Restaurant } from '@Models/Restaurant';
import { Review, SuggestReview } from '@Models/Review';
import { ImageForMultipart } from '@Models/ImageForMultipart';
import { Photo } from '@Models/Photo';
import { Dish } from '@Models/Dish';
import { NewDish } from '@Models/NewDish';
import GenericChooser from '@Components/OptionChooser/GenericChooser';
import { translate } from '@App/I18n';
import { Empty } from '@Models/Empty';
import { margins } from '@FoodListCore/Global/GlobalProps';
import InsertRating from '@FoodListCore/Components/InsertRating';
import DeliveryDelay from '@FoodListCore/Pages/ReviewOrderPage/DeliveryDelay';
import { RatingForRequest } from '@Models/Rating';
import { RowHeader } from '@FoodListCore/Components/ReviewCell';
import { getDishSectionName } from '@FoodListCommon/menu';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { Switch } from 'react-native-paper';

export interface FastReviewActions {
	newDishReview: (params: SuggestReview) => void,
	dishReview: (rating_quality: number, rating_price: number, content: string, photo: ImageForMultipart | null, dish_id: number, imageRemoved: boolean, reviewId?: number) => void,
	restaurantReview: (ratings: RatingForRequest, content: string, imageRemoved: boolean, photo: ImageForMultipart | null, restaurantId: number, reviewId?: number) => void
	updateHasContent: (hasContent: boolean) => void,
	select: (index: 0 | 1, restaurant: Restaurant | null, dish?: Dish | NewDish | null) => void,
	loadReview: (id: number, isDish: boolean) => void,
	resetReview: () => void,
	retryLoadReview: () => void,
}

export type ReviewMode = "fast" | "restaurant" | "dish"


type Props = {
	restaurant?: Restaurant
	dish?: Dish
	review: Review | null
	isDish: boolean
	autoLoading: boolean
	loading: boolean
	reviewMode: ReviewMode
	error: string | null

	actions: FastReviewActions
}

type State = {
	dishContent: string
	restaurantContent: string
	vote?: number
	location?: number | null
	price?: number | null
	quality?: number | null
	service?: number | null
	punctuality?: number | null
	delta_time?: number | null
	reviewDetail: Review | null
	photo: ImageForMultipart | null
	imageRemoved?: boolean
	initialDishContent: string
	initialRestaurantContent: string
	initialPhoto?: Photo | null
	initialPhotos?: Photo[]
	restaurant: Restaurant | null
	dish: Dish | NewDish | null
	photoRemoved: boolean //TODO: consider moving to this.photoRemoved
	reviewId?: number
	showPunctuality?: boolean
	canChangeRestaurantReviewMode: boolean
}

export default class FastReviewPage extends React.PureComponent<Props, State> {
	pickPhoto?: PickPhoto
	actions: FastReviewActions

	constructor(props: Props) {
		super(props);
		this.state = {
			dishContent: "",
			restaurantContent: "",
			reviewDetail: null,
			restaurant: props.restaurant || null,
			dish: props.dish || null,
			photoRemoved: false,
			photo: null,
			initialDishContent: "",
			initialRestaurantContent: "",
			showPunctuality: true,
			canChangeRestaurantReviewMode: true,
		}
		this.actions = props.actions
	}
	componentDidMount() {
		this.clearInput();
	}
	componentDidUpdate(prevProps: Props) {
		if (this.props.review != prevProps.review) {
			let review = this.props.review || ({} as Empty)

			const overwriteIfNotSetOrUpdated = <S extends keyof State, R extends keyof Review>(stateKey: S, reviewKey: R) => {
				if (this.state[stateKey] != prevProps.review?.[reviewKey]) {
					return this.state[stateKey] || review[reviewKey]
				}
				return review[reviewKey]
			}
			const ov = overwriteIfNotSetOrUpdated
			/*if(this.state.content == "") {
				this.state.content = null //seems wrong but it's exatly what I have to do
			}
			if(this.state.initialContent == "") {
				this.state.initialContent = null //seems wrong but it's exatly what I have to do
			}
			if(this.state.vote == 0) {
				this.state.vote = null
			}*/
			this.pickPhoto?.clearImageRemoved()
			let newValues: Partial<State> = {
				service: ov("service", "rating_service"),
				location: ov("location", "rating_location"),
				punctuality: ov("punctuality", "rating_punctuality"),
				quality: ov("quality", "rating"), //dish
				//@ts-ignore
				price: ov("price", "price_rating"), //dish
				initialPhoto: (review.photos && review.photos.length != 0) ? review.photos[0] : null,
				initialPhotos: review.photos,
				reviewId: review.id,
				photoRemoved: false,
				showPunctuality: !review.id || !!review.rating_punctuality,
				delta_time: review.rating_punctuality ? review.delta_time : null,
				canChangeRestaurantReviewMode: !review.booking_id && !review.order_id,
			}
			if (this.props.isDish) {
				let content = ov("dishContent", "content") || ""
				newValues.initialDishContent = content
				newValues.dishContent = content
			} else {
				let content = ov("restaurantContent", "content") || ""
				newValues.initialRestaurantContent = content
				newValues.restaurantContent = content
			}
			this.setState(newValues as Pick<State, keyof State>)
		}
	}
	clearInput() {
		this.setState({ dishContent: "", restaurantContent: "", vote: 0, photo: null })
	}
	clearRestaurant = () => {
		this.setState({
			restaurant: null,
			dish: null
		})
	}
	clearDish = () => {
		this.setState({
			dish: null
		})
	}

	onSubmit = () => {
		Keyboard.dismiss();
		if (this.props.isDish) {
			if(!this.state.dish) return
			if (!this.state.quality || !this.state.price) return
			if (!('id' in this.state.dish)) {
				if (!this.state.restaurant?.id) return
				this.actions.newDishReview({
					photo: this.state.photo,
					dishName: this.state.dish.name,
					category: this.state.dish.category ?? "",
					rating_quality: this.state.quality,
					rating_price: this.state.price,
					content: this.state.dishContent,
					price: this.state.dish.price?.toString(),
					restaurant_id: this.state.restaurant?.id
				});
			} else {
				this.actions.dishReview(this.state.quality, this.state.price, this.state.dishContent, this.state.photo, this.state.dish.id, this.state.photoRemoved, this.state.reviewId);
			}
		} else {
			const { showPunctuality, service, location, punctuality, delta_time, restaurant } = this.state
			if(service && (showPunctuality ? punctuality : location) && restaurant) {
				this.actions.restaurantReview({
					rating_service: service,
					rating_location: showPunctuality ? null : location,
					rating_punctuality: showPunctuality ? punctuality : null,
					from_home: showPunctuality || false,
					delta_time: delta_time ?? undefined,
				}, this.state.restaurantContent, this.state.photoRemoved, this.state.photo, restaurant.id, this.state.reviewId);
			}
		}
	}

	onImagePicked = (photo: ImageForMultipart | null) => {
		this.setState({
			photo: photo,
			photoRemoved: true
		}, this.updateHasContent)
		//this.actions.onContentUpdated(this.getContent(), photo, this.state.vote);
	}

	updateHasContent = () => {
		let hasContent = (!!this.state.restaurant || !!this.state.photo || this.state.restaurantContent.length > 0 || this.state.dishContent.length > 0 || (!!this.state.vote && this.state.vote > 0)
			|| (this.state.service ?? 0) > 0 || (this.state.location ?? 0) > 0 || (this.state.quality ?? 0) > 0 || (this.state.price ?? 0) > 0)
		this.actions.updateHasContent(hasContent)
	}

	getDishTypesForModal = () => {
		let res: { name: string }[] = [];
		if (!this.props.restaurant || !this.props.restaurant.dish_types) return res;
		for (let i = 0; i < this.props.restaurant.dish_types.length; i++) {
			res.push({
				name: this.props.restaurant.dish_types[i].label_it ?? ""
			});
		}
		return res;
	}

	hasPhoto() {
		return this.state.photo || (this.state.initialPhoto && !this.state.photoRemoved)
	}

	getContent = () => {
		return this.props.isDish ? this.state.dishContent : this.state.restaurantContent
	}
	getInitialContent = () => {
		return this.props.isDish ? this.state.initialDishContent : this.state.initialRestaurantContent
	}

	updateRatingKey = (key: string & ("service" | "location" | "quality" | "price" | "punctuality" | "delta_time"), value: number | null) => {
		this.setState({
			[key]: value
		}, this.updateHasContent)
	}

	updateShowPunctuality = (showPunctuality: boolean) => {
		this.setState({ showPunctuality })
	}
	
	render() {
		const isOrderReview = !!this.props.review?.order_id
		let showText = this.props.isDish ? (!!this.state.price && !!this.state.quality) : (
			(!!this.state.location || (!!this.state.punctuality && (!isOrderReview || (!!this.state.delta_time || this.state.delta_time === 0))))
			&& !!this.state.service
		)
		let reviewItemSelected = !!this.state.restaurant && (!this.props.isDish || !!this.state.dish)
		let buttonEnabled = (/* (this.hasPhoto() || this.getContent().length > 0) && */ showText && reviewItemSelected)

		const { reviewMode, isDish } = this.props
		const { showPunctuality } = this.state
		return (
			<View style={{ flex: 1 }}>
				<SafeAreaView style={styles.container}>
					<AutoLoadingView
						loading={this.props.autoLoading}
						error={this.props.error}
						onRetry={this.actions.retryLoadReview}
					/>
					<LoadingView visible={this.props.loading} />
					<KeyboardAwareScrollView
						keyboardShouldPersistTaps="handled">

						{reviewMode == "dish" ? (
							<></>
						) : this.props.restaurant ? (
							<Text style={[globalStyles.title, { color: colors.black, marginTop: 10}]}>{this.props.restaurant?.name}</Text>
						) : (
							<>
							<Text style={{ fontWeight: "bold", fontSize: 18, marginTop: margins.pagePadding, marginHorizontal: margins.pagePadding, marginBottom: 10 }}>{translate("selectRestaurant")}</Text>
							<View style={commonStyle.borderVertical}>
								<GenericChooser
									title={<Text style={{ fontWeight: "bold", color: this.state.restaurant ? colors.black : colors.blueMenu }}>{this.state.restaurant ? this.state.restaurant.name : translate("selectRestaurant")}</Text>}
									customModal={(navigation) => {
										navigation.push("NewSearch", {
											selectRestaurant: true,
											onItemSelected: (item) => {
												this.setState({ restaurant: item, dish: null }, this.updateHasContent)
												if (!this.props.isDish) {
													this.actions.loadReview(item.id, false)
												} else {
													this.actions.resetReview()
												}
											},
											onDishSelected: (dish, restaurant) => {
												navigation.goBack()
												this.setState({ restaurant, dish }, this.updateHasContent)
												this.actions.loadReview(dish.id, true)
											},
										})
									}}
									customLabel={() => {
										return <Text style={{ flex: 1, textAlign: 'right', color: this.state.restaurant ? colors.blueMenu : colors.red }} numberOfLines={1}>
											{this.state.restaurant ? translate("change") : translate("notSet")}
										</Text>
									}}
								/>
							</View>
							</>
						)}
						
						{reviewMode == "fast" && (
						<View style={[styles.contentView, { flexGrow: 1, marginTop: 20 }]}>
							<Text style={{marginHorizontal: 20, marginBottom: 10, textAlign: "center"}}>{translate("whatToReview")}</Text>
							<View style={{ marginBottom: 20 }}>
								<SegmentedControl
									activeButtonTextColor={colors.greyBackground}
									mainColor={colors.blueMenu}
									selected={this.props.isDish ? 0 : 1}
									items={[
										{ text: translate("singleDish"), callback: () => this.actions.select(0, this.state.restaurant, this.state.dish) },
										{ text: translate("restaurant"), callback: () => this.actions.select(1, this.state.restaurant) }
									]}
								/>
							</View>
						</View>
						)}

						{reviewMode == "dish" ? (
							<View style={{ padding: margins.pagePadding }}>
								<RowHeader item={{ dish: this.props.dish, dish_name: this.props.dish?.name, dish_section_name: getDishSectionName(this.props.dish), price: this.props.dish?.price }} />
							</View>
						) : this.props.isDish ? (
							<View style={[commonStyle.borderVertical, { marginBottom: 20 }]}>
								<GenericChooser
									disabled={!this.state.restaurant}
									title={translate("singleDish")}
									customModal={(navigation) => {
										navigation.navigate("SelectDish", {
											restaurant_id: this.state.restaurant?.id,
											onDishSelected: (item: Dish) => {
												this.setState({ dish: item }, this.updateHasContent)
												this.actions.loadReview(item.id, true)
											},
											onNewDishSelected: (item: NewDish) => {
												this.setState({ dish: item }, this.updateHasContent)
											}
										})
									}}
									customLabel={() => {
										return <Text style={[{ flex: 1, textAlign: 'right' }, when(!isDefined(this.state.dish), { color: colors.red })]} numberOfLines={1}>{this.state.dish?.name ?? translate("notSet")}</Text>
									}}
								/>
							</View>
						) : <></>}

						<TextInput
							textAlignVertical="top"
							defaultValue={this.getInitialContent()}
							onChangeText={(v) => {
								if (this.props.isDish) {
									this.setState({
										dishContent: v
									}, this.updateHasContent)
								} else {
									this.setState({
										restaurantContent: v
									}, this.updateHasContent)
								}
							}}
							multiline={true}
							style={[styles.description, commonStyle.rounded, commonStyle.shadow]}
							placeholder={translate("expressJudgement")}
						/>

						
						<View style={{ marginVertical: 10, paddingHorizontal: margins.pagePadding }}>
							{this.props.isDish ? (
								<>
									<InsertRating
										title={translate("quality")}
										value={this.state.quality || 0}
										onChange={v => this.updateRatingKey("quality", v)}
										mode="quality"
									/>
									<InsertRating
										title={translate("price")}
										value={this.state.price || 0}
										onChange={v => this.updateRatingKey("price", v)}
										mode="price"
									/>
								</>
							) : (
								<>
									{this.state.canChangeRestaurantReviewMode && (
										<TouchableRipple
											style={{ backgroundColor: colors.white, paddingHorizontal: margins.pagePadding, paddingVertical: margins.vertical, borderWidth: 1, borderColor: colors.greyBorder, borderRadius: 40, marginTop: 20 }}
											borderless
											onPress={() => this.updateShowPunctuality(!showPunctuality)}
										>
											<View style={{ flexDirection: "row", alignItems: "center" }}>
												<Text style={{ flex: 1 }}>{translate("reviewingOrder")}</Text>
												<Switch value={showPunctuality} onValueChange={this.updateShowPunctuality} />
											</View>
										</TouchableRipple>
									)}
									{!showPunctuality && (
										<InsertRating
											title={translate("location")}
											value={this.state.location || 0}
											onChange={(v) => this.updateRatingKey("location", v)}
											mode="quality"
										/>
									)}
									<InsertRating
										title={translate("service")}
										value={this.state.service || 0}
										onChange={(v) => {
											this.updateRatingKey("service", v)
										}}
										mode="quality_male"
									/>

									{showPunctuality && (
										<>
											<InsertRating
												title={translate("punctuality")}
												value={this.state.punctuality || 0}
												onChange={(v) => {
													this.updateRatingKey("punctuality", v)
												}}
												mode="quality"
											/>
											<DeliveryDelay
												setDelay={(v) => this.updateRatingKey("delta_time", v)}
												value={this.state.delta_time ?? undefined}
												optional={!isOrderReview}
											/>
										</>
									)}
								</>
							)}
						</View>
						<View style={{ marginBottom: 20, marginTop: 20 }}>
							<PickPhoto
								ref={ref => this.pickPhoto = ref ?? undefined}
								initialImage={{ uri: this.state.initialPhoto?.thumbUrl }}
								size={120}
								onImagePicked={(v) => this.onImagePicked(v)}
							/>
						</View>

						{showText && reviewItemSelected && !buttonEnabled && (
							//* Inserisci una foto o esprimi il tuo giudizio per inviare la recensione
							<Text style={{ marginHorizontal: 20, marginBottom: 10, color: 'red' }}>* {translate("insertPhotoOrComment")}</Text>
						)}
						<View style={{ marginBottom: 10 }}>
							<FormActionButton
								full={true}
								title={translate(this.state.reviewId ? "updateReview" : "sendReview")}
								onPress={this.onSubmit}
								enabled={buttonEnabled}
							/>
						</View>
					</KeyboardAwareScrollView>
				</SafeAreaView>
			</View>
		);
	}
}