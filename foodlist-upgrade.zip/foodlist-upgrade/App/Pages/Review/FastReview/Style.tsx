import { margins } from '@FoodListCore/Global/GlobalProps';
import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: colors.greyBackground,
		flexDirection: "column"
	},
	ratingStarsView: {
		alignSelf: "center",
		marginTop: 30,
		marginBottom: 30
	},
	description: {
		fontSize: 16,
		backgroundColor: colors.white,
		fontWeight: "normal",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText,
		paddingTop: 20,
		paddingLeft: 20,
		paddingRight: 20,
		paddingBottom: 20,
		marginHorizontal: margins.pagePadding,
		marginTop: 10
	},
	contentView: {
		flex: 1,
		flexDirection: "column"
	},
})
