import React, { useCallback, useRef } from 'react';
import { Alert } from 'react-native';
import FastReviewPage, { FastReviewActions, ReviewMode } from "./view"
import ReviewManager, { DishReviewValues } from "@FoodListCore/Network/ReviewManager"
import { confirmExit, isDefined, error } from '@Global/GlobalProps';
import SuggestManager, { NewDishReviewResponse } from '@Network/SuggestManager';
import { User } from '@Models/User';
import { Restaurant } from '@Models/Restaurant';
import { Review } from '@Models/Review';
import { RatingForRequest } from '@Models/Rating';
import { ImageForMultipart } from '@Models/ImageForMultipart';
import { RequestResponse } from '@Models/RequestResponse';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';
import { translate } from '@App/I18n';
import useOverrideBackPress from '@FoodListCore/Components/OverrideBackHook';
import { showError } from '@FoodListCore/Global/GlobalProps';
import { Dish } from '@Models/Dish';
/*
 *  UTILIZZO: passare alla navigation il parametro
 *  dishId, che denota l'id del piatto da recensire
 *  dishTypeId, che denota l'id della categoria del piatto da recensire
 *
 */

type Props = {
	user: User
	navigation: CommonNavigation<"FastReview">
	route: CommonRoute<"FastReview">
}

type State = {
	loading: boolean
	autoLoading: boolean
	isDish: boolean
	review: Review | null
	edit_review_id?: number
	error: string | null
}
class FastReview extends React.PureComponent<Props, State> {
	page: FastReviewPage | null
	hasContent: boolean
	//onlyStarsInserted: boolean = false
	manager = new ReviewManager()
	callbackShouldReload?: () => void
	restaurant: Restaurant | null
	dish: Dish | null
	reviewMode: ReviewMode

	constructor(props: Props) {
		super(props);

		this.page = null;
		this.hasContent = false;

		const { restaurant, dish, callbackShouldReload, reviewMode, edit_review } = props.route.params || {}

		this.reviewMode = reviewMode || "fast"
		const loadReview = this.reviewMode != "fast" && !!restaurant && !edit_review
		this.state = {
			loading: false,
			error: null,
			autoLoading: loadReview,
			isDish: reviewMode != "restaurant",
			review: null,
		};
		this.restaurant = restaurant ?? null
		this.dish = dish ?? null
		this.callbackShouldReload = callbackShouldReload
		if(loadReview) {
			this.loadOldReviews()
		} else {
			setTimeout(() => {
				this.setState({
					review: edit_review || null
				})
			})
		}
	}

	loadOldReviews = () => {
		const { dish, restaurant } = this
		if(dish) {
			this.loadReview(dish.id, true)
		} else if(restaurant) {
			this.loadReview(restaurant.id)
		}
	}

	realGoBack = () => {
		this.props.navigation.goBack()
	}

	missingContent = (content: string, photo: ImageForMultipart | null) => {
		return photo == null && (content == null || content.length == 0);
	}

	restaurantReview = (ratings: RatingForRequest, content: string, imageRemoved: boolean, photo: ImageForMultipart | null, restaurantId: number, reviewId?: number) => {
		this.setState({ loading: true });

		const rating: RatingForRequest = {
			...ratings
		}

		if (reviewId) {
			this.manager.modifyRestaurantReview(restaurantId, reviewId, rating, content, imageRemoved, photo).then((response) => {
				this.setState({ loading: false });
				this.callbackShouldReload?.()
				this.realGoBack();
			}).catch((err) => {
				this.setState({ loading: false });
				error(err);
			})
		} else {
			this.manager.restaurantReview(restaurantId, rating, content, photo).then((response) => {
				this.setState({ loading: false });
				this.callbackShouldReload?.()
				this.realGoBack();
			}).catch((err) => {
				this.setState({ loading: false });
				error(err);
			})
		}
	}

	handleResponse = (response: RequestResponse<NewDishReviewResponse>) => {
		if (response.success) {
			this.alert(translate("suggestReceivedTitle"), translate("suggestReceivedMessage"));
			this.realGoBack();
		} else {
			this.alert(translate("error"), translate("errorOccuredRetry"));
		}
	}

	loadReview = (id: number, isDish?: boolean) => {
		if(this.reviewMode == "fast") {
			this.setState({
				loading: true,
				review: null,
				error: null,
			})
		} else {
			this.setState({
				autoLoading: true,
				error: null,
			})
		}
		if(this.state.edit_review_id) return
		this.manager.getPreviousReview(id, isDish ?? false).then((body) => {
			this.setState({
				loading: false,
				autoLoading: false,
			})
			let review = body?.data?.review || null
			if ((!isDish || this.reviewMode == "dish") && this.restaurant) {
				this.setState({
					review: review
				})
			} else if (review) {
				Alert.alert(
					translate("alreadyReviewedTitle", { feed_type: isDish ? translate("singleDish").toLowerCase() : translate("restaurant").toLowerCase() }),
					translate("wantToEditReview"),
					[{
						text: translate("yes"),
						style: 'destructive',
						onPress: () => {
							this.setState({
								review: review
							})
						}
					}, {
						text: translate("no"),
						onPress: () => {
							if (isDish) {
								this.page?.clearDish()
							} else {
								this.page?.clearRestaurant()
							}
						}
					}]);
			} else {
				this.setState({
					review: null
				})
			}
		}).catch(err => {
			showError(err)
			this.setState({
				loading: false,
				autoLoading: false,
			})
			if(this.reviewMode == "fast") {
				if (isDish) {
					this.page?.clearDish()
				} else {
					this.page?.clearRestaurant()
				}
			} else {
				this.setState({
					error: translate("errorEncountered")
				})
			}
		})
	}

	alert = (title: string, message: string) => {
		Alert.alert(title, message, [{ text: translate("actionClose"), onPress: () => { } }]);
	}
	updateHasContent = (hasContent: boolean) => {
		/*if(hasContent != this.hasContent) {
			this.props.navigation.setParams({blockSwipe: hasContent})
		}*/
		this.hasContent = hasContent
	}

	actions: FastReviewActions = {
		select: (index, restaurant, dish) => {
			this.setState({
				isDish: (index == 0)
			})
			if (dish && 'id' in dish) {
				this.loadReview(dish.id, true)
			} else if (index == 1 && isDefined(restaurant?.id)) {
				this.loadReview(restaurant!.id, false)
			}
		},

		dishReview: (rating_quality, rating_price, content, photo, dish_id, photoRemoved, reviewId) => {
			this.setState({ loading: true });

			const reviewParams: DishReviewValues = {
				rating: rating_quality,
				price_rating: rating_price,
				content,
				remove_photo: photoRemoved,
			}
			if (reviewId) {
				this.manager.modifyDishReview(dish_id, reviewId, reviewParams, photo).then((response) => {
					this.setState({ loading: false });
					this.callbackShouldReload?.()
					this.realGoBack();
				}).catch((err) => {
					this.setState({ loading: false });
					error(err);
				})
			} else {
				this.manager.dishReview(dish_id, reviewParams, photo).then((response) => {
					this.setState({ loading: false });
					this.callbackShouldReload?.()
					this.realGoBack();
				}).catch((err) => {
					this.setState({ loading: false });
					error(err);
				})
			}
		},

		newDishReview: async (body) => {
			let suggestManager = new SuggestManager();
			try {
				this.setState({ loading: true });
				let response = await suggestManager.newDishReview(body);
				this.setState({ loading: false });
				this.handleResponse(response)
			} catch (err) {
				showError(err)
				this.setState({ loading: false });
			}
		},

		restaurantReview: this.restaurantReview,
		updateHasContent: this.updateHasContent,
		loadReview: this.loadReview,
		resetReview: () => {
			this.setState({ review: null })
		},
		retryLoadReview: this.loadOldReviews
		//onContentUpdated: this.onContentUpdated
	}

	render() {
		return (
			<FastReviewPage
				actions={this.actions}
				ref={component => this.page = component}
				loading={this.state.loading}
				isDish={this.state.isDish}
				autoLoading={this.state.autoLoading}
				review={this.state.review}
				restaurant={this.restaurant ?? undefined}
				dish={this.dish ?? undefined}
				reviewMode={this.reviewMode}
				error={this.state.error}
			/>
		);
	}
}

const FastReviewContainer = (props: Props) => {
	const pageRef = useRef<FastReview>(null)
	const handleBackPress = useCallback(() => {
		confirmExit(() => {
			props.navigation.goBack()
		}, pageRef.current?.hasContent || false)
		return true
	}, [])

	useOverrideBackPress(handleBackPress)

	return <FastReview {...props} ref={pageRef} />
}

export default FastReviewContainer;