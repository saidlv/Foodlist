/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { colors } from '@Global/GlobalProps';
import CurvedHeader from '@Components/CurvedHeader';

const instructions = Platform.select({
	ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
	android:
		'Double tap R on your keyboard to reload,\n' +
		'Shake or press menu button for dev menu',
});

type Props = {};
export default class App extends React.PureComponent<Props> {
	render() {
		return (
			<View style={[styles.container, { backgroundColor: colors.greyBackground }]}>
				<CurvedHeader source={require('@testImages/3.jpg')} backgroundColor={colors.greyBackground} customHeight={160} />

				<Icon name={'logo'} size={150} color={colors.red} />

				<View style={{ flex: 1, flexDirection: 'row' }}>
					<Icon name={'photo-2'} size={32} color={colors.greyText} />
					<Icon name={'phone'} size={24} color={colors.starColor} style={{ paddingLeft: 10, paddingRight: 10 }} />
					<Icon name={'sidebar'} size={24} color="#000" />
				</View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#F5FCFF',
	},
	welcome: {
		fontSize: 20,
		textAlign: 'center',
		margin: 10,
	},
	instructions: {
		textAlign: 'center',
		color: '#333333',
		marginBottom: 5,
	},
});
