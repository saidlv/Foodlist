import React from 'react';
import { StatusBar, FlatList, RefreshControl, Text, View } from 'react-native';
import { setNotificationRead } from '@Redux/Actions';
import styles from './Style';
import LoadingView from '@Components/LoadingView';
import NotificationCell from "./NotificationCell";
import { getNotificationIdentifier } from '@Global/GlobalProps';
import { connect } from 'react-redux';
import { ReduxState } from '@Redux/StateFormat';
import { Dispatch } from 'redux';
import { Notification } from '@Models/Notification';
import { translate } from '@App/I18n';

type Props = {
	dispatch: Dispatch
	loading: boolean
	refreshing: boolean
	notifications: Notification[]
	unread_notifications: string[]
	onPress: (notification: Notification) => void
	userRequestedReload: () => void
}

class NotificationsPage extends React.PureComponent<Props> {
	componentDidMount() {
		StatusBar.setHidden(false)
	}
	isNotRead(notification: Notification) {
		let key = getNotificationIdentifier(notification)
		if (this.props.unread_notifications.indexOf(key) >= 0) {
			return true
		} else {
			return false
		}
	}
	onPress = (item: Notification) => {
		this.props.dispatch(setNotificationRead(getNotificationIdentifier(item)))
		this.props.onPress(item)
	}
	render() {
		return (
			<View style={styles.container}>
				<LoadingView visible={this.props.loading} />
				{(this.props.notifications.length > 0 || this.props.refreshing) ?
					<FlatList
						style={styles.containerList}
						refreshControl={
							<RefreshControl
								style={{ zIndex: 10 }}
								refreshing={this.props.refreshing}
								onRefresh={this.props.userRequestedReload}
							/>
						}
						data={this.props.notifications}
						keyExtractor={(x, i) => i.toString()}
						renderItem={({ item }) =>
							<NotificationCell
								notRead={this.isNotRead(item)}
								notification={item}
								onPress={this.onPress}
							/>
						}
					/>
					:
					<Text style={{ marginHorizontal: 30, textAlign: 'center' }}>{translate("noNotifications")}</Text>
				}
			</View>
		);
	}
}

export default connect((state: ReduxState) => {
	return {
		unread_notifications: state.unread_notifications ?? []
	}
})(NotificationsPage)