import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		backgroundColor: colors.greyBackground,
		height: '100%',
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center'
	},
	containerList: {
		height: '100%',
		alignSelf: 'flex-start'
	}
});
