import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		padding: 5,
		alignItems: "center",
		flexDirection: "row",
		justifyContent: 'space-between',
		flex: 1,
	},
	textContainer: {
		flex: 1,
		flexDirection: "column",
		justifyContent: "space-between"
	},
	username: {
		height: 16,
		fontSize: 14,
		fontWeight: "bold",
		fontStyle: "normal",
		lineHeight: 16,
		letterSpacing: 0,
		color: colors.link
	},
	content: {
		marginRight: 20,
		fontSize: 14,
		fontWeight: "normal",
		fontStyle: "normal",
		lineHeight: 16,
		letterSpacing: 0,
		color: colors.link
	},
	followButton: {
		width: 71,
		height: 24,
		margin: 0,
		marginLeft: 0,
		marginRight: 0,
		marginTop: 0,
		marginBottom: 0,
		alignSelf: "flex-end",
		borderRadius: 12
	},
	followButtonText: {
		fontWeight: "bold",
		fontStyle: "normal",
		letterSpacing: 0,
		textAlign: "center",
		fontSize: 10
	},
	itemImage: {
		width: 48,
		height: 48,
		marginRight: 15
	},
	userImageContainer: {
		marginLeft: 20,
		marginRight: 20,
		marginTop: 13,
		marginBottom: 13,
		alignItems: "center"
	},
	separator: {
		backgroundColor: colors.separator,
		height: 1,
		marginTop: 0
	},
	accessoryContainer: {
		marginTop: 13,
		marginBottom: 13,
		alignItems: "flex-end"
	},
	appImage: {
		width: 32,
		height: 32,
		alignItems: "center",
		justifyContent: "center",
		backgroundColor: colors.foodlist,
		borderRadius: 16
	},
	date: {
		marginTop: 2,
		fontSize: 12,
		color: colors.greyText
	}
});
