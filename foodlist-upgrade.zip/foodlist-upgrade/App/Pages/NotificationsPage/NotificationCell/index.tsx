import React from 'react';
import { View, Text } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from "./Style"
import { colors, when } from "@Global/GlobalProps"
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import ProfileImage from "@Components/ProfileImage"
import FollowButton from "@Components/FollowButton/FollowButton"
import { Notification, FollowerNotification } from '@Models/Notification';
import { getDiffStringFromNow } from '@FoodListCore/Services/DateManager';
import FLImage from '@FoodListCore/Components/FLImage';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { translate } from '@FoodListCore/I18n';

type Props = {
	notification: Notification
	notRead?: boolean
	onPress: (notification: Notification) => void
}

const isFollowing = (notification: FollowerNotification) => {
	return notification.follower?.is_followed ?? false
}

export default class NotificationCell extends React.PureComponent<Props> {
	getUser() {
		const item = this.props.notification;
		//console.log("notif", item.type, item)
		switch (item.type) {
			case "follower": return item.follower;
			case "dish_review_like": return item.review_dish_like.user;
			case "dish_review_comment": return item.review_dish_comment.user;
			case "restaurant_review_like": return item.review_restaurant_like.user;
			case "restaurant_review_comment": return item.review_restaurant_comment.user;
		}
	}

	componentDidMount() {
	}
	getReview() {
		const item = this.props.notification;
		switch (item.type) {
			case "follower": return null;
			case "dish_review_status": return item.review_dish;
			case "dish_review_like": return item.review_dish_like.review_dish;
			case "dish_review_comment": return item.review_dish_comment.review_dish;
			case "restaurant_review_status": return item.review_restaurant;
			case "restaurant_review_like": return item.review_restaurant_like.review_restaurant;
			case "restaurant_review_comment": return item.review_restaurant_comment.review_restaurant;
		}
	}
	getNotificationText() {
		return this.props.notification.body;
	}
	getNotificationTitle() {
		return this.props.notification.title;
	}
	getDate() {
		const item = this.props.notification;
		return getDiffStringFromNow(item.created_at, translate)
	}
	getItemImage() {
		const review = this.getReview();
		if (review == null) return null;
		if (review.photos && review.photos.length > 0) return { uri: review.photos[0].thumbUrl };
		return null;
	}
	isUnRead() {
		return this.props.notRead || this.props.notification.read_at == null;
	}
	render() {
		const user = this.getUser();
		const image = this.getItemImage()

		return (
			<TouchableRipple onPress={() => { this.props.onPress(this.props.notification) }} style={{ flex: 1, flexDirection: "column", backgroundColor: colors.greyBackground }}>
				<View style={[styles.container, when(this.isUnRead(), { backgroundColor: colors.withAlpha(colors.blueMenu, 220) })]}>
					<View style={styles.userImageContainer}>
						{!!user && <ProfileImage source={user.photo} />}
						{!user && (
							<View style={styles.appImage}>
								<Icon name="logo-img" color={colors.white} size={16} />
							</View>
						)}
					</View>
					<View style={styles.textContainer}>
						<Text style={styles.username}>{this.getNotificationTitle()}</Text>
						<Text numberOfLines={3} style={styles.content}>{this.getNotificationText()}</Text>
						<Text style={styles.date}>{this.getDate()}&nbsp;&nbsp;{this.isUnRead() ? <Text style={{ color: colors.blueMenu, fontSize: 15 }}>•</Text> : undefined}</Text>
					</View>
					{this.props.notification.type == "follower" ? (
						<FollowButton
							userName={user?.username ?? ""}
							userId={this.props.notification.follower_id}
							following={isFollowing(this.props.notification)}
						/>
					) : (!!image && <FLImage style={styles.itemImage} source={image} /> )}
				</View>
				<View style={styles.separator} />
			</TouchableRipple>
		);
	}
}
