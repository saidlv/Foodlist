import React from 'react';
import NotificationsManager from '@FoodListCore/Network/NotificationsManager';
import { getNotificationIdentifier, error } from '@Global/GlobalProps';
import NotificationsPage from './view'
import { connect } from "react-redux"
import { setNotifications, setNotReadNotifications } from "@Redux/Actions"
import { store } from '@Redux/Reducer'
import { Dispatch } from 'redux';
import { ReduxState } from '@Redux/StateFormat';
import { Notification } from '@Models/Notification';
import { ReviewToLoad } from '@Models/ReviewToLoad';
import { CommonNavigation } from '@RouteParams/Common';
import { AuthNavigation } from '@RouteParams/Auth';
import { Pluto } from '@Models/Pluto';

type Props = {
	navigation: CommonNavigation<"Notifications">
	dispatch: Dispatch
	notifications: Notification[]
}

type State = {
	loading: boolean
	refreshing: boolean
	notifications?: Notification[]
}

class NotificationsPageContainer extends React.PureComponent<Props, State> {
	manager = new NotificationsManager()

	constructor(props: Props) {
		super(props);
		this.state = {
			loading: false,
			refreshing: false
		}
	}

	componentDidMount() {
		this.props.navigation.addListener("focus", this.pageWillFocus);
	}
	componentWillUnmount() {
		this.props.navigation.removeListener("focus", this.pageWillFocus);
	}

	updateNotReadNotifications = (notifications = this.props.notifications) => {
		let not_read_notifications = []
		//console.log("Previous Not read", not_read_notifications)
		for (var i in notifications) {
			const notif = notifications[i];
			if (notif.read_at == null) {
				not_read_notifications.push(getNotificationIdentifier(notif))
				notif.read_at = new Date();
			}
		}
		this.props.dispatch(setNotReadNotifications(not_read_notifications));
	}
	readNotifications = () => {
		this.manager.setRead().then(() => {
		});
	}
	pageWillFocus = () => {
		//console.log("Reload on focus")
		this.load()
	}
	load = () => {
		this.setState({ refreshing: true })
		this.props.dispatch(setNotifications([]));
		this.manager.list().then((notifications) => {
			if (notifications) {
				//console.log(notifications);
				this.props.dispatch(setNotifications(notifications))
				this.updateNotReadNotifications(notifications)
				this.readNotifications()
				this.setState({ refreshing: false, notifications: notifications })
			} else {
				this.setState({
					refreshing: false
				})
			}
		}).catch(error)
	}
	userRequestedReload = () => {
		//console.log("User requested reload")
		this.props.dispatch(setNotReadNotifications([]))
		this.load()
	}
	indexOf(id: number) {
		for (let i in this.state.notifications) {
			if (this.state.notifications[parseInt(i)].id == id) return i;
		}
		return -1;
	}
	static onUserDetail(id: number, navigation: CommonNavigation<Pluto>, onBack?: () => void) {
		navigation.push("ProfilePage", { user_id: id, onBack: onBack })
	}

	static showOrder(order_id: number, navigation: CommonNavigation<Pluto>, onBack?: () => void) {
		navigation.push("NotificationOrderDetail", { order_id, onBack, from_notification: true })
	}

	static showBooking(booking_id: number, navigation: CommonNavigation<Pluto>, onBack?: () => void) {
		navigation.push("NotificationBookingDetail", { booking_id })
	}

	static onReviewDetail(review_id: number | undefined, item_id: number | undefined, isDish: boolean, navigation: CommonNavigation<Pluto>, onBack?: () => void) {
		if (!review_id || !item_id) return
		const type = isDish ? "DISH" : "RESTAURANT";
		const data: ReviewToLoad = { feed_type: type, id: review_id }; //TODO: don't know how to fix this
		if (isDish) data["dish"] = { id: item_id };
		else data["restaurant"] = { id: item_id };

		navigation.push("ReviewDetail", { data: data, onBack: onBack })
	}
	static handleNotificationPress(notification: Notification, navigation: CommonNavigation<Pluto> | AuthNavigation<Pluto>, onBack?: () => void) {
		let review;
		const type = notification.notif_type || notification.type
		//console.log("notification press", type, notification.order_id, notification.id)
		switch (type) {
			case "dish_review_like":
				review = notification.review_dish_like?.review_dish;
				return this.onReviewDetail(review?.id, review?.dish_id, true, navigation, onBack);
			case "dish_review_comment":
				review = notification.review_dish_comment?.review_dish;
				return this.onReviewDetail(review?.id, review?.dish_id, true, navigation, onBack);
			case "dish_review_status":
				review = notification.review_dish;
				return this.onReviewDetail(review.id, review.dish_id, true, navigation, onBack);
			case "restaurant_review_like":
				review = notification.review_restaurant_like?.review_restaurant;
				return this.onReviewDetail(review?.id, review?.restaurant_id, false, navigation, onBack);
			case "restaurant_review_comment":
				review = notification.review_restaurant_comment?.review_restaurant;
				return this.onReviewDetail(review?.id, review?.restaurant_id, false, navigation, onBack);
			case "restaurant_review_status":
				review = notification.review_restaurant;
				return this.onReviewDetail(review.id, review.restaurant_id, false, navigation, onBack);
			case "follower":
				return this.onUserDetail(notification.follower_id, navigation, onBack)
			case "order_accepted":
				return this.showOrder(notification.order_id, navigation, onBack)
			case "order_rejected":
				return this.showOrder(notification.order_id, navigation, onBack)
			case "order_delivering":
				return this.showOrder(notification.order_id, navigation, onBack)
			case "order_updated":
				return this.showOrder(notification.order_id, navigation, onBack)
			case "booking_accepted":
				return this.showBooking(notification.booking_id, navigation, onBack)
			case "booking_rejected":
				return this.showBooking(notification.booking_id, navigation, onBack)
			case "review_reminder":
				return this.showOrder(notification.order_id, navigation, onBack)
			default: 
				navigation.navigate("Notifications")
		}
	}
	onPress = (notification: Notification) => {
		NotificationsPageContainer.handleNotificationPress(notification, this.props.navigation);
	}

	render() {
		return (
			<NotificationsPage
				userRequestedReload={this.userRequestedReload}
				notifications={this.props.notifications}
				loading={this.state.loading}
				onPress={this.onPress.bind(this)}
				refreshing={this.state.refreshing}
			/>
		)
	}
}
export default connect((state: ReduxState) => {
	return {
		notifications: state.notifications ?? []
	}
})(NotificationsPageContainer)
