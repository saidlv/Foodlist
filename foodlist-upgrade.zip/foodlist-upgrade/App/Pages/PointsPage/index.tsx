import { translate } from '@App/I18n';
import PointsManager, { SummaryResponse } from '@FoodListCore/Network/PointsManager';
import { PointsStackParams } from '@App/RouteParams/Points';
import { colors } from '@FoodListCommon/utils';
import AutoLoadingView, { AutoLoadingActions } from '@FoodListCore/Components/AutoLoadingView';
import FLIcon from '@FoodListCore/Components/FLIcon';
import FLImage from '@FoodListCore/Components/FLImage';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { margins, resetNavigation, showError } from '@FoodListCore/Global/GlobalProps';
import { Coupon } from '@Models/Coupon';
import { useFocusEffect } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useCallback, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { Dimensions, StyleSheet, Text, View, ScrollView, RefreshControl } from 'react-native';
import EarnedPointsCell from '@App/Components/EarnedPointsCell';
import { shallowEqual, useSelector } from 'react-redux';
import { ReduxState } from '@App/Redux/StateFormat';
import requestAuth from '@FoodListCore/Flows/RequestAuth';
import { DishReview, Review } from '@Models/Review';

type Props = {
	navigation: StackNavigationProp<PointsStackParams, "Points">
}

const mapFunction = (state: ReduxState) => {
	//console.log("chiama mapFunction", !!state.currentUser)
	return {
		userLogged: !!state.currentUser
	}
}

type PointsInfo = {
	id: number
	total_amount: number
	confirmed: boolean

	order_id?: number
	booking_id?: number
	coupon_id?: number
	daily_access?: boolean
	review_dish_id?: number
	review_restaurant_id?: number
	review_dish?: DishReview
	review_restaurant?: Review
}
const getTexts = (item: PointsInfo): { points: string, text: string, description?: string, color?: string } => {

	const positive = item.total_amount >= 0
	const points = positive ? "+"+item.total_amount : item.total_amount.toString()

	let text = ""
	let description = ""
	let color = positive ? colors.darkGreen : colors.darkRed

	if(item.order_id) {
		text = translate("orderPoints")
	} else if(item.booking_id) {
		text = translate("bookingPoints")
	} else if(item.coupon_id) {
		text = translate("couponRedeemPoints")
	} else if(item.daily_access) {
		text = translate("dailyAccessPoints")
	} else if(item.review_dish_id) {
		if(item.review_dish?.order_row_id) {
			text = translate("orderedDishReviewPoints")
		} else {
			text = translate("dishReviewPoints")
		}
	} else if(item.review_restaurant_id) {
		if(item.review_restaurant?.order_id) {
			text = translate("orderReviewPoints")
		} else if(item.review_restaurant?.booking_id) {
			text = translate("bookingReviewPoints")
		} else {
			text = translate("restaurantReviewPoints")
		}
	} else {
		//console.warn("not handled", item)
	}

	if(!item.confirmed) {
		color = colors.greyIcon
		
		if(text) {
			if(item.order_id) {
				description = translate("orderWaitingPoints")
			} else if(item.booking_id) {
				description = translate("bookingWaitingPoints")
			} else if(item.review_dish_id || item.review_restaurant_id) {
				description = translate("reviewWaitingPoints")
			} else {
				description = translate("genericWaitingPoints")
			}
		}
	}

	text = text || translate("unknown")

	return {
		points,
		text,
		color,
		description
	}
}

const manager = new PointsManager()

const Points = React.memo(({ navigation }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	const self = useMemo(() => ({
		availableCoupons: [] as Coupon[]
	}), [])
	//const onPress = useCallback((param: number) => { }, [])
	const [points, setPoints] = useState(0)
	const [totalPoints, setTotalPoints] = useState(0)
	const [history, setHistory] = useState<PointsInfo[]>([])
	//const [availableCoupons, setAvailableCoupons] = useState<Coupon[]>([])

	const { userLogged } = useSelector(mapFunction, shallowEqual)

	const [refreshing, setRefreshing] = useState(false)
	//console.log("userLogged?", userLogged)

	const actions: AutoLoadingActions<SummaryResponse> = useMemo(() => ({
		request: () => {
			return manager.getSummary()
		},
		onResponse: (res) => {
			setRefreshing(false)
			//console.log("non lo so", res)
			const data = res.data?.response
			const points = data?.points || 0
			const usedPoints = data?.used_points || 0
			const availablePoints = Math.round((points - usedPoints)*100)/100
			const availableCoupons = data?.available_coupons
			const history = data?.points_history || []
			self.availableCoupons = availableCoupons || []
			//setAvailableCoupons(availableCoupons)
			//console.log("coupons", availableCoupons)
			setPoints(availablePoints)
			setTotalPoints(points)
			setHistory(history)
		},
	}), [])

	const loadingRef = useRef<AutoLoadingView<SummaryResponse>>(null)
	useFocusEffect(React.useCallback(() => {
		loadingRef.current?.retry()
	}, []))

	const showCoupon = useCallback(() => {
		navigation.navigate("MyCoupons")
	}, [])

	const showAddCoupon = useCallback(() => {
		navigation.navigate("AddCoupon", {
			available_coupons: self.availableCoupons,
			points
		})
	}, [points])

	const showLogin = useCallback(() => {
		requestAuth(navigation, false)
	}, [])

	const showHowToEarnPoints = useCallback(() => {
		navigation.navigate("HowToEarnPoints")
	}, [])

	const refresh = useCallback(() => {
		setRefreshing(true)
		loadingRef.current?.retry(true)
	}, [])

	return (
		<>
		{userLogged && (
			<AutoLoadingView
				ref={loadingRef}
				actions={actions}
			/>
		)}
		<ScrollView
			style={{ flex: 1 }}
			contentContainerStyle={{ paddingBottom: 20 }}
			refreshControl={(
				<RefreshControl
					refreshing={refreshing}
					onRefresh={refresh}
				/>
			)}
		>
			<View style={styles.header}>
				<View style={{ flex: 1, alignItems: "center" }}>
					<FLImage
						source={require("@Assets/Images/trophy.png")}
						style={styles.trophy}
					/>
					<TouchableRipple
						style={styles.howIEarnPoints}
						fixAndroidModals
						onPress={showHowToEarnPoints}
					>
						<Text style={{ color: colors.white }}>{translate("howIEarnPoints")}</Text>
					</TouchableRipple>
				</View>
				<View style={{ flex: 1 }}>
					<View style={styles.points}>
						<Text style={styles.text}>{translate("availablePoints").toUpperCase()}</Text>
						<Text style={[styles.text, styles.availablePoints]}>{points}</Text>
					</View>
					<View style={styles.points}>
						<Text style={[styles.text, { fontSize: 12 }]}>{translate("totalPoints").toUpperCase()}</Text>
						<Text style={[styles.text, styles.availablePoints, { fontSize: 32 }]}>{totalPoints}</Text>
					</View>
				</View>
			</View>
			{userLogged ? (
				<View style={styles.padding}>
					<TouchableRipple
						style={styles.showCoupon}
						underlayColor={colors.darkFoodlist}
						onPress={showCoupon}
						fixAndroidModals
					>
						<Text style={styles.buttonText}>{translate("showMyCoupon")}</Text>
						<FLIcon size={28} color={colors.white} materialIcon="keyboard-arrow-right" />
					</TouchableRipple>
					<TouchableRipple
						style={styles.generateCoupon}
						underlayColor={colors.darkBlue}
						fixAndroidModals
						onPress={showAddCoupon}
					>
						<Text style={styles.buttonText}>{translate("generateCoupon")}</Text>
						<FLIcon size={24} color={colors.white} materialCommunityIcon="plus" />
					</TouchableRipple>
				</View>
			) : (
				<View style={styles.padding}>
					<TouchableRipple
						style={styles.generateCoupon}
						underlayColor={colors.darkBlue}
						onPress={showLogin}
						fixAndroidModals
					>
						<Text style={styles.buttonText}>{translate("loginOrRegisterToEarnPoints")}</Text>
						<FLIcon size={28} color={colors.white} materialIcon="keyboard-arrow-right" />
					</TouchableRipple>
				</View>
			)}
			{history.map(item => {
				//console.log("item", item)
				const pointsText = getTexts(item)
				return (
					<EarnedPointsCell item={pointsText} key={item.id} />
				)
			})}
		</ScrollView>
		</>
	);
});

const trophySize = Dimensions.get("window").width / 4

const styles = StyleSheet.create({
	header: {
		backgroundColor: colors.foodlist,
		padding: margins.pagePadding,
		flexDirection: "row",
		alignItems: "center",
	},
	text: {
		color: colors.white,
		fontWeight: "bold",
		fontSize: 14,
	},
	availablePoints: {
		fontSize: 36,
		marginTop: -5,
	},
	points: {
		alignItems: "center",
		marginTop: 10,
	},
	trophy: {
		width: trophySize,
		height: trophySize,
		resizeMode: "contain",
	},
	showCoupon: {
		backgroundColor: colors.foodlist,
		padding: margins.pagePadding,
		borderRadius: 4,
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "space-between"
	},
	generateCoupon: {
		marginTop: 10,
		backgroundColor: colors.blueMenu,
		padding: margins.pagePadding,
		borderRadius: 4,
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "space-between"
	},
	padding: {
		padding: margins.pagePadding
	},
	buttonText: {
		color: colors.white,
		fontSize: 18,
		flex: 1,
	},
	howIEarnPoints: {
		marginTop: 10,
		borderRadius: 20,
		paddingVertical: 5,
		paddingHorizontal: 10,
		backgroundColor: colors.darkFoodlist,
		overflow: "hidden",
	},
});

export default Points;
