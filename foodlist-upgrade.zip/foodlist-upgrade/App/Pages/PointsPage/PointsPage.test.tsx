import React from 'react';
import 'react-native';
import Points from './index';

import renderer from 'react-test-renderer';

it('renders Points view', () => {
	//expect(renderer.create(<Points />)).toMatchSnapshot(); //TODO: add Points props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<Points pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<Points pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
