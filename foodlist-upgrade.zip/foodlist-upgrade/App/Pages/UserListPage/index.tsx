import React from 'react';
import UserListPage, { UserListActions } from './view';
import UserManager, { FollowListResponse } from '@Network/UserManager';
import { User } from '@Models/User';
import { RequestResponse } from '@Models/RequestResponse';
import { ListParams } from '@Models/ListParams';
import { Like } from '@Models/Like';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';
import { isDefined } from '@FoodListCore/Global/GlobalProps';
import { Unsubscribe, genericFollowEvents } from '@FoodListCore/Services/EventEmitter';
import { followEmitter } from '@App/Redux/ReduxHelper';

type Props = {
	navigation: CommonNavigation<"UserListPage">
	route: CommonRoute<"UserListPage">
}

type State = {
	following_count: number
	followers_count: number
	count: number
	userCount: number
}

export default class UserList extends React.PureComponent<Props, State> {
	unsubscribe?: Unsubscribe

	constructor(props: Props) {
		super(props);
		//console.log("Trentino", this.props.navigation.getParam('data', []))
		const { data, followers_count, following_count, isCurrentUser } = props.route.params
		this.state = {
			userCount: (data ?? []).length,
			followers_count: followers_count ?? 0,
			following_count: following_count ?? 0,
			count: 0,
		}
		if (isCurrentUser && isDefined(following_count)) {
			this.unsubscribe = followEmitter().on(genericFollowEvents(), (following: boolean) => {
				this.setState({
					following_count: this.state.following_count + (following ? +1 : -1)
				})
			})
		}
	}

	componentWillUnmount() {
		this.unsubscribe?.()
	}

	getRequest = (params: ListParams) => {
		let id = this.props.route.params.id
		if(!id) throw new Error("Missing user id")
		if (this.props.route.params.followers) {
			//followers
			let manager = new UserManager()
			return manager.getFollowers(id, params)
		} else {
			//following
			let manager = new UserManager()
			return manager.getFollowing(id, params)
		}
	}

	goToDetail = (item: User | Like) => {
		if ('user' in item) { //Questo è il Like
			this.props.navigation.push("ProfilePage", {
				user_id: item.user.id
			})
		} else { //Questo è lo User
			this.props.navigation.push("ProfilePage", {
				user_id: item.id
			})
		}
	}


	actions: UserListActions = {
		goToDetail: this.goToDetail,
		request: this.getRequest
	}

	render() {
		const { isCurrentUser, followers, likes, data } = this.props.route.params
		return (
			<UserListPage
				isCurrentUser={isCurrentUser ?? false}
				followers_count={this.state.followers_count}
				following_count={this.state.following_count}
				followers={followers ?? false}
				likes={likes ?? false}
				userList={data ?? []}
				userCount={this.state.userCount}

				actions={this.actions}
			/>
		)
	}
}
