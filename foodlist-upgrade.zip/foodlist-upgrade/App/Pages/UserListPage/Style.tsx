import { margins } from '@FoodListCore/Global/GlobalProps';
import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	smallMarginLeft: {
		marginLeft: 10
	},
	container: {
		backgroundColor: colors.greyBackground,
		height: "100%"
	},
	headerBar: {
		flex: 0,
		flexDirection: 'row',
		backgroundColor: colors.white,
		padding: margins.pagePadding,
		alignItems: 'center',
		shadowOffset: {
			width: 0,
			height: 2
		},
		shadowColor: colors.shadowColor,
		shadowOpacity: 1.0,
		elevation: 2
	},
	scrollViewStyle: {
		flex: 1,
		flexDirection: 'column'
	},
	containerCell: {
		paddingLeft: margins.pagePadding,
		paddingVertical: 10,
		flex: 0,
		flexDirection: 'row',
		alignItems: 'center'
	},
	inlineElements: {
		flex: 1,
		flexDirection: 'row',
		alignItems: 'center'
	},
	alignFlexEnd: {
		alignSelf: 'flex-end'
	},
	separator: {
		height: 1,
		backgroundColor: colors.greyBorder,
		width: '100%'
	}
});
