import React from 'react';
import { colors } from '@Global/GlobalProps';
import { ScrollView, Text, View } from 'react-native';
import styles from './Style';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import LoadMoreList from '@FoodListCore/Components/LoadMoreList';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import FollowButton from '@Components/FollowButton/FollowButton'
import ProfileImage from '@Components/ProfileImage';
import { User } from '@Models/User';
import { RequestResponse } from '@Models/RequestResponse';
import { ListParams } from '@Models/ListParams';
import { Like } from '@Models/Like';
import { FollowListResponse } from '@Network/UserManager';
import { Follow } from '@Models/Follow';
import { translate } from '@App/I18n';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';

export interface UserListActions {
	goToDetail: (item: User | Like) => void
	request: (params: ListParams) => Promise<RequestResponse<FollowListResponse>>
}

type Props = {
	isCurrentUser: boolean
	followers_count: number
	following_count: number
	actions: UserListActions
	followers: boolean
	likes: boolean
	userCount: number
	userList: Like[]
}

export default class UserListPage extends React.PureComponent<Props> {
	actions: UserListActions

	constructor(props: Props) {
		super(props)
		this.actions = props.actions
	}

	getName = (item?: User) => {
		let strings: string[] = []
		if (item?.first_name) {
			strings.push(item?.first_name + " ")
		}
		if (item?.last_name) {
			strings.push(item?.last_name + " ")
		}
		return strings.join("")
	}

	twoLines = (item?: User) => {
		return item?.first_name || item?.last_name
	}

	render() {
		return (
			<View style={styles.container}>
				{(!this.props.likes) && (
					<>
					<View style={styles.headerBar}>
						<Icon name={(this.props.likes) ? 'heart' : 'user'} size={16} color={colors.red} />
						{(this.props.followers) && ((this.props.isCurrentUser) ? (
							<Text style={styles.smallMarginLeft}>{translate("myFollowersValue", { value: this.props.followers_count })}</Text>
						) : (
								<Text style={styles.smallMarginLeft}>{translate("followersValue", { value: this.props.followers_count })}</Text>)
						)}
						{(!this.props.followers && !this.props.likes) && ((this.props.isCurrentUser) ? (
							<Text style={styles.smallMarginLeft}>{translate("myFollowingValue", { value: this.props.following_count })}</Text>
						) : (
								<Text style={styles.smallMarginLeft}>{translate("followingValue", { value: this.props.following_count })}</Text>
							))}
						{(this.props.likes) && (
							<Text style={styles.smallMarginLeft}>{translate("likeValue", { value: this.props.userCount })}</Text>
						)}
					</View>
					<LoadMoreList<Follow>
						request={this.actions.request}
						contentContainerStyle={{ backgroundColor: colors.greyBackground }}
						renderItem={({ item }) => {
							let renderItem: User

							if (this.props.followers) {
								renderItem = item.follower!
							} else {
								renderItem = item.following!
							}

							return (
								<TouchableRipple onPress={() => { this.actions.goToDetail(renderItem) }}>
									<View style={styles.containerCell}>
										<View style={[styles.inlineElements, { paddingRight: 20 }]}>
											<ProfileImage source={renderItem?.photo ?? undefined} />
											{(this.twoLines(renderItem)) && (
												<View style={styles.smallMarginLeft}>
													<Text>{renderItem?.username}</Text>
													<Text style={{ color: colors.greyText }}>{this.getName(renderItem)}</Text>
												</View>
											)}
											{(!this.twoLines(renderItem)) && (
												<Text style={styles.smallMarginLeft}>{renderItem?.username}</Text>
											)}
										</View>
										<View style={styles.alignFlexEnd}>
											<FollowButton
												userId={renderItem?.id}
												userName={renderItem?.username}
												following={renderItem?.is_followed ?? false}
											/>
										</View>
									</View>
									<View style={styles.separator} />
								</TouchableRipple>
							)
						}}
					/>
					</>
				)}
				{(this.props.likes) && (
					<View style={styles.headerBar}>
						<Icon name={'heart'} size={16} color={colors.red} />
						<Text style={styles.smallMarginLeft}>{translate("likeValue", { value: this.props.userCount })}</Text>
					</View>
				)}
				{(this.props.likes) && (
					<ScrollView style={styles.scrollViewStyle}>
						{this.props.userList.map((item, index) => {
							return (
								<View key={item.id}>
									<TouchableRipple style={styles.containerCell} onPress={() => { this.actions.goToDetail(item) }}>
										<>
										<View style={[styles.inlineElements, { paddingRight: 20 }]}>
											<ProfileImage source={item.user?.photo ?? undefined} />
											{(this.twoLines(item.user)) && (
												<View style={styles.smallMarginLeft}>
													<Text>{item.user.username}</Text>
													<Text style={{ color: colors.greyText }}>{this.getName(item.user)}</Text>
												</View>)}
											{(!this.twoLines(item.user)) && (
												<Text style={styles.smallMarginLeft}>{item.user.username}</Text>
											)}
										</View>
										<View style={styles.alignFlexEnd}>
											<FollowButton
												userId={item.user.id}
												userName={item.user.username}
												following={item.following_user || item.user.is_followed || false}
											/>
										</View>
										</>
									</TouchableRipple>
									<View style={styles.separator} />
								</View>
							)
						})}
					</ScrollView>
				)}
			</View>
		);
	}
}
