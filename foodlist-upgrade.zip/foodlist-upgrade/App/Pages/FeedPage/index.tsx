import React from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { colors } from '@Global/GlobalProps';
import FeedItem from "@Components/FeedItem"
import LoadMoreList, { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import ProfileImage from '@Components/ProfileImage';
import ScrollViewBounceFix from '@Components/ScrollViewBounceFix'
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { Review } from '@Models/Review';
import FeedItemMap from '@Components/FeedItem/map'
import FeedManager from '@Network/FeedManager';
import { translate } from '@App/I18n';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { margins } from '@FoodListCore/Global/GlobalProps';
import { useFocusEffect } from '@react-navigation/core';
import { ListParams } from '@Models/ListParams';
import requestAuth from '@FoodListCore/Flows/RequestAuth';
import { StackNavigationProp } from '@react-navigation/stack';
import { SearchParamList } from '@App/RouteParams/Search';
import { shallowEqual, useSelector } from 'react-redux';
import { ReduxState } from '@FoodListCore/Redux/StateFormat';
import { getCurrentLocation } from '@FoodListCore/Services/LocationManager';
import SheetPopup from '@FoodListCore/Components/SheetPopup';
import PositionPicker from '@FoodListCore/Components/PositionPicker';
import { Location } from '@Models/Location';
import Button from '@FoodListCore/Components/Button';
import { TouchableOpacity } from '@FoodListCore/Components/TouchableFixed';
import FLIcon from '@FoodListCore/Components/FLIcon';
import Line from '@FoodListCore/Components/Line';
import ActionSheet from '@alessiocancian/react-native-actionsheet';
import { radiusNumOptions } from '@App/Components/SearchFilters';
import style from '@FoodListCore/Pages/InsertCodePage/style';
import SegmentedControl from '@FoodListCore/Components/SegmentedControl';
import { IgnoreResponse } from '@App/Network/SearchManager';

type Props = {
	navigation: StackNavigationProp<SearchParamList, any>
}

const reduxMap = (state: ReduxState) => {
	return {
		user: state.currentUser
	}
}

const Feed = React.memo((props: Props) => {
	const self = React.useMemo(() => ({
		followersSelected: false
	}), [])

	const listRef = React.useRef<LoadMoreListType<Review>>(null)
	const positionSheetOptionsRef = React.useRef<ActionSheet>(null)
	const distanceSheetOptionsRef = React.useRef<ActionSheet>(null)
	const [followersSelected, _setFollowersSelected] = React.useState(false)

	const [mapVisible, setMapVisible] = React.useState(false)
	const [position, setPosition] = React.useState<Location | null>(null)
	const [distance, setDistance] = React.useState(20)

	const refresh = React.useCallback(() => {
		listRef.current?.reload()
	}, [])

	useFocusEffect(React.useCallback(() => {
		listRef.current?.reload(true)
	}, []))

	const setFollowersSelected = React.useCallback((value: boolean) => {
		self.followersSelected = value
		_setFollowersSelected(value)
		refresh()
	}, [])

	const request = React.useCallback((params?: ListParams) => {
		//console.log('Params', params)
		return new Promise(async (resolve,reject) => {
			let searchPosition
			if(!followersSelected) {
				if(position) {
					searchPosition = position
				} else {
					try {
						searchPosition = await getCurrentLocation(true)
					} catch {
						reject(translate("locationError"))
						return
					}
				}
			}
			let manager = new FeedManager()
			return manager.getList(params, searchPosition ? {
				...searchPosition,
				distance,
			} : undefined).then((res) => {
				if(followersSelected == self.followersSelected) {
					resolve(res)
				} else {
					resolve(IgnoreResponse)
				}
			}).catch(reject)
		})
	}, [followersSelected, position, distance])

	const writeReview = React.useCallback(() => {
		if(requestAuth(props.navigation, true)) {
			props.navigation.navigate("FastReview", {
				reviewMode: "fast"
			})
		}
	}, [])

	const showFeedOptions = React.useCallback(() => {
		positionSheetOptionsRef.current?.show()
	}, [])
	const showDistanceOptions = React.useCallback(() => {
		distanceSheetOptionsRef.current?.show()
	}, [])
	const pickFromMap = React.useCallback(() => {
		setMapVisible(true)
	}, [])

	const { user } = useSelector(reduxMap, shallowEqual)

	React.useEffect(() => {
		refresh()
	}, [user?.id])

	return (
		<View style={styles.container}>
			<View style={styles.header}>
				<TouchableRipple onPress={writeReview} style={styles.reviewButton}>
					<ProfileImage source={user?.photo ?? undefined} customSize={42} />
					<View style={{ flexDirection: 'column', marginHorizontal: 15, justifyContent: 'space-between', alignSelf: 'center' }}>
						<Text style={{ color: colors.greyText, fontSize: 16 }}>{translate("writeReviewDots")}</Text>
					</View>
				</TouchableRipple>
			</View>
			<View style={{ backgroundColor: colors.white, paddingTop: 8, paddingBottom: followersSelected ? 8 : 4 }}>
				<SegmentedControl
					mainColor={colors.blueMenu}
					activeButtonTextColor={colors.white}

					selected={followersSelected ? 0 : 1}
					items={[{
						text: translate("following"),
						callback: () => {
							if(requestAuth(props.navigation)) {
								setFollowersSelected(true)
							}
						},
					}, {
						text: translate("discover"),
						callback: () => setFollowersSelected(false),
					}]}
				/>
				
				{/* <View style={{ flex: 1, alignItems: "flex-end" }}>
					<TouchableOpacity onPress={() => setFollowersSelected(true)}>
						<Text style={[styles.topButton, followersSelected ? styles.topButtonSelected : null]}>{translate("following")}</Text>
					</TouchableOpacity>
				</View>
				<View style={styles.verticalLine} />
				<View style={{ flex: 1, alignItems: "flex-start" }}>
					<TouchableOpacity onPress={() => setFollowersSelected(false)}>
						<Text style={[styles.topButton, followersSelected ? null : styles.topButtonSelected]}>{translate("discover")}</Text>
					</TouchableOpacity>
				</View> */}
			</View>
			{followersSelected ? (
				<></>
			) : (
				<View style={styles.optionsRow}>
					<TouchableRipple style={[styles.optionsButton, { marginRight: 10, flex: 1 }]} borderless onPress={showFeedOptions}>
						<Text style={{ marginRight: 5, flex: 1, textAlign: "center", fontSize: 13 }}>{translate(position ? "positionFromMap" : "currentPosition")}</Text>
						<FLIcon materialIcon="keyboard-arrow-down" size={20} />
					</TouchableRipple>
					<TouchableRipple style={styles.optionsButton} borderless onPress={showDistanceOptions}>
						<Text style={{ marginRight: 5, fontSize: 13 }}>{distance} km</Text>
						<FLIcon materialIcon="keyboard-arrow-down" size={20} />
					</TouchableRipple>
				</View>
			)}
			<Line />
				
			<LoadMoreList<Review>
				request={request}
				onEndReachedThreshold={4}
				listRef={listRef}
				//ListHeaderComponent={headerComponent}
				noDataComponent={(
					<View style={{ alignItems: 'center' }}>
						{followersSelected ? (
							<>
								<Text style={{ color: colors.greyInfoText, fontSize: 16, textAlign: 'center', marginHorizontal: margins.pagePadding, lineHeight: 22 }}>
									{translate("followYourFriendsMessage")}
								</Text>
								<TouchableOpacity onPress={() => props.navigation.navigate("SuggestContacts")}>
									<Text style={{ fontSize: 16, marginTop: 12, fontWeight: 'bold', color: colors.blueMenu }}>{translate("findYourFriends")}</Text>
								</TouchableOpacity>
							</>
						) : (
							<>
								<Text style={{ fontSize: 15, color: colors.darkGreyText }}>{translate("noResultsForCurrentPosition")}</Text>
								<Button
									title={translate("changeSearchPosition")}
									lowercase
									noMargin
									containerStyle={{ marginTop: 20 }}
									rippleStyle={{ paddingHorizontal: 30 }}
									onPress={pickFromMap}
								/>
							</>
						)}
					</View>
				)}
				
				contentContainerStyle={styles.list}
				renderItem={({ item }) =>
					<FeedItem
						key={item.id + "_" + item.updated_at}
						item={FeedItemMap(item)}
						showDetail={true}
						callbackShouldReload={refresh}
					/>
				}

				errorComponent={(
					<View style={{ alignItems: "center", paddingHorizontal: 30 }}>
						<TouchableOpacity
							onPress={refresh}
						>
							<Text style={{ paddingHorizontal: 15, paddingVertical: 10, color: colors.blueMenu, fontWeight: "bold", fontSize: 16, }}>{translate("retry")}</Text>
						</TouchableOpacity>
						<Button
							title={translate("changeSearchPosition")}
							lowercase
							noMargin
							containerStyle={{ width: "100%", marginTop: 20 }}
							rippleStyle={{ paddingHorizontal: 15 }}
							onPress={pickFromMap}
						/>
					</View>
				)}
			/>

			<ActionSheet
				ref={positionSheetOptionsRef}
				options={React.useMemo(() => ([
					translate("currentPosition"),
					translate("pickFromMap"),
					translate("cancel"),
				]), [])}
				cancelButtonIndex={2}
				onPress={(index) => {
					if(index == 0) {
						setPosition(null)
						refresh()
					} else if(index == 1) {
						pickFromMap()
					}
				}}
			/>
			<ActionSheet
				ref={distanceSheetOptionsRef}
				options={React.useMemo(() => ([
					...(radiusNumOptions.map(num => num + " km")),
					translate("cancel"),
				]), [])}
				cancelButtonIndex={radiusNumOptions.length}
				onPress={(index) => {
					if(index < radiusNumOptions.length) {
						setDistance(radiusNumOptions[index])
						refresh()
					}
				}}
			/>

			{mapVisible && (
				<SheetPopup
					//ref={popupRef}
					visible={mapVisible}
					actions={{
						onTapOutside: () => setMapVisible(false)
					}}
				>
					<View style={{ alignSelf: "stretch", height: Platform.OS == "web" ? "70vh" : "100%" }}>
						<PositionPicker
							buttonLabel={"Seleziona"}
							initialPosition={position || undefined}
							actions={{
								onPositionPicked: (position) => {
									setMapVisible(false)
									setPosition(position)
									refresh()
								},
								onBackPressed: () => setMapVisible(false)
							}}
						/>
					</View>
				</SheetPopup>
			)}
		</View>
	);
});

const styles = StyleSheet.create({
	container: {
		backgroundColor: colors.greyBackground,
		height: "100%"
	},
	header: {
		backgroundColor: colors.white,
		zIndex: 10,
		...CommonStyle.shadow,
	},
	reviewButton: {
		flexDirection: 'row',
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 15,
		alignItems: 'center',
		backgroundColor: colors.white,
	},
	button: {
		flex: 1,
		borderTopWidth: 2,
		borderLeftWidth: 1,
		borderRightWidth: 1,
		borderColor: colors.greyBackground,
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 10
	},
	list: {
		paddingVertical: 10,
	},
	optionsRow: {
		backgroundColor: colors.white,
		paddingHorizontal: margins.pagePadding,
		paddingTop: 2,
		paddingBottom: 5,
		flexDirection: "row",
		alignItems: "center",
	},
	optionsButton: {
		paddingLeft: margins.pagePadding,
		paddingRight: margins.vertical,
		paddingVertical: 5,
		backgroundColor: colors.lightGrey,
		borderRadius: 20,
		flexDirection: "row",
		alignItems: "center",
	}, 
	verticalLine: {
		width: 2,
		height: 10,
		backgroundColor: colors.greyTextSubMenu,
		borderRadius: 4,
		marginHorizontal: 6,
	},
	topButton: {
		padding: 5,
		paddingVertical: 8,
		color: colors.greyText,
		fontSize: 15,
	},
	topButtonSelected: {
		color: colors.darkGreyText,
		fontWeight: "bold",
	},
});

export default Feed;
