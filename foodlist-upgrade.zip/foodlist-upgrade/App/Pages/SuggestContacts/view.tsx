import React, { ReactChild } from 'react';
import { colors } from '@Global/GlobalProps';
import commonStyles from '@FoodListCore/Global/CommonStyle';
import { View, FlatList, SafeAreaView, StyleSheet } from 'react-native';
import AutoLoadingView from '@FoodListCore/Components/AutoLoadingView'
import FormActionButton from '@Components/FormActionButton'
import { User } from '@Models/User';
import { translate } from '@App/I18n';
import UserCell from '@App/Components/Cells/UserCell';

type Props = {
	isAfterRegistration: boolean
	loading: boolean
	error?: string
	retryComponent?: ReactChild
	onRetry?: () => void
	data?: User[]
	onContinue: () => void
}

export default class SearchPage extends React.PureComponent<Props> {
	render() {
		return (
			<View style={styles.container}>
				<SafeAreaView style={{ flex: 0, backgroundColor: colors.foodlist }} />
				<SafeAreaView style={{ flex: 1, backgroundColor: colors.greyBackground }}>
					<View style={styles.container}>
						<AutoLoadingView
							loading={this.props.loading}
							error={this.props.error}
							retryComponent={this.props.retryComponent}
							onRetry={this.props.onRetry}
						/>

						<FlatList
							style={styles.container}
							data={this.props.data}
							renderItem={({ item }) => <UserCell item={item} />}
						/>
					</View>
					{this.props.isAfterRegistration &&
						<View style={commonStyles.buttonContainer}>
							<FormActionButton
								enabled={true}
								full
								/* style={styles.button} */
								title={translate("continue")}
								onPress={this.props.onContinue}
								noPadding
							/>
						</View>
					}
				</SafeAreaView>
			</View>
		)
	}
}

const styles = StyleSheet.create({
	container: {
		flex: 1
	},
	/* button: {
			flex: 0,
			justifyContent: 'flex-end'
	} */
})