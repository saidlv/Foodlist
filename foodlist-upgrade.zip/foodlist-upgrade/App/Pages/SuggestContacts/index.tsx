import React, { ReactChild } from 'react';
import { AppState, Alert, Platform, NativeEventSubscription, AppStateStatus } from 'react-native';
import { connect } from 'react-redux';
import PageView from './view';
import Contacts from 'react-native-contacts';
import Permissions from 'react-native-permissions'
import Country from "@FoodListCore/Assets/flags/countries"
import { currentLocale } from '@App/I18n'
import { sha256 } from 'react-native-sha256';
import AndroidOpenSettings from 'react-native-android-open-settings'
import FriendsManager from '@Network/FriendsManager';
import { BackHandler } from 'react-native';
import { getContactsPermissionStatus, requestContactsPermission, PERMISSION_RESULTS } from '@Services/PermissionManager';
import { User } from '@Models/User';
import { AuthNavigation, AuthRoute } from '@RouteParams/Auth';
import { translate } from '@App/I18n';

type Props = {
	navigation: AuthNavigation<"SuggestContacts">
	route: AuthRoute<"SuggestContacts">
}

type State = {
	isAfterRegistration: boolean
	loading: boolean
	error?: string
	retryComponent?: ReactChild
	onRetry?: () => void
	appState: AppStateStatus
	defaultCountryCode: string
	loaded: boolean
	data?: User[]
}

class SuggestContactsContainer extends React.PureComponent<Props, State> {
	loaded: boolean
	didFocusLsn?: NativeEventSubscription
	alreadyNegatedPermissions: boolean = false

	constructor(props: Props) {
		super(props);
		this.loaded = false
		this.state = {
			isAfterRegistration: props.route.params?.isAfterRegistration ?? false,
			loading: true,
			loaded: false,
			appState: AppState.currentState,
			defaultCountryCode: (Country.getCountryDataByCode(currentLocale(false)) || Country.getCountryDataByCode("it")).dialCode
		}
	}

	componentDidMount() {
		this.props.navigation.addListener("focus", this.pageDidFocus)
		AppState.addEventListener('change', this._handleAppStateChange)
		BackHandler.addEventListener('hardwareBackPress', this.handleBackPress);
	}

	componentWillUnmount() {
		this.props.navigation.removeListener("focus", this.pageDidFocus)
		AppState.removeEventListener('change', this._handleAppStateChange);
		BackHandler.removeEventListener('hardwareBackPress', this.handleBackPress);
	}

	pageDidFocus = () => {
		if (!this.loaded) {
			this.handlePermissions()
			this.loaded = true
		}
	}

	handleBackPress = () => {
		if (this.state.isAfterRegistration) {
			this.resetToMain();
		} else {
			this.props.navigation.goBack();
		}
		//this.resetToMain();
		return true
	}

	resetToMain = () => {
		this.props.navigation.reset({
			index: 0,
			routes: [{
				name: "TabBarPage"
			}]
		})
	}

	_handleAppStateChange = (nextAppState: AppStateStatus) => {
		if ((this.state.appState === "inactive" || this.state.appState === "background") && nextAppState === 'active') {
			//console.log('App attiva');
			if (!this.state.loaded) {
				this.resetLoadingView();
				this.handlePermissions();
			}
		}
		this.setState({ appState: nextAppState });
	}

	resetLoadingView = () => {
		this.setState({ loading: true, error: undefined, retryComponent: undefined, onRetry: undefined })
	}

	handlePermissions = async () => {
		let response = await this.getPermissionStatus();
		if (response == PERMISSION_RESULTS.GRANTED) {
			this.getContacts();
		} else if (!this.alreadyNegatedPermissions) {
			let response = await this.requestPermission();
			if (response == PERMISSION_RESULTS.GRANTED) {
				this.handlePermissions();
			} else {
				this.alreadyNegatedPermissions = true;
				this.showPermissionError();
			}
		} else {
			this.showPermissionError();
		}
	}

	showPermissionError = () => {
		this.setState({
			loading: false,
			error: translate("giveContactsAuthorization"),
			retryComponent: translate("goToSettings"),
			onRetry: () => {
				if (Platform.OS == 'android') {
					AndroidOpenSettings.appDetailsSettings()
				} else {
					Permissions.openSettings();
				}
			}
		});
	}

	showNoSuggestions = () => {
		this.setState({
			error: translate("alreadyFollowAllContacts")
		});
	}

	getPermissionStatus = async () => {
		let response = await getContactsPermissionStatus();
		return response;
	}

	requestPermission = async () => {
		let response = await requestContactsPermission();
		return response;
	}

	getContacts = async () => {
		Contacts.getAll(async (err, contacts) => {
			if (err) {
				this.alert(translate("error"), translate("contactsRetrievingError"));
			} else {
				let phoneNumbers = await this.getPhoneNumbers(contacts);
				this.setState({ loaded: true });
				let response = await this.sendRequest(phoneNumbers);
				if (response.status == 200) {
					this.setState({
						data: response.data?.users,
						loading: false
					});
					if (response.data?.users.length == 0) {
						this.showNoSuggestions();
					}
				} else {
					this.setState({
						loading: false,
						error: translate("errorOccuredRetry"),
						retryComponent: translate("retry"),
						onRetry: () => {
							this.resetLoadingView();
							this.getContacts();
						}
					});
				}
			}
		})
	}

	getPhoneNumbers = async (contacts: Contacts.Contact[]) => {
		return new Promise<string[]>(async (resolve, reject) => {
			let res: string[] = [];
			for (let i = 0; i < contacts.length; i++) {
				let item = contacts[i];
				if (item?.phoneNumbers[0]?.number) {
					let number = item.phoneNumbers[0].number;
					if (!number.includes('+')) {
						number = this.state.defaultCountryCode + '' + number;
					}
					number = number.replace(/\D/g, '');
					number = await sha256(number);
					res.push(number);
				}
			}
			resolve(res);
		})
	}

	sendRequest = async (contacts: string[]) => {
		let manager = new FriendsManager();
		let response = await manager.getContactFriends({
			contacts: contacts
		});
		return response;
	}

	alert = (title: string, message: string, buttons?: { text: string, onPress: () => void }[]) => {
		Alert.alert(title, message, (buttons) ? buttons : [
			{ text: translate("ok"), onPress: () => { } }
		]);
	}

	render() {
		return <PageView
			isAfterRegistration={this.state.isAfterRegistration}
			loading={this.state.loading}
			error={this.state.error}
			retryComponent={this.state.retryComponent}
			onRetry={this.state.onRetry}
			data={this.state.data}
			onContinue={this.resetToMain}
		/>
	}
}

export default connect()(SuggestContactsContainer);
