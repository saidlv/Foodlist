import DatetimePickerPopup from '@App/Components/DatetimePickerPopup';
import SearchFilters, { Filters, FiltersRefType, isExploreTab } from '@App/Components/SearchFilters';
import SelectAddress, { SelectAddressActions } from '@FoodListCore/Components/SelectAddress';
import SearchManager, { IgnoreResponse } from '@FoodListCore/Network/OrderManager';
import { CommonParamList } from '@App/RouteParams/Common';
import { getCurrentLocation } from '@FoodListCore/Services/LocationManager';
import RestaurantCell from '@Components/NewRestaurantCell';
import { getMoment, RECEIPT_DATETIME_FORMAT, SERVER_DATETIME_FORMAT, SERVER_DATE_FORMAT } from '@FoodListCommon/DateManager';
import { getDisplayInfos, sortAndPProRestaurants } from '@FoodListCommon/SearchHelper';
import { formatUserAddress } from '@FoodListCommon/user';
import Line from '@FoodListCore/Components/Line';
import LoadMoreList, { LoadMoreListType, LoadMoreResponse } from '@FoodListCore/Components/LoadMoreList';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import { MaterialCommunityIcon, MaterialIcon } from '@FoodListCore/Iconfont/FoodListIconfont';
import { getCurrentUser, setActiveRestaurant } from '@FoodListCore/Redux/ReduxHelper';
import { ListParams } from '@Models/ListParams';
import { Location } from '@Models/Location';
import { RequestResponse } from '@Models/RequestResponse';
import { Restaurant } from '@Models/Restaurant';
import { UserAddress } from '@Models/UserAddress';
import { RouteProp } from '@react-navigation/native';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Keyboard, ListRenderItemInfo, Platform, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { Separator } from './Separator';
import Button from './Button';
import ExpandRadius from './ExpandRadius';
import { Mode } from "@Components/SearchFilters";
import { StackNavigationProp } from '@react-navigation/stack';
import { getOrderParams, getUserAddressById } from '@FoodListCore/Pages/OrderPage/helper';
import { MAX_LIST_WIDTH } from '@FoodListCore/Global/WebHelpers';

type Props = {
	navigation: StackNavigationProp<CommonParamList, "NewSearch">
	route: RouteProp<CommonParamList, "NewSearch">
}

const exploreInfoProps = {
	showOpenNow: true,
}

type Self = {
	generated_address?: UserAddress
	initialRequestDone?: boolean
}

const tryGetAddressPosition = (address: UserAddress | undefined): Location | undefined => {
	if(address?.latitude && address?.longitude) {
		return {
			latitude: address.latitude,
			longitude: address.longitude,
		}
	}
}

const pproFilters = (filters: Filters, mode: Mode) => {
	console.log("ppro filters", filters, mode)
	const _filters = {
		...filters,
	}
	if(isExploreTab(mode)) {
		_filters.order_by = _filters.explore_order_by
		delete _filters.free_delivery
		delete _filters.foodlist_sort_by_first
		if(mode == "explore-dishes") {
			delete _filters.open_now
			delete _filters.categories
		}
	} else {
		delete _filters.open_now
	}
	delete _filters.explore_order_by
	if(mode == "delivery") {
		delete _filters.distance
	}
	return _filters
}

const manager = new SearchManager()

const NewSearchPage = (props: Readonly<Props>): JSX.Element => {
	const isSelectRestaurant = props.route.params?.selectRestaurant
	const customSelectDish = props.route.params?.onDishSelected

	const loadMoreList = useRef<LoadMoreListType<Restaurant>>(null)
	const [datetimeVisible, setDatetimeVisible] = useState(false)
	const [selectPositionVisible, setSelectPositionVisible] = useState(false)
	const [mode, setMode] = useState<Mode>(isSelectRestaurant ? "explore-restaurants" : (props.route.params?.mode ||"delivery"))

	const self: Self = useMemo(() => {
		return {}
	}, [])
	const filtersRef = useRef<FiltersRefType>(null)

	const routeParams = useMemo(() => {
		const { latitude, longitude, address_id, from_map } = props.route.params || {}
		const initialPosition = (latitude && longitude) ? { latitude: parseFloat(latitude), longitude: parseFloat(longitude), fromMap: from_map == "1" } : null
		const address = initialPosition ? null : ((address_id && getUserAddressById(address_id)) || getCurrentUser()?.addresses?.[0])
		return /* deepCopy(props.route.params) || */ {
			mode: "delivery" as Mode,
			address,
			address_id: address?.id,
			position: initialPosition as (Location | null | undefined),
			for_date: null as string | null,
		}
	}, [])

	const request = useCallback((loadMoreParams: ListParams) => {
		return new Promise<RequestResponse<LoadMoreResponse<Restaurant>>>(async (resolve, reject) => {
			if(!routeParams.address && !routeParams.position) {
				try {
					const position = await getCurrentLocation(true)
					routeParams.position = position
				} catch (e) {
					console.log("errore posizione", e)
					reject(translate("locationError"))
					return
				}
			}
			const filters = filtersRef.current?.filters
			const searchMode = routeParams.mode
			const searchText = filters?.name || ""

			manager.getDeliveryPlaces({
				user_address_id: routeParams.address_id,
				for_date: routeParams.for_date || undefined,
				...routeParams.position,
			}, loadMoreParams, searchMode, pproFilters(filters!, searchMode)).then(res => {
				const currentSearchText = filtersRef.current?.filters?.name || ""
				if(routeParams.mode != searchMode || searchText != currentSearchText) {
					resolve(IgnoreResponse)
					return
				}
				if(res?.data) {
					const data = res.data
					self.generated_address = data.reverse_geocoded_address
					/* if(searchMode != "explore-restaurants") {
						res.data.response = sortAndPProRestaurants(res.data.response, searchMode == "booking", filters?.foodlist_sort_by_first || false)
					} */
					resolve(res)
				} else {
					reject(res.error)
				}
			}).catch(reject)
		})
	}, [self, routeParams])

	const [scrollEnabled, setScrollEnabled] = useState(true)

	const onPress = useCallback((item: Restaurant): void => {
		if(isSelectRestaurant) {
			props.navigation.navigate("FastReview") //go back
			props.route.params?.onItemSelected?.(item)
			return
		}
		setActiveRestaurant(item.id, props.navigation)
		const { section, displayableDays, date, booking } = getDisplayInfos(item, translate)
		const day = displayableDays?.[0]
		if(!section || !day) {
			if(booking) {
				props.navigation.push("BookTable", {
					date: date.format(SERVER_DATE_FORMAT),
					booking_hour: booking.id,
					restaurant: item,
					restaurant_id: item.id,
				})
			} else {
				props.navigation.push("NewRestaurant", {
					restaurant: item,
					id: item.id,
				})
			}
			return
		}

		props.navigation.push("NewOrderOnline", {
			orderParams: getOrderParams({
				item,
				address: routeParams.mode == "delivery" ? routeParams.address : undefined,
				generated_address: self.generated_address,
				restaurant_id: item.id,
				for_date: routeParams.for_date,
			}),
			restaurant: item,
			restaurant_id: item.id,
			for_date: routeParams.for_date || "asap",
			address: routeParams.address_id,
			latitude: routeParams.position?.latitude,
			longitude: routeParams.position?.longitude,
			takeaway: routeParams.mode == "takeaway" ? 1 : undefined,
		})
	}, [routeParams])
	const onFiltersChanged = useCallback(() => {
		loadMoreList.current?.reload()
	}, [])
	const renderItem = useCallback(({ item: rest, index }: ListRenderItemInfo<Restaurant>) => {
		return (
			<>
			{routeParams.mode != "explore-restaurants" && (
				<Separator index={index} item={rest} bookings={mode == "booking"} />
			)}
			<RestaurantCell
				item={rest}
				actions={{
					onPress: () => onPress(rest),
					changeVerticalScrollEnabled: setScrollEnabled,
					customDishPress: customSelectDish,
				}}
				mode={routeParams.mode == "booking" ? "bookings" : routeParams.mode == "explore-restaurants" ? "explore" : "orders"}
				infoProps={mode == "explore-restaurants" ? exploreInfoProps : undefined}
			/>
			</>
		)
	}, [mode, routeParams])

	const selectPositionActions: SelectAddressActions = useMemo(() => {
		return {
			onAddressSelected: (address) => {
				delete routeParams.position
				routeParams.address = address
				routeParams.address_id = address.id
				loadMoreList.current?.reload()
				setSelectPositionVisible(false)
				props.navigation.setParams({
					address_id: address.id,
					latitude: undefined,
					longitude: undefined,
					full_address: undefined,
				})
			},
			onPositionSelected: (position) => {
				delete routeParams.address_id
				delete routeParams.address
				routeParams.position = position
				loadMoreList.current?.reload()
				setSelectPositionVisible(false)
				props.navigation.setParams({
					address_id: undefined,
					full_address: undefined,
					latitude: position.latitude,
					longitude: position.longitude,
					from_map: position.fromMap ? "1" : undefined,
				})
			},
			close: () => {
				setSelectPositionVisible(false)
			}
		}
	}, [routeParams])

	const showDateTimePicker = useCallback(() => {
		setDatetimeVisible(true)
		Keyboard.dismiss()
	}, [])
	const showSelectPosition = useCallback(() => {
		setSelectPositionVisible(true)
		Keyboard.dismiss()
	}, [])

	useEffect(() => {
		props.navigation.setParams({
			mode,
		})
		routeParams.mode = mode
		const timeout = self.initialRequestDone ? 0 : 500
		setTimeout(() => {
			loadMoreList.current?.reload()
		}, timeout)
		self.initialRequestDone = true
	}, [mode, routeParams])

	const isExplore = isExploreTab(mode)
	const hideTime = isExplore

	const availableWidth = useWindowDimensions().width - MAX_LIST_WIDTH
	const sideFilters = availableWidth >= 250
	const alignListRight = sideFilters && (availableWidth / 2 < 250)

	return (
		<>
			<View style={styles.headersContainer}>
				{!isSelectRestaurant && (
				<View style={[styles.header, styles.selectHeader]}>
					{/* <Icon name="logo-img" size={28} color={colors.white} style={{ marginRight: 10 }} />
					<View style={{ flexGrow: 1 }}></View> */}
					<Button
						title={translate("deliveryShort")}
						selected={mode == "delivery"}
						icon="delivery-dining"
						onPress={useCallback(() => {
							setMode("delivery")
						}, [])}
					/>
					<Button
						title={translate("takeawayShort")}
						selected={mode == "takeaway"}
						icon="storefront"
						onPress={useCallback(() => {
							setMode("takeaway")
						}, [])}
					/>
					<Button
						title={translate("bookingShort")}
						selected={mode == "booking"}
						icon="book-online"
						onPress={useCallback(() => {
							setMode("booking")
						}, [])}
					/>
					{Platform.OS != "web" && (
						<Button
							selected={isExplore}
							icon="explore"
							iconSize={18}
							onPress={useCallback(() => {
								setMode("explore-restaurants")
							}, [])}
						/>
					)}
				</View>
				)}
				<View style={styles.header}>
					<View style={[styles.border, { backgroundColor: colors.white }]}>
					<TouchableRipple
						style={styles.addressContainer}
						onPress={showSelectPosition}
					>
						<MaterialCommunityIcon
							name={"map-marker"}
							size={18}
							color={colors.black}
							style={{ marginLeft: 5, marginRight: 7 }}
						/>
						<View style={{ flex: 1, marginRight: 10 }}>
							<Text style={{ fontSize: 12, color: colors.darkGreyText }}>{translate(mode == "delivery" ? "deliveryNear" : mode == "takeaway" ? "takeawayNear" : isExplore ? "searchNear" : "bookingNear")}</Text>
							<Text style={styles.addressText} numberOfLines={1} >{routeParams.address ? formatUserAddress(routeParams.address) : (props.route.params?.full_address || translate(routeParams.position?.fromMap ? "positionFromMap" : "currentPosition"))}</Text>
						</View>
						<View style={[styles.border, { borderColor: "#ccc", borderWidth: 1, opacity: hideTime ? 0 : 1 }]}>
						<TouchableRipple
							style={styles.timeContainer}
							onPress={showDateTimePicker}
							disabled={hideTime}
						>
							<Text>{routeParams.for_date ? getMoment(routeParams.for_date).format(RECEIPT_DATETIME_FORMAT) : translate("now")}</Text>
							<MaterialIcon name="keyboard-arrow-down" size={18} style={{ marginLeft: 3 }} />
						</TouchableRipple>
						</View>
					</TouchableRipple>
				</View>
				</View>
			</View>
			{!sideFilters && (
				<>
				<SearchFilters onFiltersChanged={onFiltersChanged} mode={mode} ref={filtersRef} />
				<Line />
				</>
			)}

			<View style={styles.relative}>
			{sideFilters && (
				<View style={styles.sideFilters}>
					<SearchFilters vertical onFiltersChanged={onFiltersChanged} mode={mode} ref={filtersRef} />
				</View>
			)}
			<LoadMoreList<Restaurant>
				listRef={loadMoreList}
				contentContainerStyle={styles.contentContainer}
				customStyle={{ marginLeft: alignListRight ? 250 : 0 }}
				request={request}
				renderItem={renderItem}
				dontStart
				onEndReachedThreshold={3}
				mergeElementsOnResponse={(data, newItems) => {
					if(newItems[0]?.firstOfExternalServices) {
						const externalAlreadyStarted = !!data.find(item  => item.firstOfExternalServices)
						if(externalAlreadyStarted) {
							newItems[0].firstOfExternalServices = false
						}
					}
					return data.concat(newItems)
				}}
				endResultComponent={(
					<ExpandRadius
						listRef={loadMoreList}
						filtersRef={filtersRef}
						mode={mode}
						showSelectPosition={showSelectPosition}
					/>
				)}
				noDataComponent={(
					<ExpandRadius
						noResult
						listRef={loadMoreList}
						filtersRef={filtersRef}
						mode={mode}
						showSelectPosition={showSelectPosition}
					/>
				)}
				scrollProps={{
					scrollEnabled: scrollEnabled,
					disableVirtualization: Platform.OS == "web",
				}}
			/>
			<DatetimePickerPopup
				visible={datetimeVisible}
				onDateChanged={(date) => {
					routeParams.for_date = date ? date.format(SERVER_DATETIME_FORMAT) : null
					loadMoreList.current?.reload()
					setDatetimeVisible(false)
					//actions.changeTime(date)
				}}
				onClose={() => setDatetimeVisible(false)}
			/>
			{selectPositionVisible && (
				<SelectAddress
					actions={selectPositionActions}
					initialPosition={tryGetAddressPosition(routeParams.address) || routeParams.position || undefined}
				/>
			)}
			</View>
		</>
	);
};

const styles = StyleSheet.create({
	headersContainer: { 
		flexDirection: "row",
		alignItems: "center",
		flexWrap: "wrap",
		backgroundColor: colors.foodlist,
		justifyContent: "center",
		paddingVertical: 4,
		width: "100%",
	},
	relative: {
		position: "relative",
		flex: 1,
	},
	sideFilters: {
		position: "absolute",
		zIndex: 100,
		width: 250,
		backgroundColor: colors.devilGrey,
		height: "100%",
	},
	contentContainer: {
		paddingVertical: margins.pagePadding / 2,
	},
	header: {
		backgroundColor: colors.foodlist,
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 2,
		maxWidth: "100%",
		width: Platform.OS == "web" ? "auto" : "100%",
	},
	selectHeader: {
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "center",
		flexWrap: "wrap",
	},
	border: {
		borderRadius: 20,
		overflow: "hidden",
	},
	addressContainer: {
		padding: 4,
		flexDirection: "row",
		alignItems: "center",
	},
	addressText: {
		fontSize: 12,
		fontWeight: "bold",
		color: colors.black,
	},
	timeContainer: {
		paddingVertical: 8,
		paddingRight: 7,
		paddingLeft: 12,
		flexDirection: "row",
		alignItems: "center",
	},
})

export default NewSearchPage;
