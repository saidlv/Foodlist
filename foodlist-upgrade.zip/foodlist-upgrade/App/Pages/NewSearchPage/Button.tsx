import React from "react";
import { colors } from '@FoodListCore/Global/GlobalProps';
import Icon, { MaterialCommunityIcon, MaterialIcon, MaterialIconName } from '@FoodListCore/Iconfont/FoodListIconfont';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { TouchableRipple } from "@FoodListCore/Components/TouchableRipple";

type ButtonProps = {
	title?: string,
	onPress: () => void,
	selected: boolean
	icon: MaterialIconName
	iconSize?: number
}

const Button = React.memo(({ title, onPress, selected, icon, iconSize }: ButtonProps) => {
	return (
		<TouchableRipple
			borderless
			onPress={onPress}
			style={[styles.modeButton, selected ? styles.modeButtonActive : null]}
		>
			<View style={styles.row}>
				{(selected || !title || Platform.OS == "web") && (
					<MaterialIcon name={icon} color={colors.white} size={iconSize || 14} />
				)}
				{!!title && (
					<Text selectable={false} style={styles.title}>{title}</Text>
				)}
			</View>
		</TouchableRipple>
	)
})

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		alignItems: "center"
	},
	title: {
		color: colors.white,
		fontWeight: "bold",
		marginLeft: 5
	},
	modeButton: {
		borderRadius: 20,
		paddingHorizontal: 10,
		paddingVertical: 5,
		marginHorizontal: 2,
		marginVertical: 2,
		overflow: "hidden",
	},
	modeButtonActive: {
		backgroundColor: colors.darkFoodlist,
	},
})

export default Button;