import { Filters, FiltersRefType, Mode, radiusNumOptions, radiusOptionLabel } from "@App/Components/SearchFilters"
import Button from "@FoodListCore/Components/Button"
import { LoadMoreListType } from "@FoodListCore/Components/LoadMoreList"
import { colors, margins } from "@FoodListCore/Global/GlobalProps"
import { translate } from "@FoodListCore/I18n"
import React, { useCallback } from "react"
import { StyleSheet, Text, View } from "react-native"

type Props = {
	noResult?: boolean
	filtersRef: React.RefObject<FiltersRefType>
	listRef: React.RefObject<LoadMoreListType<any>>
	mode: Mode
	showSelectPosition: () => void
}

const ExpandRadius = React.memo((props: Props) => {

	const searchRadius = props.filtersRef.current?.filters.distance
	const nextRadius = radiusNumOptions.find(num => num > (searchRadius || 0))
	const changeRadius = useCallback(() => {
		const filtersRef = props.filtersRef.current
		if(filtersRef) {
			const maxRadius = radiusNumOptions[radiusNumOptions.length - 1]
			if((props.mode == "explore-dishes" || props.mode == "explore-restaurants") && filtersRef.filters.explore_order_by == "distance") {
				filtersRef.setRadius(maxRadius)
				props.listRef?.current?.retryLoadMore()
			} else if(nextRadius) {
				filtersRef.setRadius(maxRadius)
				props.listRef.current?.resetFinishedData()
				props.listRef.current?.reload()
			}
		}
	}, [props.filtersRef, props.listRef, props.mode, searchRadius])

	const canExpand = props.mode != "delivery" && !!searchRadius && !!nextRadius
	return (
		<View style={styles.container}>
			<Text style={styles.noResultText}>{translate(props.noResult ? "noResultText" : "resultsEndedText")}{"\n"}{translate(canExpand ? "tryExpandSearchRadius" : "tryChangeSearchPosition")}</Text>
			{/* {!!searchRadius && (
				<Text>{radiusOptionLabel(searchRadius)}</Text>
			)} */}
			
			<Button title={translate(canExpand ? "expandSearch" : "changeSearchPosition")} onPress={canExpand ? changeRadius : props.showSelectPosition} noMargin />
		</View>
	)
})

const styles = StyleSheet.create({
	container: {
		padding: margins.pagePadding,
		paddingBottom: margins.pagePadding * 3
	},
	noResultText: {
		textAlign: "center",
		marginBottom: margins.vertical,
		fontSize: 15,
		color: colors.darkGreyText,
	},
})

export default ExpandRadius