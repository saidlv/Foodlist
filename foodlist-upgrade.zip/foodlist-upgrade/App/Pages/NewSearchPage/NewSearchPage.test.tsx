import React from 'react';
import 'react-native';
import NewSearchView from './view';

import renderer from 'react-test-renderer';

it('renders NewSearchView view', () => {
	//expect(renderer.create(<NewSearchView />)).toMatchSnapshot(); //TODO: add NewSearchView props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<NewSearchView pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<NewSearchView pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
