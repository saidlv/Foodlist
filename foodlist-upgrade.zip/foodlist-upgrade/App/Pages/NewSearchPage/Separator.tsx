import IconSepator from "@FoodListCore/Components/IconSepator"
import { colors, margins } from "@FoodListCore/Global/GlobalProps"
import { translate } from "@FoodListCore/I18n"
import { Restaurant } from "@Models/Restaurant"
import React from "react"
import { StyleSheet, Text, View } from "react-native"

export const Separator = React.memo(({ bookings, item, index } : { bookings?: boolean, item: Restaurant, index?: number }) => {
	/* {rest.firstOfExternalServices && (
		<Separator item={rest} bookings={mode == "booking"} />
	)}
	{(rest.firstOfPreorder && mode != "booking") && (
		<Separator preorder />
	) */
	const reorder = item.firstOfForwarding
	const preorder = item.firstOfPreorder || item.firstForwardingPreorder
	const external = item.firstOfExternalServices
	const firstOfFoodlist = index == 0 //if not one of the previous

	if(!reorder && !preorder && !external && !firstOfFoodlist) {
		return <></>
	}
	return (
		<View style={styles.container}>
			{preorder ? (
				<>
					<Text style={styles.title}>{translate(item.firstOfPreorder ? "preorderWithFoodlist" : "preorderWithOthers")}</Text>
					{item.firstOfPreorder}
					{item.firstForwardingPreorder && <Text style={styles.description}>{translate("forwardingOrdersDescription")}</Text>}
					{/* <Text style={styles.description}>{item.firstOfPreorder ? "FoodList" : "Riordina"}</Text> */}
				</>
			) : reorder ? (
				<>
					<Text style={styles.title}>{translate("orderNowWithOthers")}</Text>
					<Text style={styles.description}>{translate("forwardingOrdersDescription")}</Text>
				</>
			) : external ? (
				<>
					<IconSepator materialCommunityIcon="web" size={20} color={colors.blueMenu} />
					<Text style={styles.title}>{translate("externalServices")}</Text>
					<Text style={styles.description}>{translate(bookings ? "externalBookingsDescr" : "externalOrdersDescr")}</Text>
				</>
			) : (
				<>
					<Text style={styles.title}>{translate(bookings ? "bookWithFoodlist" : "orderNowWithFoodlist")}</Text>
				</>
			)}
		</View>
	)
})

const styles = StyleSheet.create({
	container: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: margins.vertical,
		width: "100%",
	},
	title: {
		fontSize: 20,
		fontWeight: "bold",
	},
	description: {

	},
})
