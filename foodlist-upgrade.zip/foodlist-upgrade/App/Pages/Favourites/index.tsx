import React from 'react';
import { ScrollView } from 'react-native'
import FavouritesManager, { GetDishesResponse, GetRestaurantsResponse } from '@Network/FavouritesManager';
import FavouritesPage, { FavouritesViewActions } from './view';
import { alert } from '@Global/GlobalProps';
import { RequestResponse } from '@Models/RequestResponse';
import { Favourite } from '@Models/Favourite';
import { StackNavigationProp } from '@react-navigation/stack';
import { useScrollToTop } from '@react-navigation/native';
import { translate } from '@App/I18n';
import { Dish } from '@Models/Dish';
import { Restaurant } from '@Models/Restaurant';
import { Pluto } from '@Models/Pluto';

type Props = {
	navigation: StackNavigationProp<Pluto>
}

type FavouritesPageState = {
	cellOpened: boolean
	chosenIndex: number
	refreshing: boolean
	dishes: Dish[]
	restaurants: Restaurant[]
}

class FavouritesPageContainer extends React.PureComponent<Props & { scrollRef: React.RefObject<ScrollView> }, FavouritesPageState> {
	manager = new FavouritesManager()
	state: Readonly<FavouritesPageState> = {
		chosenIndex: 0,
		refreshing: false,
		dishes: [],
		restaurants: [],
		cellOpened: false
	}
	chosenIndex = 0
	scrollViewRef?: ScrollView

	componentDidMount() {
		this.props.navigation.addListener('focus', this.onFocus)
	}
	onFocus = () => {
		this.load();
	}
	callbackOpenCell = () => {
		this.setState({
			cellOpened: true
		})
	}
	componentWillUnmount() {
		this.props.navigation.removeListener('focus', this.onFocus)
	}
	loadDishes = () => {
		this.dishesRequest()
			.then(this.onDishesResponse.bind(this))
			.catch((error) => alert(translate("error"), error))
	}
	dishesRequest = () => {
		return this.manager.getDishes()
	}
	onDishesResponse = (body: RequestResponse<GetDishesResponse>) => {
		this.setState({
			dishes: []
		}, () => {
			this.setState({ chosenIndex: this.chosenIndex, refreshing: false, dishes: this.getDishResults(body) })
		})
	}
	loadRestaurants = () => {
		this.restaurantsRequest()
			.then(this.onRestaurantsResponse)
			.catch(error => alert(translate("error"), error))
	}
	restaurantsRequest = () => {
		return this.manager.getRestaurants()
	}
	onRestaurantsResponse = async (body: RequestResponse<GetRestaurantsResponse>) => {
		await this.setState({
			restaurants: []
		})
		this.setState({ chosenIndex: this.chosenIndex, refreshing: false, restaurants: this.getRestResults(body) })
	}

	getResults = (body: RequestResponse<GetDishesResponse | GetRestaurantsResponse>) => {
		return ((body && body.data && body.data.response) || [])
	}

	getDishResults = (body: RequestResponse<GetDishesResponse>) => {
		return this.getResults(body).map((item: Favourite) => {
			if(item.dish) {
				item.dish.is_favourite = true
			}
			return item.dish!
		})
	}

	getRestResults = (body: RequestResponse<GetRestaurantsResponse>) => {
		return this.getResults(body).map((item: Favourite) => {
			if(item.restaurant) {
				item.restaurant.is_favourite = true
			}
			return item.restaurant!
		})
	}

	load = () => {
		if (!this.state.refreshing) {
			this.setState({ refreshing: true })
			if (this.chosenIndex == 0) {
				this.loadRestaurants();
			} else {
				this.loadDishes();
			}
		}
	}

	getData = () => {
		return this.chosenIndex == 0 ? this.state.restaurants : this.state.dishes;
	}

	onIndexChosen = (index: number) => {
		this.chosenIndex = index;
		this.setState({ chosenIndex: index })
	}

	actions: FavouritesViewActions = {
		setRef: this.props.scrollRef,
		onIndexChosen: index => {
			this.chosenIndex = index;
			this.setState({ chosenIndex: index })
		},
		refreshRestaurants: () => {
			this.setState({
				refreshing: true
			})
			this.loadRestaurants()
		},
		refreshDishes: () => {
			this.setState({
				refreshing: true
			})
			this.loadDishes()
		},
		callbackOpenCell: this.callbackOpenCell,
		dishesActions: {
			request: this.dishesRequest,
			onResponse: this.onDishesResponse
		},
		restaurantsActions: {
			request: this.restaurantsRequest,
			onResponse: this.onRestaurantsResponse
		}
	}

	render() {
		return <FavouritesPage
			chosenIndex={this.state.chosenIndex}
			dishes={this.state.dishes}
			restaurants={this.state.restaurants}
			refreshing={this.state.refreshing}
			actions={this.actions}
		/>
	}
}

export default function (props: Props) {
	const ref = React.useRef(null)
	useScrollToTop(ref)

	return <FavouritesPageContainer {...props} scrollRef={ref} />
}