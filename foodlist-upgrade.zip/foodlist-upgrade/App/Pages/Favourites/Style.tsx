import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	scrollContainer: {
		flex: 1,
		flexDirection: "column",
		justifyContent: "space-between"
	},
	container: {
		backgroundColor: colors.greyBackground,
	},
	padding: {
		paddingVertical: 10,
		backgroundColor: colors.white,
		borderBottomColor: colors.greyBorder,
		borderBottomWidth: 1
	}
});
