import React from 'react';
import { colors } from '@Global/GlobalProps';
import { StatusBar, ScrollView, RefreshControl, View } from 'react-native';
import styles from './Style';
import SegmentedControl from '@FoodListCore/Components/SegmentedControl';
import AutoLoadingView, { AutoLoadingActions } from '@FoodListCore/Components/AutoLoadingView'
import { Restaurant } from '@Models/Restaurant';
import { Dish } from '@Models/Dish';
import { GetDishesResponse, GetRestaurantsResponse } from '@Network/FavouritesManager';
import { translate } from '@App/I18n';
import DishList from '@App/Components/ListMenu/DishList';
import RestaurantList from '@App/Components/ListMenu/RestaurantList';

export interface FavouritesViewActions {
	refreshRestaurants: () => void
	refreshDishes: () => void
	onIndexChosen: (index: number) => void
	setRef: React.RefObject<ScrollView>
	callbackOpenCell: () => void
	restaurantsActions: AutoLoadingActions<GetRestaurantsResponse>
	dishesActions: AutoLoadingActions<GetDishesResponse>
}

type ViewProps = {
	actions: FavouritesViewActions
	chosenIndex: number
	refreshing: boolean
	restaurants: Restaurant[]
	dishes: Dish[]
}

type ViewState = {
}

export default class FavouritesPage extends React.PureComponent<ViewProps, ViewState> {
	actions: FavouritesViewActions

	constructor(props: ViewProps) {
		super(props)
		this.actions = props.actions
	}

	componentDidMount() {
		StatusBar.setHidden(false)
	}
	
	onIndexChosen = (i: number) => {
		this.actions.onIndexChosen(i)
	}
	render() {
		return (
			<View
				style={[styles.container, styles.scrollContainer]}
			>
				<View style={styles.padding}>
					<SegmentedControl
						activeButtonTextColor={colors.greyBackground}
						mainColor={colors.blueMenu}
						selected={this.props.chosenIndex}
						onItemSelected={this.onIndexChosen}
						items={[
							{ text: translate("locals") },
							{ text: translate("dish") }
						]}
					/>
				</View>
				{this.props.chosenIndex == 0 &&
					<View style={{ flex: 1, flexGrow: 1 }}>
						<AutoLoadingView
							actions={this.actions.restaurantsActions}
							noData={this.props.restaurants.length == 0}
						/>
						<RestaurantList
							scrollable
							items={this.props.restaurants}
							callbackOpenCell={this.actions.callbackOpenCell}
							refreshControl={
								<RefreshControl
									style={{ zIndex: 10 }}
									refreshing={this.props.refreshing}
									onRefresh={this.actions.refreshRestaurants}
								/>
							}
						/>
					</View>
				}
				{this.props.chosenIndex == 1 &&
					<View style={{ flex: 1, flexGrow: 1 }}>
						<AutoLoadingView
							actions={this.actions.dishesActions}
							noData={this.props.dishes.length == 0}
						/>
						<DishList
							scrollable
							items={this.props.dishes}
							callbackOpenCell={this.actions.callbackOpenCell}
							refreshControl={
								<RefreshControl
									style={{ zIndex: 10 }}
									refreshing={this.props.refreshing}
									onRefresh={this.actions.refreshDishes}
								/>
							}
						/>
					</View>
				}
			</View>
		);
	}
}
