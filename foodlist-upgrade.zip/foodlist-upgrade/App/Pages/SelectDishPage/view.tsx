import React from 'react';
import { colors, regex, stringDefined } from '@Global/GlobalProps';
import { Text, View } from 'react-native';
import FLEditText from '@FoodListCore/Components/Input/FLEditText';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import SegmentedControl from '@FoodListCore/Components/SegmentedControl';
import FormActionButton from '@Components/FormActionButton'
import DishTypeSelection from '@Components/DishTypeSelection';
import { DishType } from '@Models/DishType';
import { Dish } from '@Models/Dish';
import { NewDish } from '@Models/NewDish';
import { translate } from '@App/I18n';
import CommonMenu, { CommonMenuActions } from '@FoodListCore/Components/CommonMenu';
import FlatSearchBar from '@FoodListCore/Components/FlatSearchBar';

type Props = {
	restId: number
	loading: boolean
	dish_types?: DishType[]
	hasMenu: boolean
	onDishSelected: (item: Dish) => void
	onNewDishSelected: (item: NewDish) => void
	actions: CommonMenuActions
}

type State = {
	isNewDish: boolean
	price?: string
	priceValid: boolean
	dishName?: string
	category?: string

	searchText: string
}

export default class SelectDishPage extends React.PureComponent<Props, State> {
	state: Readonly<State> = {
		isNewDish: false,
		priceValid: false,
		searchText: "",
	}

	dishTypeSelection: DishTypeSelection | null = null

	updateHasContent = () => {
		/*let hasContent = (this.state.photo || this.state.content.length > 0 || this.state.vote > 0 
			|| (this.state.price && this.state.price.length > 0) || this.state.dishName?.length > 0 || this.state.category != null)
		this.props.updateHasContent?.(hasContent)*/
	}
	updatePrice = (price: string, isValid: boolean) => {
		this.setState({
			price: price,
			priceValid: isValid
		}, this.updateHasContent)
	}
	updateDishName = (v: string) => {
		this.setState({
			dishName: v
		}, this.updateHasContent)
	}
	onCategorySelected = (item: string) => {
		this.setState({ category: item });
	}
	updateCategory(category: string) {
		this.setState({
			category: category
		}, this.updateHasContent)
	}
	onSubmit = () => {
		if (!this.state.category) return

		this.props.onNewDishSelected({
			name: this.state.dishName ?? "",
			price: this.state.price ?? "",
			category: this.state.category
		})
	}
	render() {
		let hasMenu = this.props.hasMenu
		let isNewDish = this.state.isNewDish || !hasMenu
		let buttonEnabled = (this.state.priceValid && !!this.state.dishName && this.state.dishName.length > 0 && stringDefined(this.state.category))
		//console.log(this.state)
		return (
			<View style={{ flex: 1, backgroundColor: colors.greyBackground }}>
				<View style={{ marginTop: 20 }}>
					{hasMenu && !this.props.loading &&
						<SegmentedControl
							activeButtonTextColor={colors.greyBackground}
							mainColor={colors.blueMenu}
							selected={isNewDish ? 1 : 0}
							items={[
								{ text: translate("chooseFromMenu"), callback: () => { if (hasMenu) this.setState({ isNewDish: false }) } },
								{ text: translate("newDish"), callback: () => { this.setState({ isNewDish: true }) } }
							]}
						/>
					}
					{!hasMenu && <Text style={{ marginHorizontal: 20 }}>{translate("thisRestaurantNoMenu")}</Text>
					}
				</View>
				<View style={(this.props.loading || !isNewDish) ? { marginTop: 10, flex: 1 } : { height: 0, opacity: 0 }}>
					{!this.props.loading && (
						<FlatSearchBar
							onChangeText={(searchText) => this.setState({ searchText })}
							placeholder={translate("searchSectionDishIngredient")}
						/>
					)}
					<CommonMenu
						searchText={this.state.searchText}
						restId={this.props.restId}
						actions={this.props.actions}
					/>
				</View>
				{!this.props.loading && (isNewDish) && (
					<View style={[commonStyle.borderVertical, { marginTop: 20 }]}>
						<FLEditText
							actions={{
								onChangeText: (v) => { this.updateDishName(v) }
							}}
							inputContainerConfig={{
								necessary: true,
							}}
							textInputProps={{
								placeholder: translate("newDishName"),
								fontSize: 18,
								title: translate("name")
							}}
						/>
						<FLEditText
							actions={{
								onPress: () => { this.dishTypeSelection?.show() },
								onChangeText: (v) => { this.updateCategory(v) }
							}}
							inputContainerConfig={{
								necessary: true,
							}}
							textInputProps={{
								placeholder: translate("portataPlaceholder"),
								fontSize: 18,
								defaultValue: this.state.category,
								title: translate("portata"),
								editable: false,
							}}
						/>
						<FLEditText
							actions={{
								onChangeText: (v, isValid) => this.updatePrice(v, isValid)
							}}
							inputContainerConfig={{

							}}
							textInputProps={{
								placeholder: "0,00",
								fontSize: 18,
								title: translate("priceCurrency"),
								keyboardType: "numeric"
							}}
							regex={regex.PRICE}
							price
						/>
						<DishTypeSelection
							ref={ref => this.dishTypeSelection = ref}
							items={this.props.dish_types?.map((item) => {
								return {
									id: item.id,
									name: item.label_it ?? ""
								}
							}) ?? []}
							onItemSelected={this.onCategorySelected}
						/>
					</View>
				)}

				{!this.props.loading && (isNewDish) && (
					<View style={{ marginVertical: 10 }}>
						<FormActionButton enabled={buttonEnabled} full={true} title={translate("confirm")} onPress={() => { this.onSubmit() }} />
					</View>
				)}
			</View>

		);
	}
}
