import React from 'react';
import RestaurantManager from '@Network/RestaurantManager';
import InfoPage from "./view"
import { error } from '@Global/GlobalProps';
import { Menu } from '@Models/Menu';
import { DishType } from '@Models/DishType';
import { Dish } from '@Models/Dish';
import { ItemsMap } from '@Models/ItemsMap';
import { NewDish } from '@Models/NewDish';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';
import { CommonMenuActions } from '@FoodListCore/Components/CommonMenu';


type Props = {
	navigation: CommonNavigation<"SelectDish">
	route: CommonRoute<"SelectDish">
}

type State = {
	id?: number
	hasMenu: boolean
	loading: boolean
	dish_types?: DishType[]
}

export default class SelectDishContainer extends React.PureComponent<Props, State> {
	manager = new RestaurantManager()
	onDishSelected?: (item: Dish) => void
	onNewDishSelected?: (item: NewDish) => void

	constructor(props: Props) {
		super(props);
		const { onDishSelected, onNewDishSelected, restaurant_id } = props.route.params
		this.onDishSelected = onDishSelected
		this.onNewDishSelected = onNewDishSelected
		this.state = {
			id: restaurant_id,
			hasMenu: true,
			loading: true
		}
	}
	componentDidMount = () => {
		this.loadMenu()
	}

	loadMenu() {
		if (!this.state.id) return
	}

	openDish = (item: Dish) => {
		this.onDishSelected?.(item)
		this.props.navigation.goBack()
	}

	onNewDish = (item: NewDish) => {
		this.onNewDishSelected?.(item)
		this.props.navigation.goBack()
	}

	actions: CommonMenuActions = {
		openDish: this.openDish,
		onMenuLoaded: (menu) => {
			this.setState({
				hasMenu: menu?.length > 0,
				dish_types: (menu || []).map(section => ({
					id: section.id,
					label_it: section.name,
					name: section.name,
				})),
				loading: false,
			})
		},
	}

	render() {
		return (
			<InfoPage
				restId={this.state.id}
				loading={this.state.loading}
				hasMenu={this.state.hasMenu}
				dish_types={this.state.dish_types}
				onDishSelected={this.openDish}
				onNewDishSelected={this.onNewDish}
				actions={this.actions}
			/>
		);
	}
}