import { margins } from '@FoodListCore/Global/GlobalProps';
import { colors } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet, Platform, Dimensions } from 'react-native';

export default StyleSheet.create({
	container: {
		marginTop: margins.pagePadding,
		alignItems: 'center'
	},
	commentsText: {
		paddingRight: 22
	},
	title: {
		fontSize: 16,
		fontWeight: "700",
		textAlign: 'center'
	},
	reviewContainer: {
		backgroundColor: colors.white,
		borderRadius: 6,
		marginHorizontal: margins.pagePadding,
		marginTop: 10
	},
	headerContainer: {
		flex: 1,
		flexDirection: 'row'
	},
	kitchenKind: {
		alignSelf: "flex-start",
		fontWeight: '700',
		fontSize: 12,
		textAlignVertical: 'center',
		color: colors.greyText
	},
	header: {
		flex: 1,
		alignItems: 'stretch',
		marginVertical: 12,
		justifyContent: 'center'
	},
	text: {
		width: 57,
		marginRight: 30,
		fontSize: 12,
		fontWeight: "500",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText
	},
	imageContainer: {
		flex: 0,
		marginLeft: 12,
		marginVertical: 12,
		marginRight: 10
	},
	image: {
		height: 30,
		width: 30,
		borderRadius: 15
	},
	headerReview: {
		fontSize: 14,
		fontWeight: "bold",
		flex: 1,
		color: colors.blackText
	},
	smallTextReview: {
		fontSize: 10,
		fontWeight: "bold",
		fontStyle: "normal",
		color: colors.greyText
	},
	alignRight: {
		textAlign: 'right',
		flex: 0
	},
	flexAdapt: {
		flex: 1,
		alignItems: 'stretch'
	},
	smallMarginTop: {
		marginTop: 3
	},
	reviewText: {
		fontSize: 14,
		fontWeight: "normal",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText
	},
	marginText: {
		marginTop: 12,
		marginLeft: 12,
		marginRight: 12,
		marginBottom: 12
	},
	marginImage: {
		marginTop: 12,
		marginHorizontal: 12
	},
	imageReview: {
		width: "100%",
		resizeMode: 'contain'
	},
	flexRowBottom: {
		flex: 1,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginTop: 12,
		marginLeft: 12,
		marginBottom: 12
	},
	inline: {
		flex: 0,
		flexDirection: 'row',
		alignItems: 'center'
	},
	flexRow: {
		flex: 1,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center'
	},
	justifySpaceBetween: {
		justifyContent: 'space-between',
	},
	greyText: {
		fontStyle: "normal",
		fontSize: 12,
		fontWeight: '900',
		color: colors.greyText,
		textAlignVertical: 'center',
		paddingLeft: 6,
		paddingRight: 22
	},
	redText: {
		fontStyle: "normal",
		fontSize: 12,
		fontWeight: '900',
		color: colors.red,
		textAlignVertical: 'center',
		paddingLeft: 6,
		paddingRight: 22
	},
	commentBox: {
		flex: 0,
		alignSelf: "stretch",
		justifyContent: 'flex-end',
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 10,
		shadowColor: '#000',
		backgroundColor: colors.greyBackground,
		shadowOffset: { width: 0, height: 0 },
		shadowOpacity: 0.25,
		shadowRadius: 3,
		borderTopWidth: Platform.select({
			android: 1,
			ios: 0
		}),
		borderColor: colors.darkGreyBorder
	},
	innerCommentBox: {
		flex: 0,
		backgroundColor: colors.greyBackground,
		borderRadius: 6,
		overflow: 'hidden'
	},
	infoBox: {
		//minHeight: 40,
		backgroundColor: 'rgba(236, 236, 236, 0.35)'
	},
	bottomRowContainer: {
		paddingVertical: 10,
		paddingHorizontal: 12
	},
	postTime: {
		marginHorizontal: 12,
		marginTop: 10
	},
	ratingRow: {
		flex: 1,
		flexDirection: 'row',
		width: "100%",
		justifyContent: 'space-between'
	}

});
