import React from 'react';
import { View, Keyboard, ScrollView, Text } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import FLEditText from '@FoodListCore/Components/Input/FLEditText'
import Icon from '@FoodListCore/Iconfont/FoodListIconfont'
import { colors } from '@Global/GlobalProps';
import globalStyles from '@FoodListCore/Global/CommonStuff/PageStyle';
import styles from './Style'
import commonStyles from '@FoodListCore/Global/CommonStyle';
import FeedItem from "@Components/FeedItem"
import ProfileImage from '@Components/ProfileImage';
import AutoLoadingView from '@FoodListCore/Components/AutoLoadingView'
import { connect } from 'react-redux';
import ActionSheet from '@alessiocancian/react-native-actionsheet';
import { ReduxState } from '@Redux/StateFormat';
import { User } from '@Models/User';
import { FeedTypePrefix } from '@Models/FeedType';
import FLKeyboardAwareScrollView from '@Components/FLKeyboardAwareScrollView';
import { Review } from '@Models/Review';
import { ReviewToLoad } from '@Models/ReviewToLoad';
import { Comment } from '@Models/Comment';
import { translate } from '@App/I18n';
import { getDiffStringFromNow } from '@FoodListCore/Services/DateManager';
import { margins } from '@FoodListCore/Global/GlobalProps';

export interface Actions {
	onComment: (input: string, onFinish: () => void) => void,
	reloadData: (del?: boolean) => void,
	callbackUpdateData?: () => void,
	onDeleteComment: (type: FeedTypePrefix, id: number, reviewId: number, commentId: number) => void,
	showUser: (user: User) => void

	scrollRef: (ref: ScrollView) => void
}

type Props = {
	data: Review | ReviewToLoad
	commentsList: Comment[]
	actions: Actions
	loading: boolean
	sendingComment: boolean
	refresh: boolean
	review: Review | ReviewToLoad | undefined
	disableUserPress: boolean
	current_user_id?: number
}

type State = {
	input: string
	data: Review | ReviewToLoad
	commentsList: Comment[]
	statusBarHeight?: number
	selectedComment?: Comment
}

class ReviewDetail extends React.PureComponent<Props, State> {
	actions: Actions
	editText: FLEditText | null = null
	actionSheet: ActionSheet | null = null
  /* statusBarListener: EmitterSubscription | null = null
  keyboardAwareScrollView: KeyboardAwareScrollView | null = null */

	constructor(props: Props) {
		super(props);
		this.actions = props.actions

		//TODO: sta roba non aveva un cazzo di senso
    /*SessionManager.getCurrentUser((user) => {
      this.props.review.liked = this.props.data.likes.filter((item) => item.user_id == user.id).length > 0;
      this.setState({liked: this.props.review.liked}) //trigger rerender
    })*/

		this.state = {
			input: "",
			data: this.props.data || {},
			commentsList: this.props.commentsList || []
		}
	}

  /* componentWillUnmount () {
    if (Platform.OS === 'ios' && this.statusBarListener) {
      this.statusBarListener.remove()
    }
  } */

  /* componentWillReceiveProps(nextProps: Props) {
    if(nextProps.commentsList != this.props.commentsList) {
      this.setState({
        data: nextProps.data,
        commentsList: nextProps.commentsList
      })
    }
  }*/

	static getDerivedStateFromProps(props: Props, state: State) {
		if (props.commentsList != state.commentsList) {
			return {
				data: props.data,
				commentsList: props.commentsList
			}
		}
		return null
	}

	showActionSheet = (index: number) => {
		//To show the Bottom ActionSheet
		this.setState({
			selectedComment: this.props.commentsList[index]
		}, () => {
			this.actionSheet?.show();
		})
	}

	clearInput = () => {
		this.setState({ input: "" })
		this.editText?.clear();
	}
	onComment = () => {
		Keyboard.dismiss();

		this.actions.onComment(this.state.input, () => {
			this.clearInput()
		})
	}
	getReviewImage() {
		return /* this.props.data.image ||  */'reviewImage' in this.props.data && this.props.data.reviewImage
	}

	render() {
		var optionArray = [
			translate("delete"),
			translate("cancel"),
		];
		const item = this.state.data
		return (
			<FLKeyboardAwareScrollView
				contentContainerStyle={{ flex: 1 }}
				hasNestedScrollView
				extraScrollHeight={28}
			>
				<View style={{ flex: 1, flexDirection: "column" }}>
					<AutoLoadingView loading={this.props.loading} />
					<ScrollView
						style={[globalStyles.flexColumn, { backgroundColor: colors.greyBackground }]}
						contentContainerStyle={{ paddingBottom: margins.pagePadding, paddingTop: 10 }}
						keyboardShouldPersistTaps={'handled'}
						ref={this.actions.scrollRef}
					>
						{'content' in item &&
							<FeedItem
								key={item.id + "_" + item.updated_at}
								item={item}
								showDetail={false}
								callbackShouldReload={this.actions.reloadData}
								disableUserPress={this.props.disableUserPress}
								callbackUpdateData={this.actions.callbackUpdateData}
							/>
						}
						<View>
							{this.props.commentsList.map((item, index) => {
								return (
									<View key={index} style={[styles.reviewContainer, commonStyles.shadow]}>
										<View style={styles.headerContainer}>
											<View style={{ flex: 1, flexDirection: 'row' }}>
												<View style={{ flex: 0, alignSelf: 'flex-start' }}>
													<TouchableOpacity style={styles.imageContainer} onPress={() => { this.actions.showUser(item.user) }}>
														<ProfileImage source={item.user.photo || undefined} />
													</TouchableOpacity>
												</View>

												<View style={{ flex: 1 }}>
													<View style={styles.header}>
														<Text>
															<Text style={styles.headerReview} onPress={() => { this.actions.showUser(item.user) }}>{item.user.username}</Text>
															<Text style={styles.reviewText}>&nbsp; {item.content} &nbsp;</Text>
															<Text style={[styles.smallTextReview, styles.alignRight]}>{ getDiffStringFromNow(item.created_at.toString(), translate)}</Text>
														</Text>
													</View>
												</View>

												<View style={{ flex: 0, alignSelf: 'center' }}>
													{(this.props.current_user_id == item.user_id) && (
														<View style={{ transform: [{ rotate: '90deg' }] }}>
															<TouchableOpacity style={{ padding: 10 }} onPress={() => { this.showActionSheet(index) }}>
																<Icon name="more" size={4} color={colors.greyText} />
															</TouchableOpacity>
														</View>
													)}
												</View>

											</View>

											<ActionSheet
												ref={o => this.actionSheet = o}
												options={optionArray}
												cancelButtonIndex={1}
												destructiveButtonIndex={0}
												onPress={index => {
													if (index == 0) {
														const type = (this.state?.data?.feed_type == "RESTAURANT") ? "restaurants" : "dishes"
														// @ts-ignore
														const id = (type == "restaurants") ? this.state.data.restaurant_id : this.state.data.dish_id
														const reviewId = this.state.selectedComment?.review_id
														const commentId = this.state.selectedComment?.id

														this.actions.onDeleteComment(type, id, reviewId!, commentId!)
													}
												}}
											/>
										</View>
									</View>
								)
							})}
						</View>
					</ScrollView>
					<View style={styles.commentBox}>
						<View style={styles.innerCommentBox}>
							<FLEditText
								ref={input => { this.editText = input }}
								actions={{
									onSubmit: () => this.onComment(),
									onChangeText: (t) => this.setState({ input: t })
								}}
								inputContainerConfig={{
									icon: "comment",
									actionButtonProps: {
										sendingComment: this.props.sendingComment,
										actionEnabled: this.state.input.length > 0,
										action: translate("send")
									}
								}}
								textInputProps={{
									placeholder: translate("writeCommentPlaceholder"),
								}}
							/>
						</View>
					</View>
				</View>
			</FLKeyboardAwareScrollView>
		);
	}
}

export default connect((state: ReduxState) => {
	return {
		current_user_id: state.currentUser?.id
	}
})(ReviewDetail)