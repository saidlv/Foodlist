import React from 'react';
import ReviewDetail, { Actions } from './view';
import { alert } from '@Global/GlobalProps';

import ReviewDetailManager from '@Network/ReviewDetailManager';
import FeedItemMap from "@Components/FeedItem/map"
import { User } from '@Models/User';
import { FeedTypePrefix } from '@Models/FeedType';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';
import { Review, isFullReview } from '@Models/Review';
import { ReviewToLoad } from '@Models/ReviewToLoad';
import { Comment } from '@Models/Comment';
import requestAuth from '@FoodListCore/Flows/RequestAuth';
import { getCurrentUser } from '@FoodListCore/Redux/ReduxHelper';
import { ScrollView } from 'react-native';

type Props = {
	navigation: CommonNavigation<"ReviewDetail">
	route: CommonRoute<"ReviewDetail">
}

type State = {
	loading: boolean
	sendingComment: boolean
	disableUserPress: boolean
	data: Review | ReviewToLoad
	commentsList: Comment[]
	review: Review | ReviewToLoad | undefined
	refresh?: boolean
}

export default class ReviewDetailContainer extends React.PureComponent<Props, State> {
	manager = new ReviewDetailManager();
	scrollRef: ScrollView | null = null

	constructor(props: Props) {
		super(props);
		const { disableUserPress, data } = props.route.params
		this.state = {
			loading: false,
			sendingComment: false,
			disableUserPress: disableUserPress || false,
			data: data,
			review: undefined,
			commentsList: []
		}
	}

	componentDidMount() {
		this.loadData()
	}

	loadData = () => {
		const review: Review | ReviewToLoad = this.props.route.params.data

    /* const reloadDataComments = (review?.comments?.length > 0) ? 
        ((review?.comments[0]?.hasOwnProperty('user')) ? false : true) 
        : 
        (review?.hasOwnProperty('comments')) ? false : true */
		let reloadDataComments
		if ('comments' in review && review?.comments?.length > 0) {
			reloadDataComments = !review?.comments[0]?.hasOwnProperty('user')
		} else {
			reloadDataComments = !review?.hasOwnProperty('comments')
		}

		if (!review || reloadDataComments) {
			this.setState({ loading: true })

			this.manager.getInfoReviewDetail(review).then((response) => {
				this.setState({ loading: false })
				if (response.success) {
					let data = response.data!.response
					data.feed_type = review.feed_type;
					const result = FeedItemMap(data);
					this.setState({
						data: result,
						review: result,
						commentsList: data.comments,
					});

				} else {
					throw new Error(response.error)
				}
			}).catch((error) => {
				this.setState({ loading: false })
				alert("Errore", error)
			})
		} else {
			this.setState({
				loading: false,
				data: review,
				review: review,
				commentsList: 'comments' in review ? review.comments : [],
			});
		}
	}

	onComment = (text: string, clearInput: () => void) => {
		if (text == null || text == "") return;
		if(!requestAuth(this.props.navigation)) return

		if ('content' in this.state.data) {
			this.setState({ sendingComment: true });
			const comments = this.state.commentsList;
			this.manager.comment(this.state.data, text).then((response) => {
				clearInput?.()
				this.setState({ sendingComment: false });
				const currentUser = getCurrentUser()
				if (response.success && response.data && currentUser) {
					response.data.response.user = currentUser
					comments.push(response.data.response)
					const data = { ...this.state.data }
					if ('comments' in data) {
						data.comments = comments;
						this.props.route.params.callbackUpdateData?.(data)
					}
					this.setState({
						refresh: !this.state.refresh,
						data: data,
						commentsList: comments
					}, () => {
						setTimeout(() => {
							this.scrollRef?.scrollToEnd()
						})
					});
				} else {
					throw new Error(response.error);
				}
			}).catch((error) => {
				alert("Error", error)
				this.setState({ sendingComment: false })
			})
		}
	}

	onDeleteComment = (type: FeedTypePrefix, id: number, reviewId: number, commentId: number) => {
		if (!this.state.loading) {
			this.setState({ loading: true })
			this.manager.deleteComment(type, id, reviewId, commentId).then((body) => {
				//console.log(body)
				if (body?.success) {
					this.setState({ loading: false })

					const removedCommentList = this.state.commentsList.filter(function (item) {
						return item.id != commentId;
					});

					const data = { ...this.state.data }
					if ('comments' in data) {
						data.comments = removedCommentList;
						this.props.route.params.callbackUpdateData?.(data)
						this.setState({
							data: data,
							loading: false,
							commentsList: removedCommentList
						})
					}
				} else {
					this.setState({ loading: false })
					throw new Error(body.error)
				}
			})
		}
	}

	reloadData = (del?: boolean) => {
		if (del) {
			this.props.route.params.callbackShouldReload?.(true)
			this.props.navigation.goBack()
		} else {
			this.props.route.params.callbackShouldReload?.()
			this.setState({ loading: true })
			this.loadData()
		}
	}

	actions: Actions = {
		onComment: this.onComment,
		onDeleteComment: this.onDeleteComment,
		reloadData: this.reloadData,
		callbackUpdateData: this.props.route.params.callbackUpdateData,
		showUser: (user: User) => {
			if (!this.state.disableUserPress) {
				this.props.navigation.push("ProfilePage", { user_id: user.id })
			}
		},
		scrollRef: (ref) => {
			this.scrollRef = ref
		}
	}

	render() {
		return (
			<ReviewDetail
				actions={this.actions}
				sendingComment={this.state.sendingComment}
				refresh={this.state.refresh ?? false}
				loading={this.state.loading}
				data={this.state.data}
				review={this.state.review}
				commentsList={this.state.commentsList}
				disableUserPress={this.state.disableUserPress}
			/>
		);
	}
}
