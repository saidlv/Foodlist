import { SearchNavigation, SearchRoute } from '@App/RouteParams/Search';
import { translate } from '@FoodListCore/I18n';
import React from 'react';
import PickPositionView, { PickPositionViewActions } from './view';

type Props = {
	navigation: SearchNavigation<"PickLocation">
	route: SearchRoute<"PickLocation">
}

export type State = {
	
}

class PickPositionPage extends React.PureComponent<Props, State> {
	constructor(props: Props) {
		super(props)
		this.state = {

		}
	}

	actions: PickPositionViewActions = {
		onPositionPicked: (position) => {
			this.props.navigation.navigate("SearchPage", {
				searchPosition: {
					...position,
					id: -1,
					region_name: "Dalla mappa",
					region_name_long: translate("positionFromMap"),
					parent_region_name_long: "Ti ho detto dalla mappa"
				}
			})
		}
	};

	render() {
		return (
			<PickPositionView
				actions={this.actions}
				state={this.state}
				initialPosition={this.props.route.params.defaultPosition || {
					latitude: 45,
					longitude: 12
				}}
			/>
		);
	}
}

export default PickPositionPage;
