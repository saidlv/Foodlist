import React from 'react';
import 'react-native';
import PickPositionView from './view';

import renderer from 'react-test-renderer';

it('renders PickPositionView view', () => {
	//expect(renderer.create(<PickPositionView />)).toMatchSnapshot(); //TODO: add PickPositionView props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<PickPositionView pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<PickPositionView pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
