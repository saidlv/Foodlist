import React from 'react';
import { State } from './';
import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';
import PositionPicker, { PositionPickerActions } from '@FoodListCore/Components/PositionPicker';
import { Region } from '@FoodListCore/Global/CommonStuff/CommonFunctions';

export interface PickPositionViewActions extends PositionPickerActions {

}

type Props = {
	actions: PickPositionViewActions
	state: Readonly<State>

	initialPosition: Region
}

const PickPositionView = (props: Readonly<Props>) => {
	const { state, actions } = props
	return (
		<PositionPicker
			initialPosition={{
				...props.initialPosition,
				latitudeDelta: 0.1,
				longitudeDelta: 0.1
			}}
			actions={actions}
		/>
	);
};

const styles = StyleSheet.create({

});

export default PickPositionView;
