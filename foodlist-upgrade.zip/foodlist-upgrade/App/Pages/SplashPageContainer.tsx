import React, { Component } from 'react'
import { View, Platform, Alert, StatusBar } from 'react-native'
import { NetworkNavigation } from "@Network/NetworkManager"
import { colors } from '@Global/GlobalProps';
import SessionManager from "@FoodListCore/Services/SessionManager"
import { connect } from "react-redux";
import GlobalManager from "@Network/GlobalManager";
import NotificationsManager from "@FoodListCore/Network/NotificationsManager";
import { setNotifications, addNotification, setFoodPreferences, setOccasions, setPaymentMethods, ReduxAction, setRestaurantCategories } from "@Redux/Actions"
import VersionNumber from 'react-native-version-number';
import NetworkManager from '@Network/NetworkManager';
import SplashScreen from 'react-native-splash-screen';
import FirebaseMessaging from "@Services/FirebaseMessaging"
import FirebaseAnalytics from "@Services/FirebaseAnalytics"
import { ShareGlobals, resetToHome } from '@Services/ShareManager';
import NotificationsPageContainer from "@Pages/NotificationsPage";
import { alert } from '@Global/GlobalProps';
import { ReduxState } from '@Redux/StateFormat';
import { Dispatch } from 'redux';
import { AuthNavigation } from '@RouteParams/Auth';
import { translate } from '@App/I18n';
import { Pippo } from '@Models/Pippo';
import { store } from '@App/Redux/Reducer';
import { StackNavigationProp } from '@react-navigation/stack';
import { userLogged } from '@FoodListCore/Redux/ReduxHelper';
import AutoLoadingView from '@App/Components/AutoLoadingView';
import { CommonNavigation } from '@App/RouteParams/Common';
import { INITIAL_SEARCH_RADIUS } from '@App/Redux/StateFormat/FiltersFormat';
import SearchManager from '@App/Network/SearchManager';
import AuthManager from '@FoodListCore/Network/AuthManager';

const handleReduxRequest = (promise: Promise<Pippo>, reduxAction: (args: Pippo[]) => ReduxAction) => {
	return {
		promise,
		reduxAction
	}
}

const mapRedux = (state: ReduxState) => {
	return {
		dishFilters: state.dishFilters,
		restFilters: state.restFilters,
		skipLogin: state.ignoreLogin
	}
}

type SplashPageContainerProps = {
	navigation: AuthNavigation<"SplashPage">
	dispatch: Dispatch
} & ReturnType<typeof mapRedux>

type SplashPageContainerState = {
	loading: boolean
	error: string | null
}


class SplashPageContainer extends React.PureComponent<SplashPageContainerProps, SplashPageContainerState> {
	constructor(props: SplashPageContainerProps) {
		super(props)
		this.state = {
			loading: true,
			error: null
		}
		NetworkNavigation.navigation = props.navigation;
	}

	static loadData() {
		let notificationsManager = new NotificationsManager();
		let globalManager = new GlobalManager();
		let reduxRequests = [
			...(userLogged() ? [handleReduxRequest(notificationsManager.list(), setNotifications)] : []),
			handleReduxRequest(globalManager.getRestaurantCategories(), setRestaurantCategories),
			/* //handleReduxRequest(globalManager.getDishRestrictions(), setDishRestrictions),
			handleReduxRequest(globalManager.getFoodPreferences(), setFoodPreferences),
			handleReduxRequest(globalManager.getOccasions(), setOccasions),
			//handleReduxRequest(globalManager.getStyles(), setStyles),
			handleReduxRequest(globalManager.getPaymentMethods(), setPaymentMethods), */
		]
		return Promise.all(reduxRequests.map((item) => { return item.promise })).then((values) => {
			values.forEach((response, index) => {
				const data = response?.data?.response
				if (data) {
					store.dispatch(reduxRequests[index].reduxAction(data))
				} else if (index == 0) {
					store.dispatch(reduxRequests[0].reduxAction(response))
				}
			})
		})
	}

	onFocus = () => {
		if(this.wasHandlingNotifications) {
			resetToHome()
		}
	}

	componentDidMount() {
		setTimeout(() => {
			StatusBar.setBackgroundColor(colors.darkFoodlist)
			StatusBar.setHidden(false)
			SplashScreen.hide();
		})

		this.props.restFilters.values.orderBy = 0
		this.props.restFilters.values.maxSearchRadius = INITIAL_SEARCH_RADIUS
		this.props.dishFilters.values.orderBy = 0

		this.props.navigation.addListener("focus", this.onFocus)
		
		/*setTimeout(() => {
			//ShareGlobals.navigator = this.props.navigation;
		this.reset();
	}, 2000)*/
		ShareGlobals.navigator = this.props.navigation;

		SessionManager.loadStorageToRedux().then(this.loadAllData)
	}

	componentWillUnmount() {
		this.props.navigation.removeListener("focus", this.onFocus)
	}

	wasHandlingNotifications = false
	loadAllData = async () => {
		try {
			if(Platform.OS !== "web") {
				let versions: Pippo = await NetworkManager.getMinVersions();
				//console.log('Versions', versions);
				let build = VersionNumber.buildVersion;
				console.log("versions", versions, build)
				if (Platform.OS == 'android' && build < versions.min_build_android) {
					this.updateDialog();
					return
				} else if (Platform.OS == 'ios' && build < versions.min_build_ios) {
					this.updateDialog();
					return
				}
			}
			if(this.props.skipLogin) {
				console.log("skip login")
				SplashPageContainer.reset(true, this.props.navigation)
			} else {
				const authManager = new AuthManager()
				authManager.loginSilently().then(async res => {
					await FirebaseMessaging.linkToken();
					FirebaseAnalytics.initUser();

					await SplashPageContainer.loadData() //TODO: rimettere la load delle notifiche
					//this.handleDeepLink();
					this.wasHandlingNotifications = true
					SplashPageContainer.handleNotifications(true, this.props.navigation)
				})
				.catch(async () => {
					await SessionManager.logout()
					SplashPageContainer.reset(false, this.props.navigation)
				})
			}
		} catch (error) {
			this.showError(error)
		}
	}


	showError = (error: string) => {
		this.setState({
			error: translate("impossibleToFetchData"),
			loading: false
		})
	}

	static reset = (isLogged: boolean, navigation: StackNavigationProp<any>) => {
		const route = SessionManager.getRouteNameFor(isLogged);

		setTimeout(() => {
			navigation.reset({
				index: 0,
				routes: [{
					name: route
				}]
			})
		}, 10)
	}

	
	static handleNotifications = (isLogged: boolean, navigation: CommonNavigation<any> | AuthNavigation<any>, preventReset?: boolean) => {
		FirebaseMessaging.listenForNotifications();
		FirebaseMessaging.getEntryPointNotification().then((notification) => {
			//console.log('Notification received', notification)
			const item = FirebaseMessaging.getBody(notification?.notification);
			if (item != null) {
				store.dispatch(addNotification(item))
				NotificationsPageContainer.handleNotificationPress(item, navigation, () => {
					resetToHome();
				});
			} else if(!preventReset) {
				SplashPageContainer.reset(isLogged, navigation);
			}
		}).catch((error) => {
			alert("Errore", error)
		});
	}

	updateDialog = () => {
		Alert.alert(translate("updateRequiredTitle"), translate("updateRequiredMessage"), [
			{ text: translate("update"), onPress: () => { } },
			{ text: translate("actionClose"), onPress: () => { } }
		]);
	}

	retry = () => {
		this.setState({
			error: null,
			loading: true
		})
		this.loadAllData()
	}

	render() {
		console.disableYellowBox = true;
		return (
			<View style={{ alignItems: 'center', justifyContent: 'center', flex: 1, backgroundColor: colors.greyBackground }}>
				<AutoLoadingView
					dontStart
					loading={this.state.loading}
					error={this.state.error}
					actions={{
						onRetry: this.retry
					}}
					showLogo
				/>
			</View>
		);
	}
}
export default connect(mapRedux)(SplashPageContainer)
