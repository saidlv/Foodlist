/* eslint-disable no-console */
import React from 'react';
import ReviewsListLoadMorePage from './view';
import InfoFoodManager from '@FoodListCore/Network/InfoFoodManager';
import RestaurantManager from '@Network/RestaurantManager';
import UserManager from '@Network/UserManager';
import { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import { ReviewsListActions } from '@Models/ReviewsListActions';
import { ReviewsStaticData } from '@Components/ReviewsList';
import { RequestResponse } from '@Models/RequestResponse';
import { ReviewsFilterOptions } from '@Components/ReviewListFilterHeader/view';
import { Review } from '@Models/Review';
import { ListParams } from '@Models/ListParams';
import { ReviewType } from '@Models/ReviewType';
import { ReviewListResponse } from '@FoodListCore/Network/ReviewManager';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';

export type ReviewsListLoadMoreParams = {
	actions: ReviewsListActions
	data: ReviewsStaticData
	options: ReviewsFilterOptions
	typeFilter: ReviewType
	ratingFilter: string
}

type Props = {
	navigation: CommonNavigation<"ReviewsListLoadMorePage">
	route: CommonRoute<"ReviewsListLoadMorePage">
}

type State = {
	loading: boolean
	params: Partial<ListParams>
	typeFilter: ReviewType
	ratingFilter: string
}

export default class ReviewsListLoadMore extends React.PureComponent<Props, State> {
	list?: LoadMoreListType<Review>
	navigationParams: ReviewsListLoadMoreParams

	constructor(props: Props) {
		super(props);

		const { route } = props
		this.navigationParams = route.params.listParams

		this.state = {
			params: {},
			typeFilter: this.navigationParams.typeFilter,
			ratingFilter: this.navigationParams.ratingFilter,
			loading: false
		}

		this.navigationParams.actions = {
			callbackShouldReload: this.callbackShouldReload,
			filterCallback: (type, rating) => {
				this.setState({
					typeFilter: type,
					ratingFilter: rating,
				})
				//this.navigationParams.actions.filterCallback(type, rating)
				this.list?.reload()
			},
		}
	}

	custom_sort(a: Review, b: Review) {
		return new Date(b.content_updated_at).getTime() - new Date(a.content_updated_at).getTime()
	}

	getRequest = (params: ListParams) => {
		const data = this.navigationParams.data
		this.setState({ params: params })
		return new Promise<RequestResponse<ReviewListResponse | null>>(async (resolve, reject) => {
			let manager
			let response
			if (!this.state.loading) {

				this.setState({ loading: true })
				const { ratingFilter, typeFilter } = this.state

				if (data.restaurantReview) {
					if (!data.restaurantData?.id) return
					manager = new RestaurantManager()
					response = await manager.getReviewsRestaurant(data.restaurantData?.id, params, typeFilter, ratingFilter)
					this.setState({ loading: false })
				} else if (data.dishReview) {
					if (!data.dishData?.id) return
					manager = new InfoFoodManager()
					//TODO: was using this.props.navigation.getParam('restaurant_id', null), don't know how it was working :O
					response = await manager.getReviewsFood(data.dishData?.id, params, ratingFilter)
					this.setState({ loading: false })
				} else if (this.navigationParams.options.isProfile) {
					if (!data.user?.id) return

					manager = new UserManager()
					let review_response = await manager.getReviews(data.user?.id, params, typeFilter, ratingFilter)
					this.setState({ loading: false })

					let allReviews: Review[] = []
					const restaurantReviews: Review[] = review_response.data?.response?.restaurants || []
					const dishReviews: Review[] = review_response.data?.response?.dishes || []

					restaurantReviews.forEach(elem => {
						allReviews.push(elem)
					})
					dishReviews.forEach(elem => {
						allReviews.push(elem)
					})

					response = {
						...(review_response),
						data: {
							...(review_response.data),
							response: allReviews.sort(this.custom_sort)
						}
					}
				}
			}
			resolve(response);
		});
	}

	callbackShouldReload = () => {
		//this.navigationParams.actions.callbackShouldReload?.()
		this.list?.reload(false)
	}

	render() {
		return (
			<ReviewsListLoadMorePage
				callbackRef={(ref) => { this.list = ref }}
				request={this.getRequest}
				params={{
					...this.navigationParams,
					typeFilter: this.state.typeFilter,
					ratingFilter: this.state.ratingFilter,
				}}
			/>
		)
	}
}
