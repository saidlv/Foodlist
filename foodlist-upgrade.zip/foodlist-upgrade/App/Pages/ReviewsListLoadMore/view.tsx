import React from 'react';
import { View } from 'react-native';
import LoadMoreList, { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import FeedItem from '@Components/FeedItem'
import ReviewListFilterHeader from '@Components/ReviewListFilterHeader';
import { colors } from '@Global/GlobalProps';
import FeedItemMap from '@Components/FeedItem/map';
import { RequestResponse } from '@Models/RequestResponse';
import { ReviewsListLoadMoreParams } from '.';
import { Review } from '@Models/Review';
import { ReviewListResponse } from '@FoodListCore/Network/ReviewManager';
import { ListParams } from '@Models/ListParams';
import { margins } from '@FoodListCore/Global/GlobalProps';

type Props = {
	params: ReviewsListLoadMoreParams
	callbackRef: (ref: LoadMoreListType<Review>) => void
	request: (params: ListParams) => Promise<RequestResponse<ReviewListResponse | null>>
}

export default class UserListPage extends React.PureComponent<Props> {
	render() {
		const { params } = this.props
		const { options, actions, data } = params
		const isProfile = options.isProfile
		this.props.params.ratingFilter
		return (
			<View style={{ flex: 1, backgroundColor: colors.greyBackground }}>
				<View style={{ paddingVertical: 10, backgroundColor: colors.white, borderBottomWidth: margins.hairlineWidth, borderColor: colors.greyBorder }}>
					<ReviewListFilterHeader
						options={options}
						actions={actions}
						initialTypeFilter={params.typeFilter}
						initialRatingFilter={params.ratingFilter}
					/>
				</View>
				<LoadMoreList
					request={this.props.request}
					listRef={this.props.callbackRef}
					contentContainerStyle={{ backgroundColor: colors.greyBackground }}
					renderItem={({ item }) => {
						//console.log('prova item review', item)

						item.feed_type = item.dish ? "DISH" : "RESTAURANT"
						item.name = item.restaurant?.name || item.dish?.name
						item.user = item.user || data.user

						if (!isProfile || false) {
							if (data.dishReview) {
								item.feed_type = "DISH"
								item.dish = data.dishData
							} else if (data.restaurantReview) {
								item.feed_type = "RESTAURANT"
								item.restaurant = data.restaurantData
							}
						}

						return (
							<FeedItem
								key={item.id + "_" + item.updated_at}
								item={FeedItemMap(item)}
								showDetail={true}
								disableUserPress={data.disableUserPress}
								callbackShouldReload={actions.callbackShouldReload}
								hideButton={!isProfile}
							/>
						)
					}}
				/>
			</View>
		);
	}
}
