import PlacesAutocomplete from '@App/Components/PlacesAutocomplete';
import { formatUserAddress } from '@FoodListCommon/user';
import FLIcon from '@FoodListCore/Components/FLIcon';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { webRequestAuth } from '@FoodListCore/Flows/RequestAuth';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { colors, spacing } from '@FoodListCore/Global/Constants';
import { DEFAULT_IMAGES_BASEURL, webStyles } from '@FoodListCore/Global/WebHelpers';
import { resolveHref } from '@FoodListCommon/utils';
import { ReduxState } from '@FoodListCore/Redux/StateFormat';
import { User } from '@Models/User';
import { UserAddress } from '@Models/UserAddress';
import AsyncStorage from '@react-native-community/async-storage';
import { NavigationProp } from '@react-navigation/native';
import React, { useState } from 'react';
import { ImageBackground, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { shallowEqual, useSelector } from 'react-redux';
import { WebPages } from 'web/pagesAndParams';

type Props = {
	navigation: NavigationProp<WebPages, "Home">
}

type SavedAddress = {
	lat?: number,
	lng?: number,
	full_address?: string
	address_id?: number
}
const SEARCH_ADDRESSES_KEY = "fl_last_search_adresses"
const loadAddresses = async (user?: User): Promise<SavedAddress[]> => {
	if(user?.addresses && user.addresses.length > 0) {
		return user.addresses.slice(0, 3).map(item => ({
			full_address: formatUserAddress(item),
			address_id: item.id,
		}))
	}
	try {
		const res = await AsyncStorage.getItem(SEARCH_ADDRESSES_KEY) || "[]"
		//TODO: check duplicates (full_address)
		const addresses = JSON.parse(res) as SavedAddress[]
		return addresses || []
	} catch (e) {
		return []
	}
}
const saveAddress = async (address: SavedAddress) => {
	const old = await loadAddresses()

	const newArray = [address, ...old.filter(item => item.full_address != address.full_address).slice(0, 2)]
	console.log("save list", newArray)
	await AsyncStorage.setItem(SEARCH_ADDRESSES_KEY, JSON.stringify(newArray))
}

const reduxMap = (state: ReduxState) => {
	return {
		user: state.currentUser,
	}
}

const WebHome = React.memo(({ navigation }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	const self = React.useMemo(() => ({
		lastAddress: null as SavedAddress | null,
	}), [])
	//const [loading, setLoading] = useState(false)
	const [lastAddresses, setLastAddresses] = useState<SavedAddress[]>([])
	const { user } = useSelector(reduxMap, shallowEqual)

	React.useEffect(() => {
		loadAddresses(user).then(setLastAddresses)
	}, [user])

	const showSearch = (address: SavedAddress | null) => {
		if(!address) return
		const { lat: latitude, lng: longitude, full_address, address_id } = address
		navigation.push("NewSearch", {
			latitude,
			longitude,
			address_id,
			full_address: address_id ? undefined : full_address,
		})
	}

	const {width} = useWindowDimensions()
	const mobile = width <= 550

	return (
		<ImageBackground source={{ uri: resolveHref(DEFAULT_IMAGES_BASEURL, "background.jpg") }} style={styles.background}>
			<View style={[styles.container, webStyles.listMaxWidth, CommonStyle.deepShadow]}>
				<Text style={styles.headerText}>I piatti giusti per i tuoi gusti!</Text>
				<Text style={styles.addressText}>Inserisci l'indirizzo per cercare ristoranti nei tuoi dintorni</Text>
				<View style={styles.row}>
					<View style={{ flex: 1 }}>
						<PlacesAutocomplete
							onPositionSelected={React.useCallback((lat, lng, full_address) => {
								const address = { lat, lng, full_address }
								self.lastAddress = address
								saveAddress(address)
								showSearch(address)
							}, [])}
						/>
					</View>
					{!mobile && (
						<TouchableRipple style={styles.button} onPress={() => showSearch(self.lastAddress)}>
							<Text selectable={false} style={styles.buttonText}>Trova ristoranti</Text>
						</TouchableRipple>
					)}
				</View>
				{mobile && (
					<TouchableRipple style={[styles.button, styles.buttonMobile]} onPress={() => showSearch(self.lastAddress)}>
						<Text selectable={false} style={styles.buttonText}>Trova ristoranti</Text>
					</TouchableRipple>
				)}
				{lastAddresses.length > 0 ? (
					<Text style={styles.savedAddressText}>Oppure utilizza gli indirizzi {lastAddresses[0].address_id ? "salvati" : "recenti"}</Text>
				) : !user && (
					<Text style={styles.savedAddressText}><Text onPress={() => { webRequestAuth(() => {}) }} style={styles.loginText}>Accedi</Text> per usare gli indirizzi salvati</Text>
				)}
				{lastAddresses.map((item, index) => {
					return (
						<View key={index} style={{ flexDirection: "row", width: "100%" }}>
							<TouchableRipple onPress={() => showSearch(item)} style={styles.addressesButton}>
								<View style={styles.row}>
									<FLIcon materialIcon="location-pin" color={colors.greyArrow} size={16} />
									<Text style={styles.previousAddressText} numberOfLines={1}>{item.full_address}</Text>
								</View>
							</TouchableRipple>
						</View>
					)
				})}
			</View>
		</ImageBackground>
	);
});

const styles = StyleSheet.create({
	container: {
		paddingVertical: spacing.pagePadding,
		paddingHorizontal: 20,
		backgroundColor: colors.white,
		margin: spacing.pagePadding,
		borderRadius: 10,
	},
	background: {
		height: "100%",
		alignItems: "center",
		justifyContent: "center",
		padding: spacing.pagePadding,
	},
	row: {
		width: "100%",
		flexDirection: "row",
		alignItems: "center",
	},
	button: {
		backgroundColor: colors.foodlist,
		borderRadius: 4,
		paddingHorizontal: 10,
		alignItems: "center",
		justifyContent: "center",
		marginLeft: 10,
		alignSelf: "stretch",
	},
	buttonMobile: {
		paddingVertical: 10,
		marginLeft: 0,
		marginTop: 10,
	},
	buttonText: {
		color: colors.white,
		fontWeight: "bold",
		fontSize: 16,
	},

	headerText: {
		fontSize: 36,
		fontWeight: "900",
		color: colors.foodlist,
		marginVertical: spacing.vertical,
	},

	addressText: {
		fontSize: 16,
		marginVertical: spacing.vertical,
	},
	savedAddressText: {
		marginTop: spacing.pagePadding,
		marginBottom: spacing.vertical,
	},
	loginText: {
		color: colors.blueMenu,
		textDecorationLine: "underline",
		cursor: "pointer",
	},
	addressesButton: {
		padding: 5,
		borderRadius: 8,
		width: "100%",
	},
	previousAddressText: {
		marginLeft: 7,
		color: colors.darkGreyText,
		flex: 1,
	},
})

export default WebHome;
