import CouponCell from '@FoodListCore/Components/CouponCell';
import PointsManager from '@FoodListCore/Network/PointsManager';
import FLImage from '@FoodListCore/Components/FLImage';
import LoadingView from '@FoodListCore/Components/LoadingView';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { colors, formatPrice, margins, showError } from '@FoodListCore/Global/GlobalProps';
import { Coupon } from '@Models/Coupon';
import { RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, FlatList, StyleSheet, Text, View } from 'react-native';
import { translate } from '@App/I18n';
import { PointsStackParams } from '@App/RouteParams/Points';

export interface AddCouponActions {

}

type Props = {
	navigation: StackNavigationProp<PointsStackParams, "AddCoupon">
	route: RouteProp<PointsStackParams, "AddCoupon">
}

const manager = new PointsManager()

const AddCoupon = React.memo(({ route, navigation}: Props) => {
	const routeParams = route.params

	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])

	const onItemPressed = useCallback((item: Coupon) => {
		Alert.alert(translate("redeemCoupon"), translate("redeemCouponDisclaimer", { points: item.points }), [{
			text: translate("confirm"),
			onPress: () => {
				setLoading(true)
				manager.requestNewCoupon(item.id).then(res => {
					console.log("preso", res)
					if(res.error) {
						throw new Error(res.error)
					} else {
						navigation.goBack()
					}
				}).catch(showError)
				.finally(() => {
					setLoading(false)
				})
			}
		}, {
			text: translate("cancel"),
			onPress: () => {}
		}])
	}, [])

	return (
		<>
			<View style={styles.header}>
				<FLImage
					source={require("@Assets/Images/trophy.png")}
					style={{ width: 40, height: 40, marginRight: 10  }}
				/>
				<Text style={{ fontSize: 16, fontWeight: "bold", /* color: colors.white */ }}>{translate("numAvailablePoints", { num: routeParams.points }).toUpperCase()}</Text>
			</View>
			<FlatList
				contentContainerStyle={styles.scrollContainer}
				data={routeParams.available_coupons as Coupon[]}
				renderItem={({ item }) => {
					return (
						<CouponCell
							coupon={item}
							onPress={() => onItemPressed(item)}
							userPoints={routeParams.points}
						/>
					)
				}}
			/>
			<LoadingView
				visible={loading}
			/>
		</>
	);
});

const styles = StyleSheet.create({
	header: {
		backgroundColor: "#fff",
		padding: margins.pagePadding,
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "center",
		borderBottomColor: colors.greyBorder,
		borderBottomWidth: 1,
	},
	scrollContainer: {
		paddingVertical: margins.pagePadding / 2,
	},
	coupon: {
		marginHorizontal: margins.pagePadding,
		marginVertical: margins.pagePadding / 2,
		padding: margins.pagePadding,
		borderRadius: 10,
		backgroundColor: colors.white,
		...CommonStyle.shadow,
	},
	cannotPurchase: {
		backgroundColor: colors.inactiveGrey
	},
});

export default AddCoupon;
