import React from 'react';
import ImproveProfileView from "./View"
import { confirmExit, alert } from '@Global/GlobalProps';
import SuggestManager, { SuggestResponse } from '@Network/SuggestManager';
import { BackHandler, NativeEventSubscription } from 'react-native';
import { Dish } from '@Models/Dish';
import { Restaurant } from '@Models/Restaurant';
import { RequestResponse } from '@Models/RequestResponse';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';
import { translate } from '@App/I18n';

/**
 * @param data: info del locale
 */


type PageProps = {
	navigation: CommonNavigation<"ImproveProfile">
	route: CommonRoute<"ImproveProfile">
}

type PageState = {
	loading: boolean
}

export default class ImproveProfilePage extends React.PureComponent<PageProps, PageState> {
	backHandler?: NativeEventSubscription
	hasContent = false

	restaurant?: Restaurant
	dish?: Dish

	constructor(props: PageProps) {
		super(props);
		const { restaurant, dish } = this.props.route.params
		this.restaurant = restaurant
		this.dish = dish
		//console.log('Modifica piatto', data);
		this.state = {
			loading: false
		}
		this.injectOnBack()
	}

	realGoBack = () => {
		//console.warn("realGoBack called but not overriden")
	}

	injectOnBack() {
		this.realGoBack = this.props.navigation.goBack;
		this.props.navigation.goBack = this.goBack;
	}

	goBack = (routeKey?: string | null) => {
		confirmExit(this.realGoBack, this.hasContent)
		return false
	}

	componentDidMount() {
		//this.props.navigation.setParams({blockSwipe: false})
		this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
			this.goBack()
			return true;
		});
	}

	componentWillUnmount() {
		this.backHandler?.remove();
	}

	onSubmit = async (body: Partial<Dish | Restaurant>) => {
		//console.log('Valori da suggerire:', body);
		//console.log('Modifica piatto', body);
		let manager = new SuggestManager();
		this.setState({ loading: true });
		if (this.dish) {
			try {
				let response = await manager.dishSuggest(body);
				this.setState({ loading: false })
				this.handleResponse(response);
				//console.log('Valori da suggerire - dish - response', response);
			} catch (err) {
				//console.log(err);
			}
		} else {
			try {
				let response = await manager.restaurantSuggest(body);
				this.setState({ loading: false })
				this.handleResponse(response);
				//console.log('Valori da suggerire - restaurant - response', response);
			} catch (err) {
				//console.log(err);
			}
		}
	}

	handleResponse = (response: RequestResponse<SuggestResponse>) => {
		if (response.status == 200) {
			alert(translate("suggestReceivedTitle"), translate("suggestReceivedMessage"));
			this.realGoBack();
		} else {
			alert(translate("error"), translate("errorOccuredRetry"));
		}
	}

	onHasContent = (hasContent: boolean) => {
    /*if(hasContent != this.hasContent) {
      this.props.navigation.setParams({blockSwipe: hasContent})
    }*/
		this.hasContent = hasContent
	}

	render() {
		return (
			<ImproveProfileView
				loading={this.state.loading}
				dish={this.dish}
				restaurant={this.restaurant}
				onHasContent={this.onHasContent}
				onSubmit={this.onSubmit}
			/>
		);
	}
}
