import React from 'react';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import { Keyboard, View, SafeAreaView, KeyboardTypeOptions, NativeEventSubscription } from 'react-native';
import styles from './Style';
import FormActionButton from '@Components/FormActionButton'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { regex } from '@Global/GlobalProps'
import FLEditText from '@FoodListCore/Components/Input/FLEditText'
import { ItemsMap } from '@Models/ItemsMap';
import { Address } from '@Models/Address';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';
import { translate } from '@App/I18n';

let validator: ItemsMap<boolean> = {}
const handleChange = (item: Option, newValue: string, values: Address, isValid: boolean, setCanSubmit: (result: boolean) => void) => {
	values[item.destKey] = newValue
	validator[item.destKey] = isValid

	let result = true
	Object.values(validator).forEach((item) => {
		if (!item) {
			result = false
		}
	})
	setCanSubmit(result)
}

type Option = {
	title: string
	destKey: keyof Address
	keyboardType?: KeyboardTypeOptions
	regex?: RegExp
}
const _ = (title: string, destKey: keyof Address, keyboardType?: KeyboardTypeOptions, regex?: RegExp): Option => {
	return {
		title,
		destKey,
		keyboardType,
		regex
	}
}


type PageProps = {
	navigation: CommonNavigation<"ImproveAddress">
	route: CommonRoute<"ImproveAddress">
}

type PageState = {
	canSubmit: boolean
}

class ImproveAddressPage extends React.PureComponent<PageProps, PageState> {
	options: Option[]
	values: Address

	constructor(props: PageProps) {
		super(props);
		this.state = {
			canSubmit: true
		}
		this.values = props.route.params.data
		this.options = [
			_(translate("city"), "city"),
			_(translate("cap"), "cap", "numeric", regex.CAP),
			_(translate("address"), "address"),
			_(translate("civicNumber"), "house_number", "numbers-and-punctuation", regex.HOUSE_NUMBER)
		]
	}
	onSubmit() {
		Keyboard.dismiss();
		//console.log("Indirizzo, Valori inseriti", this.values)
		this.props.navigation.goBack()
	}
	setCanSubmit = (canSubmit: boolean) => {
		this.setState({
			canSubmit
		})
	}
	render() {
		return (
			<View style={{ flex: 1 }}>
				<SafeAreaView style={styles.container}>
					<KeyboardAwareScrollView
						keyboardShouldPersistTaps="handled"
						style={{ flex: 1 }}
					>
						<View style={[styles.contentView, { paddingBottom: 20 }]}>
							<View style={{ marginTop: 20 }}>
								{this.options.map((item, index) => {
									let initialValue = this.values[item.destKey]?.toString()
									return (
										<View key={index} style={index != 0 ? commonStyle.borderBottom : commonStyle.borderVertical}>
											<FLEditText
												actions={{
													onChangeText: (text, isValid) => {
														handleChange(item, text, this.values, isValid ?? false, this.setCanSubmit)
													}
												}}
												inputContainerConfig={{

												}}
												textInputProps={{
													title: item.title,
													defaultValue: initialValue,
													keyboardType: item.keyboardType
												}}
												regex={item.regex}
											/>
										</View>
									)
								})}
							</View>
						</View>
					</KeyboardAwareScrollView>
					<View style={[commonStyle.buttonContainer]}>
						<FormActionButton noPadding enabled={this.state.canSubmit} full={true} title="Conferma" onPress={() => { this.onSubmit() }} />
					</View>
				</SafeAreaView>
			</View>
		);
	}
}
export default ImproveAddressPage