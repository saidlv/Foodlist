import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: colors.greyBackground,
		flexDirection: "column"
	},
	ratingStarsView: {
		alignSelf: "center",
		marginTop: 40,
		marginBottom: 30
	},
	description: {
		fontSize: 16,
		backgroundColor: colors.white,
		fontWeight: "normal",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText,
		height: 240,
		paddingTop: 20,
		paddingLeft: 20,
		paddingRight: 20,
		paddingBottom: 20,
		marginHorizontal: 20
	},
	contentView: {
		flex: 1,
		flexDirection: "column",
		marginTop: 24
	},
	roundButton: {
		borderRadius: 16,
		paddingHorizontal: 2,
		paddingVertical: 2,
		flexDirection: 'row',
		alignItems: 'center'
	}
})
