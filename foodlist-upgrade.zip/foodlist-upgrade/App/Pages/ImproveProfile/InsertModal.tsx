import React from 'react';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import { View } from 'react-native';
import FormActionButton from '@Components/FormActionButton'
import FLDateEditText from '@FoodListCore/Components/Input/FLDateEditText';
import { isDefined } from '@Global/GlobalProps';
import FormContainer from '@Components/FormContainer';
import { translate } from '@App/I18n';

type ViewProps = {
	insertTimePressed: (start: string, end: string) => void
}

type ViewState = {
	canSubmit: boolean
	startTime: string | null
	endTime: string | null
}

class InsertModal extends React.PureComponent<ViewProps, ViewState> {
	insertForm?: FormContainer

	constructor(props: ViewProps) {
		super(props)
		this.state = {
			canSubmit: true,
			startTime: null,
			endTime: null
		}
	}
	showModal = () => {
		this.setState({ startTime: "08:00", endTime: "12:00" })
		this.insertForm?.showModal()
	}
	closeModal = () => {
		this.insertForm?.closeModal()
	}

	getDateFromHours = (time: string): Date => {
		let date = new Date();
		let splittedTime = time.split(":");
		date.setHours(parseInt(splittedTime[0]), parseInt(splittedTime[1]))
		return date
	}

	render() {
		return (
			<FormContainer ref={(ref) => { this.insertForm = ref || undefined }}>
				<View style={{ flex: 0 }}>
					{[{ title: translate("openingTime") }, { title: translate("closingTime") }].map((item, index) => {
						let date = index == 0 ? this.state.startTime : this.state.endTime
						return (
							<View key={index} style={commonStyle.borderBottom} >
								<FLDateEditText
									actions={{
										onChangeText: (text, formattedTime) => {
											if (isDefined(text) && text != "" && isDefined(formattedTime)) {
												if (index == 0) {
													this.setState({
														startTime: formattedTime,
														canSubmit: this.state.endTime != null
													})
												} else {
													this.setState({
														endTime: formattedTime,
														canSubmit: this.state.startTime != null
													})
												}
											}
										}
									}
									}
									inputContainerConfig={{

									}}
									textInputProps={{
										title: item.title
									}}
									selectedDate={date || ""}
									pickerMode="time"
								/>
							</View>
						)
					})}
					<View style={{ paddingHorizontal: 20, paddingTop: 10 }}>
						<FormActionButton
							enabled={this.state.canSubmit}
							noPadding
							full={true}
							title={translate("insert")}
							onPress={() => {
								this.props.insertTimePressed(this.state.startTime || "", this.state.endTime || "")
								this.setState({ startTime: null, endTime: null })
							}}
						/>
					</View>
				</View>
			</FormContainer>
		)
	}
}

export default InsertModal