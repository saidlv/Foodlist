import React from 'react';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import { Keyboard, View, SafeAreaView, Text } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './Style';
import FormActionButton from '@Components/FormActionButton'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { colors, when, deepCopy } from '@Global/GlobalProps';
import Icon from "@FoodListCore/Iconfont/FoodListIconfont"
import InsertModal from './InsertModal';
import { Day } from '@Models/Day';
import { Time } from '@Models/Time';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';
import { translate } from '@App/I18n';

type Option = {
	title: string
	destKey: string
}

const _ = (title: string, destKey: string): Option => {
	return {
		title,
		destKey
	}
}

type Props = {
	navigation: CommonNavigation<"InsertTimes">
	route: CommonRoute<"InsertTimes">
}

class InsertTimesPage extends React.PureComponent<Props> {
	valuesRef: Day[]
	values: Day[]
	options: Option[]
	insertModal?: InsertModal
	insertCb?: (startTime: string, endTime: string) => void

	constructor(props: Props) {
		super(props);
		this.valuesRef = props.route.params.data ?? []
		this.values = deepCopy(this.valuesRef)
		this.options = []
	}
	onSubmit() {
		Keyboard.dismiss();
		this.valuesRef.splice(0, this.valuesRef.length)
		for (const day of this.values) {
			this.valuesRef.push(day)
		}
		//console.log("Indirizzo, Valori inseriti", this.values)
		this.props.navigation.goBack()
	}
	remove = (index: number, array: Time[]) => {
		array.splice(index, 1)
		this.forceUpdate()
	}
	showTimesModal = (cb: (start: string, end: string) => void) => {
		this.insertCb = cb
		this.insertModal?.showModal()
	}
	addTimes = (item: Day) => {
		this.showTimesModal((start, end) => {
			if (!item.times) {
				item.times = []
			}
			item.times.push({ timeString: start + " - " + end, isNow: false, from: start, to: end })
			item.times.sort((first, second) => {
				return first.timeString.localeCompare(second.timeString)
			})
			this.forceUpdate()
		})
	}
	insertTimePressed = (start: string, end: string) => {
		this.insertModal?.closeModal()
		this.insertCb?.(start, end)
	}
	render() {
		return (
			<View style={{ flex: 1 }}>
				<SafeAreaView style={styles.container}>
					<KeyboardAwareScrollView
						keyboardShouldPersistTaps="handled"
						style={{ flex: 1 }}
					>
						<View style={[styles.contentView, { paddingBottom: 20 }]}>
							<View style={{}}>
								<View style={{ flexDirection: 'column', justifyContent: 'flex-end' }}>
									{this.values.map((item, index) => {
										return (
											<View key={index}
												style={[{ flexDirection: 'row', flex: 1, justifyContent: 'space-between', alignItems: 'center', paddingVertical: 2, marginLeft: 20, paddingRight: 20 },
												when(index != 0, commonStyle.borderTop)]}
											>
												<Text style={{ fontWeight: '400', fontSize: 16 }}>{item.day}</Text>
												<View style={{ marginLeft: 10, flexDirection: 'column', alignItems: 'flex-end' }}>
													{item.times?.map((itemH, indexH) => {
														return (
															<View key={indexH} style={{ flexDirection: 'row', marginTop: 15 }}>
																<Text style={{ fontSize: 15, fontWeight: "500" }}>{itemH?.timeString}</Text>
																<TouchableOpacity
																	onPress={() => {
																		this.remove(indexH, item.times)
																	}}
																	style={[{ marginLeft: 10, backgroundColor: colors.red }, styles.roundButton]}
																>
																	<Text style={{ fontWeight: 'bold', color: colors.white, fontSize: 12 }}>  {translate("remove")}  </Text>
																	<Icon name="delete" size={16} color={colors.white} />
																</TouchableOpacity>
															</View>
														)
													}
													)}
													<TouchableOpacity
														onPress={() => {
															this.addTimes(item)
														}}
														style={[{ marginVertical: 15, backgroundColor: colors.blueMenu }, styles.roundButton]}
													>
														<View style={{ transform: [{ rotate: '45deg' }] }}>
															<Icon name="delete" color={colors.white} size={18} />
														</View>
														<Text style={{ fontWeight: 'bold', color: colors.white, fontSize: 13 }}>  {translate("addTimeRange")}  </Text>
													</TouchableOpacity>
												</View>
											</View>
										)
									})}
								</View>
							</View>
						</View>
					</KeyboardAwareScrollView>
					<InsertModal ref={(ref) => { this.insertModal = ref || undefined }} insertTimePressed={this.insertTimePressed} />
					<View style={[commonStyle.buttonContainer]}>
						<FormActionButton noPadding full={true} title={translate("confirm")} onPress={() => { this.onSubmit() }} />
					</View>
				</SafeAreaView>
			</View>
		);
	}
}
export default InsertTimesPage