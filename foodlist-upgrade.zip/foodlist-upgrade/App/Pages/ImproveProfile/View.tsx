import React from 'react';
import { deepCopy, regex, isDefined } from '@Global/GlobalProps';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import LoadingView from '@Components/LoadingView'
import { Keyboard, View, SafeAreaView, KeyboardTypeOptions } from 'react-native';
import styles from './Style';
import QuickPicker from 'quick-picker'
import FormActionButton from '@Components/FormActionButton'
import FLEditText from '@FoodListCore/Components/Input/FLEditText';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { store } from '@Redux/Reducer'
import { isEqual as deepComparison } from 'underscore'
import { ImageSource } from '@Models/ImageSource';
import { Restaurant } from '@Models/Restaurant';
import { DishRestriction } from '@Models/DishRestriction';
import { FoodPreference } from '@Models/FoodPreference';
import { PaymentMethod } from '@Models/PaymentMethod';
import { RestaurantCategory } from '@Models/Category';
import { RestaurantStyle } from '@Models/RestaurantStyle';
import { Occasion } from '@Models/Occasion';
import { Service } from '@Models/Service';
import { Day } from '@Models/Day';
import { ItemsMap } from '@Models/ItemsMap';
import { PrintableItem } from '@Models/PrintableItem';
import { ImageForMultipart } from '@Models/ImageForMultipart';
import { Address } from '@Models/Address';
import { Dish } from '@Models/Dish';
import AddressChooser from '@Components/OptionChooser/AddressChooser';
import TimeChooser from '@Components/OptionChooser/TimeChooser';
import MultiselectChooser from '@Components/OptionChooser/MultiselectChooser';
import { DishType } from '@Models/DishType';
import { translate } from '@App/I18n';
import { Any } from '@Models/Any';
import { mapServices } from '@App/Redux/ReduxHelper';
import { GenericParams } from '@FoodListCore/Network/NetworkManager';
import { formatWeekTimes } from '@FoodListCore/Services/DateManager';

enum OptionType {
	TEXT = 1,
	MULTI,
	TIMES,
	ADDRESS,
	SINGLE
}
const TEXT = OptionType.TEXT
const MULTI = OptionType.MULTI
const TIMES = OptionType.TIMES
const ADDRESS = OptionType.ADDRESS
const SINGLE = OptionType.SINGLE

let validator: ItemsMap<boolean> = {}

type Option = {
	type: OptionType,
	title: string,
	destKey: string,
	reduxKey: string,
	keyboardType?: KeyboardTypeOptions
	regex?: RegExp
	options?: PrintableItem[]
}

const _ = (type: OptionType, title: string, destKey: string, reduxKey?: string | null, keyboardType?: KeyboardTypeOptions, regex?: RegExp, options?: PrintableItem[]): Option => { //reduxKey is used as options for single item
	return {
		type,
		title,
		destKey,
		reduxKey: reduxKey || destKey,
		keyboardType,
		regex,
		options
	}
}

type ViewProps = {
	onHasContent: (hasContent: boolean) => void
	onSubmit: (changes: Partial<Dish | Restaurant>) => void
	loading: boolean
	dish?: Dish
	restaurant?: Restaurant
}

type ViewState = {
	canSubmit: boolean
	category?: string
	photo?: ImageSource
}

type DishValues = {
	id: number,
	name: string,
	price: string,
	dish_type: DishType,
	description: string,
	restaurant_id: number,
	restrictions: DishRestriction[],
	preferences: FoodPreference[]
}
type RestValues = {
	address?: Address,
	phone: string,
	email: string,
	website: string,
	categories: RestaurantCategory[],
	payments: PaymentMethod[],
	styles: RestaurantStyle[],
	occasions: Occasion[],
	services: Service[],
	times: Day[]
}

type Values = (DishValues | RestValues) & {
	[index: string]: Any //TODO: find something better
}

export default class ImproveProfilePage extends React.PureComponent<ViewProps, ViewState> {
	values: Values
	initialValues: Values
	options: Option[]

	constructor(props: ViewProps) {
		super(props)
		this.state = {
			canSubmit: true,
			category: props.dish?.dish_type?.label_it
		}
		if (props.dish) {
			let data = props.dish
			//console.log("Dish", data)
			this.values = {
				id: data.id,
				name: data.name,
				price: data.price?.toString() || "",
				dish_type: data.dish_type,
				description: data.description,
				restaurant_id: data.menu.restaurant_id!,
				restrictions: deepCopy(data.dish_restrictions || []),
				preferences: deepCopy(data.food_preferences || []),
			}
			this.options = [
				_(TEXT, translate("name"), "name"),
				_(SINGLE, translate("portata"), "dish_type"),
				_(TEXT, translate("priceCurrency"), "price", null, "numeric", regex.PRICE),
				_(TEXT, translate("description"), "description"),
				//_(MULTI, "Preferenze alimentari", "restrictions", "dishRestrictions"),
				_(MULTI, translate("preferences"), "preferences", "foodPreferences")
			]
		} else {
			let data = props.restaurant!
			this.values = {
				id: data.id,
				name: data.name,
				address: {
					city: data.city,
					cap: data.cap,
					address: data.address,
					house_number: data.house_number
				},
				phone: data.phone,
				email: data.email,
				website: data.website,
				categories: deepCopy(data.restaurant_categories ?? []),
				payments: deepCopy(data.restaurant_payment_methods ?? []),
				styles: deepCopy(data.restaurant_styles ?? []),
				occasions: deepCopy(data.restaurant_occasions ?? []),
				services: deepCopy(mapServices(data.services)),
				times: formatWeekTimes(deepCopy(data.restaurant_hours ?? []))
			}
			//console.log("Servizi", this.values.services, this.values.occasions)
			this.options = [
				_(TEXT, translate("name"), "name"),
				_(ADDRESS, translate("address"), "address"),
				_(MULTI, translate("categories"), "categories", "restCategories"),
				_(TEXT, translate("phone"), "phone", null, "phone-pad", regex.PHONE),
				_(TEXT, translate("email"), "email", null, "email-address", regex.EMAIL),
				_(TEXT, translate("website"), "website", null, "url", regex.URL),
				_(MULTI, translate("paymentMethods"), "payments", "paymentMethods"),
				//_(MULTI, "Stili e atmosfera", "styles"),
				_(MULTI, translate("occasion"), "occasions"),
				_(MULTI, translate("whatOffers"), "services"), //da gestire meglio l'handleChange per inviare i valori al server (non sono gestiti come gli altri)
				_(TIMES, translate("time"), "times")
			]
		}

		this.initialValues = deepCopy(this.values)
		this.options.forEach((item) => {
			if (item.type == TEXT && !isDefined(this.initialValues[item.destKey])) {
				this.initialValues[item.destKey] = ""
			}
		})
	}

	handleChange = (item: Option, newValue: string | PrintableItem[], values: Values, isValid?: boolean, setCanSubmit?: (canSubmit: boolean) => void) => {
		values[item.destKey] = newValue
		if (setCanSubmit) {
			validator[item.destKey] = isValid
		}

		let result = true
		Object.values(validator).forEach((item) => {
			if (!item) {
				result = false
			}
		})
		setCanSubmit?.(result)
		this.onHasContent()
	}

	onHasContent = (changed?: boolean) => {
		let hasContent = changed || !deepComparison(this.initialValues, this.values)
			|| this.props.dish?.dish_type?.label_it != this.state.category
		//console.log("has content", changed, hasContent, !deepComparison(this.initialValues, this.values), this.initialValues, this.values, this.state.category, this.props.data?.dish_type?.label_it)
		this.props.onHasContent(hasContent)
	}
	handleTimesChange = () => {
		this.onHasContent()
	}

	renderOption = (item: Option, values: Values, setCanSubmit?: (canSubmit: boolean) => void) => {
		let initialValue = values[item.destKey]
		if (item.type == TEXT) {
			return <FLEditText
				actions={{
					onChangeText: (text, isValid) => {
						this.handleChange(item, text, values, isValid, setCanSubmit)
					}
				}}
				inputContainerConfig={{

				}}
				textInputProps={{
					title: item.title,
					startLowerCase: item.destKey == "email" || item.destKey == "website",
					defaultValue: initialValue,
					keyboardType: item.keyboardType,
				}}
				regex={item.regex}
				price={item.destKey == "price"}
			/>
		} else if (item.type == MULTI) {
			let options = store.getState()[item.reduxKey]
			return <MultiselectChooser
				title={item.title}
				options={options || []}
				isCategories={item.destKey == "categories"}
				noSelectionText={translate("notSet")}
				onSelectionChange={(options) => {
					/*const ids = options.map((item) => {
						return item.id
					})*/
					this.handleChange(item, options, values)
				}}
				initialSelections={initialValue || []}
			/>
		} else if (item.type == SINGLE) {
			let options = item.options
			let textOptions = options?.map((item) => {
				return item.label_it
			})
			initialValue = textOptions?.indexOf(initialValue.label_it)
			/*onPress={() => {
				this.searchableOptions.toggleSelector()
			}}*/
			return <FLEditText
				actions={{
					onChangeText: (v) => { this.setState({ category: v }) }
				}}
				inputContainerConfig={{

				}}
				textInputProps={{
					placeholder: translate("portataPlaceholder"),
					fontSize: 18,
					defaultValue: this.state.category,
					title: translate("portata")
				}}
			/>
		} else if (item.type == TIMES) {
			return <TimeChooser title={item.title} times={initialValue} onTimeChange={this.handleTimesChange} />
		} else {
			return <AddressChooser title={item.title} address={initialValue} />
		}
	}

	onSubmit() {
		Keyboard.dismiss();
		if (this.state.category && 'dish_type' in this.values) {
			this.values.dish_type = this.state.category;
		}
		let changes: ItemsMap<string | object> = {}
		Object.keys(this.values).forEach((key) => {
			let value = this.values[key]
			if (key == 'id' || !deepComparison(value, this.initialValues[key])) {
				if (key == "address" || key == "times") {
					let objChanges: GenericParams = {}
					for (let _key in value) {
						if (!deepComparison(value[_key], this.initialValues[key][_key])) {
							objChanges[_key] = value[_key]
						}
					}
					changes[key] = objChanges
				} else {
					changes[key] = value
				}
			}
		})
		//console.log("Changes", changes)
		this.props.onSubmit(changes);
	}
	onImagePicked(photo: ImageForMultipart) {
		this.setState({ photo: photo })
	}
	setCanSubmit = (canSubmit: boolean) => {
		this.setState({
			canSubmit
		})
	}

	getDishTypesForModal = () => {
		let res: { name: string }[] = [];
		if (this.props.restaurant?.dish_types) {
			for (let i = 0; i < this.props.restaurant.dish_types.length; i++) {
				res.push({
					name: this.props.restaurant.dish_types[i].label_it ?? ""
				});
			}
		}
		return res;
	}

	onItemSelected = (item: string) => {
		this.setState({ category: item });
	}

	render() {
		return (
			<View style={{ flex: 1 }}>
				<SafeAreaView style={styles.container}>
					<LoadingView visible={this.props.loading} />
					<KeyboardAwareScrollView
						keyboardShouldPersistTaps="handled"
						style={{ flex: 1 }}
					>
						<View style={[styles.contentView, { paddingBottom: 20 }]}>
							<View style={{ marginTop: 0 }}>
								{this.options.map((item, index) => {
									return <View key={index} style={index != 0 ? commonStyle.borderBottom : commonStyle.borderVertical}>
										{this.renderOption(item, this.values, this.setCanSubmit)}
									</View>
								})}
							</View>
						</View>
						<View style={{ paddingBottom: 20, paddingHorizontal: 20 }}>
							<FormActionButton noPadding full={true} enabled={this.state.canSubmit} title={translate("confirm")} onPress={() => { this.onSubmit() }} />
						</View>
					</KeyboardAwareScrollView>
					<QuickPicker />
					{/*<SearchableOptions
						ref={ref => this.searchableOptions = ref}
						items={this.getDishTypesForModal()}
						uniqueKey='name'
						onItemSelected={this.onItemSelected}
						allowNewOption
						searchPlaceHolderText={'Cerca o aggiungi...'}
						confirmText={'Cancella'}
					/>*/}
				</SafeAreaView>
			</View>
		);
	}
}
