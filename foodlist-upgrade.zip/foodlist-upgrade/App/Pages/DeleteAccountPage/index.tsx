import Button from '@FoodListCore/Components/Button';
import FLIcon from '@FoodListCore/Components/FLIcon';
import LoginComponent from '@FoodListCore/Components/LoginPage';
import FLModal from '@FoodListCore/Components/SheetPopup/index.web';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { colors, spacing } from '@FoodListCore/Global/Constants';
import { alert, resetNavigation, showError } from '@FoodListCore/Global/GlobalProps';
import { webStyles } from '@FoodListCore/Global/WebHelpers';
import NetworkManager, { NetworkNavigation } from '@FoodListCore/Network/NetworkManager';
import SessionManager from '@FoodListCore/Services/SessionManager';
import { User } from '@Models/User';
import React, { useCallback } from 'react';
import { Platform, StyleSheet, Text, TextInput, View } from 'react-native';

type Props = {
}

const DeleteAccount = React.memo(() => {
	const [loggedUser, setLoggedUser] = React.useState<User | null>(null) //richiede di fare nuovamente il login anche se già loggato
	const [loading, setLoading] = React.useState(false)
	const [showModal, setShowModal] = React.useState(false)
	const [insertedUsername, setInsertedUsername] = React.useState("")

	const closeModal = useCallback(() => {
		setShowModal(false)
		setInsertedUsername("")
	}, [])
	const deleteAccount = useCallback(() => {
		if(!loggedUser) {
			return
		}
		setLoading(true)
		const manager = new NetworkManager()
		manager.handleRequest(`/gdpr/${loggedUser?.id}/delete`, "POST").then(() => {
			alert("Account eliminato", "Le tue informazioni personali sono state eliminate con successo", () => {
				setLoggedUser(null)
				closeModal()
			})
		}).catch(showError).finally(() => {
			setLoading(false)
		})
	}, [loggedUser])

	const showConfirm = useCallback(() => {
		setShowModal(true)
	}, [])

	return (
		<View style={[webStyles.listMaxWidth, CommonStyle.roundedBox, styles.container]}>
			{!loggedUser ? (
				<View>
					<LoginComponent
						headerView={(
							<View style={styles.loginHeader}>
								<FLIcon foodlistIcon="menu-logo" color={colors.foodlist} size={28} />
								<Text style={{ marginTop: spacing.pagePadding, fontSize: 16, fontWeight: "600" }}>Effettua l'accesso con l'account che vuoi eliminare</Text>
							</View>
						)}
						showNextPage={(user) => setLoggedUser(user!)}
						loginOnly
						onForgotPassword={undefined}
						navigation={undefined}
					/>
				</View>
			) : (
				<View style={styles.deleteContainer}>
					<Text style={styles.title}>Ciao, {loggedUser.first_name || loggedUser.username}!</Text>
					<Text style={styles.description}>Vuoi eliminare le tue informazioni? Non sarà possibile recuperare l'account in seguito</Text>
					<Button
						rippleStyle={{ backgroundColor: colors.darkRed}}
						titleStyle={{ color: colors.white }}
						title={`ELIMINA DATI`}
						noMargin
						lowercase
						onPress={showConfirm}
					/>
					<FLModal
						visible={showModal}
						close={closeModal}
						headerText="Elimina account"
					>
						<View style={styles.deleteContainer}>
							<Text>L'operazione è irreversibile, non sarà possibile recuperare l'account in seguito.</Text>
							<Text style={{ marginTop: 5 }}>Scrivi l'username per confermare: <Text style={{ fontWeight: "bold" }}>{loggedUser.username}</Text></Text>
							<TextInput style={styles.input} onChangeText={setInsertedUsername} />
							<Button
								disabled={insertedUsername !== loggedUser.username}
								onPress={deleteAccount}
								title="ELIMINA"
								noMargin
								rippleStyle={{ backgroundColor: colors.darkRed}}
								titleStyle={{ color: colors.white }}
								containerStyle={insertedUsername !== loggedUser.username ? { opacity: 0.5 } : undefined}
								loading={loading}
							/>
						</View>
					</FLModal>
				</View>
			)}
		</View>
	);
});

const styles = StyleSheet.create({
	container: {
		marginVertical: spacing.pagePadding,
		maxWidth: Platform.OS == "web" ? 500 : "100%",
		backgroundColor: colors.white,
	},
	loginHeader: {
		alignItems: "center",
		paddingVertical: spacing.pagePadding,
	},
	deleteContainer: {
		padding: spacing.pagePadding,
		maxWidth: Platform.OS == "web" ? 500 : "100%",
	},
	title: {
		fontSize: 20,
	},
	description: {
		marginTop: spacing.vertical,
		marginBottom: spacing.pagePadding,
	},
	input: {
		padding: spacing.vertical,
		backgroundColor: colors.lightGrey,
		borderRadius: 4,
		marginVertical: spacing.pagePadding,
		borderColor: colors.greyText,
		borderWidth: spacing.hairlineWidth,
	},
});

export default DeleteAccount;
