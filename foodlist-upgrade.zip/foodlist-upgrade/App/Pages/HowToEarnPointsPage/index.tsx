import EarnedPointsCell, { EarnedPoints } from '@App/Components/EarnedPointsCell';
import AutoLoadingView, { AutoLoadingActions } from '@FoodListCore/Components/AutoLoadingView';
import Line from '@FoodListCore/Components/Line';
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import PointsManager from '@FoodListCore/Network/PointsManager';
import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';

export interface HowToEarnPointsActions {

}

type Props = {
	actions: HowToEarnPointsActions
}

const manager = new PointsManager()



const HowToEarnPoints = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	const [data, setData] = useState<EarnedPoints[]>([])

	const loadingActions: AutoLoadingActions<any> = useMemo(() => ({
		request: () => {
			return manager.getHowToEarnPoints()
		},
		onResponse: (res) => {
			const list = res.data.response
			setData(list)
			/* console.log("vediamo come stanno", res)
			console.log("data", res.data)
			console.log("res", res.data.response) */
		},
	}), [])

	return (
		<View style={styles.background}>
			<AutoLoadingView
				actions={loadingActions}
			/>
			<FlatList
				data={data}
				contentContainerStyle={styles.scrollContainer}
				ListHeaderComponent={(
					<View style={styles.padding}>
						<Text style={styles.title}>Ordina o prenota nei locali affiliati</Text>
						<Text>Raggiungi almeno 100 punti e potrai riscattare un coupon da utilizzare per il prossimo ordine.</Text>
					</View>
				)}
				ItemSeparatorComponent={() => (
					<Line />
				)}
				renderItem={({ item, index }) => {
					return (
						<EarnedPointsCell item={item} key={index} />
					)
				}}
			/>
		</View>
	);
});

const styles = StyleSheet.create({
	scrollContainer: {
		paddingVertical: margins.pagePadding,
	},
	background: {
		backgroundColor: colors.white,
		flex: 1,
	},
	padding: {
		paddingHorizontal: margins.pagePadding,
		paddingBottom: margins.pagePadding,
		fontSize: 16,
	},
	title: {
		fontSize: 18,
		fontWeight: "bold"
	},
});

export default HowToEarnPoints;
