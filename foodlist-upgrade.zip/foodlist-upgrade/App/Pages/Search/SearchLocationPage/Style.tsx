import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		flex: 1,
		height: "100%",
		flexDirection: 'column',
		backgroundColor: colors.greyBackground
	},
	searchBoxContainer: {
		padding: 20
	},
	currentPosition: {
		flex: 0,
		flexDirection: 'row'
	},
	positionIcon: {
		paddingVertical: 18,
		paddingLeft: 32,
		paddingRight: 26
	},
	positionText: {
		fontSize: 16,
		fontWeight: "500",
		color: colors.white,
		paddingTop: 14,
		paddingBottom: 14
	},
	border: {
		borderStyle: "solid",
		borderBottomWidth: 1,
		borderBottomColor: colors.timesGreyBorder,
		marginLeft: 20,
		paddingRight: 20
	},

	itemContainer: {
		flex: 0,
		flexDirection: "row"
	},
	pinContainer: {
		paddingLeft: 12,
		paddingRight: 20,
		paddingTop: 22
	},
	infoContainer: {
		paddingVertical: 19
	},
	title: {
		fontSize: 16,
		fontWeight: "500",
		color: colors.blackText
	},
	lightGreyLabel: {
		fontSize: 11,
		fontWeight: "500",
		color: colors.greyInfoText,
		justifyContent: 'center'
	}
})
