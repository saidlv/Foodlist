import React from 'react';
import { colors } from '@Global/GlobalProps';
import styles from './Style';
import { View, Text } from 'react-native';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import FLEditText from '@FoodListCore/Components/Input/FLEditText'
import LoadMoreList, { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import { RequestResponse } from '@Models/RequestResponse';
import { City } from '@Models/City';
import { SearchCityResponse } from '@Network/SearchManager';
import { ListParams } from '@Models/ListParams';
import { translate } from '@App/I18n';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';

type Props = {
	onSearchTextChanged: (text: string) => void
	positionSelected: (city: City | null) => void
	setRef: (ref: LoadMoreListType<City>) => void
	request: (params: ListParams) => Promise<RequestResponse<SearchCityResponse>>
	showPickPosition: () => void
}

export default class SearchLocationPage extends React.PureComponent<Props> {
	render() {
		return (
			<View style={styles.container}>
				<View style={styles.searchBoxContainer}>
					<FLEditText
						actions={{
							onChangeText: this.props.onSearchTextChanged
						}}
						inputContainerConfig={{
							standalone: true,
							icon: "position-o",
							showClearIcon: true,
						}}
						textInputProps={{
							placeholder: translate("insertDestination")
						}}
						focus
					/>
				</View>
				<TouchableRipple underlayColor={colors.darkBlue} style={{ backgroundColor: colors.blueMenu }} onPress={() => { this.props.positionSelected(null) }}>
					<View style={styles.currentPosition}>
						<Icon name="navigate" size={12} color={colors.white} style={styles.positionIcon} />
						<Text style={styles.positionText}>{translate("currentPosition")}</Text>
					</View>
				</TouchableRipple>
				<TouchableRipple underlayColor={colors.green} style={{ backgroundColor: colors.green }} onPress={this.props.showPickPosition}>
					<View style={styles.currentPosition}>
						<Icon name="position" size={12} color={colors.white} style={styles.positionIcon} />
						<Text style={styles.positionText}>{translate("pickFromMap")}</Text>
					</View>
				</TouchableRipple>
				<View style={{ flex: 0, flexGrow: 1 }}>
					<LoadMoreList
						listRef={this.props.setRef}
						request={this.props.request}
						dontStart
						renderItem={({ item }) => {
							return (
								<View key={item.id} style={{ width: "100%" }}>
										<TouchableRipple onPress={() => { this.props.positionSelected(item) }}>
										<View style={styles.border}>
												<View style={styles.itemContainer}>
													<View style={styles.pinContainer}>
														<Icon name="position" size={24} color={colors.foodlist} />
													</View>
													<View style={styles.infoContainer}>
														<Text style={styles.title}>{item.region_name}</Text>
														<Text style={styles.lightGreyLabel}>{item.parent_region_name_long}</Text>
													</View>
												</View>
										</View>
									</TouchableRipple>
								</View>
							)
						}}
					/>
				</View>
			</View>
		)
	}
}
