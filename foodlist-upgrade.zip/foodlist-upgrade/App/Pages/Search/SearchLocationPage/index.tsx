import React from 'react';
import SearchLocationPage from './view';
import SearchManager, { SearchRequest, SearchCityResponse, IgnoreResponse } from '@Network/SearchManager';
import { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import { City } from '@Models/City';
import { RequestResponse } from '@Models/RequestResponse';
import { ListParams } from '@Models/ListParams';
import { SearchNavigation, SearchRoute } from '@RouteParams/Search';
import { Region } from '@FoodListCore/Global/CommonStuff/CommonFunctions';
var _ = require("underscore")

const SEARCH_INACTIVE_TIME = 500

type Props = {
	navigation: SearchNavigation<"SearchLocationPage">
	route: SearchRoute<"SearchLocationPage">
}

export default class SearchLocationPageContainer extends React.PureComponent<Props> {
	listRef?: LoadMoreListType<City>

	manager = new SearchManager()
	searchText = ""
	nextSearch = ""
	citySelectedCb: (city: City) => void
	currentPositionSelectedCb: () => void
	lastPosition?: Region
	results?: City[]

	constructor(props: Props) {
		super(props)
		this.state = {
			results: []
		}
		const { lastPosition, citySelected, currentPositionSelected } = props.route.params
		this.onResponse = this.onResponse.bind(this)

		this.lastPosition = lastPosition
		this.citySelectedCb = citySelected
		this.currentPositionSelectedCb = currentPositionSelected
	}

	onResponse(body: RequestResponse<SearchCityResponse>) {
		let data = body?.data?.response
		if (data) {
			this.setState({
				results: data
			})
		}
	}

	reload = () => {
		this.listRef?.reload()
	}

	getRequest = async (loadMoreParams: ListParams) => {
		return await this.searchRequest(this.manager.getCities, loadMoreParams)
	}
	searchRequest = async (request: SearchRequest<SearchCityResponse>, loadMoreParams: ListParams) => {
		const searchText = this.searchText
		const body = await request(searchText, loadMoreParams)
		if (searchText == this.nextSearch) {
			this.results = body.data?.response
			return body
		} else {
			return IgnoreResponse
		}
	}
	onSearchTextChanged = (text: string) => {
		this.nextSearch = text
		setTimeout(() => {
			if (this.nextSearch == text) {
				this.searchText = text
				this.reload()
			}
		}, SEARCH_INACTIVE_TIME)
	}

	positionSelected = (item: City | null) => {
		if (item == null) {
			//Using Current Position
			this.currentPositionSelectedCb && this.currentPositionSelectedCb()
		} else {
			this.citySelectedCb && this.citySelectedCb(item)
		}
		this.props.navigation.goBack()
	}
	setRef = (ref: LoadMoreListType<City>) => {
		this.listRef = ref
	}
	render() {
		return <SearchLocationPage
			setRef={this.setRef}
			request={this.getRequest}
			onSearchTextChanged={this.onSearchTextChanged}
			positionSelected={this.positionSelected}
			showPickPosition={() => {
				this.props.navigation.navigate("PickLocation", {
					defaultPosition: this.lastPosition || this.results?.[0] || {
						// Roma
						latitude: 41.89277044,
						longitude: 12.48366723
					}
				})
			}}
		/>
	}
};
