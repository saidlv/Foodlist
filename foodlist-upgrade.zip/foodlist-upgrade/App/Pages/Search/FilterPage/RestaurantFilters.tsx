import React from 'react';
import FilterPage from './view';
import { resetRestFilters } from '@Redux/Actions';
import { connect } from 'react-redux';
import { ReduxState } from '@Redux/StateFormat';
import { Dispatch } from 'redux';
import { RestaurantInitialValues } from '@Redux/StateFormat/FiltersFormat';
import { SearchNavigation, SearchRoute } from '@RouteParams/Search';

const mapStateToProps = (state: ReduxState) => {
	return {
		filters: state.restFilters,
		dishFilters: state.dishFilters
	}
}

type Props = {
	navigation: SearchNavigation<"RestaurantFilter">
	route: SearchRoute<"RestaurantFilter">
	dispatch: Dispatch
} & ReturnType<typeof mapStateToProps>

class FilterPageContainer extends React.PureComponent<Props> {

	constructor(props: Props) {
		super(props)
		props.navigation.setParams({
			handleReset: this.onResetPressed
		})
	}

	initialValueOf = (index: number) => {
		let filters = this.props.filters
		return filters.values[filters.optionKeys[index]]
	}
	updateStateOf = (index: number, value: boolean) => {
		let filters = this.props.filters
		// @ts-ignore
		filters.values[filters.optionKeys[index]] = value
		this.forceUpdate()
	}
	onSearchPressed = () => {
		this.props.navigation.goBack()
	}
	onResetPressed = () => {
		this.props.dispatch(resetRestFilters())
		this.props.navigation.goBack()
	}
	shouldSetState = (obj: Partial<RestaurantInitialValues>, _values?: RestaurantInitialValues) => {
		let values = _values || this.props.filters.values
		for (let key in obj) {
			if (key in values) {
				// @ts-ignore
				values[key] = obj[key]
				// @ts-ignore
				if (Array.isArray(obj[key])) {
					this.forceUpdate()
				}
			}
		}
		setTimeout(() => {
			//this.forceUpdate()
		})
	}

	render() {
		let filters = this.props.filters
		const { hideBookings, hideOrderOnline } = this.props.route?.params || {}
		return <FilterPage
			isDish={false}
			searchPressed={this.onSearchPressed}
			// @ts-ignore
			initialValueOf={this.initialValueOf}
			updateStateOf={this.updateStateOf}
			filters={filters.values}
			setState={this.shouldSetState}
			MAX_PRICE={filters.MAX_PRICE}
			MAX_SEARCH_RADIUS={filters.MAX_SEARCH_RADIUS}
			multioptions={filters.options}
			navigation={this.props.navigation}
			hideBookings={hideBookings}
			hideOrderOnline={hideOrderOnline}
		/>
	}
}

export default connect(mapStateToProps)(FilterPageContainer)
