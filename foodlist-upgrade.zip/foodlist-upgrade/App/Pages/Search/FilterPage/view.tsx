import React from 'react';
import { colors } from '@Global/GlobalProps';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import styles from './Style';
import { View, Text, ScrollView } from 'react-native';
import SwitchOption from '@Components/OptionChooser/SwitchOption';
import QuickPicker from 'quick-picker';
import SliderOption from "./SliderOption";
import { connect } from 'react-redux';
import { ReduxState } from '@Redux/StateFormat';
import { RestaurantInitialValues, DishInitialValues } from '@Redux/StateFormat/FiltersFormat';
import SingleChooser from '@Components/OptionChooser/SingleChooser';
import MultiselectChooser from '@Components/OptionChooser/MultiselectChooser';
import { SearchNavigation } from '@RouteParams/Search';
import { translate, I18nKey } from '@App/I18n';
import { Pluto } from '@Models/Pluto';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import Line from '@FoodListCore/Components/Line';

const getMaxSearchRadius = (orderBy: number | undefined, max: number, isDish?: boolean) => {
	if (isDish || orderBy == 0) {
		return max - 1
	}
	return max
}

const mapStateToProps = (state: ReduxState) => {
	return {
		filterOptions: {
			notifications: state.notifications,
			dishRestrictions: state.dishRestrictions,
			foodPreferences: state.foodPreferences,
			occasions: state.occasions,
			styles: state.styles,
			paymentMethods: state.paymentMethods
		}
	}
}

type Props = {
	filters: RestaurantInitialValues | DishInitialValues
	isDish?: boolean
	navigation: SearchNavigation<Pluto>
	MAX_SEARCH_RADIUS: number
	MAX_PRICE: number
	multioptions?: I18nKey[]
	setState: (params: Partial<RestaurantInitialValues | DishInitialValues>) => void
	searchPressed: () => void
	updateStateOf?: (index: number, value: boolean) => void
	initialValueOf?: (index: number) => boolean

	hideBookings?: boolean
	hideOrderOnline?: boolean

} & ReturnType<typeof mapStateToProps>

type State = {
	maxRadius: number,
	scrollEnabled: boolean
}

class FilterPage extends React.PureComponent<Props, State> {
	constructor(props: Props) {
		super(props)
		this.state = {
			maxRadius: getMaxSearchRadius(props.filters?.orderBy, props.MAX_SEARCH_RADIUS, props.isDish),
			scrollEnabled: true
		}
	}

	disableScroll = () => {
		this.setState({
			scrollEnabled: false
		})
		this.props.navigation.setParams({ blockSwipe: true })
	}

	enableScroll = () => {
		this.setState({
			scrollEnabled: true
		})
		this.props.navigation.setParams({ blockSwipe: false })
	}

	render() {
		let filters = this.props.filters
		let filterOptions = this.props.filterOptions
		return (
			<View style={styles.container}>
				<View style={styles.scrollContainer}>
					<ScrollView contentContainerStyle={styles.scrollView} scrollEnabled={this.state.scrollEnabled}>
						<View style={commonStyle.borderVertical}>
							<SingleChooser
								title="Ordina per"
								options={[translate("bestNear"), translate("valutation"), translate("distance")]}
								onSelectionChange={(_, index) => {
									let maxRadius = getMaxSearchRadius(index ?? 0, this.props.MAX_SEARCH_RADIUS)
									let nextState = {
										orderBy: index,
										maxSearchRadius: Math.min(filters.maxSearchRadius, maxRadius)
									}
									this.setState({
										maxRadius: maxRadius
									})
									this.props.setState(nextState)
								}}
								initialIndex={filters.orderBy}
							/>
						</View>
						<View style={commonStyle.borderBottom}>
							<MultiselectChooser
								title={translate("categories")}
								isCategories
								options={[]}
								isDish={this.props.isDish}
								noSelectionText={translate("allTypes")}
								onSelectionChange={(items) => {
									this.props.setState({ categories: items })
								}}
								initialSelections={filters.categories}
							/>
						</View>

						<View style={[styles.sliderContainer, { paddingBottom: 0 }]}>
							<SliderOption
								title={translate("searchRadius")}
								textFor={(value) => {
									return (value == this.props.MAX_SEARCH_RADIUS) ? translate("nothing") : translate("kmDistance", { value: value })
								}}
								initialValue={Math.min(filters.maxSearchRadius, this.state.maxRadius)}
								onValueChange={value => this.props.setState({ maxSearchRadius: value })}
								max={this.state.maxRadius}
								min={1}
								step={1}
								onSlidingStart={this.disableScroll}
								onSlidingComplete={this.enableScroll}
							/>
						</View>

						{(this.props.isDish) && (
							<View style={[styles.sliderContainer, { paddingBottom: 0 }]}>
								<SliderOption
									title={this.props.isDish ? translate("maxPrice") : translate("maxAveragePrice")}
									textFor={(value) => {
										return (value == this.props.MAX_PRICE) ? translate("nothing") : translate("priceValue", { value: value.toString() })
									}}
									initialValue={filters.maxPrice}
									onValueChange={value => this.props.setState({ maxPrice: value })}
									max={this.props.MAX_PRICE}
									min={5}
									step={5}
									onSlidingStart={this.disableScroll}
									onSlidingComplete={this.enableScroll}
								/>
							</View>
						)}

						<View style={styles.sliderContainer}>
							<SliderOption
								title={translate("minValutation")}
								initialValue={filters.minRating}
								onValueChange={value => this.props.setState({ minRating: value })}
								max={5}
								step={0.5}
								onSlidingStart={this.disableScroll}
								onSlidingComplete={this.enableScroll}
							/>
						</View>

						{/*<View style={commonStyle.borderVertical}>
              <MultiselectChooser
                title="Preferenze alimentari"
                options={filterOptions.dishRestrictions}
                initialSelections={filters.restrictions}
                noSelectionText="Nessuna"
                onSelectionChange={(item, index) => {this.props.setGlobal({restrictions: item})}}
                navigate={this.props.navigate} />
            </View>*/}

						<Line />
						{(this.props.isDish) && (
							<>
								<Line />
								<MultiselectChooser
									title={translate("pref")}
									options={filterOptions.foodPreferences || []}
									// @ts-ignore
									initialSelections={filters.preferenze}
									noSelectionText={translate("nothing_female")}
									onSelectionChange={(item) => { this.props.setState({ preferenze: item }) }}
								/>
								<Line />
							</>
						)}
						{!this.props.isDish && (this.props.multioptions || []).map((item, index) => {
							if((this.props.hideOrderOnline && item == "orderOnline") || (this.props.hideBookings && item == "booking_with_foodlist")) {
								return
							}
							return (
								<View key={index} style={commonStyle.borderBottom}>
									<SwitchOption
										title={translate(item)}
										value={this.props.initialValueOf?.(index) ?? false}
										valueChanged={(value) => {
											this.props.updateStateOf?.(index, value)
										}} />
								</View>
							)
						})}
						{!this.props.isDish && (
							<>
								<MultiselectChooser
									title={translate("occasion")}
									options={filterOptions.occasions || []}
									initialSelections={filters.occasions}
									noSelectionText={translate("allOccasions")}
									onSelectionChange={(item) => { this.props.setState({ occasions: item }) }}
								/>
								<Line />
							</>
						)}
						{/*
                <View style={commonStyle.borderBottom}>
                  <MultiselectChooser
                    title="Stili ed atmosfera"
                    options={filterOptions.styles}
                    initialSelections={filters.styles}
                    noSelectionText="Tutti i tipi"
                    onSelectionChange={(item, index) => {this.props.setState({styles: item})}}
                    navigate={this.props.navigate} />
                </View>
              </View>
            )*/}
					</ScrollView>
				</View>
				<View style={commonStyle.buttonContainer}>
					<TouchableRipple underlayColor={colors.darkRed} style={styles.button} onPress={this.props.searchPressed}>
						<Text style={styles.buttonText}>{translate("search")}</Text>
					</TouchableRipple>
				</View>
				<QuickPicker />
			</View>
		)
	}
}

export default connect(mapStateToProps)(FilterPage)