import React from 'react';
import FilterPage from './view';
import { resetDishFilters } from '@Redux/Actions';
import { connect } from 'react-redux';
import { ReduxState } from '@Redux/StateFormat';
import { Dispatch } from 'redux';
import { DishInitialValues } from '@Redux/StateFormat/FiltersFormat';
import { SearchNavigation } from '@RouteParams/Search';

const mapStateToProps = (state: ReduxState) => {
	return {
		filters: state.dishFilters,
		restFilters: state.restFilters
	}
}

type Props = {
	navigation: SearchNavigation<"DishFilterPage">
	dispatch: Dispatch
} & ReturnType<typeof mapStateToProps>

class DishFilterPage extends React.PureComponent<Props> {
	componentDidMount() {
		this.props.navigation.setParams({
			handleReset: this.onResetPressed
		})
	}
	onSearchPressed = () => {
		this.props.navigation.goBack()
	}
	onResetPressed = () => {
		this.props.dispatch(resetDishFilters())
		this.props.navigation.goBack()
	}
	shouldSetState = (obj: Partial<DishInitialValues>, _values?: DishInitialValues) => {
		let values = _values || this.props.filters?.values
		for (let key in obj) {
			if (!obj.hasOwnProperty(key)) continue;
			values[key] = obj[key]
			this.forceUpdate()
		}
	}
	render() {
		let filters = this.props.filters
		return <FilterPage
			isDish={true}
			searchPressed={this.onSearchPressed.bind(this)}
			filters={this.props.filters.values}
			MAX_PRICE={filters.MAX_PRICE}
			MAX_SEARCH_RADIUS={filters.MAX_SEARCH_RADIUS}
			setState={this.shouldSetState}
			navigation={this.props.navigation}
		/>
	}
}

export default connect(mapStateToProps)(DishFilterPage);