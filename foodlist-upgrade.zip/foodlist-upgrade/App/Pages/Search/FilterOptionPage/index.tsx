import React from 'react';
import FilterPage, { FilterOptionActions } from './view';
import SearchManager, { SearchCategoryResponse, IgnoreResponse } from '@Network/SearchManager';
import { RequestResponse } from '@Models/RequestResponse';
import LoadMoreList, { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import { RestaurantCategory, GenericCategory } from '@Models/Category';
import { PrintableItem } from '@Models/PrintableItem';
import { CommonNavigation, CommonRoute } from '@RouteParams/Common';
import { ListParams } from '@Models/ListParams';

type Props = {
	navigation: CommonNavigation<"FilterOptionPage">
	route: CommonRoute<"FilterOptionPage">
}

type State = {
	loading: boolean
	originalOptions: PrintableItem[]
	options: PrintableItem[]
	sectionedOptions: PrintableItem[][]
}

class FilterOptionPageContainer extends React.PureComponent<Props, State> {
	isCategories: boolean
	isDish: boolean
	searchText: string
	nextText: string
	listRef?: LoadMoreListType<GenericCategory>

	manager = new SearchManager()
	request: (search: string, params: ListParams) => Promise<RequestResponse<SearchCategoryResponse>>

	constructor(props: Props) {
		super(props)
		const { isCategories, isDish, options, } = props.route.params
		this.isCategories = isCategories ?? false
		this.isDish = isDish ?? false
		this.state = {
			originalOptions: JSON.parse(JSON.stringify(options ?? [])),
			options: options ?? [],
			sectionedOptions: [[], []],
			loading: this.isCategories && !this.isDish
		}
		this.searchText = ""
		this.nextText = ""
		this.request = this.isDish ? this.manager.getDishCategories : this.manager.getRestCategories
	}

	componentDidMount() {
		if (this.isCategories && !this.isDish) {
			this.getRequest({}).then((response) => {
				if (response.data?.ignore) return
				let options = response?.data?.response || []
				this.setState({
					originalOptions: options,
					sectionedOptions: this.sectionedOptions(options)
				})
			}).catch((err) => {
				console.error(err)
			}).finally(() => {
				this.setState({
					loading: false
				})
			})
		}
	}

	sectionedOptions = (options: RestaurantCategory[]) => {
		return options.reduce<[RestaurantCategory[], RestaurantCategory[]]>((acc, item) => {
			acc[item.ethnic ? 1 : 0].push(item)
			return acc
		}, [[], []])
	}

	getCategories = () => {
		this.listRef?.reload()
	}
	getRequest = async (params: ListParams) => {
		//console.log("request")
		let searchText = this.searchText
		const body = await this.request(searchText, params)
		if (searchText == this.nextText) {
			return body
		} else {
			return IgnoreResponse
		}
	}
	getSelections = () => {
		return this.props.route.params.selections ?? []
	}
	onSearchTextChanged = (text: string) => {
		if (this.isCategories && this.isDish) {
			this.nextText = text
			setTimeout(() => {
				if (this.nextText == text) {
					this.searchText = text
					this.getCategories()
				}
			}, 500)
		} else {
			let filteredOptions = this.state.originalOptions.filter((item) => {
				let item_text = item?.label_it?.toLowerCase() || ""
				return item_text.includes(text?.toLowerCase())
			})
			if ((this.isCategories && !this.isDish)) {
				this.setState({ sectionedOptions: this.sectionedOptions(filteredOptions) })
			} else {
				this.setState({
					options: filteredOptions
				})
			}
		}
	}

	actions: FilterOptionActions = {
		savePressed: () => {
			this.props.navigation.goBack()
		},
		updateProp: (item) => {
			this.props.route.params.onItemChanged?.(item)
		},
		onSearchTextChanged: this.onSearchTextChanged,
		listRef: (ref) => this.listRef = ref,
		request: this.getRequest
	}

	render() {
		return <FilterPage
			options={this.state.options}
			sectionedOptions={this.state.sectionedOptions}
			selections={this.getSelections()}
			isCategories={this.isCategories}
			isDish={this.isDish}
			loading={this.state.loading}

			actions={this.actions}
		/>
	}
}

export default FilterOptionPageContainer