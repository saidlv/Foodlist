import { colors } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet, Dimensions } from 'react-native';

export default StyleSheet.create({
	positionBoxContainer: {
		paddingHorizontal: 20,
		paddingVertical: 10,
		marginTop: 10
	},
	flexLine: {
		flex: 1,
		flexDirection: 'row',
		justifyContent: 'space-between'
	},
	flexStart: {
		alignSelf: 'flex-start'
	},
	flexEnd: {
		alignSelf: 'flex-end'
	},
	container: {
		flex: 1,
		flexDirection: "column",
		backgroundColor: colors.greyBackground
	},
	scrollContainer: {
		flex: 1,
		flexDirection: "column",
		alignSelf: 'stretch'
	},
	scrollView: {
		paddingTop: 10,
		paddingBottom: 5,
		width: Dimensions.get('window').width
	},
	borderVertical: {
		borderStyle: "solid",
		borderBottomWidth: 1,
		borderTopWidth: 1,
		borderColor: colors.greyBorder
	},
	borderBottom: {
		borderStyle: "solid",
		borderBottomWidth: 1,
		borderColor: colors.greyBorder
	},
	sliderContainer: {
		flex: 1,
		padding: 20
	},
	button: {
		alignSelf: "stretch",
		justifyContent: 'center',
		height: 48,
		borderRadius: 4,
		backgroundColor: colors.foodlist
	},
	buttonText: {
		textAlign: "center",
		alignSelf: "center",
		fontSize: 18,
		fontWeight: "bold",
		color: "#ffffff"
	},
	sliderWheel: {
		width: 28,
		height: 28,
		borderRadius: 14,
		backgroundColor: colors.white,
		shadowRadius: 2,
		shadowOffset: { width: 0, height: 3 },
		shadowOpacity: 0.2,
		borderStyle: "solid",
		borderWidth: 0.5,
		borderColor: 'rgba(0, 0, 0, 0.1)'
	}
})
