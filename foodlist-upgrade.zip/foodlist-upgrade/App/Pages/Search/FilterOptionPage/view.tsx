import React, { ReactChild } from 'react';
import styles from './Style';
import { View, ScrollView, Text, SectionList } from 'react-native';
import SwitchOption from '@Components/OptionChooser/SwitchOption';
import AutoLoadingView from '@FoodListCore/Components/AutoLoadingView'
import FLEditText from '@FoodListCore/Components/Input/FLEditText';
import LoadMoreList, { LoadMoreListType } from '@FoodListCore/Components/LoadMoreList';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import { colors } from '@Global/GlobalProps';
import { PrintableItem } from '@Models/PrintableItem';
import { GenericCategory } from '@Models/Category';
import { SearchCategoryResponse } from '@Network/SearchManager';
import { RequestResponse } from '@Models/RequestResponse';
import { ListParams } from '@Models/ListParams';
import { translate } from '@App/I18n';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';

/*
@param options
*/

export type FilterOptionActions = {
	savePressed: () => void
	updateProp: (item: PrintableItem[]) => void
	listRef: (ref: LoadMoreListType<GenericCategory>) => void
	onSearchTextChanged: (newText: string) => void
	request: (params: ListParams) => Promise<RequestResponse<SearchCategoryResponse>>
}

type Props = {
	options: PrintableItem[]
	sectionedOptions: PrintableItem[][]
	selections: PrintableItem[]
	loading: boolean
	isDish: boolean
	isCategories: boolean

	actions: FilterOptionActions
}

type State = {
	selections: PrintableItem[]
}

export default class FilterOptionPage extends React.PureComponent<Props, State> {
	actions: FilterOptionActions

	constructor(props: Props) {
		super(props)
		this.state = {
			selections: props.selections || []
		}
		this.actions = props.actions
	}
	isSelected = (item: PrintableItem, opposite?: boolean) => {
		let items = (this.state.selections) || []
		let result = items.find((_item) => {
			return _item.id == item.id
		})
		if (result) {
			return !!result.opposite == !!opposite
		}
		return false
	}
	updateSelections = (item: PrintableItem & { opposite?: boolean }, newValue: boolean) => {
		let array = this.state.selections

		//elimino sempre in modo da gestire correttamente gli opposite_label_it
		let index = array.findIndex((elem) => {
			return elem.id == item.id
		})
		if (index != -1) {
			array.splice(index, 1)
		}

		if (newValue) {
			array.push(item)
		}
		this.setState({
			selections: array.concat()
		})
		this.actions.updateProp(array.concat())
	}
	cell = (item: PrintableItem, index: number, opposite?: boolean) => {
		return (
			<View key={index + (opposite ? "-1" : "-0")} style={styles.borderBottom}>
				<SwitchOption
					title={item.label_it}
					value={this.isSelected(item, opposite)}
					valueChanged={(value) => {
						this.updateSelections({
							...item,
							opposite: opposite
						}, value)
					}}
				/>
			</View>
		)
	}
	render() {
		return (
			<View style={styles.container}>
				<View style={styles.scrollContainer}>
					<View style={styles.positionBoxContainer}>
						<FLEditText
							actions={{
								onChangeText: this.actions.onSearchTextChanged
							}}
							inputContainerConfig={{
								icon: "search",
								standalone: true,
							}}
							textInputProps={{
								placeholder: translate("searchCategories")
							}}
						/>
					</View>
					<View style={{ alignItems: 'stretch', flex: 1, }}>
						{this.props.loading &&
							<View style={{ marginTop: 40, flex: 1 }}>
								<AutoLoadingView loading={true} />
							</View>
						}
						{!this.props.loading && !this.props.isCategories &&
							<ScrollView contentContainerStyle={styles.scrollView}>
								{this.props.options.reduce<ReactChild[]>((prev, item, index) => {
									prev.push(this.cell(item, index))
									return prev
								}, [])}
							</ScrollView>
						}
						{!this.props.loading && this.props.isCategories && !this.props.isDish &&
							<View style={{ flex: 1 }}>
								<SectionList
									renderItem={({ item, index, section }) => this.cell(item, index)}
									renderSectionHeader={({ section: { title } }) => (
										<View style={{ backgroundColor: colors.lightGrey, padding: 10, paddingLeft: 20, borderBottomWidth: 1, borderTopWidth: 1, borderColor: colors.darkGreyBorder }}>
											<Text style={{ fontWeight: 'bold' }}>{title}</Text>
										</View>
									)}
									sections={[
										{ title: translate("tipology").toUpperCase(), data: this.props.sectionedOptions?.[0] || [] },
										{ title: translate("origin").toUpperCase(), data: this.props.sectionedOptions?.[1] || [] },
									]}
									keyExtractor={(item, index) => (item.id + index).toString()}
								/>
							</View>
						}
						{!this.props.loading && this.props.isCategories && this.props.isDish &&
							<View style={{ flex: 1 }}>
								<LoadMoreList
									listRef={this.actions.listRef}
									dontStart
									noDataText={translate("noResults")}
									renderItem={({ item, index }) => { return this.cell(item, index) }}
									request={this.actions.request}
								/>
							</View>
						}
						<View style={commonStyle.buttonContainer}>
							<TouchableRipple underlayColor={colors.darkRed} style={styles.button} onPress={this.actions.savePressed}>
								<Text style={styles.buttonText}>{translate("save")}</Text>
							</TouchableRipple>
						</View>
					</View>
				</View>
			</View>
		)
	}
}
