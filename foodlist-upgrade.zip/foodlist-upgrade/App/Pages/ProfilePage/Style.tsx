import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	tab: {
		width: "100%",
		borderWidth: 1,
		marginTop: 20,
		borderColor: colors.greyBorder,
		backgroundColor: colors.white
	},
	alignCenter: {
		alignItems: 'center'
	},
	text: {
		marginLeft: 20,
		fontSize: 14,
		fontWeight: "500",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText
	},
	progressText: {
		fontWeight: "bold",
		color: colors.greyInfoText,
		fontSize: 12,
		marginBottom: 5
	},
	rightText: {
		position: "absolute",
		right: 20
	},
	marginTopBetween: {
		marginTop: 20
	},
	bigMarginTop: {
		marginTop: 32
	}

})
