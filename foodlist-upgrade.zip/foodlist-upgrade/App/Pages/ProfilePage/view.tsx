import React from 'react';
import { colors, when, userImage } from '@Global/GlobalProps';
import AutoLoadingView, { AutoLoadingActions } from '@FoodListCore/Components/AutoLoadingView'
import { Text, View, ScrollView, RefreshControl, NativeScrollEvent, NativeSyntheticEvent } from 'react-native';
import ReviewsList from '@Components/ReviewsList';
import Progress from "@Components/ProgressIndicator";
import FollowLine from "@Components/FollowLine";
import localStyles from './Style';
import styles from '@FoodListCore/Global/CommonStuff/PageStyle';

import { connect } from 'react-redux';
import { ReduxState } from '@Redux/StateFormat';
import { ReviewsListActions } from '@Models/ReviewsListActions';
import { User } from '@Models/User';
import { Review } from '@Models/Review';
import { mapStringsToItems } from '@Components/InlineSubMenu';
import { UserContainer } from '.';
import { ReviewType } from '@Models/ReviewType';
import { GetProfileAndReviewsResponse } from '@Network/UserManager';
import { translate } from '@App/I18n';
import IntegrationComponent from '@FoodListCore/Flows/User/integration-component';
import InlineInfo from '@FoodListCore/Components/InlineInfo';
import Heading from '@FoodListCore/Components/Heading';
import Line from '@FoodListCore/Components/Line';

export type ProfilePageActions = {
	loadingActions: AutoLoadingActions<GetProfileAndReviewsResponse>
	reviewsListActions: ReviewsListActions
	handleScroll: (event: NativeSyntheticEvent<NativeScrollEvent>) => void
	refreshData: () => void
	loadingRef: (ref: AutoLoadingView<GetProfileAndReviewsResponse>) => void
	showFollowers: () => void
	showFollowing: () => void
}

type Props = {
	actions: ProfilePageActions
	loading: boolean
	refreshing: boolean
	isCurrentUser: boolean
	current_user: User
	data: UserContainer | undefined
	showingNameTopBar: boolean
	reviewList: Review[]
	filtersActive: boolean
	loadingReviews: boolean
	ratingFilter: string
	typeFilter: ReviewType
}

const hasName = (userInfo: User | null | undefined) => {
	return userInfo?.first_name || userInfo?.last_name
}

class ProfilePage extends React.PureComponent<Props> {
	actions: ProfilePageActions
	constructor(props: Props) {
		super(props)
		this.actions = props.actions
	}
	render() {
		let data = this.props.data
		let level_starts_at = data?.level_starts_at
		let missing_points = data?.next_user_level?.missing_points || 0
		let current_points = data?.points || 0
		let next_level_points = current_points + missing_points
		let userInfo = this.props.isCurrentUser ? this.props.current_user : data
		const hasPhone = userInfo && userInfo.country_code && userInfo.phone && userInfo.verified
		//console.log("userinfo", userInfo, this.props.current_user, data)
		return (
			<View style={{ flex: 1 }}>
				<AutoLoadingView
					actions={this.actions.loadingActions}
					ref={this.actions.loadingRef}
				/>
				<ScrollView
					contentContainerStyle={{ paddingBottom: 20 }}
					style={styles.flexColumn}
					scrollEventThrottle={1}
					onScroll={this.actions.handleScroll}
					refreshControl={
						<RefreshControl
							style={{ zIndex: 10 }}
							tintColor="#fff"
							refreshing={this.props.refreshing}
							onRefresh={this.actions.refreshData}
						/>
					}>
					{(!this.props.loading && !!data) && (
						<View>
							<Heading
								title={this.props.showingNameTopBar ? "" : (userInfo?.username ?? "")}
								image={userImage(userInfo?.photo, true)}
								fullImage={userImage(userInfo?.photo, false)}
								hideNumber
								headerColor={colors.foodlist}
							>
								<FollowLine
									showFollowers={this.actions.showFollowers}
									showFollowing={this.actions.showFollowing}
									userName={userInfo?.username || ""}
									followingId={data.id || 0}
									followers_count={data.followers || 0}
									following_count={data.following || 0}
									reviews_count={data.reviews_count || 0}
									following={data.following_user || false}
								/>
							</Heading>

							<View style={[localStyles.tab, styles.flexRow, { flexDirection: 'column', paddingHorizontal: 20, paddingVertical: 10, marginBottom: this.props.isCurrentUser ? 20 : 0 }]}>
								<View style={{ flexDirection: 'row', alignSelf: 'stretch', justifyContent: 'space-between' }}>
									<Text style={[localStyles.progressText, {}]}>Livello {data.user_level_id} • {data?.user_level?.label_it}</Text>
									<Text style={localStyles.progressText}>{current_points + "/" + next_level_points}</Text>
								</View>
								<Progress min={level_starts_at || 0} max={next_level_points} current={current_points} />
							</View>

							{this.props.isCurrentUser && (
								<View style={{ marginTop: 20 }}>
									<Line />
									<InlineInfo
										title={translate("name")}
										placeholderContent={!hasName(userInfo)}
										content={hasName(userInfo) ? `${userInfo?.first_name ?? ""} ${userInfo?.last_name ?? ""}` : translate("notSet")}
									/>
									<Line />
									<InlineInfo
										title={translate("email")}
										content={userInfo?.email ?? ""}
									/>
									<Line />
									<InlineInfo
										title={translate("phone")}
										placeholderContent={!hasPhone}
										content={hasPhone ? ("+" + userInfo?.country_code + " " + userInfo?.phone) : translate("notSet")}
									/>
									<Line />
									<View style={{marginBottom: 20}} />
									<IntegrationComponent />
								</View>
							)}

							{(this.props.reviewList.length == 0 && !this.props.filtersActive) && (
								<View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 30 }}>
									<Text style={[styles.descriptionText, styles.placeholder]}>{translate("noLocalOrDishReviewd")}</Text>
								</View>
							)}
							{(this.props.reviewList.length != 0 || this.props.filtersActive) && (
								<View style={localStyles.bigMarginTop}>
									<View style={{ width: "100%" }}>
										<ReviewsList
											filterOptions={{
												isProfile: true,
												itemsInlineSubMenu: mapStringsToItems([translate("allReviews").toUpperCase(), translate("localReviews").toUpperCase(), translate("dishReviews").toUpperCase()])
											}}
											actions={this.actions.reviewsListActions}
											data={{
												user: data,
												disableUserPress: true
											}}
											reviewsList={this.props.reviewList}
											loadingReviews={this.props.loadingReviews}
											ratingFilter={this.props.ratingFilter}
											typeFilter={this.props.typeFilter}
										/>
									</View>
								</View>
							)}
						</View>
					)}
				</ScrollView>
			</View>
		);
	}
}
export default connect((state: ReduxState) => {
	return {
		current_user: state.currentUser!
	}
})(ProfilePage)