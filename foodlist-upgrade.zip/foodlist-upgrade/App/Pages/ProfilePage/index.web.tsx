import { margins } from "@FoodListCore/Global/GlobalProps"
import { ReduxState } from "@FoodListCore/Redux/StateFormat"
import React from "react"
import { StyleSheet, Text, View } from "react-native"
import { shallowEqual, useSelector } from "react-redux"
import { UserPageWrapper } from "@FoodListCore/Components/UserSideMenu"
import ShadowProfileImage from "@FoodListCore/Components/ShadowProfileImage"
import CommonStyle from "@FoodListCore/Global/CommonStyle"
import InlineInfo from "@FoodListCore/Components/InlineInfo"
import { translate } from "@FoodListCore/I18n"
import Line from "@FoodListCore/Components/Line"
import { User } from "@Models/User"

const reduxMap = (state: ReduxState) => ({
	user: state.currentUser,
})

const hasName = (userInfo: User | null | undefined) => {
	return userInfo?.first_name || userInfo?.last_name
}

const ProfilePage = React.memo(() => {
	const { user } = useSelector(reduxMap, shallowEqual)
	const userInfo = user
	const hasPhone = userInfo && userInfo.country_code && userInfo.phone && userInfo.verified

	//TODO: reload user
	return (
		<UserPageWrapper activePage="profile">
			<View style={styles.container}>
				<ShadowProfileImage item={user} type="user" disableFullscreen size={160} />
				<Text style={styles.username}>{user?.username}</Text>
				<View style={[CommonStyle.roundedBox, { width: "100%" }]}>
					<InlineInfo
						title={translate("name")}
						placeholderContent={!hasName(userInfo)}
						content={hasName(userInfo) ? `${userInfo?.first_name ?? ""} ${userInfo?.last_name ?? ""}` : translate("notSet")}
					/>
					<Line />
					<InlineInfo
						title={translate("email")}
						content={userInfo?.email ?? ""}
					/>
					<Line />
					<InlineInfo
						title={translate("phone")}
						placeholderContent={!hasPhone}
						content={hasPhone ? ("+" + userInfo?.country_code + " " + userInfo?.phone) : translate("notSet")}
					/>
				</View>
			</View>
		</UserPageWrapper>
	)
})

const styles = StyleSheet.create({
	container: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: margins.pagePadding * 2,
		alignItems: "center",
	},
	username: {
		marginTop: 10,
		fontSize: 18,
		marginBottom: 20,
	},
})

export default ProfilePage
