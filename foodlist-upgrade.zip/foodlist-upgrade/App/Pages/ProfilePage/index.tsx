import React from 'react';
import UserManager, { GetReviewsResponse, GetProfileAndReviewsResponse } from '@Network/UserManager';
import SessionManager from "@Services/SessionManager";
import ProfilePage, { ProfilePageActions } from "./view"
import { nameAppearOnScrollGlobal } from '@Global/GlobalProps';
import { connect } from 'react-redux';
import { NativeSyntheticEvent, NativeScrollEvent } from 'react-native';
import { ReduxState } from '@Redux/StateFormat';
import { User } from '@Models/User';
import { Review, ReviewDistribution } from '@Models/Review';
import AutoLoadingView from '@FoodListCore/Components/AutoLoadingView';
import { RequestResponse } from '@Models/RequestResponse';
import { ReviewType } from '@Models/ReviewType';
import { CommonRoute, CommonNavigation } from '@RouteParams/Common';
import { Dispatch } from 'redux';

export type UserContainer = User & {
	points?: number,
	level_starts_at?: number,
	next_user_level?: {
		missing_points?: number
	},
}

type Props = {
	current_user_id: number
	route: CommonRoute<"ProfilePage">
	navigation: CommonNavigation<"ProfilePage">
}

type State = {
	data?: UserContainer
	loading: boolean
	refreshing: boolean
	shouldReload: boolean
	reviewList: Review[]
	percentageStarReviews?: ReviewDistribution
	filtersActive: boolean
	showingNameTopBar: boolean
	followerList: User[]
	followingList: User[]
	loadingReviews: boolean
	id: number | null
	ratingFilter: string
	typeFilter: ReviewType
}

class ProfilePageContainer extends React.PureComponent<Props, State> {
	manager = new UserManager()
	isCurrentUser = false
	shouldReloadFollowers = false
	user_id: number
	loadRef?: AutoLoadingView<GetProfileAndReviewsResponse>

	constructor(props: Props) {
		super(props);

		this.state = {
			data: undefined,
			loading: true,
			refreshing: false,
			shouldReload: false,
			reviewList: [],
			percentageStarReviews: undefined,
			filtersActive: false,
			showingNameTopBar: false,
			followerList: [],
			followingList: [],
			loadingReviews: false,
			id: null,
			ratingFilter: "",
			typeFilter: "all"
		}

		this.user_id = props.route.params?.user_id ?? this.props.current_user_id
		this.isCurrentUser = this.user_id == this.props.current_user_id
	}

	loadData = () => {
		this.user_id = this.props.route.params?.user_id ?? this.props.current_user_id
		this.isCurrentUser = this.user_id == this.props.current_user_id

		if (this.user_id != this.state.id || this.state.shouldReload || this.state.refreshing) {

			this.setState({ shouldReload: false }, () => {
				this.reload()
			})
		}
	}
	_loadData = () => {

		this.setState({ loading: (this.state.refreshing) ? false : true })

		this.nameAppearOnScroll(null)
		this.shouldReloadFollowers = false

		this.setState({
			reviewList: [],
			percentageStarReviews: undefined,
			filtersActive: false,
			showingNameTopBar: false
		})
	}

	reload = () => {
		this._loadData()
		this.loadRef?.retry?.()
	}
	handleReviewResponse = (type: string, response: RequestResponse<GetReviewsResponse>) => {
		if (type == "restaurants" || type == "dishes") {
			this.setState({
				reviewList: (type === "restaurants") ? response?.data?.response?.restaurants || [] : response?.data?.response?.dishes || []
			})
		} else {
			this.setState({
				reviewList: this.mergeAndSortReviewsArray(response?.data?.response?.restaurants!, response?.data?.response?.dishes!)
			})
		}
	}

	filterCallback = async (type: ReviewType, rating: string) => {
		this.setState({
			filtersActive: true,
			ratingFilter: rating,
			typeFilter: type,
			loadingReviews: true
		})

		var response = await this.manager.getReviews(this.user_id, { limit: 6, offset: 0 }, type, rating)
		this.setState({ loadingReviews: false })

		if (response.success) {
			this.handleReviewResponse(type, response)
		} else {
			throw new Error(response.error)
		}
	}

	nameAppearOnScroll = (event: NativeSyntheticEvent<NativeScrollEvent> | null) => {
		nameAppearOnScrollGlobal(event, this, this.state.data?.username || "", this.state.showingNameTopBar);
	}

	requestPromise = () => {
		//TODO: don't know if needed
		//this.user_id = this.props.navigation.getParam("user_id", this.props.current_user_id)
		return this.manager.getProfileAndReviews(this.user_id!, "all", "")
	}

	custom_sort(a: Review, b: Review) {
		return new Date(b.content_updated_at).getTime() - new Date(a.content_updated_at).getTime()
	}

	mergeAndSortReviewsArray(restaurants: Review[], dishes: Review[]) {
		let allReviews = restaurants.concat(dishes)
		return allReviews.sort(this.custom_sort)
	}

	onResponse = (body: RequestResponse<GetProfileAndReviewsResponse>) => {
		if(this.unmounted) return
		if (body.success) {
			const bodyReviews = body.data?.[0]?.response
			const user_info = body.data?.[1]?.response

			if (this.isCurrentUser && user_info) {
				SessionManager.setCurrentUser(user_info);
			}

			if(this.unmounted) return
 			/* this.props.navigation.setParams({
				userToShare: user_info
			}) */

			this.setState({
				data: user_info,
				percentageStarReviews: body.data?.[1]?.response?.reviews_distribution,
				refreshing: false,
				loading: false,
				reviewList: this.mergeAndSortReviewsArray(bodyReviews?.restaurants!, bodyReviews?.dishes!)
			})
		} else {
			throw new Error(body.error)
		}
	}

	handleOnNavigateBack = () => {
		this.setState(this.state);
	}

	showFollowers = () => {
		this.props.navigation.push("UserListPage", {
			"followers": true,
			likes: false,
			id: this.user_id,
			isCurrentUser: this.user_id == this.props.current_user_id,
			followers_count: this.state.data?.followers,
		});
	}

	showFollowing = () => {
		this.props.navigation.push("UserListPage", {
			"followers": false,
			likes: false,
			id: this.user_id,
			isCurrentUser: this.user_id == this.props.current_user_id,
			following_count: this.state.data?.following,
		});
	}

	refreshData = () => {
		this.setState({ refreshing: true }, async () => {
			//TODO: again don't know if needed
			//this.user_id = this.props.navigation.getParam("user_id", this.props.current_user_id);
			let response = await this.manager.getProfileAndReviews(this.user_id!, this.state.typeFilter, this.state.ratingFilter)
			this.onResponse(response)
		})
	}

	callbackShouldReload = () => {
		this.setState({ shouldReload: true }, () => {
			this.loadData()
		})
	}

	actions: ProfilePageActions = {
		loadingActions: {
			request: this.requestPromise,
			onResponse: this.onResponse
		},
		reviewsListActions: {
			filterCallback: this.filterCallback,
			callbackShouldReload: this.callbackShouldReload
		},
		//loadingRef: ()
		handleScroll: this.nameAppearOnScroll,
		showFollowers: this.showFollowers,
		showFollowing: this.showFollowing,
		refreshData: this.refreshData,
		loadingRef: (ref) => {
			this.loadRef = ref
		}
	}

	render() {
		return (
			<ProfilePage
				refreshing={this.state.refreshing}
				data={this.state?.data}
				reviewList={this.state?.reviewList || []}
				loading={this.state?.loading}
				showingNameTopBar={this.state?.showingNameTopBar}
				filtersActive={this.state?.filtersActive}
				isCurrentUser={this.user_id == this.props.current_user_id}
				//following_count={(this.isCurrentUser) ? this.props.followingList?.length || 0 : this.state?.data?.following || 0}
				loadingReviews={this.state.loadingReviews}
				ratingFilter={this.state.ratingFilter}
				typeFilter={this.state.typeFilter}
				actions={this.actions}
			/>
		);
	}
}

export default connect((state: ReduxState) => {
	return {
		followingList: state.followingList,
		current_user_id: state.currentUser?.id!
	}
})(ProfilePageContainer);