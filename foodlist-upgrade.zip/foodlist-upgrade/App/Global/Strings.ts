export default {
	//usernameError: "Caratteri speciali ammessi: ._-",
	usernameError: "Non valido"
}