import React, { ReactNode, ReactElement } from 'react';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import { View, Alert, NativeSyntheticEvent, NativeScrollEvent, ViewStyle, StyleProp } from 'react-native';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import 'moment/locale/it';
import { Photo } from '@Models/Photo';
import { ImageSource } from '@Models/ImageSource';
import { Restaurant } from '@Models/Restaurant';
import { Dish } from '@Models/Dish';
import { Review } from '@Models/Review';
import { Notification } from '@Models/Notification';
import { ItemsMap } from '@Models/ItemsMap';
import { CommonNavigation } from '@RouteParams/Common';
import { translate } from '@App/I18n';
import { Pluto } from '@Models/Pluto';
import { Any } from '@Models/Any';
import { IconName } from '@FoodListCore/Iconfont/IconName';
var _ = require("underscore")

export { colors } from "@FoodListCore/Global/GlobalProps"

import { formatPrice as coreFormatPrice } from "@FoodListCore/Global/GlobalProps"

export const termsLink = "https://foodlist.eu/documents/Termini_e_Condizioni.pdf";
export const privacyLink = "https://foodlist.eu/documents/Informativa_Privacy.pdf";

let hexAlpha = (alpha: number): string => {
	return ('00' + Math.round(255 * alpha).toString(16)).substr(-2)
}
/* Ritorna la stringa iso del locale corrente.
 * se withState = true ritorna anche le info dello stato (en-US, it-IT)
 * se false, ritorna solo il locale (en, it)
 */
/* export const currentLocale = (withState: boolean): string => {
	let locale
	if (Platform.OS == 'android') {
		locale = NativeModules.I18nManager.localeIdentifier
	} else {
		locale = NativeModules.SettingsManager.settings.AppleLocale || NativeModules.SettingsManager.settings.AppleLanguages[0]
	}

	//console.log("Locale", locale);

	if (withState) return locale;
	return locale.split("-")[0];
} */

export const length = (array: Any) => {
	if (array && Array.isArray(array)) {
		return array.length
	}
	return 0
}

export const dishImage = (fileName: string, thumb: boolean): string => {
	return _image("reviews/dishes", fileName, thumb)
}

export const restaurantImage = (fileName: string, thumb: boolean): string => {
	return _image("reviews/restaurants", fileName, thumb)
}
export const _image = (prefix: string, fileName: string, thumb: boolean): string => {
	const number = fileName.substring(0, fileName.indexOf("."));
	const id = number.slice(-2);
	if (thumb) fileName.replace(".", "_thumb.");
	return "https://foodlist.eu/uploads/" + prefix + "/" + id + "/" + fileName;
}
export const returnIfTrue = <T extends Any>(val: T, fn: (val: T) => boolean): T | null => {
	if (fn(val)) return val;
	return null;
}

export const fontSizes = {
	formButtonTitle: 18
}
export const regex = {
	EMAIL: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
	CAP: /^\d{4,5}$/,
	PRICE: /^\d+(?:$|[\.,]\d{1,2}$)/,
	URL: /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:\/?#[\]@!\$&'\(\)\*\+,;=.%]+$/,
	HOUSE_NUMBER: /^[a-zA-Z\d\/\\\^\.\,\ \-]+$/,
	PHONE: /^\+?[\d\s]{3,}$/,
	USER_NAME: /^\w{1,}(\.|-|\w){1,}\w{1,}$/,
	PASSWORD: /^.{6,}$/,
	EMAIL_OR_USERNAME: /^((\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+)|(\w{1,}(\.|\w){1,}\w{1,}))$/
}

export const usernameErrorText = (text?: string): string => {
	if (stringDefined(text)) {
		if (text?.indexOf(" ") != -1) {
			return translate("dontInsertSpaces")
		}
		if (text?.indexOf("@") != -1) {
			return translate("dontInsertAt")
		}
		if (text?.length < 3) {
			return translate("atLeast3Chars")
		}
	}
	return translate("notValid")
}


export const when = <T extends {}>(cond: boolean | undefined | null, style: StyleProp<T>): StyleProp<T | {}> => {
	return whenElse(cond, style, {});
}
export const whenElse = <T extends {}>(cond: boolean | undefined | null, style: StyleProp<T>, elseStyle: StyleProp<T>): StyleProp<T> => {
	if (cond) {
		return style
	}
	return elseStyle
}

export const iconStyle = {}
export const iconNamed = (name: IconName, onPress?: () => void, size = 17): ReactElement => {
	if (onPress) {
		return (
			<TouchableOpacity onPress={onPress} style={{ height: "100%", alignItems: "center", justifyContent: "center" }}>
				<Icon style={{ marginHorizontal: 20 }} name={name} size={size} color="#fff" />
			</TouchableOpacity>
		)
	} else {
		return <Icon name={name} size={size} color="#fff" />
	}
}

const getSource = (item: Photo, thumb?: boolean): ImageSource => {
	return { uri: thumb ? item.thumbUrl : item.fullUrl }
}

export const imagesRestaurant = (data: Restaurant | Dish | null, thumb?: boolean): ImageSource[] => {
	let images: ImageSource[] = []
	if (data?.photos && data?.photos.length != 0) {
		data.photos.forEach(item => {
			images.push(getSource(item, thumb))
		})
	}
	if (data?.review_photos) {
		data.review_photos.forEach(item => {
			images.push(getSource(item, thumb))
		})
	}
	if (data?.review_photo) {
		images.push(getSource(data.review_photo, thumb))
	}
	if (images.length == 0 && data && "g_photo" in data && data.g_photo) {
		images.push(getSource(data.g_photo, thumb))
	}
	return images
}

export const imageRestaurant = (data: Restaurant | null, thumb?: boolean): ImageSource => {
	return imagesRestaurant(data, thumb)?.[0] || require('@FoodListCore/Assets/Images/ristorante.jpg')
}

export const imagesFood = imagesRestaurant

export const imageFood = (data: Dish, thumb?: boolean): ImageSource => {
	return imagesFood(data, thumb)?.[0] || require('@FoodListCore/Assets/Images/piatto.jpg');
}

export const backIcon = (navigation: CommonNavigation<Pluto>, action?: () => void): ReactNode => {
	return iconNamed("back-arrow", () => {
		if (action == undefined) {
			navigation.goBack()
		} else {
			action();
		}
	}, 14)
}

export const inlineIcons = (...icons: ReactElement[]): ReactElement => {
	return (
		<View style={{ height: "100%", flexDirection: "row" }}>
			{icons.map((item, index) => {
				if (icons[index].props) {
					icons[index].props.key = index
				}
				let style: ViewStyle = {
					overflow: 'hidden'
				}
				if (index == 0) {
					style.marginRight = -10
				} else if (index == icons.length - 1) {
					style.marginLeft = -10
				} else {
					style.marginLeft = -10
					style.marginRight = -10
				}
				return <View key={index} style={{ overflow: 'hidden' }}>
					<View style={style}>{icons[index]}</View></View>
			})}
		</View>
	)
}

/* export const slideTransitionConfig = (): TransitionEvent | null => {
  if(Platform.OS === "android") {
    return {
      transitionSpec: {
        duration: 750,
        easing: Easing.out(Easing.poly(4)),
        timing: Animated.timing,
        useNativeDriver: true,
      },
      screenInterpolator: sceneProps => {
        const { layout, position, scene } = sceneProps

        const thisSceneIndex = scene.index
        const width = layout.initWidth

        const translateX = position.interpolate({
          inputRange: [thisSceneIndex - 1, thisSceneIndex],
          outputRange: [width, 0],
        })

        return { transform: [ { translateX } ] }
      },
    }
  }
  return null;
} */

export const getDishRestaurant = (dish: Dish | undefined | null): Restaurant | undefined => {
	return dish?.section?.orderings?.[0]?.menu?.restaurant
}

export const formatPrice = (price?: number): string => {
	return coreFormatPrice(price)
}

export const mapById = <T extends { id?: number }>(options: T[]): ItemsMap<T> => {
	return options.reduce((accumulator: ItemsMap<T>, item) => {
		if (item.id) {
			accumulator[item.id?.toString()] = item
		}
		return accumulator
	}, {})
}

export const calculateMeanStar = (item: Review): number => {
	const rating_location = item.rating_location
	const rating_price = item.rating_price
	const rating_quality = item.rating_quality
	const rating_service = item.rating_service
	return (rating_location + rating_price + rating_quality + rating_service) / 4
}

interface NavigationComponent {
	setState: (obj: Any) => void //basta che lo state abbia showingNameTopBar
	state: { showingNameTopBar: boolean } //che è richiesto già qua
	props: { navigation: CommonNavigation<Pluto> }
}

export const nameAppearOnScrollGlobal = (event: NativeSyntheticEvent<NativeScrollEvent> | null = null, that: NavigationComponent, nameToDisplay: string, showingNameTopBar: boolean): void => {
	if ((event?.nativeEvent.contentOffset.y || 0) > 20) {
		if (!showingNameTopBar) {
			that.setState({ showingNameTopBar: true })
			that.props.navigation.setParams({
				headerTitle: nameToDisplay
			})
		}
	} else {
		if (showingNameTopBar) {
			that.setState({ showingNameTopBar: false })
			that.props.navigation.setParams({
				headerTitle: () => null
			})
		}
	}
}

export const deepCopy = <T extends {} | []>(obj: T): T => {
	return JSON.parse(JSON.stringify(obj))
}

export const isDefined = (item: Any): boolean => {
	return item != null && item != undefined
}

export const stringDefined = (item: Any) => {
	return isDefined(item) && typeof item == "string" && item.length > 0
}

export const addhttp = (url: string): string => {
	if (url && !/^(f|ht)tps?:\/\//i.test(url)) {
		url = "http://" + url;
	}
	return url;
}

export const restAddress = (rest: Restaurant): string => {
	const address = rest.city + (rest.address ? (", " + rest.address) : "")
	const house_number = (rest.house_number ? (" " + rest.house_number) : "")
	if(!address.endsWith(house_number)) {
		return address + house_number
	}
	return address
}

export const userImage = (data?: { photos: Photo[] } | Photo | null, thumb?: boolean): ImageSource => {
	if (data) {
		if ('photos' in data && data.photos.length > 0) {
			return {
				uri: thumb ? data.photos[0].thumbUrl : data.photos[0].fullUrl
			}
		} else if (thumb && 'thumbUrl' in data && isDefined(data.thumbUrl)) {
			return { uri: data.thumbUrl }
		} else if ('fullUrl' in data && isDefined(data.fullUrl)) {
			return { uri: data.fullUrl }
		}
	}
	return require('@FoodListCore/Assets/Images/utente.jpg');
}

export const alert = (title: string, content: string): void => {
	Alert.alert(title, (content || "").toString(), [{ text: translate("ok"), onPress: () => { } }])
}

export const error = (content: string) => {
	alert(translate("error"), (content || "").toString())
}

export const confirmExit = (exitCb: () => void, hasContent: boolean, description: string = translate("defaultQuitDesription")): void => {
	if (hasContent) {
		Alert.alert(translate("confirmExitTitle"), description, [{
			text: translate("quit"),
			style: 'destructive',
			onPress: exitCb
		}, {
			text: translate("cancel"),
			onPress: () => { }
		}]);
	} else {
		exitCb()
	}
}

export const getNotificationIdentifier = (notification: Notification) => {
	return notification.type + ":" + notification.id
}