import { CustomConfig } from "foodlist-core/ExampleConfig/types";
import { Platform } from "react-native";

const isWeb = Platform.OS == "web"

const config : CustomConfig = {
	showReviewImages: true,
	hideFavouriteButtons: isWeb,
	hideReviewButtons: isWeb,
	hideRateYourOrder: isWeb,
}

export default config
