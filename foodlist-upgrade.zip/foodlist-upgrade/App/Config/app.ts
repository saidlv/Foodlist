import { ThemeColorsType } from "foodlist-core/ExampleConfig/types"
import { Platform } from "react-native"

export const ThemeColors: ThemeColorsType = {
	lightStatusBar: false,
	primary: '#FF6907',
	secondary: '#212946',
	topBarBackground: "#fff",
	topBarTintColor: "#000",
	bottomBarBackground: "#fff",
	bottomBarActiveTint: "#FF6907",
	bottomBarInactiveTint: "#555",
	pagePadding: 15,

	loginPage: {
		hideLoginWithFoodlist: true,
		logoHeight: 30,
	},
}

export const AppSchema = "foodlist-app-payment"
export const GoogleWebClientId = "455758928490-s3efqhv7j3e7rji33p3c2d00h5rnf310.apps.googleusercontent.com"
export const FacebookClientId = "824583321608673"
export const AppleClientId = "it.servalcode.signin.foodlist"

export const AppData = {
	app_source_prefix: Platform.OS == "web" ? "foodlist-web" : "foodlist-app",//for order notifications
	name: "FoodList-" + Platform.OS,
	restaurants: [],
}
