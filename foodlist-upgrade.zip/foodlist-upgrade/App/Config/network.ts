import { config } from "./env"

const IS_PRODUCTION = config == "production"
export default {
	//base_url: "http://192.168.1.100:3000/",
	"base_url": "https://foodlist.eu/",
	"api_path": IS_PRODUCTION ? "api" : "test-api",
	"stripe_publishable_key": IS_PRODUCTION ? "pk_live_51IH3snKinfpB1fEXSK5Ls195aJyhaqcFEyITxCiVkCgGL8PROh625UxtSdvjfKKtwbq0CVgBKJanMbYQwaRcsXju00MQzYPVFi" : "pk_test_51IH3snKinfpB1fEXdQ6gkY6akAEBOSMIbNrj8sRL0nQpasonh69P4olggD5bn1nIsy8o8DOxbdXlLjdsu5zyB0L700Le3WiLbS",
}