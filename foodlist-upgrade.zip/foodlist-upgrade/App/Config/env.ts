type Config = "production" | "test"
export const config: Config = "production"