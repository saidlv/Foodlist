import AsyncStorage from "@react-native-community/async-storage"
import { setUser } from '@Redux/Actions'
import { store } from '@Redux/Reducer'
import { isDefined } from '@Global/GlobalProps'
import { User } from "@Models/User";
import { ReduxState } from "@Redux/StateFormat";

export default class SessionManager {


	static AUTH_KEY = "foodlist_auth_token";
	static USER_KEY = "foodlist_auth_user";
	static PASS_KEY = "foodlist_auth_password";

	constructor() { }

	static getRouteNameFor(isLogged: boolean): "TabBarPage" | "MainAuthPage" {
		return isLogged ? "TabBarPage" : "MainAuthPage"
	}

	static async saveToken(token: string): Promise<void> {
		try {
			await AsyncStorage.setItem(SessionManager.AUTH_KEY, token);
		} catch (error) {
			// Error saving data
		}
	}

	static async setCurrentPassword(password: string): Promise<void> {
		return await AsyncStorage.setItem(SessionManager.PASS_KEY, password);
	}

	static async setCurrentUser(user: User): Promise<void> {
		var userRaw = JSON.stringify(user);
		this.addUserToRedux(user)
		return await AsyncStorage.setItem(SessionManager.USER_KEY, userRaw);
	}

	static getMockUser() {
		return {
			"id": 2,
			"username": "leomessi",
			"email": "leo@fcbarcelona.es",
			"password": "cab40eee87c81cdaf414045bd2081bf9",
			"first_name": "Lionel Andrés",
			"last_name": "Messi Cuccittini",
			"photo": null,
			"phone": "+34 123456789",
			"date_of_birth": "1987-06-24",
			"gender": "M",
			"points": 0,
			"created_at": "2019-01-06T19:12:06.000Z",
			"updated_at": "2019-01-06T19:12:09.000Z",
			"user_level_id": 1,
			"reviews_count": 2,
			"followers": 1,
			"following": 0
		}
	}

	static async getCurrentUser(): Promise<User | null> {
		let reduxState: ReduxState = store.getState()
		if (isDefined(reduxState.currentUser) && reduxState.currentUser?.id != -1) {
			//console.log("Get current user: redux")
			return reduxState.currentUser ?? null
		} else {
			//console.log("Get current user: storage")
			const user = await AsyncStorage.getItem(SessionManager.USER_KEY);
			if (user == null) {
				this.addUserToRedux(null)
				return null;
			}
			const parsedUser = JSON.parse(user)
			this.addUserToRedux(parsedUser)
			return parsedUser;
		}
	}

	static addUserToRedux = (parsedUser: User | null): void => {
		store.dispatch(setUser(parsedUser))
	}

	static async getCurrentPassword(): Promise<string | null> {
		return await AsyncStorage.getItem(SessionManager.PASS_KEY);
	}

	static async _getToken(): Promise<string | null> {
		return await AsyncStorage.getItem(SessionManager.AUTH_KEY);
	}

	static async logout(): Promise<void> {
		try {
			await AsyncStorage.removeItem(SessionManager.AUTH_KEY);
			await AsyncStorage.removeItem(SessionManager.USER_KEY);
			await AsyncStorage.removeItem(SessionManager.PASS_KEY);
		} catch (error) {
			// Error saving data
		}
	}
}
