import firebase from "react-native-firebase"
import SessionManager from "@Services/SessionManager"
import DeviceInfo from 'react-native-device-info';
import { FeedTypeAnalytics } from "@Models/FeedType";
import { Review } from "@Models/Review";
import { Pippo } from "@Models/Pippo";
import { Platform } from "react-native";
let Analytics = firebase.analytics();
export default class FirebaseAnalytics {

	constructor() { }

	static setScreen(name: string): void {
		Analytics.setCurrentScreen(name)
	}

	static async initUser(): Promise<void> {
		const user = await SessionManager.getCurrentUser();
		Analytics.setAnalyticsCollectionEnabled(true);
		Analytics.setUserId("" + user?.id);
		Analytics.setUserProperty("device_id", DeviceInfo.getUniqueId());
	}

	static deinitUser(): void {
		Analytics.setUserId("-1");
		Analytics.setUserProperty("device_id", DeviceInfo.getUniqueId());
	}

	static setFavourite(id: number, value: boolean, type: FeedTypeAnalytics): void {
		this.log("set_favourite", {
			"type": type,
			"id": id,
			"value": value
		});
	}

	//LINKED
	static websiteClick(id: number, value: string): void {
		this.log("website_click", {
			"id": id,
			"value": value
		});
	}

	//LINKED
	static phoneClick(id: number, value: string): void {
		this.log("phone_click", {
			"id": id,
			"value": value
		});
	}

	//LINKED
	static mailClick(id: number, value: string): void {
		this.log("mail_click", {
			"id": id,
			"value": value
		});
	}

	//LINKED
	static addDishReview(value: Pippo): void {
		this.log("add_dish_review", {
			"value": value
		});
	}

	//LINKED
	static addRestaurantReview(value: Pippo): void {
		this.log("add_restaurant_review", {
			"value": value
		});
	}

	//LINKED
	static logout(): void {
		this.log("logout", {});
		this.deinitUser()
	}

	//LINKED
	static login(username: string | null, email: string | null): void {
		this.log("login", {
			"username": username,
			"email": email
		});
	}

	//LINKED
	static signup(username: string, email: string, phone: string, firstName?: string, lastName?: string, birthDate?: string, gender?: string): void {
		this.log("signup", {
			"username": username,
			"email": email,
			"phone": phone,
			"firstName": firstName,
			"lastName": lastName,
			"birthDate": birthDate,
			"gender": gender
		});
	}

	static writeReviewFailed(type: FeedTypeAnalytics, cause: "ONLY_STARS_INSERTED" | "UNKNOWN"): void {
		this.log("write_review_give_up", {
			"type": type,
			"cause": cause
		});
	}

	static feedCommentPressed(feedItem: Review): void {
		this.log("feed_comment_icon_pressed", {
			"review_id": feedItem.id,
			"type": feedItem.feed_type
		});
	}

	static filterClicked(name: string) {
		this.log("filter_clicked", {
			"name": name
		});
	}

	static feedDishRestaurantPressed(feedItem: Review): void {
		this.log("feed_dish_restaurant_pressed", {
			"review_id": feedItem.id,
			"type": feedItem.feed_type
		});
	}

	static feedDetailPressed(feedItem: Review): void {
		this.log("feed_detail_pressed", {
			"review_id": feedItem.id,
			"type": feedItem.feed_type
		});
	}

	static feedRelatedItemPressed(feedItem: Review): void {
		this.log("feed_related_item_pressed", {
			"review_id": feedItem.id,
			"type": feedItem.feed_type
		});
	}

	//LINKED
	static searchDishes(params: Pippo): void {
		this.log("search_dish", params);
	}

	//LINKED
	static searchUsers(params: Pippo): void {
		this.log("search_user", params);
	}

	//LINKED
	static searchRestaurants(params: Pippo): void {
		this.log("search_restaurant", params);
	}

	static skippedLogin = () => {
		FirebaseAnalytics.log("skipped_login", {
			platform: Platform.OS
		})
	}

	static log(event: string, params: Pippo): void {
		Analytics.logEvent(event, params);
	}

}
