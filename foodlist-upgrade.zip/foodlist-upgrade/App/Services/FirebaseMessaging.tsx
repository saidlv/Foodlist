//import { AsyncStorage, Vibration} from "react-native"
import AsyncStorage from '@react-native-community/async-storage'
import NotificationsManager, { UpsertTokenResponse } from '@FoodListCore/Network/NotificationsManager';
import firebase from "react-native-firebase"
import PushNotification from "react-native-push-notification"


import { NetworkNavigation } from "@Network/NetworkManager"
import NotificationsPageContainer from "@Pages/NotificationsPage";
import { Notification, NotificationOpen } from "react-native-firebase/notifications";
import { RequestResponse } from "@Models/RequestResponse";
import { Pippo } from '@Models/Pippo';

export default class FirebaseMessaging {

	static INSTALLATION_KEY = "foodlist_installation";
	constructor() { }

	static init(): void {

		PushNotification.createChannel({
			channelId: "high-priority",
			channelName: "FoodList",
			channelDescription: "Notifiche di FoodList",
			soundName: "default",
			importance: 4
		}, (created) => {
			console.log("created", created)
		})

		/* const channel = new firebase.notifications.Android.Channel('foodlist-channel', 'Foodlist', firebase.notifications.Android.Importance.Max)
			.setDescription('Foodlist');
		// Create the channel
		firebase.notifications().android.createChannel(channel);
		// Build a channel group
		const channelGroup = new firebase.notifications.Android.ChannelGroup('foodlist-group', 'Foodlist Group');

		// Create the channel group
		firebase.notifications().android.createChannelGroup(channelGroup); */

	}

	static async linkToken(): Promise<void> {
		//console.log("Linking token");
		const enabled = await firebase.messaging().hasPermission();
		if (enabled) {
			await this.getToken();
		} else {
			await this.requestPermission();
		}
	}

	static listenForNotifications(): void {
		this.init();
		//console.log("Listening for notifications...");
		firebase.notifications().onNotification((notification) => {
			const item = this.getBody(notification);
			//console.log("notification", item, notification);

			const notificationBody = {
				title: item.title,
				body: item.body
			}
			if (item != null) {
				//Vibration.vibrate(400);
				NetworkNavigation.notificationRef?.showNotification({
					text: notificationBody,
					onPress: () => {
						if (NetworkNavigation.navigation) {
							NotificationsPageContainer.handleNotificationPress(item, NetworkNavigation.navigation)
						}
					}
				});
			}
		});

		firebase.notifications().onNotificationOpened((notificationOpen) => {
			const item = this.getBody(notificationOpen.notification);
			//console.log('Notification background', item);
			if (item != null && NetworkNavigation.navigation) {
				NotificationsPageContainer.handleNotificationPress(item, NetworkNavigation.navigation)
			}
		});
	}

	static getBody(notification: Notification): Pippo {
		const data = notification?.data?.json;
		return data != null ? JSON.parse(data) : null;
	}

	static getEntryPointNotification(): Promise<NotificationOpen> {
		return firebase.notifications().getInitialNotification();
	}

	static async getToken(): Promise<void> {
		try {
			const fcmToken = await firebase.messaging().getToken();
			//console.log("fcmToken", fcmToken);
			var response = await FirebaseMessaging.persistToken(fcmToken);
			const installation = response?.data?.response;
			if (response.success && installation) {
				//console.log("Installation found", installation);
				await AsyncStorage.setItem(FirebaseMessaging.INSTALLATION_KEY, JSON.stringify(installation));
			}
		} catch (e) {
			//console.log(e)
		}
	}


	//2
	static async requestPermission(): Promise<void> {
		try {
			await firebase.messaging().requestPermission();
			// User has authorised
			this.getToken();
		} catch (error) {
			// User has rejected permissions
			//console.log('permission rejected');
		}
	}

	static async getCurrentInstallation(): Promise<string | null> {
		return AsyncStorage.getItem(FirebaseMessaging.INSTALLATION_KEY);
	}

	static async persistToken(token: string): Promise<RequestResponse<UpsertTokenResponse>> {
		const manager = new NotificationsManager();
		return manager.upsertToken(token);
	}

	static async dropToken(): Promise<void> {
		const manager = new NotificationsManager();
		manager.dropToken().finally(() => {
			AsyncStorage.removeItem(FirebaseMessaging.INSTALLATION_KEY);
		});
	}

}
