import { check, request, PERMISSIONS, RESULTS, Permission, PermissionStatus } from 'react-native-permissions';
import { Platform } from 'react-native';

export const PERMISSION_RESULTS = {
	UNAVAILABLE: RESULTS.UNAVAILABLE,
	DENIED: RESULTS.DENIED,
	GRANTED: RESULTS.GRANTED,
	BLOCKED: RESULTS.BLOCKED,
}

export type AndroidIOSPermission = Permission | undefined
export type AndroidIOSPermissionStatus = PermissionStatus | undefined

const _requestPermission = async (permission: AndroidIOSPermission): Promise<AndroidIOSPermissionStatus> => {
	if (permission) {
		return request(permission);
	}
}

//LOCATION
const LOCATION_PERMISSION: AndroidIOSPermission = Platform.select({
	android: PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
	ios: PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
})

export const getLocationPermission = async (noAsk: boolean): Promise<AndroidIOSPermissionStatus> => {

	if (LOCATION_PERMISSION) {
		let requested: AndroidIOSPermissionStatus = await check(LOCATION_PERMISSION);
		if (requested != PERMISSION_RESULTS.GRANTED && !noAsk) {
			requested = await _requestLocationPermission();
		}
		return requested;
	}
}

const _requestLocationPermission = (): Promise<AndroidIOSPermissionStatus> => {
	return _requestPermission(Platform.select({
		android: PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
		ios: PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
	}));
}
export const requestLocationPermission = _requestLocationPermission;

//CAMERA
const CAMERA_PERMISSION: AndroidIOSPermission = Platform.select({
	android: PERMISSIONS.ANDROID.CAMERA,
	ios: PERMISSIONS.IOS.CAMERA,
})
export const getCameraPermissionStatus = async (): Promise<AndroidIOSPermissionStatus> => {
	if (CAMERA_PERMISSION) {
		let status = await check(CAMERA_PERMISSION);
		return status
	}
}

export const requestCameraPermission = (): Promise<AndroidIOSPermissionStatus> => {
	return _requestPermission(CAMERA_PERMISSION);
}

//LIBRARY
const LIBRARY_PERMISSION: AndroidIOSPermission = Platform.select({
	android: PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE,
	ios: PERMISSIONS.IOS.PHOTO_LIBRARY,
})
export const getLibraryPermissionStatus = async (): Promise<AndroidIOSPermissionStatus> => {
	if (LIBRARY_PERMISSION) {
		let status = await check(LIBRARY_PERMISSION);
		return status
	}
}

export const requestLibraryPermission = () => {
	return _requestPermission(LIBRARY_PERMISSION);
}

//CONTACTS
const CONTACTS_PERMISSION: AndroidIOSPermission = Platform.select({
	android: PERMISSIONS.ANDROID.READ_CONTACTS,
	ios: PERMISSIONS.IOS.CONTACTS
});
export const getContactsPermissionStatus = async (): Promise<AndroidIOSPermissionStatus> => {
	if (CONTACTS_PERMISSION) {
		let result = await check(CONTACTS_PERMISSION);
		return result
	}
}

export const requestContactsPermission = () => {
	return _requestPermission(CONTACTS_PERMISSION);
}


