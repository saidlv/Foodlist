//import { AsyncStorage, Vibration} from "react-native"
import AsyncStorage from '@react-native-community/async-storage'

export default class FirebaseMessaging {

	static INSTALLATION_KEY = "foodlist_installation";
	constructor() { }

	static init(): void {
	}

	static async linkToken(): Promise<void> {}

	static listenForNotifications() {}

	static getBody(notification: any) {
		const data = notification?.data?.json;
		return data != null ? JSON.parse(data) : null;
	}

	static async getEntryPointNotification(): Promise<any> {}

	static async getToken(): Promise<void> {}

	static async requestPermission(): Promise<void> {}

	static async getCurrentInstallation(): Promise<string | null> {
		return AsyncStorage.getItem(FirebaseMessaging.INSTALLATION_KEY);
	}

	static async persistToken(token: string) {}

	static async dropToken(): Promise<void> {}

}
