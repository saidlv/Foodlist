import { Share } from "react-native";
import NetworkManager from "@FoodListCore/Network/NetworkManager";
import { FeedType } from "@Models/FeedType";
import { AuthNavigation } from "@RouteParams/Auth";
import { translate } from "@App/I18n";
import { Pluto } from "@Models/Pluto";

const baseUrl = NetworkManager.BASE_URL + 'share/';
export const shareBaseUrl = baseUrl

export class ShareGlobals {
	static navigator: AuthNavigation<Pluto> | null = null;
}

enum _SHARE_ACTIONS {
	RESTAURANT,
	DISH,
	REVIEW_RESTAURANT,
	REVIEW_DISH,
	USER
}

const _resetToHome = (): void => {
	ShareGlobals.navigator?.reset({
		index: 0,
		routes: [{
			name: "TabBarPage"
		}]
	})
}

export const resetToHome = _resetToHome;

export type DeepLinkingProp = {
	id: string,
	routeName: string,
}

export type DeepLinkingData = {
	id?: number
	user_id?: number,
	data?: DeepLinkingReviewData,
	deepLinking: boolean,
	//onBack?: () => void
}

export type DeepLinkingReviewData = {
	feed_type: FeedType,
	id: number,
	dish?: { id: number },
	restaurant?: { id: number }
}
export const SHARE_ACTIONS = _SHARE_ACTIONS;

type ShareOptions = { id: number | string, text: string }
const _share = (action: _SHARE_ACTIONS, options: ShareOptions): void => {
	let url;
	switch (action) {
		case _SHARE_ACTIONS.RESTAURANT:
			url = baseUrl + 'restaurant/' + options.id;
			break;
		case _SHARE_ACTIONS.DISH:
			url = baseUrl + 'dish/' + options.id;
			break;
		case _SHARE_ACTIONS.REVIEW_RESTAURANT:
			url = baseUrl + 'restaurant_review/' + options.id;
			break;
		case _SHARE_ACTIONS.REVIEW_DISH:
			url = baseUrl + 'dish_review/' + options.id;
			break;
		case _SHARE_ACTIONS.USER:
			url = baseUrl + 'user/' + options.id;
			break;
	}

	let text = (options.text) ? options.text + '\n' : ''

	let shareContent = {
		message: text + url
	};
	let shareOptions = {
		subject: translate("shareSubject")
	};
	Share.share(shareContent, shareOptions);
}

export const share = _share;