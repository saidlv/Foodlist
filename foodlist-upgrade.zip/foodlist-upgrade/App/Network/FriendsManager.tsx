import NetworkManager from '@FoodListCore/Network/NetworkManager';
import { PhoneNumber } from '@Models/PhoneNumber';
import { RequestResponse } from '@Models/RequestResponse';
import { User } from '@Models/User';

type ContactsParam = {
		contacts: PhoneNumber[]
}

export type GetContactFriendsResponse = {
		users: User[]
} | null

export default class FriendsManager extends NetworkManager {
		constructor() {
				super()
		}

		getContactFriends(params: ContactsParam): Promise<RequestResponse<GetContactFriendsResponse>> {
				return super.request("/users/:current_user_id/friends/sync", "POST", params);
		}
}
