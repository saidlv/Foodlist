import NetworkManager, { Meta } from '@FoodListCore/Network/NetworkManager';
import { RequestResponse } from '@Models/RequestResponse';
import { ListParams } from '@Models/ListParams';
import { ReviewType } from '@Models/ReviewType';
import { Restaurant } from '@Models/Restaurant';
import { ItemsMap } from '@Models/ItemsMap';
import { Menu } from '@Models/Menu';
import { Dish } from '@Models/Dish';
import { DishType } from '@Models/DishType';
import { Review } from '@Models/Review';
import { ReviewListResponse } from '@FoodListCore/Network/ReviewManager';

export type GetInfoRestaurantResponse = {
	response: Restaurant,
	meta: Meta
} | null

export type GetMenuRestaurantResponse = {
	response: {
		menus: ItemsMap<Dish[]>
	}
} | null

export type GetDishTypesResponse = {
	dish_types: DishType[]
} | null

export type GetReviewsRestaurantResponse = ReviewListResponse | null

export default class RestaurantManager extends NetworkManager {
	constructor() {
		super()
		//this.imgBasePath = "@testImages"
	}
	/* getImagePath(relPath) {
			return this.imgBasePath + path
	} */
	getInfoRestaurant(id: number): Promise<RequestResponse<GetInfoRestaurantResponse>> {
		//TODO change params /restaurants/:id
		//TODO il menu è in una richiesta a parte, /api/menus/restaurant/:id, intanto cambiare parametri prendendoli da quella richiesta
		//TODO gli orari mi sa che non ci sono ancora
		return super.handleRequest("/restaurants/" + id, "GET", null, { user_id: ":current_user_id", populate: true, compact: true, with_dishes: true });
	}

	getMenuRestaurant(id: number): Promise<RequestResponse<GetMenuRestaurantResponse>> {
		//TODO change params /restaurants/:id
		//TODO il menu è in una richiesta a parte, /api/menus/restaurant/:id, intanto cambiare parametri prendendoli da quella richiesta
		//TODO gli orari mi sa che non ci sono ancora
		return super.request("/menus/restaurant/" + id + "?populate=true", "GET");
	}

	getDishTypes(id: number): Promise<RequestResponse<GetDishTypesResponse>> {
		return super.request("/restaurants/" + id + "/dish_types", "GET")
	}

	getReviewsRestaurant(id: number, params: ListParams, category: ReviewType, rating: string): Promise<RequestResponse<GetReviewsRestaurantResponse>> {
		//TODO change params /restaurants/:id
		//TODO il menu è in una richiesta a parte, /api/menus/restaurant/:id, intanto cambiare parametri prendendoli da quella richiesta
		//TODO gli orari mi sa che non ci sono ancora
		if (category != "all") {
			return super.request("/restaurants/" + id + "/reviews", "GET", null, { populate: true, user_id: ':current_user_id', category: category, rating: rating, ...params });
		} else {
			return super.request("/restaurants/" + id + "/reviews", "GET", null, { populate: true, user_id: ':current_user_id', rating: rating, ...params });
		}
	}
}
