import { AuthNavigation } from '@RouteParams/Auth';
import LocalNotification from '@Components/LocalNotification';
import { Pluto } from '@Models/Pluto';
import NetworkConfig from '@config/network'

/*   Se nel path oppure nel body :current_user_id, viene sostituito col currentUser da AsyncStorage
 *   Risposta delle chiamate:
 *   data: payload json della risposta
 *   status: HTTP status della risposta
 *   success: Booleano che a partire dallo status descrive l'andamento della richiesta
 *   user: se la chiamata è autenticata, ritorna il currentUser che ha fatto la richiesta (da asyncstorage)
 */
export class NetworkNavigation {
	static navigation: AuthNavigation<Pluto> | null = null;
	static notificationRef: LocalNotification | null = null
}

export default class NetworkManager {

	static BASE_URL: string = NetworkConfig.base_url
	BASE_API_URL: string

	constructor() {
		this.BASE_API_URL = NetworkManager.BASE_URL + NetworkConfig.api_path
	}

	reset(): void {
		NetworkNavigation.navigation?.navigate("MainAuthPage");
	}

	static getMinVersions = async () => {
		let response = await fetch(NetworkManager.BASE_URL + 'info/ws.json');
		response = await response.json();
		return response;
	}
}
