import NetworkManager from '@FoodListCore/Network/NetworkManager';
import { RequestResponse } from '@Models/RequestResponse';
import { DishType } from '@Models/DishType';
import { FoodPreference } from '@Models/FoodPreference';
import { Occasion } from '@Models/Occasion';
import { PaymentMethod } from '@Models/PaymentMethod';
import { PrintableItem } from '@Models/PrintableItem';

export type GetDishTypesResponse = {
	dish_types: DishType[]
} | null

export type GetFoodPreferencesResponse = {
	response: FoodPreference[]
} | null

export type PrintableItemResponse = {
	response: PrintableItem[]
} | null

export type GetOccasionsResponse = {
	response: Occasion[]
} | null

export type GetPaymentMethodsResponse = {
	response: PaymentMethod[]
} | null

export default class GlobalManager extends NetworkManager {

	constructor() {
		super()
	}

	getDishTypes(): Promise<RequestResponse<GetDishTypesResponse>> {
		return super.request("/dish-types", "GET")
	}
	getRestaurantCategories(): Promise<RequestResponse<PrintableItemResponse>> {
		return super.request("/restaurant-categories", "GET", null, { no_ethnic: true })
	}
	/* getDishCategories(): Promise<RequestResponse> {
		return super.request("/dish-categories", "GET")
	} */
	/* getDishRestrictions(): Promise<RequestResponse> {
		return super.request("/dish-restrictions", "GET")
	} */
	getFoodPreferences(): Promise<RequestResponse<GetFoodPreferencesResponse>> {
		return super.request("/food-preferences", "GET")
	}
	getOccasions(): Promise<RequestResponse<GetOccasionsResponse>> {
		return super.request("/occasions", "GET")
	}
	/* getStyles(): Promise<RequestResponse> {
		return super.request("/styles", "GET")
	} */
	getPaymentMethods(): Promise<RequestResponse<GetPaymentMethodsResponse>> {
		return super.request("/payment-methods", "GET")
	}
}
