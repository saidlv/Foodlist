import NetworkManager, { clearEmptyParams, GenericParams } from '@FoodListCore/Network/NetworkManager';
//import FirebaseAnalytics from "@Services/FirebaseAnalytics"
import { RestaurantFiltersFormat, DishFilterFormat, RestaurantInitialValues, DishInitialValues } from '@Redux/StateFormat/FiltersFormat';
import { ListParams } from '@Models/ListParams';
import { RequestResponse } from '@Models/RequestResponse';
import { User } from '@Models/User';
import { Dish } from '@Models/Dish';
import { Restaurant } from '@Models/Restaurant';
import { City } from '@Models/City';
import { DishCategory, RestaurantCategory } from '@Models/Category';
import { Any } from '@Models/Any';
import { getCurrentUser } from '@FoodListCore/Redux/ReduxHelper';
import { UserAddress } from '@Models/UserAddress';

type KeyType = keyof RestaurantInitialValues | keyof DishInitialValues

export const IgnoreResponse = {
	status: 200,
	success: true,
	data: {
		ignore: true,
		response: undefined
	},
}

class FilterParams<Values extends RestaurantInitialValues | DishInitialValues, Filters extends RestaurantFiltersFormat | DishFilterFormat> {
  /* filters: FilterParamsModel
  params: ApiFilters */
	filters: Values /* (RestaurantInitialValues | DishInitialValues) & {
		[index: string]: Any //TODO: find better way
	} */
	params: GenericParams

	constructor(filters: Values) {
		this.filters = filters
		this.params = {}
	}

	addCommon(_filters: Filters, km?: number) {
		let values = this.filters
		let _params = this

		let orderBy = "distance"
		let orderByValue = values.orderBy
		if (orderByValue == 0) {
			orderBy = "popularity"
		} else if (orderByValue == 1) {
			orderBy = "reviews_rating"
		}
		this.params["order_by"] = orderBy

		if (values.maxPrice != _filters.MAX_PRICE) {
			_params.addParam("maxPrice", "max_price")
		}
		if (km || values.maxSearchRadius != _filters.MAX_SEARCH_RADIUS) {
			let distance = values.maxSearchRadius
			if (km && distance !== undefined) {
				distance = Math.min(km, distance)
			}
			this.params["distance"] = distance
		}
		if (values.minRating != 0) {
			_params.addParam("minRating", "min_rating")
		}
	}

	addBoolParam(key: keyof Values, apiKey: string) {
		if (key in this.filters && this.filters[key]) {
			this.params[apiKey] = 1
		}
	}

	addParam(key: keyof Values, apiKey: string) {
		if (key in this.filters) {
			this.params[apiKey] = this.filters[key]
		}
	}

	addIds(key: keyof Values, apiKey: string) {
		let array = this.filters[key]
		if (Array.isArray(array) && array.length > 0) {
			this.params[apiKey] = array.map((item: Any) => item.id || item).join(",")
		}
	}

	getParams() {
		return this.params
	}
}

export type SearchCityResponse = {
	response?: City[]
} | null

export type SearchUserResponse = {
	response?: User[]
} | null

export type SearchDishResponse = {
	response?: Dish[]
} | null

export type SearchRestaurantResponse = {
	response?: Restaurant[]
	reverse_geocoded_address?: UserAddress
} | null

export type SearchDishCategoriesResponse = {
	response?: DishCategory[]
} | null

export type SearchRestaurantCategoriesResponse = {
	response?: RestaurantCategory[]
} | null
export type SearchCategoryResponse = SearchDishCategoriesResponse | SearchRestaurantCategoriesResponse

export type SearchRequest<T> = (search: string, loadMoreParams: ListParams) => Promise<RequestResponse<T>>

export default class SearchManager extends NetworkManager {
	constructor() {
		super()
		//this.imgBasePath = "@testImages"
	}

	getDishes(latitude: number, longitude: number, filters: { filters: DishFilterFormat, searchText?: string }, loadMoreParams?: ListParams): Promise<RequestResponse<SearchDishResponse>> {
		let params: GenericParams = {}
		if (filters?.filters) {
			let _filters = filters.filters
			let values = _filters.values
			let _params = new FilterParams(values)

			_params.addCommon(_filters)

			//TODO: verificare come li mette Giovanni
			_params.addIds("categories", "categories")
			_params.addIds("restrictions", "restrictions")
			_params.addIds("preferenze", "food_preferences")

			params = _params.getParams()
		}

		params.latitude = latitude
		params.longitude = longitude
		params.name = filters?.searchText || ""
		params.populate = true
		params = {
			...params,
			...loadMoreParams,
		}

		//console.log("Get dishes request", params)
		//TODO change params /dishes
		//sulla lista della ricerca nella tab dei piatti
		//FirebaseAnalytics.searchDishes(params);
		return super.request("/search/dishes" + this._getRequestQuery(params), "GET")
	}
	getUsers = (name: string, loadMoreParams?: ListParams): Promise<RequestResponse<SearchUserResponse>> => {
		let params = {
			name: name || "",
			populate: true,
			user_id: ":current_user_id",
			...loadMoreParams,
		}
		//FirebaseAnalytics.searchUsers(params);
		return super.request("/search/users" + this._getRequestQuery(params), "GET")
	}
	getAutocomplete<T>(endpoint: string, search: string, params: ListParams & { search?: string } = {}): Promise<RequestResponse<T | null>> {
		params.search = search
		return super.request("/autocomplete/" + endpoint + this._getRequestQuery(params), "GET")
	}
	getCities = (search: string, params: ListParams): Promise<RequestResponse<SearchCityResponse>> => {
		return this.getAutocomplete<SearchCityResponse>("places", search, params)
	}

	getRestCategories = (search: string, params: ListParams): Promise<RequestResponse<SearchRestaurantCategoriesResponse>> => {
		return this.getAutocomplete("categories/restaurants", search, params)
	}

	getDishCategories = (search: string, params: ListParams): Promise<RequestResponse<SearchDishCategoriesResponse>> => {
		return this.getAutocomplete("categories/dishes", search, params)
	}

	searchDishes = (params: { user_address_id?: number, user_address_full?: string, name?: string, latitude?: number, longitude?: number }, loadMoreParams?: ListParams, filters?: object) => {
		const queryParams = clearEmptyParams({
			...params,
			...loadMoreParams,
			user_id: getCurrentUser()?.id,
			...filters,
		})
		return super.request<SearchDishResponse>("/search/dishes" + this._getRequestQuery(queryParams), "GET")
	}

	getPlaces(latitude: number, longitude: number, filters: { maxDistance?: number, searchText?: string, filters: RestaurantFiltersFormat }, loadMoreParams?: ListParams): Promise<RequestResponse<SearchRestaurantResponse>> {
		let params: GenericParams = {}
		if (filters?.filters) {
			let _filters = filters.filters
			let values = _filters.values
			//console.log("Filter places", values)
			let _params = new FilterParams(values)
			for(const index in _filters.optionKeys) {
				_params.addBoolParam(_filters.optionKeys[index], _filters.infoKeys[index])
			}

			_params.addCommon(_filters, filters?.maxDistance)

			//TODO: capire come vanno messi
			//_params.addIds("categories", "")
			//_params.addIds("", "dish_types")
			_params.addIds("categories", "categories")
			_params.addIds("restrictions", "restrictions")
			_params.addIds("occasions", "occasions")
			_params.addIds("styles", "styles")

			params = _params.getParams()
			//console.warn(params)
		}

		params.latitude = latitude
		params.longitude = longitude
		params.name = filters?.searchText || ""

		params = {
			...params,
			...loadMoreParams,
		}
		//FirebaseAnalytics.searchRestaurants(params);
		//TODO change params /restaurants
		//sulla mappa e nella lista della ricerca sulla tab dei ristoranti (ora non c'è niente perchè devo ancora sistemare)
		return super.request<SearchRestaurantResponse>("/search/restaurants" + this._getRequestQuery(params), "GET").then((body) => {
			//console.log("Search places", body)
			return body
		})
	}
}
