import NetworkManager from '@FoodListCore/Network/NetworkManager';
import { ListParams } from '@Models/ListParams';
import { RequestResponse } from '@Models/RequestResponse';
import { Review } from '@Models/Review';
import { ReviewListResponse } from '@FoodListCore/Network/ReviewManager';


export type GetFeedListResponse = ReviewListResponse | null

export default class FeedManager extends NetworkManager {

		//imgBasePath: string

		constructor() {
				super()
				//this.imgBasePath = "@testImages"
		}

		/* getImagePath(relPath) {
				return this.imgBasePath + path
		} */
		
		getList(params?: ListParams, position?: { latitude: number, longitude: number, distance?: number }): Promise<RequestResponse<GetFeedListResponse>> {
			const query = {
				...params,
				user_id: ":current_user_id",
				...position,
			}
			return super.handleRequest("/feed", "GET", null, query);
		}
}
