import NetworkManager, { StatusOnlyResponse } from '@FoodListCore/Network/NetworkManager';
import { FeedType, FeedTypePrefix } from '@Models/FeedType';
import { RequestResponse } from '@Models/RequestResponse';
import { Review } from '@Models/Review';
import { ReviewToLoad } from '@Models/ReviewToLoad';
import { Like } from '@Models/Like';
import { Comment } from '@Models/Comment';
import { ReviewResponse } from '@FoodListCore/Network/ReviewManager';

export type PressLikeResponse = {
	response: Like | { status: string }
} | null

export type CommentResponse = {
	response: Comment
} | null

export type DeleteCommentResponse = StatusOnlyResponse | null

export type GetInfoReviewDetailResponse = ReviewResponse | null
export type GetInfoReviewDetailOnlyIdResponse = ReviewResponse | null

export default class ReviewDetailManager extends NetworkManager {
	constructor() {
		super()
		//this.imgBasePath = "@testImages"
	}
	/* getImagePath(relPath) {
			return this.imgBasePath + path
	} */

	pressLike(id: number, review_id: number, feedType: FeedType, liked: boolean, likeId?: number): Promise<RequestResponse<PressLikeResponse>> {
		const prefix = feedType == "DISH" ? "dishes" : "restaurants";
		return this._handleLike(prefix, id, review_id, liked, likeId);
	}
	_handleLike(prefix: FeedTypePrefix, id: number, review_id: number, liked: boolean, likeId?: number): Promise<RequestResponse<PressLikeResponse>> {
		const baseUrl = "/" + prefix + "/" + id + "/reviews/" + review_id + "/likes";
		const method = liked ? "POST" : "DELETE";
		const url = liked ? baseUrl : baseUrl + "/" + likeId;
		return super.handleRequest(url, method, { user_id: ":current_user_id" })
	}
	static isRestaurant(review: Review | ReviewToLoad): boolean {
		return (review.feed_type == "RESTAURANT");
	}

	getItemIdForReview(review: Review | ReviewToLoad): number | undefined {
		return ReviewDetailManager.isRestaurant(review) ? review.restaurant?.id : review.dish?.id;
	}

	getPathForReview(review: Review | ReviewToLoad): FeedTypePrefix {
		return ReviewDetailManager.isRestaurant(review) ? "restaurants" : "dishes";
	}

	comment(review: Review, content: string): Promise<RequestResponse<CommentResponse>> {
		const id = this.getItemIdForReview(review);
		const type = this.getPathForReview(review);
		return super.request("/" + type + "/" + id + "/reviews/" + review.id + "/comments", "POST", { content: content, user_id: ":current_user_id" });
	}

	deleteComment(type: FeedTypePrefix, id: number, reviewId: number, commentId: number): Promise<RequestResponse<DeleteCommentResponse>> {
		return super.request("/" + type + "/" + id + "/reviews/" + reviewId + "/comments/" + commentId, "DELETE");
	}

	// review = {restaurant: {id: x}, dish: {id: x}, feed_type: ("RESTAURANT"/"DISH")}
	getInfoReviewDetail(review: Review | ReviewToLoad): Promise<RequestResponse<GetInfoReviewDetailResponse>> {
		const id = this.getItemIdForReview(review);
		const type = this.getPathForReview(review);
		return super.request("/" + type + "/" + id + "/reviews/" + review.id + "?populate=true&user_id=:current_user_id", "GET");
	}

	getInfoReviewDetailOnlyId(type: FeedTypePrefix, restaurantId: number, reviewId: number): Promise<RequestResponse<GetInfoReviewDetailOnlyIdResponse>> {
		return super.request("/" + type + "/" + restaurantId + "/reviews/" + reviewId + "?populate=true&user_id=:current_user_id", "GET");
	}

}
