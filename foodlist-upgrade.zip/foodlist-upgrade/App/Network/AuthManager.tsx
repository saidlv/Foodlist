import NetworkManager, { StatusOnlyResponse } from '@FoodListCore/Network/NetworkManager';
import SessionManager from "@Services/SessionManager"
//import FirebaseAnalytics from "@Services/FirebaseAnalytics"
import { RequestResponse } from '@Models/RequestResponse';
import { User } from '@Models/User';
import { Restaurant } from '@Models/Restaurant';
import { Pippo } from '@Models/Pippo';

export type LoginResponse = {
	response: User & { token: string },
	associated_restaurants: Restaurant[],
	error_code: string
} | null

export type RequestTokenResponse = {
	response: {
		token: string,
		expires_in: string,
		isAdmin: boolean
	}
} | null

export type ResetPasswordResponse = StatusOnlyResponse | null

export default class AuthManager extends NetworkManager {

	constructor() {
		super()
	}

	login = async (username: string | null, email: string | null, password: string): Promise<RequestResponse<LoginResponse>> => {
		//FirebaseAnalytics.login(username, email);
		let response = await super.request<LoginResponse>("/auth/login", "POST", {
			"username": username,
			"password": password,
			"email": email
		})
		//console.log(response);
		return response;
	}

	async loginWithToken(username: string | null, email: string | null, password: string): Promise<void> {
		var output_username;

		let response = await this.login(username, email, password)
		if (response.success) {
			const user = response.data?.response;
			output_username = user?.username;
			await Promise.all([SessionManager.setCurrentPassword(password), SessionManager.setCurrentUser(user!)]);
		} else {
			throw new Error(response.data?.error_code);
		}

		let requestTokenresponse = await this.requestToken(output_username!, password);
		await SessionManager.saveToken(requestTokenresponse.data!.response.token);

	}

	requestToken(username: string, password: string): Promise<RequestResponse<RequestTokenResponse>> {
		return super.request<RequestTokenResponse>("/token/request", "POST", {
			"username": username,
			"password": password
		});
	}

	resetPassword = (username: string | null, email: string | null): Promise<RequestResponse<ResetPasswordResponse>> => {
		return super.request<ResetPasswordResponse>("/auth/reset-password", "POST", {
			"username": username,
			"email": email
		})
	}

	async verifyCode(username: string, password: string, countryCode: string, phone: string, verificationCode: string): Promise<void> {
		//const scope = this;
		let response = await super.request("/auth/verify-code", "POST", {
			"country_code": countryCode,
			"phone": phone,
			"verification_code": verificationCode
		})

		let requestTokenResponse
		if (response.success) {
			requestTokenResponse = await this.requestToken(username, password);
		} else {
			throw new Error(response.error);
		}

		await SessionManager.saveToken(requestTokenResponse.data?.response.token!);

	}

	_register(username: string, email: string, password: string, countryCode: string, phone: string, firstName?: string, lastName?: string, birthDate?: string, gender?: string | number | null): Promise<RequestResponse<Pippo>> {
		return super.request("/users", "POST", {
			"username": username,
			"email": email,
			"password": password,
			"country_code": countryCode,
			"phone": phone,
			"first_name": firstName,
			"last_name": lastName,
			"date_of_birth": birthDate,
			"gender": gender
		});
	}

	async register(username: string, email: string, password: string, countryCode: string, phone: string, firstName?: string, lastName?: string, birthDate?: string, gender?: string): Promise<RequestResponse<Pippo>> {
		//FirebaseAnalytics.signup(username, email, phone, firstName, lastName, birthDate, gender);

		let response = await this._register(username, email, password, countryCode, phone, firstName, lastName, birthDate, gender)
		if (response.success) {
			const user = response.data.response;
			await Promise.all([new Promise((resolve, reject) => { resolve(response) }), SessionManager.setCurrentPassword(password), SessionManager.setCurrentUser(user)]);
			return response;
		} else {
			throw new Error(response.data.error_code);
		}

		/* return this._register(username, email, password, countryCode, phone, firstName, lastName, birthDate, gender)
						.then((response) => {
							if(response.success) {
								const user = response.data.response;
								return Promise.all([new Promise((resolve, reject) => {resolve(response)}), SessionManager.setCurrentPassword(password), SessionManager.setCurrentUser(user)]);
							} else {
								var error = new Error(response.data.error_code);
								error.code = response.data.meta.basic_info_error
								throw error;
							}
					}) */
	}

	requestCode(countryCode: string, phone: string, locale: string): Promise<RequestResponse<Pippo>> {
		return super.request("/auth/request-code", "POST", {
			"country_code": countryCode,
			"phone": phone,
			"locale": locale
		});
	}
}
