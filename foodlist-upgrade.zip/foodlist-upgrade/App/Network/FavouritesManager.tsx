import NetworkManager, { StatusOnlyResponse } from '@FoodListCore/Network/NetworkManager';
import FirebaseAnalytics from "@Services/FirebaseAnalytics"
import { RequestResponse } from '@Models/RequestResponse';
import { Favourite } from '@Models/Favourite';

export type GetDishesResponse = {
	response: Favourite[]
} | null

export type GetRestaurantsResponse = {
	response: Favourite[]
} | null

export type HandleFavouriteResponse = { //Se si aggiunge un preferito ritorna il preferito, sennò una string (status: "SUCCESS")
	response: Favourite
} | StatusOnlyResponse | null

export default class FavouritesManager extends NetworkManager {

	constructor() {
		super()
	}
	getDishes(): Promise<RequestResponse<GetDishesResponse>> {
		return super.request("/favourites/user/:current_user_id/dishes?populate=true", "GET")
	}

	handleFavourite(isRestaurant: boolean, id: number, isFavourite: boolean): Promise<RequestResponse<HandleFavouriteResponse>> {
		FirebaseAnalytics.setFavourite(id, isFavourite, isRestaurant ? "restaurant" : "dish");
		return isRestaurant ? this.handleRestaurant(id, isFavourite) : this.handleDish(id, isFavourite);
	}

	handleRestaurant(id: number, isFavourite: boolean): Promise<RequestResponse<HandleFavouriteResponse>> {
		const method = isFavourite ? "POST" : "DELETE";
		return super.request("/favourites/user/:current_user_id/restaurants", method, {restaurant_id: id}, {restaurant_id: id});
	}
	handleDish(id: number, isFavourite: boolean): Promise<RequestResponse<HandleFavouriteResponse>> {
		const method = isFavourite ? "POST" : "DELETE";
		return super.request("/favourites/user/:current_user_id/dishes", method, {dish_id: id}, {dish_id: id});
	}

	getRestaurants(): Promise<RequestResponse<GetRestaurantsResponse>> {
		return super.handleRequest("/favourites/user/:current_user_id/restaurants", "GET")
	}
}
