import NetworkManager, { MultipartField, StatusOnlyResponse } from '@FoodListCore/Network/NetworkManager';
import { Restaurant } from '@Models/Restaurant';
import { RequestResponse } from '@Models/RequestResponse';
import { Dish } from '@Models/Dish';
import { Review, SuggestReview } from '@Models/Review';

export type SuggestResponse = StatusOnlyResponse | null

export type NewDishReviewResponse = {
	status: string,
	review: Review,
	dish: Dish
}

export default class SuggestManager extends NetworkManager {

	constructor() {
		super()
	}

	restaurantSuggest = (body: Partial<Restaurant>): Promise<RequestResponse<SuggestResponse>> => {
		let url = '/restaurants/suggest/' + body.id + '?user_id=:current_user_id';
		//console.log(url);
		return super.request(url, 'PUT', body);
	}

	dishSuggest = (body: Partial<Dish>): Promise<RequestResponse<SuggestResponse>> => {
		let url = '/dishes/suggest/' + body.id + '?user_id=:current_user_id';
		//console.log(url);
		return super.request(url, 'PUT', body);
	}

	newDishReview = async (body: SuggestReview): Promise<RequestResponse<NewDishReviewResponse>> => {
		//console.log("New dish review")
		let url = '/dishes/suggest_review?user_id=:current_user_id';
		let fields: MultipartField[] = [
			{ name: 'name', data: body.dishName },
			{ name: 'dish_type', data: body.category },
			{ name: 'price', data: body.price },
			{ name: 'rating', data: body.rating_quality.toString() },
			{ name: 'price_rating', data: body.rating_price.toString() },
			{ name: 'content', data: body.content },
			{ name: 'restaurant_id', data: body.restaurant_id.toString() }
		]
		//console.log('prima di photo', fields)
		if (body.photo != null && body.photo != undefined) {
			let photo = super.parseFile("photo", body.photo)
			//body.photo.name = body.photo.fileName;
			fields.push(photo);
		}
		//console.log('fields', fields)
		return super.multipart(url, "PUT", fields);
	}

  /* handleFavourite(isRestaurant, id, isFavourite) {
    FirebaseAnalytics.setFavourite(id, isFavourite, isRestaurant ? "restaurant" : "dish");
    return isRestaurant ? this.handleRestaurant(id, isFavourite) : this.handleDish(id, isFavourite);
  }
  handleRestaurant(id, isFavourite) {
    const method = isFavourite ? "POST" : "DELETE";
    return super.request("/favourites/user/:current_user_id/restaurants", method, {restaurant_id: id}, {restaurant_id: id});
  }
  handleDish(id, isFavourite) {
    const method = isFavourite ? "POST" : "DELETE";
    return super.request("/favourites/user/:current_user_id/dishes", method, {dish_id: id}, {dish_id: id});
  }
  getRestaurants() {
    return super.request("/favourites/user/:current_user_id/restaurants", "GET")
  } */
}
