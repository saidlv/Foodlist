import NetworkManager, { showAll, StatusOnlyResponse, GenericParams } from '@FoodListCore/Network/NetworkManager';
import { RequestResponse } from '@Models/RequestResponse';
import { ImageForMultipart } from '@Models/ImageForMultipart';
import { ListParams } from '@Models/ListParams';
import { User } from '@Models/User';
import { Follow } from '@Models/Follow';
import { Review } from '@Models/Review';
import { ReviewType } from '@Models/ReviewType';

export type EditUserResponse = {
	response: User
} | null

export type FollowResponse = {
	response: Follow
} | null

export type UnfollowResponse = StatusOnlyResponse | null
export type DropPhotoResponse = StatusOnlyResponse | null

export type GetReviewsResponse = {
	response: {
		restaurants: Review[],
		dishes: Review[],
	}
} | null

export type GetInfoProfileResponse = {
	response: User
} | null

export type GetProfileAndReviewsResponse = [GetReviewsResponse, GetInfoProfileResponse] | null

export type FollowListResponse = {
	response: Follow[]
} | null

export default class UserManager extends NetworkManager {
	constructor() {
		super()
	}

	edit = (id: number, params: GenericParams): Promise<RequestResponse<EditUserResponse>> => {
		return super.request("/users/" + id, "PUT", params, null, ["gender", "first_name", "last_name"]);
	}

	follow = (id: number): Promise<RequestResponse<FollowResponse>> => {
		return this.handleFollow(id, true);
	}

	unfollow = (id: number): Promise<RequestResponse<UnfollowResponse>> => {
		return this.handleFollow(id, false);
	}

	handleFollow = <T extends {}>(user_id: number, following: boolean): Promise<RequestResponse<T | null>> => {
		const method = following ? "POST" : "DELETE";
		return super.request("/followers/user/" + user_id, method, { "follower_id": ":current_user_id" }, { "follower_id": ":current_user_id" });
	}

	uploadPhoto = (source: ImageForMultipart): Promise<RequestResponse<EditUserResponse>> => {
		const fields = [
			super.parseFile('file', source),
		]
		//console.log('file', fields, source)
		return super.multipart("/uploads/users/:current_user_id", "POST", fields);
	}

	dropPhoto = (): Promise<RequestResponse<DropPhotoResponse>> => {
		return super.handleRequest("/uploads/users/:current_user_id", "DELETE");
	}

	getReviews = (id: number, params: ListParams, type: ReviewType, rating: string): Promise<RequestResponse<GetReviewsResponse>> => {
		//TODO: waiting for giovanni
		return super.handleRequest('/users/' + id + '/reviews', "GET", null, { populate: true, user_id: ':current_user_id', type: type, rating: rating, ...params })
	}

	getInfoProfile = (id: number): Promise<RequestResponse<GetInfoProfileResponse>> => {
		//console.log("Profile get", id)
		return super.handleRequest("/users/" + id, "GET", null, showAll)
	}

	getProfileAndReviews = async (id: number, type: ReviewType, rating: string): Promise<RequestResponse<GetProfileAndReviewsResponse>> => {
		let reviews = await this.getReviews(id, { limit: 6, offset: 0 }, type, rating);
		let infoProfile = await this.getInfoProfile(id);
		return {
			data: [reviews.data, infoProfile.data],
			status: Math.max(reviews.status, infoProfile.status),
			success: reviews.success && infoProfile.success,
			user: reviews.user,
			error: reviews.error || infoProfile.error,
		}
		//return Promise.all([this.getReviews(id, {limit: 6, offset: 0}, type, rating), this.getInfoProfile(id)])
	}

	getFollowers = (id: number, params: ListParams): Promise<RequestResponse<FollowListResponse>> => {
		return super.handleRequest('/followers/user/' + id, "GET", null, { populate: true, user_id: ':current_user_id', ...params })
	}
	getFollowing = (id: number, params: ListParams): Promise<RequestResponse<FollowListResponse>> => {
		return super.handleRequest('/following/user/' + id, "GET", null, { populate: true, user_id: ':current_user_id', ...params })
	}
}
