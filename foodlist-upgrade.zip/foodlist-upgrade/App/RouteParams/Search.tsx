import { StackNavigationProp } from "@react-navigation/stack"
import { RouteProp } from "@react-navigation/native"
import { CommonParamList, StateRoute } from "./Common"
import { City } from "@Models/City"
import { Restaurant } from "@Models/Restaurant"
import { Region } from "@FoodListCore/Global/CommonStuff/CommonFunctions"

export type SearchParamList = {
	MapPage: {
		city?: City
	} | undefined
	SearchLocationPage: {
		citySelected: (city: City) => void
		currentPositionSelected: () => void
		lastPosition: Region | undefined
	}
	SearchPage: {
		searchPosition?: City | null
		selectRestaurant?: boolean
		title?: string
		showUsers?: boolean
		showOrderOnline?: boolean
		showBookings?: boolean
		onItemSelected?: (item?: Restaurant) => void
	} | undefined
	DishFilterPage: {
		blockSwipe?: boolean
		handleReset?: () => void
	} | undefined
	RestaurantFilter: {
		hideOrderOnline?: boolean
		hideBookings?: boolean
		blockSwipe?: boolean
		handleReset?: () => void
	} | undefined
	PickLocation: {
		defaultPosition?: {
			latitude: number,
			longitude: number
		}
	}
} & CommonParamList

export type SearchNavigation<T extends keyof SearchParamList> = StackNavigationProp<SearchParamList, T>
export type SearchRoute<T extends keyof SearchParamList> = RouteProp<SearchParamList, T>
export type SearchStateRoute<Key extends keyof SearchParamList> = StateRoute<SearchParamList, Key>