import { Coupon } from "@Models/Coupon";

export type PointsStackParams = {
	Points: {} | undefined,
	MyCoupons: {} | undefined,
	AddCoupon: {
		available_coupons: Coupon[],
		points: number
	},
	HowToEarnPoints: {} | undefined,
}