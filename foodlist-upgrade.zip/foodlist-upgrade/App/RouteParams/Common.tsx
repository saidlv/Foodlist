import { StackNavigationProp } from "@react-navigation/stack"
import { RouteProp } from "@react-navigation/native"
import { ReviewToLoad } from "@Models/ReviewToLoad"
import { Review } from "@Models/Review"
import { Like } from "@Models/Like"
import { User } from "@Models/User"
import { Restaurant } from "@Models/Restaurant"
import { Address } from "@Models/Address"
import { DishOrRestaurant } from "@Models/DishOrRestaurant"
import { Day } from "@Models/Day"
import { ReviewsListLoadMoreParams } from "@Pages/ReviewsListLoadMore"
import { PrintableItem } from "@Models/PrintableItem"
import { Dish } from "@Models/Dish"
import { NewDish } from "@Models/NewDish"
import { ParamList } from "@FoodListCore/Flows/Restaurant/params"
import { UserAddress } from "@Models/UserAddress"
import { Location } from "@Models/Location"
import { ReviewMode } from "@App/Pages/Review/FastReview/view"

export type CommonParamList = {
	NewSearch: {
		selectRestaurant?: boolean,
		onItemSelected?: (item: Restaurant) => void,
		onDishSelected?: (dish: Dish, restaurant: Restaurant) => void

		latitude?: number
		longitude?: number
		full_address?: string
		address_id?: number
		mode?: "delivery" | "takeaway"
		from_map?: string
		/* address_id?: number,
		address_full?: string,
		for_date?: string
		mode?: "delivery" | "takeaway" | "booking"
		address?: UserAddress | null
		position?: Location */
	} | undefined,
	NewRestaurant: {
		id: number
		restaurant?: Restaurant
	}
	ProfilePage: {
		user_id?: number
		onBack?: () => void
		headerTitle?: string
		deepLinking?: boolean
		userToShare?: User
	} | undefined
	EditProfile: {
		isAfterRegistration?: boolean
	} | undefined
	ReviewDetail: {
		onBack?: () => void
		deepLinking?: boolean
		callbackUpdateData?: (data?: Review) => void
		data: ReviewToLoad | Review
		disableUserPress?: boolean
		callbackShouldReload?: (del?: boolean) => void
	}
	Notifications: {} | undefined
	UserListPage: {
		data?: Like[]
		followers_count?: number
		following_count?: number
		id?: number
		followers?: boolean
		likes?: boolean
		isCurrentUser?: boolean
	}
	ImproveProfile: DishOrRestaurant
	ImproveAddress: {
		data: Address
	}
	InsertTimes: {
		data: Day[]
	}
	FastReview: {
		callbackShouldReload?: () => void
		restaurant?: Restaurant
		dish?: Dish
		reviewMode: ReviewMode
		/** changes title */
		isEdit?: boolean
		edit_review?: Review
	} | undefined
	ReviewsListLoadMorePage: {
		listParams: ReviewsListLoadMoreParams
	}
	FilterOptionPage: {
		title?: string
		isCategories?: boolean
		isDish?: boolean
		options?: PrintableItem[]
		selections?: PrintableItem[]
		onItemChanged?: (item: PrintableItem[]) => void
	}
	SelectDish: {
		onDishSelected: (item: Dish) => void
		onNewDishSelected: (item: NewDish) => void
		restaurant_id?: number
	}
	SuggestContacts: {
		isAfterRegistration?: boolean
	} | undefined
	NotificationOrderDetail: {
		order_id: number
		onBack?: () => void
	}
	NotificationBookingDetail: {
		booking_id: number
	}
} & ParamList

export type StateRoute<ParamList, PageKey extends keyof ParamList> = {
	name: PageKey,
	params: ParamList[PageKey]
}

export type CommonNavigation<T extends keyof CommonParamList> = StackNavigationProp<CommonParamList, T>
export type CommonRoute<T extends keyof CommonParamList> = RouteProp<CommonParamList, T>
export type CommonStateRoute<T extends keyof CommonParamList> = StateRoute<CommonParamList, T>
