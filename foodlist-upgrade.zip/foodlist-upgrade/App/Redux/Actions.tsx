import { User } from "@Models/User"
import { Notification } from "@Models/Notification"
import { FoodPreference } from "@Models/FoodPreference"
import { Occasion } from "@Models/Occasion"
import { PaymentMethod } from "@Models/PaymentMethod"
import { DishRestriction } from "@Models/DishRestriction"
import { RestaurantStyle } from "@Models/RestaurantStyle"
import { Any } from "@Models/Any"
import { RestaurantCategory } from "@Models/Category"

export type ReduxAction = {
	type: string,
	value?: Any,
	list?: Any[],
	item?: Any,
	user?: User | null,
	notification?: Notification,
	notifications?: Notification[],
	notificationId?: string,
	notificationIds?: string[],
}

export const setUser = (user: User | null): ReduxAction => {
	return {
		type: "user",
		user: user
	}
}

export const setNotifications = (list: Notification[]): ReduxAction => {
	return {
		type: "notifications",
		list: list
	}
}
export const addNotification = (item: Notification): ReduxAction => {
	return {
		type: "add_notification",
		item: item
	}
}
export const setNotReadNotifications = (notifications: string[]): ReduxAction => {
	return {
		type: "set_unread_notifications",
		notificationIds: notifications
	}
}
export const setNotificationRead = (notification: string): ReduxAction => {
	return {
		type: "set_single_read",
		notificationId: notification
	}
}
export const setDishRestrictions = (list: DishRestriction[]): ReduxAction => {
	return {
		type: "dishRestrictions",
		list: list
	}
}
export const setFoodPreferences = (list: FoodPreference[]): ReduxAction => {
	return {
		type: "foodPreferences",
		list: list
	}
}

export const setRestaurantCategories = (list: RestaurantCategory[]): ReduxAction => {
	return {
		type: "restaurantCategories",
		list: list
	}
}

export const setOccasions = (list: Occasion[]): ReduxAction => {
	return {
		type: "occasions",
		list: list
	}
}

export const setStyles = (list: RestaurantStyle[]): ReduxAction => {
	return {
		type: "styles",
		list: list
	}
}

export const setPaymentMethods = (list: PaymentMethod[]): ReduxAction => {
	return {
		type: "paymentMethods",
		list: list
	}
}

export const resetRestFilters = (): ReduxAction => {
	return {
		type: "resetRestFilters"
	}
}

export const resetDishFilters = (): ReduxAction => {
	return {
		type: "resetDishFilters"
	}
}

export const filtersUpdate = (): ReduxAction => {
	return {
		type: "filtersUpdate"
	}
}
