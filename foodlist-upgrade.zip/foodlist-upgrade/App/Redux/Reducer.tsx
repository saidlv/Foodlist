import { createStore } from 'redux';
import { ReduxState, initialState, deepCopy } from './StateFormat';
import { dishFiltersFormat, restFiltersFormat } from './StateFormat/FiltersFormat';
import { ReduxAction } from './Actions';
import { Notification } from '@Models/Notification';

import { parseAction as coreParseAction } from "@FoodListCore/Redux/Reducer"

const merge = (state: ReduxState, updates: Partial<ReduxState>): ReduxState => {
	let newState: Partial<ReduxState> = {}
	for (let key in state) {
		newState[key] = state[key]
	}
	for (let key in updates) {
		newState[key] = updates[key]
	}
	return newState as ReduxState
}

const notificationID = (item: Notification): string => {
	return item.type + item.id;
}

const addNotification = (item: Notification, notifications?: Notification[]): Notification[] | number | undefined => {
	const item_id = notificationID(item);
	for (var i in notifications) {
		const id = notificationID(notifications[parseInt(i)]);
		if (item_id == id) return notifications;
	}
	return notifications?.unshift(item);
}

const parseAction = (action: ReduxAction, state: ReduxState): {} | Partial<ReduxState> => {
	switch (action.type) {
		case 'user': return {
			currentUser: action.user
		}
		case "notifications": return {
			notifications: action.list
		}
		case "add_notification": return {
			notificationsManager: addNotification(action.item, state.notifications)
		}
		case "set_unread_notifications": {
			return {
				unread_notifications: action.notificationIds
			}
		}
		case "set_single_read": {
			if (action.notificationId) {
				let index = state.unread_notifications.indexOf(action.notificationId)
				let new_unread = deepCopy(state.unread_notifications)
				if(index != -1) {
					new_unread.splice(index, 1)
				}
				return {
					unread_notifications: new_unread
				}
			}
		}
		case "dishRestrictions": return {
			dishRestrictions: action.list
		}
		case "foodPreferences": return {
			foodPreferences: action.list
		}
		case "occasions": return {
			occasions: action.list
		}
		case "styles": return {
			styles: action.list
		}
		case "paymentMethods": return {
			paymentMethods: action.list
		}
		case "restaurantCategories": return {
			restCategories: action.list
		}
		case "resetRestFilters": return {
			restFilters: deepCopy(restFiltersFormat),
			filtersUpdate: !state.filtersUpdate
		}
		case "resetDishFilters": return {
			dishFilters: deepCopy(dishFiltersFormat),
			filtersUpdate: !state.filtersUpdate
		}
		case "filtersUpdate": return {
			filtersUpdate: !state.filtersUpdate
		}
	}
	return coreParseAction(action)
}

const reducer = (state: ReduxState = initialState, action: ReduxAction) => {
	state.lastAction = action
	return merge(state, parseAction(action, state))
}

export const store = createStore(reducer)
