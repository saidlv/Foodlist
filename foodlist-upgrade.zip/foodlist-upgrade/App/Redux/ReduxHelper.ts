import { store } from "./Reducer"
import { ItemsMap } from "@Models/ItemsMap"
import { Service } from "@Models/Service"

export const isCurrentUser = (id: number | null | undefined) => {
	if (id) {
		let currentUser = store.getState().currentUser?.id
		if (currentUser) {
			return currentUser == id
		}
	}
	return false
}

export const followEmitter = () => {
	return store.getState().emitter
}

export const getServices = () => {
	return store.getState()["services"]
}

export const mapServices = (services: string[] | undefined) => {
	let mappedServices: ItemsMap<Service> = {}
	getServices().forEach((item) => {
		mappedServices[item.infoKey] = item
	})
	return (services || []).map((item) => {
		return mappedServices[item]!
	})
}
