import { dishFiltersFormat, restFiltersFormat, services, RestaurantFiltersFormat, DishFilterFormat } from './FiltersFormat'
import { Service } from "@Models/Service"
import { User } from '@Models/User'
import { DishType } from '@Models/DishType'
import { Notification } from '@Models/Notification'
import { FoodPreference } from '@Models/FoodPreference'
import { Occasion } from '@Models/Occasion'
import { PaymentMethod } from '@Models/PaymentMethod'
import { ReduxAction } from '@Redux/Actions'
import { DishCategory, RestaurantCategory } from '@Models/Category'
import { DishRestriction } from '@Models/DishRestriction'
import { RestaurantStyle } from '@Models/RestaurantStyle'
import { Any } from '@Models/Any'

import { ReduxState as CoreState, initialState as coreState } from "@FoodListCore/Redux/StateFormat"
import { Platform } from 'react-native'

export const deepCopy = (obj) => {
	return JSON.parse(JSON.stringify(obj))
}

export type ReduxState = {
	[key: string]: Any //TODO: this is probably shit but I can't find a better way
	currentUser?: User
	restFilters: RestaurantFiltersFormat
	dishFilters: DishFilterFormat
	notifications: Notification[]
	unread_notifications: string[]
	dishTypes?: DishType[]
	dishCategories?: DishCategory[]
	restCategories?: RestaurantCategory[]
	dishRestrictions?: DishRestriction[]
	foodPreferences?: FoodPreference[]
	occasions?: Occasion[]
	paymentMethods?: PaymentMethod[]
	styles?: RestaurantStyle[]
	services: Service[]
	filtersUpdate?: boolean
	lastAction?: ReduxAction | null
} & CoreState

const getInitialUser = () => {
	if(Platform.OS == "web") {
		const user = window.localStorage.getItem("foodlist_auth_user") //TODO: not imported from SessionManager because of require cycles
		if(user) {
			try {
				const parsedUser = JSON.parse(user)
				return parsedUser
			} catch (e) {}
		}
	}
	return null
}

export const initialState: ReduxState = {
	currentUser: getInitialUser(),
	restFilters: deepCopy(restFiltersFormat), //TODO: fix services initialization
	dishFilters: deepCopy(dishFiltersFormat), //TODO: fix services initialization
	notifications: [],
	unread_notifications: [],
	dishTypes: [],
	dishCategories: [],
	restCategories: [],
	dishRestrictions: [],
	foodPreferences: [],
	occasions: [],
	paymentMethods: [],
	styles: [],
	filtenmrsUpdate: true,
	lastAction: null,
	...coreState
}