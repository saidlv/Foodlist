import { PrintableItem } from "@Models/PrintableItem"
//import { translate } from "@App/I18n"
import { Any } from "@Models/Any"
import { I18nKey } from "@App/I18n"

const MAX_PRICE = 205
const MAX_SEARCH_RADIUS = 51
export const INITIAL_SEARCH_RADIUS = 10

export type RestaurantInitialValues = {
	orderBy: number,
	maxPrice: number,
	minRating: number,
	maxSearchRadius: number,
	categories: PrintableItem[],
	restrictions: PrintableItem[],
	occasions: PrintableItem[],
	styles: PrintableItem[],
	openNow: boolean,
	takeaway: boolean,
	delivery: boolean,
	children: boolean,
	reservation: boolean,
	wifi: boolean,
	breakfast: boolean,
	dogsAllowed: boolean,
	with_bookings: boolean,
	with_orders: boolean,
	with_delivery: boolean
}
export const restInitialValues: RestaurantInitialValues = {
	orderBy: 2,
	maxPrice: MAX_PRICE,
	minRating: 0,
	maxSearchRadius: MAX_SEARCH_RADIUS,
	categories: [],
	restrictions: [],
	occasions: [],
	styles: [],
	openNow: false,
	takeaway: false,
	delivery: false,
	children: false,
	reservation: false,
	wifi: false,
	breakfast: false,
	dogsAllowed: false,
	with_bookings: false,
	with_orders: false,
	with_delivery: false
}
const options: I18nKey[] = [
	"openNow_option",
	"orderOnline",
	"delivery_with_foodlist",
	"booking_with_foodlist",
	/* "take_away",
	"delivery",
	"for_kids",
	/* "accepts_reservations", 
	"free_wifi",
	"for_breakfast",
	"dogs_allowed"*/
]

export type RestaurantFiltersFormat = {
	MAX_PRICE: number,
	MAX_SEARCH_RADIUS: number,
	options: I18nKey[],
	/** Redux keys */
	optionKeys: (keyof RestaurantInitialValues)[],
	/** Server keys */
	infoKeys: string[],
	values: RestaurantInitialValues
}
export const restFiltersFormat: RestaurantFiltersFormat = {
	MAX_PRICE: MAX_PRICE,
	MAX_SEARCH_RADIUS: MAX_SEARCH_RADIUS,
	options: options,
	/** Redux keys */
	optionKeys: ["openNow", "with_orders", "with_delivery", "with_bookings" /* "takeaway", "delivery", "children", "reservation", "wifi", "breakfast", "dogsAllowed"*/],
	infoKeys: ["open_now", "with_orders", "with_delivery", "with_bookings" /* "take_away", "delivery", "for_kids", "accepts_reservations", "free_wifi", "for_breakfast", "dogs_allowed"*/], //server keys
	values: restInitialValues
}

export type ReduxService = {
	id: number,
	i18n_key: I18nKey,
  /*
   * key used inside the app to reference a service
   */
	key: string,
  /*
   * key used by server to reference a service
   */
	infoKey: string,
}
export const services = options.reduce<ReduxService[]>((res, item, index) => {
	if (index != 0) { //ignore open_now
		res.push({
			id: index,
			i18n_key: item,
			key: restFiltersFormat.optionKeys[index],
			infoKey: restFiltersFormat.infoKeys[index]
		})
	}
	return res
}, [])

const categories: string[] = ["Cinese", "Giapponese", "Messicano", "Italiano", "Francese", "Americano", "Fusion"]
const portate: string[] = ["Primi", "Secondi carne", "Secondi pesce", "Contorno", "Dolce"]
const restrictions: string[] = ["Vegano", "Celiaco", "Fruttariano", "Astemio (brutta gente)"]
const preferenze: string[] = ["Vegano", "Celiaco", "Fruttariano", "Astemio (brutta gente)"]

export type DishInitialValues = {
	[key: string]: Any,
	orderBy: number,
	categories: PrintableItem[],
	maxPrice: number,
	maxSearchRadius: number,
	minRating: number,
	portate: PrintableItem[],
	restrictions: PrintableItem[],
	preferenze: PrintableItem[]
}
export const dishInitialValues = {
	orderBy: 2,
	categories: [],
	maxPrice: MAX_PRICE,
	maxSearchRadius: MAX_SEARCH_RADIUS - 1,
	minRating: 0,
	portate: [],
	restrictions: [],
	preferenze: []
}

export type DishFilterFormat = {
	MAX_PRICE: number,
	MAX_SEARCH_RADIUS: number,
	values: DishInitialValues
}
export const dishFiltersFormat: DishFilterFormat = {
	MAX_PRICE: MAX_PRICE,
	MAX_SEARCH_RADIUS: MAX_SEARCH_RADIUS,
	values: dishInitialValues
}