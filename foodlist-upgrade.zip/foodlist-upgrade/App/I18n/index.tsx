export { default, translate, currentLocale } from "@FoodListCore/I18n"
export type { I18nKey } from "@FoodListCore/I18n"