import React, { ReactNode } from 'react';
import Icon, { MaterialCommunityIcon, MaterialCommunityIconName, MaterialIcon, MaterialIconName } from '@FoodListCore/Iconfont/FoodListIconfont';
import FeedPage from '@Pages/FeedPage';
import SearchLocationPage from '@Pages/Search/SearchLocationPage';
import RestaurantFilters from '@Pages/Search/FilterPage/RestaurantFilters';
import DishFilterPage from '@Pages/Search/FilterPage/DishFilters';
import FavouritesPage from '@Pages/Favourites';
import { colors, iconNamed, inlineIcons } from '@Global/GlobalProps';
import NotificationIcon, { getUnreadCount } from "@Components/NotificationIcon"
import { store } from '@Redux/Reducer';
import { share, SHARE_ACTIONS } from '@Services/ShareManager';
import { useRoute } from '@react-navigation/native';

import { createStackNavigator, StackNavigationOptions, StackNavigationProp } from '@react-navigation/stack';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { CommonRoutes, menuHeaderLeft } from './CommonRoutes';
import { SearchParamList } from '@RouteParams/Search';
import { AuthParamList } from '@RouteParams/Auth';
import { translate } from './I18n';
import UserRoutes from '@FoodListCore/Flows/User/routes'
import { IconName } from '@FoodListCore/Iconfont/IconName';
import { userLogged } from '@FoodListCore/Redux/ReduxHelper';

import SideMenu from 'react-native-side-menu-updated';
import SideBar from '@FoodListCore/Components/SideBar';
import { SafeAreaConsumer } from 'react-native-safe-area-context';
import FirebaseMessaging from './Services/FirebaseMessaging';
import FirebaseAnalytics from './Services/FirebaseAnalytics';
import SessionManager from '@FoodListCore/Services/SessionManager';
import PickPositionPage from './Pages/PickPositionPage';
import OrderOnlinePage from './Pages/OrderOnlinePage';
import PointsPage from './Pages/PointsPage';
import MyCoupons from '@FoodListCore/Pages/MyCouponsPage';
import AddCoupon from './Pages/AddCouponPage';
import HowToEarnPoints from './Pages/HowToEarnPointsPage';
import { PointsStackParams } from './RouteParams/Points';
import { shallowEqual, useSelector } from 'react-redux';
import { ReduxState } from './Redux/StateFormat';

export class SideBarGlobals {
	static sidebarRef: SideMenu | null = null
}

let stackNavigationOptions = (title: string | (() => ReactNode)): ((props: { navigation: StackNavigationProp<AuthParamList> }) => StackNavigationOptions) => {

	return ({ navigation }) => {
		let currentUser = store.getState()?.currentUser

		let notifyIcon = <NotificationIcon />
		let shareIcon = iconNamed("share-2", () => {
			share(SHARE_ACTIONS.USER, { id: currentUser?.id ?? "", text: currentUser?.username ?? "" })
		})
		const route = useRoute();

		return ({
			headerTintColor: colors.white,
			headerStyle: {
				backgroundColor: colors.foodlist,
				borderBottomWidth: 0,
				elevation: 0,
				shadowColor: 'transparent'
			},
			headerTitle: title,
			headerBackTitle: " ",
			//headerRight: () => notifyIcon,
			headerRight: (currentUser && route.name === "User") ? () => notifyIcon : () => null
			//...TransitionPresets.SlideFromRightIOS,
		})
	}
}

const SearchStack = createStackNavigator<SearchParamList>()

export const searchRoutes = [
	<SearchStack.Screen
		key={2}
		name="SearchLocationPage"
		component={SearchLocationPage}
		options={({ navigation }) => ({
			headerRight: () => null,
			headerTitle: translate("insertDestination")
		})}
	/>,
	<SearchStack.Screen
		key={5}
		name="PickLocation"
		component={PickPositionPage}
		options={() => ({
			headerTitle: translate("pickFromMap")
		})}
	/>,
	<SearchStack.Screen
		key={3}
		name="RestaurantFilter"
		component={RestaurantFilters}
		options={({ route, navigation }) => {
			const { params } = route
			return {
				headerRight: () => iconNamed("reset-filters", params?.handleReset),
				headerTitle: translate("filterLocals"),
				gestureEnabled: !(params?.blockSwipe ?? false)
			}
		}}
	/>,
	<SearchStack.Screen
		key={4}
		name="DishFilterPage"
		component={DishFilterPage}
		options={({ route, navigation }) => {
			const { params } = route
			return {
				headerRight: () => iconNamed("reset-filters", params?.handleReset),
				headerTitle: translate("filterDishes"),
				gestureEnabled: !(params?.blockSwipe ?? false)
			}
		}}
	/>
]

let Stack = createStackNavigator()

function homeStack() {
	return (
		<Stack.Navigator
			initialRouteName="FeedPage"
			screenOptions={stackNavigationOptions(() => iconNamed("foodlist"))}
		>
			<Stack.Screen
				name="FeedPage"
				component={FeedPage}
				options={{
					title: translate("home"),
					headerLeft: menuHeaderLeft().headerLeft
				}}
			/>
			<Stack.Screen
				name="FoodListOrderOnline"
				component={OrderOnlinePage}
				options={({ route }) => ({
					headerTitle: route.params?.bookings ? translate("bookTable") : translate("orderOnline"),
				})}
			/>
			{searchRoutes}
			{CommonRoutes()}
		</Stack.Navigator>
	)
}

function searchStack() {
	return (
		<Stack.Navigator
			initialRouteName="NewSearch"
			screenOptions={stackNavigationOptions(() => iconNamed("search"))} //in più c'era notify=true, hideShadow=true
		>
			{searchRoutes}
			{CommonRoutes()}
			<Stack.Screen
				name="NewFoodListSearch"
				component={OrderOnlinePage}
				options={({ route }) => ({
					headerTitle: "Cosa vuoi fare oggi?",
					headerLeft: menuHeaderLeft().headerLeft
				})}
			/>
		</Stack.Navigator>
	)
}

function favouritesStack() {
	return (
		<Stack.Navigator
			initialRouteName="Favourites"
			screenOptions={stackNavigationOptions(translate("favourites"))} //in più c'era notify=false, hideShadow=true
		>
			<Stack.Screen
				name="Favourites"
				component={FavouritesPage}
				options={menuHeaderLeft}
			/>
			{CommonRoutes()}
		</Stack.Navigator>
	)
}

const PointsStack = createStackNavigator<PointsStackParams>()

const pointsStack = () => {
	return (
		<PointsStack.Navigator
			initialRouteName="Points"
			screenOptions={stackNavigationOptions(translate("points"))}
		>
			<PointsStack.Screen
				name="Points"
				component={PointsPage}
				options={menuHeaderLeft}
			/>
			<PointsStack.Screen
				name="MyCoupons"
				component={MyCoupons}
				options={{
					headerTitle: translate("myCoupons")
				}}
			/>
			<PointsStack.Screen
				name="AddCoupon"
				component={AddCoupon}
				options={{
					headerTitle: translate("generateCoupon")
				}}
			/>
			<PointsStack.Screen
				name="HowToEarnPoints"
				component={HowToEarnPoints}
				options={{
					headerTitle: translate("howIEarnPoints")
				}}
			/>
		</PointsStack.Navigator>
	)
}

function userStack() {
	return (
		<Stack.Navigator
			initialRouteName="ProfilePage"
			screenOptions={stackNavigationOptions("")} //in più c'era notify=false, hideShadow=true
		>
			{CommonRoutes()}
			{UserRoutes(true)}
		</Stack.Navigator>
	)
}

const Tab = createMaterialBottomTabNavigator()

type TabBarIconFn = ((props: { focused: boolean, color: string }) => React.ReactNode)

const tabIcon = (focusedIcon: IconName, unfocusedIcon?: IconName): TabBarIconFn => {
	// @ts-ignore
	let _unfocusedIcon: IconName = unfocusedIcon ?? (focusedIcon + '-o')
	return ({ focused, color }) => (
		<Icon name={focused ? focusedIcon : _unfocusedIcon} size={20} color={color} />
	)
}
const materialTabIcon = (focusedIcon: MaterialCommunityIconName, unfocusedIcon: MaterialCommunityIconName): TabBarIconFn => {
	return ({ focused, color }) => {
		// @ts-ignore
		const icon = focused ? focusedIcon : unfocusedIcon
		return (
			<MaterialCommunityIcon name={icon} size={24} color={color} />
		)
	}
}

const notificationsSelector = (state: ReduxState) => {
	return {
		count: getUnreadCount(state.notifications || []),
		userLogged: !!state.currentUser,
	}
}

export default function (props: any) {
	const logged = userLogged()
	const { count } = useSelector(notificationsSelector, shallowEqual)
	return (
	<SideMenu
		ref={ref => { SideBarGlobals.sidebarRef = ref }}
		menu={(
			<SideBar
				navigation={props.navigation}
				/** @ts-ignore */
				loginPage="MainAuthPage"
				onLogout={() => {
					FirebaseMessaging.dropToken().then(() => {
						FirebaseAnalytics.logout();
						return SessionManager.logout();
					})
				}}
			/>
		)}
		bounceBackOnOverdraw={false}
		disableGestures
	>
		<SafeAreaConsumer>
			{insets => (
		<Tab.Navigator
			initialRouteName="Search"
			activeColor={colors.foodlist}
			inactiveColor="#000"
			barStyle={{
				backgroundColor: '#fff',
				/* height: logged ? undefined : insets?.bottom,
				opacity: logged ? undefined : 0, */
			}}
			style={{
				backgroundColor: "#fff"
			}}
			labeled={false}
			shifting={false}
		>
			<Tab.Screen
				name="Home"
				component={homeStack}
				options={{
					tabBarLabel: "HOME",
					tabBarIcon: tabIcon("home")
				}}
			/>
			<Tab.Screen
				name="Search"
				component={searchStack}
				options={{
					tabBarLabel: "LIST",
					tabBarIcon: tabIcon("search")
				}}
			/>
			<Tab.Screen
				name="Points"
				component={pointsStack}
				options={{
					tabBarIcon: materialTabIcon("trophy", "trophy-outline"),
				}}
			/>
			{logged && (
				<>
					<Tab.Screen
						name="Liked"
						component={favouritesStack}
						options={{
							tabBarLabel: "LIKED",
							tabBarIcon: tabIcon("heart")
						}}
					/>
					<Tab.Screen
						name="User"
						component={userStack}
						options={{
							tabBarLabel: "USER",
							tabBarIcon: tabIcon("user"),
							tabBarBadge: count > 0 ? count : undefined,
						}}
					/>
				</>
			)}
		</Tab.Navigator>
			)}
		</SafeAreaConsumer>
	</SideMenu>
	)
}