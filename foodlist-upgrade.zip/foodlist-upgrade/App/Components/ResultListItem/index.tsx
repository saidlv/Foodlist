import React from 'react';
import { colors, when, isDefined, stringDefined } from '@Global/GlobalProps';
import { View, Text } from 'react-native';
import StarRating from '@Components/StarRating';
import styles from './Style';
import { ImageSource } from '@Models/ImageSource';
import { CommonParamList, CommonNavigation } from '@RouteParams/Common';
import { useNavigation } from '@react-navigation/native';
import { translate } from '@App/I18n';
import { Pluto } from '@Models/Pluto';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import FLImage from '@FoodListCore/Components/FLImage';
import { themeColors } from '@FoodListCore/Global/GlobalProps';

/**
 * @param title
 * @param rating: undefined or null to hide stars
 * @param secondLine
 * @param thirdLine
 * @oaram thirdLineBold
 * @param blueText: if defined shows right blue vertically centered text
 * @param bottomRightText: if defined shows bottom right grey text
 */

type ResultListItemProps = {
	source: ImageSource,
	type: number,
	rating?: number,
	blueText?: string,
	bottomRightText?: string,
	onPress?: (show: (page: keyof CommonParamList, params: object) => void) => void,
	twoLines?: boolean,
	title?: string,
	afterTitle?: string,
	time?: { open_now: boolean | null, time_string?: string | null },
	showCategory?: boolean,
	rightView?: () => JSX.Element,
	secondLine?: string,
	hideDescription?: boolean,
	thirdLine?: string,
	thirdLineBold?: string,
	categories?: string,
	callbackOpenCell?: () => void,
	warningText?: string
}

type Props = ResultListItemProps & {
	navigation: CommonNavigation<Pluto>
}

class ResultListItem extends React.PureComponent<Props> {
	getImage() {
		if (this.props.source) {
			return this.props.source
		} else {
			let type = this.props.type
			if (type == 0) {
				return require('@FoodListCore/Assets/Images/ristorante.jpg')
			} else if (type == 2) {
				return require('@FoodListCore/Assets/Images/utente.jpg')
			}
			return require('@FoodListCore/Assets/Images/piatto.jpg')
		}
	}
	hasRating() {
		return isDefined(this.props.rating)
	}
	hasBlueText() {
		return stringDefined(this.props.blueText)
	}
	hasBottomRightText() {
		return stringDefined(this.props.bottomRightText)
	}
	hasOnPress() {
		return isDefined(this.props.onPress)
	}
	onPress = () => {
		if(this.props.onPress) {
			this.props.onPress(this.props.navigation.push)
		}
	}

	render() {
		return (
			<TouchableRipple
				disabled={!this.hasOnPress()}
				onPress={this.onPress}
				style={styles.container}
			>
				<View style={styles.imageContainer}>
					<FLImage style={styles.image} source={this.getImage()} />
				</View>
				<View style={[styles.infoContainer, { alignSelf: 'center' }]}>
					<View style={{ flexDirection: "row" }}>
						<View style={{ flex: 1 }}>
							{(this.props.twoLines) && (
								<Text style={styles.title}>{this.props.title}  <Text style={{ color: colors.greyText, fontWeight: 'normal' }}>{this.props.afterTitle}</Text></Text>
							)}
							{(!this.props.twoLines) && (
								<Text style={styles.title}>{this.props.title}</Text>
							)}

							{this.props.time && this.props.time.open_now != null &&
								<View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 3 }}>
									<Text style={[styles.greyLabel, { color: this.props.time?.open_now ? colors.green : colors.red }]}>{this.props.time?.open_now ? translate("openNow", { timeString: this.props.time.time_string ?? "" }) : this.props.time.time_string}</Text>
									<View style={{ width: 8, height: 8, borderRadius: 4, marginLeft: 8 }} />
								</View>
							}
							{!this.props.rightView && (
								<View style={styles.inlineFlex}>
									{!!this.props.rating &&
										<View style={styles.stars}>
											<StarRating size={12} rating={this.props.rating} showLiteral color={colors.starColor} />
										</View>
									}
									<Text style={styles.greyLabel}>{this.props.secondLine}</Text>
								</View>
							)}
						</View>
						<View style={[styles.rightContainer, { justifyContent: "flex-start" }, when(!this.hasBlueText(), { display: "none" })]}>
							<Text style={[styles.rightText, { color: themeColors.priceTint }]}>{this.props.blueText}</Text>
						</View>
					</View>

					{(this.props.showCategory && !!this.props.categories) && (
						<View style={[styles.thirdLineFlex, { marginBottom: 5 }]}>
							<Text style={[styles.lightGreyLabel, { flex: 1 }]}>{this.props.categories}</Text>
						</View>
					)}
					{(!this.props.hideDescription) && !this.props.rightView && (
						<View style={[styles.thirdLineFlex, when(!!this.props.warningText, { marginBottom: 4 })]}>
							<Text numberOfLines={1} style={[styles.lightGreyLabel, { flex: 1 }]}>{this.props.thirdLine}<Text style={styles.greyLabel}>{this.props.thirdLineBold}</Text></Text>
							<Text style={[styles.lightGreyLabel, styles.rightContainer, when(!this.hasBottomRightText(), { display: "none" })]}>{this.props.bottomRightText}</Text>
						</View>
					)}

					{this.props.rightView && (
						<View style={[styles.thirdLineFlex, when(!!this.props.warningText, { marginBottom: 4 })]}>
							<View style={{ flex: 1, flexDirection: 'column', justifyContent: 'space-between' }} >
								<Text style={[styles.greyLabel, { paddingVertical: 5 }]}>{this.props.secondLine}</Text>
								<Text style={styles.lightGreyLabel} numberOfLines={1}>{this.props.thirdLine}<Text style={styles.greyLabel}>{this.props.thirdLineBold}</Text></Text>
							</View>
							<View style={{ flex: 0, justifyContent: 'flex-end' }}>
								{this.props.rightView()}
							</View>
						</View>
					)}
					{!!this.props.warningText && (
						<Text style={[styles.lightGreyLabel, { fontWeight: "bold", color: colors.foodlist}]}>{this.props.warningText}</Text>
					)}
				</View>
			</TouchableRipple>
		)
	}
}
export default function (props: ResultListItemProps) {
	const navigation = useNavigation<CommonNavigation<Pluto>>()
	return <ResultListItem {...props} navigation={navigation} />
}