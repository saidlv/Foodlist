import { colors, fontSizes } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
	container: {
		flex: 0,
		flexDirection: 'row',
		paddingVertical: 12,
		width: '100%',
		height: 'auto',
		justifyContent: 'space-between',
		alignItems: 'center',
		paddingHorizontal: 20
	},
	imageContainer: {
		paddingRight: 20,
		alignSelf: 'center'
	},
	image: {
		height: 80,
		width: 80,
		borderRadius: 8
	},
	infoContainer: {
		flex: 1,
		flexDirection: 'column'
	},
	rightContainer: {
		flex: 0,
		paddingLeft: 20
	},
	rightText: {
		color: colors.blueMenu,
		fontWeight: 'bold',
		fontSize: 16,
		fontStyle: "normal",
		letterSpacing: 0
	},
	title: {
		fontSize: 16,
		fontWeight: "500",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText
	},
	afterTitle: {
		color: colors.blueMenu
	},
	inlineFlex: {
		flex: 0,
		flexDirection: 'row',
		paddingVertical: 5,
		alignItems: "center"
	},
	thirdLineFlex: {
		flex: 0,
		flexDirection: 'row',
		justifyContent: 'space-between'
	},
	greyLabel: {
		fontSize: 10,
		fontWeight: "bold",
		color: colors.darkGreyText,
		justifyContent: 'center',
		fontStyle: "normal",
		letterSpacing: 0
	},
	stars: {
		marginRight: 5
	},
	lightGreyLabel: {
		fontSize: 11,
		color: colors.greyInfoText,
		justifyContent: 'center',
		letterSpacing: 0
	}
})
