import React from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { colors } from '@Global/GlobalProps';
import styles from './Style';
import map from '@Components/FeedItem/map';
import FeedItem from '@Components/FeedItem'
import RoundedButton from '@Components/RoundedButton';
import ReviewListFilterHeader from '@Components/ReviewListFilterHeader';
import { Review } from '@Models/Review';
import { ReviewsListActions } from '@Models/ReviewsListActions';
import { ReviewsFilterOptions } from '@Components/ReviewListFilterHeader/view';
import { ReviewsStaticData } from '.';
import { translate } from '@App/I18n';
import { margins } from '@FoodListCore/Global/GlobalProps';

type ReviewsListProps = {
	actions: ReviewsListActions,
	filterOptions: ReviewsFilterOptions,

	data: ReviewsStaticData,

	reviewsList: Review[],
	loadingReviews: boolean,
	showAllReviews: () => void
}

export const ReviewsList = (props: ReviewsListProps) => {
	const { data } = props
	const isProfile = props.filterOptions.isProfile

	return (
		<>
			{/* <ReviewListFilterHeader
				options={props.filterOptions}
				actions={props.actions}
			/> */}
			<Text style={styles.title}>{translate("lastReviews")}</Text>
			{(props.loadingReviews) && (
				<View style={{ marginTop: 20, marginBottom: 40 }}>
					<ActivityIndicator size="small" color={colors.blackOverlay} />
				</View>
			)}
			{(!props.loadingReviews) && (
				<View style={{ marginTop: 10 }}>
					{(props.reviewsList.length == 0) && (
						<View style={styles.container}>
							<Text>{translate("noResult")}</Text>
						</View>
					)}
					{props.reviewsList.map((item, index) => {

						item.feed_type = item.dish ? "DISH" : "RESTAURANT"
						item.name = item.restaurant?.name || item.dish?.name
						item.user = item.user || data.user

						if (!isProfile || false) {
							if (data.dishReview) {
								item.feed_type = "DISH"
								item.dish = data.dishData!
							} else if (data.restaurantReview) {
								item.feed_type = "RESTAURANT"
								item.restaurant = data.restaurantData!
							}
						}

						if (index != 5) {
							return (
								<FeedItem
									key={item.id + "_" + item.updated_at}
									item={map(item)}
									showDetail={true}
									disableUserPress={data.disableUserPress}
									callbackShouldReload={props.actions.callbackShouldReload}
									hideButton={!isProfile}
								/>
							)
						}
					})}

					{(props.reviewsList.length > 5) && (
						<View style={{ marginHorizontal: margins.pagePadding, marginTop: 10 }}>
							<RoundedButton text={translate("showAllReviews")} full={true} borderRadius={20} bottom={false} onPress={props.showAllReviews} />
						</View>
					)}
				</View>
			)}
		</>
	)
}

export default ReviewsList
