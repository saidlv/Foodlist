import { colors } from '@Global/GlobalProps';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import { StyleSheet } from 'react-native';
import { margins } from '@FoodListCore/Global/GlobalProps';

export default StyleSheet.create({
	container: {
		marginTop: 10,
		alignItems: 'center'
	},
	title: {
		marginHorizontal: margins.pagePadding,
		fontWeight: "bold",
		fontSize: 18,
	},
	reviewContainer: {
		backgroundColor: colors.white,
		borderRadius: 4,
		marginLeft: 20,
		marginRight: 20,
		marginTop: 20,
		...commonStyle.shadow
	},
	headerContainer: {
		flex: 1,
		flexDirection: 'row'
	},
	header: {
		flex: 1,
		alignItems: 'stretch',
		marginRight: 12,
		marginTop: 12
	},
	text: {
		width: 57,
		marginRight: 30,
		fontSize: 12,
		fontWeight: "500",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText
	},
	imageContainer: {
		flex: 0,
		marginLeft: 12,
		marginTop: 12,
		marginRight: 10
	},
	image: {
		height: 30,
		width: 30,
		borderRadius: 15
	},
	headerReview: {
		fontSize: 14,
		fontWeight: "500",
		flex: 1,
		color: colors.blackText
	},
	smallTextReview: {
		fontSize: 10,
		fontWeight: "bold",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.greyText
	},
	alignRight: {
		textAlign: 'right',
		flex: 0
	},
	flexAdapt: {
		flex: 1,
		alignItems: 'stretch'
	},
	smallMarginTop: {
		marginTop: 3
	},
	reviewText: {
		fontSize: 14,
		fontWeight: "normal",
		fontStyle: "normal",
		lineHeight: 22,
		letterSpacing: 0,
		color: colors.blackText
	},
	marginText: {
		marginTop: 12,
		marginLeft: 12,
		marginRight: 12
	},
	marginImage: {
		marginTop: 12,
		marginHorizontal: 12
	},
	imageReview: {
		width: "100%",
		resizeMode: 'contain'
	},
	flexRowBottom: {
		flex: 1,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center',
		marginTop: 12,
		marginLeft: 12,
		marginBottom: 12
	},
	inline: {
		flex: 0,
		flexDirection: 'row',
		alignItems: 'center'
	},
	flexRow: {
		flex: 0,
		flexDirection: "row"
	},
	justifySpaceBetween: {
		justifyContent: 'space-between',
	},
	greyText: {
		fontStyle: "normal",
		fontSize: 12,
		fontWeight: '900',
		color: colors.greyText,
		textAlignVertical: 'center',
		paddingLeft: 6,
		paddingRight: 22
	},
	redText: {
		fontStyle: "normal",
		fontSize: 12,
		fontWeight: '900',
		color: colors.red,
		textAlignVertical: 'center',
		paddingLeft: 6,
		paddingRight: 22
	}
});
