import React from 'react';
import ReviewsList from './View';
import { Dish } from '@Models/Dish';
import { Restaurant } from '@Models/Restaurant';
import { User } from '@Models/User';
import { Review } from '@Models/Review';
import { ReviewsListActions } from '@Models/ReviewsListActions';
import { ReviewsFilterOptions } from '@Components/ReviewListFilterHeader/view';
import { useNavigation } from '@react-navigation/native';
import { CommonNavigation } from '@RouteParams/Common';
import { ReviewType } from '@Models/ReviewType';
import { Pluto } from '@Models/Pluto';

export type ReviewsStaticData = {
	restaurantReview?: boolean,
	dishReview?: boolean,
	dishData?: Dish,
	user?: User,
	restaurantData?: Restaurant,
	disableUserPress?: boolean,
}

type ReviewsListContainerProps = {
	actions: ReviewsListActions
	filterOptions: ReviewsFilterOptions

	data: ReviewsStaticData

	ratingFilter?: string,
	typeFilter?: ReviewType,

	loadingReviews: boolean,
	reviewsList: Review[],
}

type Props = ReviewsListContainerProps & {
	navigation: CommonNavigation<Pluto>
}

class ReviewsListContainer extends React.PureComponent<Props> {
	showAllReviews = () => {
		this.props.navigation.push("ReviewsListLoadMorePage", {
			listParams: {
				actions: this.props.actions,
				options: this.props.filterOptions,
				data: this.props.data,
				ratingFilter: this.props.ratingFilter ?? "",
				typeFilter: this.props.typeFilter ?? "all"
			}
		})
	}

	render() {
		return (
			<ReviewsList
				showAllReviews={this.showAllReviews}
				reviewsList={this.props.reviewsList || []}
				loadingReviews={this.props.loadingReviews}

				data={this.props.data}
				filterOptions={this.props.filterOptions}
				actions={this.props.actions}
			/>
		)
	}
}

export default function (props: ReviewsListContainerProps) {
	const navigation = useNavigation<CommonNavigation<Pluto>>()
	return <ReviewsListContainer {...props} navigation={navigation} />
}

