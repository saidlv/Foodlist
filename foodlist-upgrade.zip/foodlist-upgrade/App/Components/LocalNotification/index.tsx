import React from 'react';
import { View, Text, TouchableOpacity, Animated, Platform } from 'react-native';
import { colors } from '@Global/GlobalProps';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import { margins } from '@FoodListCore/Global/GlobalProps';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import Line from '@FoodListCore/Components/Line';
import CommonStyle from '@FoodListCore/Global/CommonStyle';

export type LocalNotificationConfig = {
	text: {
		title: string,
		body: string,
	},
	onPress: () => void
}

type LocalNotificationProps = {

}

type LocalNotificationState = {
	height: Animated.Value,
	text?: {
		title: string,
		body: string,
	}
	onPress?: () => void
}

export default class LocalNotification extends React.PureComponent<LocalNotificationProps, LocalNotificationState> {

	minHeight: number = 90
	paddingTop: number = 0

	constructor(props: LocalNotificationProps) {
		super(props)
		this.paddingTop = this.getNotificationMarginTop()

		this.state = {
			text: undefined,
			onPress: undefined,

			height: new Animated.Value(0),
		}
	}

	getNotificationMarginTop = () => {
		let statusBarHeight = getStatusBarHeight(true);
		return statusBarHeight
	}

	render() {
		return (
			<Animated.View style={{
				alignSelf: 'stretch', flexDirection: 'column', justifyContent: 'center',
				position: 'absolute', top: 0, left: 0, right: 0, zIndex: 1000,
				height: this.state.height,
				marginTop: this.paddingTop,
			}}>
				<View style={[{ marginBottom: 10, backgroundColor: colors.foodlist }, CommonStyle.deepShadow]}>
					<TouchableRipple onPress={this.onPress} style={{ height: "100%", alignItems: "center", justifyContent: "center" }}>
						{!!this.state.text && (
							<View style={{ paddingHorizontal: margins.pagePadding }}>
								<Text style={{ fontWeight: "bold", color: colors.white, fontSize: 18 }}>{this.state.text.title}</Text>
								<Text style={{ color: colors.white, marginTop: 2, fontSize: 15 }}>{this.state.text.body}</Text>
							</View>
						)}
					</TouchableRipple>
				</View>
			</Animated.View>
		)
	}

	onPress = () => {
		this.closeNotification()
		this.state.onPress?.()
	}

	showNotification = (config: LocalNotificationConfig) => {
		let openDuration = 200;
		setTimeout(() => {
			this.setState({
				text: config.text,
				onPress: config.onPress
			});
		}, openDuration / 2);

		Animated.timing(this.state.height, {
			toValue: this.minHeight,
			duration: openDuration,
			useNativeDriver: false,
		}).start();

		setTimeout(() => {
			this.closeNotification();
		}, 5000);
	}

	closeNotification = () => {
		let closeDuration = 200;

		setTimeout(() => {
			this.setState({ text: undefined });
		}, closeDuration / 2);

		Animated.timing(this.state.height, {
			toValue: 0,
			duration: closeDuration,
			useNativeDriver: false,
		}).start();
	}
}
