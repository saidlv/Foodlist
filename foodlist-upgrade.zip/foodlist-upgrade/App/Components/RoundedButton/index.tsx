import React from 'react';
import { Text } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './Style';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
/**
 * @param onPress: on click callback
 * @param text: text of the button
 * @param borderRadius: value of the border radius of the button
 * @param full: boolean parameter to decide if button background is full or not
 * @param width: width of the button
 * @param height: height of the button
 * @param bottom: boolean parameter to decide text style based on position of the button

 * @return graphical representation of a rounded button
 */

type RoundedButtonProps = {
	full?: boolean,
	bottom?: boolean,
	borderRadius: number,
	onPress?: () => void,
	text: string,
}

export default class RoundedButton extends React.PureComponent<RoundedButtonProps> {
	render() {
		return (
			<TouchableRipple style={[styles.buttonStyle, this.props.full ? styles.fullButton : styles.emptyButton, { borderRadius: this.props.borderRadius, overflow: "hidden", paddingVertical: 5 }]} borderless onPress={this.props.onPress}>
				<Text style={[this.props.bottom ? styles.bottomText : styles.textStyle, this.props.full ? styles.fullTitle : styles.emptyTitle]}>{this.props.text}</Text>
			</TouchableRipple>
		);
	}
}
