import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	buttonStyle: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center'
	},
	textStyle: {
		fontSize: 12,
		fontWeight: "bold",
		paddingLeft: 10,
		paddingRight: 10,
		letterSpacing: 0,
		textAlign: "center",
		fontStyle: "normal"
	},
	fullButton: {
		backgroundColor: colors.foodlist,
		borderColor: colors.foodlist
	},
	emptyButton: {
		backgroundColor: colors.greyBackground,
		borderColor: colors.foodlist,
		borderWidth: 1
	},
	fullTitle: {
		color: colors.white
	},
	emptyTitle: {
		color: colors.foodlist
	},
	bottomText: {
		fontSize: 12,
		fontWeight: "500",
		fontStyle: "normal",
		letterSpacing: 0,
		textAlign: "center"
	}
})
