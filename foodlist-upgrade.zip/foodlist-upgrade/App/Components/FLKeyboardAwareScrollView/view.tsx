import React, { ReactChild, ReactNode } from 'react';
import { ViewStyle } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

export interface FLKeyboardAwareScrollViewViewActions {
	onKeyboardWillHide: () => void
}

type FLKeyboardAwareScrollViewViewProps = {
	onRef?: (ref: KeyboardAwareScrollView | null) => void,
	children: ReactNode,
	hasNestedScrollView?: boolean,
	multipleInputs?: boolean,
	extraScrollHeight?: number
	actions?: FLKeyboardAwareScrollViewViewActions,
	contentContainerStyle?: ViewStyle,
}

const FLKeyboardAwareScrollViewView = (props: FLKeyboardAwareScrollViewViewProps) => {
	return (
		<KeyboardAwareScrollView
			ref={ref => props.onRef?.(ref)}
			onKeyboardWillHide={() => props.actions?.onKeyboardWillHide()}

			bounces={!props.hasNestedScrollView}
			scrollEnabled={!props.hasNestedScrollView}
			extraHeight={props.multipleInputs ? -64 : undefined} // This is a workaround, but it works

			contentContainerStyle={props.contentContainerStyle}
			extraScrollHeight={props.extraScrollHeight}

			automaticallyAdjustContentInsets={false}
			keyboardShouldPersistTaps="handled"
		>
			{props.children}
		</KeyboardAwareScrollView>
	);
};

export default FLKeyboardAwareScrollViewView;
