import React from 'react';
import { Text } from 'react-native';
import FLKeyboardAwareScrollViewView from './view';

import renderer from 'react-test-renderer';

it('renders FLKeyboardAwareScrollViewView view', () => {
	expect(renderer.create(<FLKeyboardAwareScrollViewView><Text>Prova</Text></FLKeyboardAwareScrollViewView>)).toMatchSnapshot(); //TODO: add FLKeyboardAwareScrollViewView props with random values

  /*
  //if view displays different outputs when passing different values as props use:

  expect.assertions(2); // increase '2' if you add more assertions

  const first = renderer.create(<FLKeyboardAwareScrollViewView pippo={true} />).toJSON();
  expect(first).toMatchSnapshot();

  const second = renderer.create(<FLKeyboardAwareScrollViewView pippo={false} />).toJSON();
  expect(second).toMatchSnapshot();
  */
});
