import React, { useState } from 'react';
import { ActivityIndicator, Platform, StyleSheet, Text, View } from 'react-native';
import { translate } from '@App/I18n';
import { CommonNavigation, CommonRoute } from '@App/RouteParams/Common';
import { ScrollView } from 'react-native-gesture-handler';
import RestaurantCellContent from '@FoodListCore/Components/Cells/NewRestaurantCell';
import WebReviews from '@FoodListCore/Components/WebReviews';
import CollapsableHeader, { useToolbarVisible } from '@FoodListCore/Components/CollapsableHeader';
import { Restaurant } from '@Models/Restaurant';
import IntegrationComponent from "@FoodListCore/Flows/Restaurant/integration-component"
import TimesSubMenu from './SubMenuViews/TimesSubMenu';
import { isOpenNow } from '@FoodListCore/Services/DateManager';
import { colors, margins, showError } from '@FoodListCore/Global/GlobalProps';
import DirectionsSubMenu from './SubMenuViews/DirectionsSubMenu';
import InfoSubMenu from './SubMenuViews/InfoSubMenu';
import RestaurantManager from '@Network/RestaurantManager';
import { setActiveRestaurant } from '@FoodListCore/Redux/ReduxHelper';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import WriteReview from '@FoodListCore/Components/WriteReview';
import { useShowSideCart } from '@FoodListCore/Global/WebHelpers';
import BestDishes from '@FoodListCore/Components/BestDishes';
export interface NewRestaurantActions {

}

type Props = {
	actions: NewRestaurantActions
	route: CommonRoute<"NewRestaurant">
	navigation: CommonNavigation<"NewRestaurant">
}

const manager = new RestaurantManager()
const NewRestaurant = React.memo((props: Props) => {
	const routeParams = props.route.params

	const [loading, setLoading] = useState(true)
	const [item, setRestaurant] = useState<Restaurant | undefined>(routeParams.restaurant)
	const id = item?.id || routeParams.id
	//const item = routeParams.restaurant as Restaurant

	const openNowResult = React.useMemo(() => {
		const result = item ? isOpenNow(item) : false
		return result
	}, [item])

	const loadData = React.useCallback(() => {
		manager.getInfoRestaurant(id).then(res => {
			if(res.data) {
				setRestaurant({
					...res?.data?.response,
					distance: routeParams.restaurant?.distance,
				})
			}
			setLoading(false)
		}).catch(showError)
	}, [])
	React.useEffect(() => {
		setActiveRestaurant(id, props.navigation)
		loadData()
	}, [])

	const [scrollProps, toolbarVisible] = useToolbarVisible()

	const showSide = useShowSideCart()

	const responsiveItems = (
		<View>
			{openNowResult?.week && openNowResult?.week.length > 0 && (
				<>
					<Text style={styles.titleHeader}><Text style={styles.title}>{translate("times")}</Text> &nbsp;
						{!!openNowResult.time_string && (
							<>
								({(openNowResult.open_now ? translate("openNow_option") : openNowResult.time_string).toLowerCase()})
							</>
						)}
					</Text>
					<TimesSubMenu times={openNowResult.week} />
				</>
			)}

			{item && !!(item.latitude && item.longitude) && (
				<View style={styles.margin}>
					<DirectionsSubMenu name={item.name} latitude={item.latitude} longitude={item.longitude} disableInteraction />
				</View>
			)}
		</View>
	)

	return (
		<>
		<CollapsableHeader
			toolbarVisible={toolbarVisible}
			title={item?.name || ""}
			addFavouriteRestaurant={item}
		/>
		<ScrollView {...scrollProps} style={{ marginTop: getStatusBarHeight(true) }} contentContainerStyle={styles.contentContainer}>
			{item ? (
			<RestaurantCellContent
				item={item}
				headerHeight={240}
				openReviews
				rightComponent={(
					<WriteReview
						restaurant={item}
						user_review_id={loading ? null : item?.user_review_id}
					/>
				)}
				rightInfos={showSide && !loading ? (
					<View style={styles.side}>
						{responsiveItems}
					</View>
				) : undefined}
			>
				{!loading && (
				<View style={styles.content}>
					{Platform.OS != "web" ? (
						<IntegrationComponent restaurant={item} />
					) : (
						<BestDishes dishes={item.dishes} restaurant_id={item.id} style={styles.dishesContainer} />
					)}
					<WebReviews
						restaurant={item}
						hideReviews
					/>
					{!!item.description && (
						<View style={styles.margin}>
							<InfoSubMenu description={item?.description} />
						</View>
					)}
					{!showSide && responsiveItems}
				</View>
				)}
			</RestaurantCellContent>
			) : <></>}

			<View style={styles.margin} />

			{loading || !item ? (
				<ActivityIndicator size="large" />
			) : (
				<></>
			)}
		</ScrollView>
		</>
	);
});

const styles = StyleSheet.create({
	title: {
		fontSize: 18,
		fontWeight: "bold",
	},
	titleHeader: {
		marginTop: margins.pagePadding,
		paddingHorizontal: margins.pagePadding,
		marginBottom: 7,
	},
	margin: {
		marginTop: margins.pagePadding,
	},
	contentContainer: {
		width: "100%",
		maxWidth: margins.maxPageWidth,
		marginLeft: "auto",
		marginRight: "auto",
	},
	side: {
		width: 400,
		marginLeft: margins.pagePadding,
		paddingLeft: margins.pagePadding,
	},
	content: {
		marginHorizontal: -margins.pagePadding,
		marginTop: margins.pagePadding,
	},
	dishesContainer: {
		paddingHorizontal: margins.pagePadding,
		marginVertical: margins.vertical,
		marginBottom: 20,
	},
});

export default NewRestaurant;
