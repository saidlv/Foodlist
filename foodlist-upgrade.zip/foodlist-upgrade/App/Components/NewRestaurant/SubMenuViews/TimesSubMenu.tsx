import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import commonStyles from '@FoodListCore/Global/CommonStuff/PageStyle';
import { colors, when } from '@Global/GlobalProps'
import { Day } from '@Models/Day';
import { translate } from '@App/I18n';
import { todayDate as getTodayDate } from '@FoodListCore/Services/DateManager'
import { margins } from '@FoodListCore/Global/GlobalProps';

type Props = {
	times: Day[]
}

export default class TimesSubMenu extends React.PureComponent<Props> {

	alreadyActiveDay = false


	checkIsToday = (item: Day) => {
		const todayDate = getTodayDate()
		const todayDay = todayDate.format('dddd');

		return item.day.toLowerCase() == todayDay.toLowerCase()

	}
	checkOpenDay = (item: Day) => {

		let result = false

		for (let i = 0; i < item.times.length; i++) {
			if (item.times[i].isNow) {
				this.alreadyActiveDay = true;
				//this.setState({alreadyActiveDay: true})
				result = true;
				break;
			}
		}

		if (!result && !this.alreadyActiveDay) {
			result = this.checkIsToday(item)
		}
		return result
	}

	render() {
		return (
			<View style={styles.margin}>
				{(this.props.times?.length != 0) && (
					<View>
						{this.props.times?.map((item, index) => {
							const isToday = this.checkOpenDay(item)
							return (
								<View key={index} style={[styles.line, when(isToday, {
									backgroundColor: colors.withAlpha(colors.blueMenu, 0.1)
								})]}>
									<View style={styles.container}>
										<Text style={isToday ? styles.currentDay : styles.normalDay}>{item?.day}</Text>
										<View style={{ flexDirection: 'column', alignItems: 'flex-end' }}>
											{item?.times?.map((itemH, index) => {
												return (
													<Text key={index} style={itemH.isNow ? styles.currentTime : styles.normalTime}>{itemH?.timeString}</Text>
												)
											}
											)}
											{(item?.times?.length == 0) && (
												<Text style={styles.closed}>{translate("closed")}</Text>
											)}
										</View>
									</View>
									{(index != 6) && (
										<View style={styles.border} />
									)}
								</View>
							)
						})}
					</View>
				)}
				{(this.props.times?.length == 0) && (
					<View style={{ marginTop: 20 }}>
						<Text style={commonStyles.noInfoText}>{translate("noTimesAvailable")}</Text>
					</View>
				)}
			</View>
		);
	}
}

const styles = StyleSheet.create({
	line: {
		justifyContent: 'center',
		paddingLeft: margins.pagePadding,
	},
	margin: {
		marginBottom: 20
	},
	container: {
		flexDirection: 'row',
		flex: 1,
		alignItems: 'center',
		paddingVertical: 2,
		paddingRight: margins.pagePadding,
	},
	closed: {
		color: colors.greyInfoText
	},
	border: {
		minHeight: 1,
		backgroundColor: colors.timesGreyBorder
	},
	currentDay: {
		flex: 1,
		color: colors.blueMenu,
		fontWeight: "bold"
	},
	normalDay: {
		flex: 1,
		color: colors.blackText,
		fontWeight: "normal"
	},
	currentTime: {
		fontWeight: "bold",
		color: colors.blueMenu
	},
	normalTime: {
		//marginVertical: 2,
		fontWeight: "normal",
		color: colors.greyInfoText
	}
});