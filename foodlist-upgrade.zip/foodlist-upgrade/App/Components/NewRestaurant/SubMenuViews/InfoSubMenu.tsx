import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { isDefined, colors } from '@Global/GlobalProps';
import commonStyles from '@FoodListCore/Global/CommonStuff/PageStyle';
import { translate } from '@App/I18n';
import { margins } from '@FoodListCore/Global/GlobalProps';
import SimpleReadMore from "rn-simple-read-more";

type Props = {
	description?: string
}

export default class InfoSubMenu extends React.PureComponent<Props> {
	render() {
		return (<View style={styles.descriptionBox}>
			{(isDefined(this.props.description)) && (
				<SimpleReadMore
					numberOfLines={5}
					lineHeight={15}
					readMoreText={translate("readMore")}
					showLessText={translate("showLess")}
					text={<Text style={styles.descriptionText}>{this.props.description}</Text>}
				/>
			)}
			{(!isDefined(this.props.description)) && (
				<Text style={[commonStyles.noInfoText]}>{translate("noDescription")}</Text>
			)}
		</View>
		);
	}
}

const styles = StyleSheet.create({
	descriptionBox: {
		margin: margins.pagePadding,
	},
	descriptionText: {
		fontSize: 13,
		fontStyle: "italic",
		color: colors.darkGreyText
	}
});