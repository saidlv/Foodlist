import React from 'react';
import SearchableOptions from '@Components/SearchableOptions';
import { translate } from '@App/I18n';



export type Option =  {
	name: string
}

type DishTypeSelectionProps = {
	items: Option[],
	onItemSelected: (item: string) => void
}

type Item = {
	name: string,
	items: {name: string}[]
}

class DishTypeSelection extends React.PureComponent<DishTypeSelectionProps> {
	searchableOptions: SearchableOptions<Item, string, Option> | null = null

	suggestedItems: string[]
	constructor(props: DishTypeSelectionProps) {
		super(props)

		this.suggestedItems = translate("portataSuggestedItems").split(", ")
	}

	show() {
		this.searchableOptions?.toggleSelector()
	}
	render() {
		let items: Item[] = [{
			name: translate("fromRestaurantMenu"),
			items: this.props.items || []
		}, {
			name: translate("suggested"),
			items: this.suggestedItems.map((item) => {
				return {
					name: item
				}
			})
		}]
		return (
			<SearchableOptions<Item, string, Option>
				ref={ref => this.searchableOptions = ref}
				items={items}
				uniqueKey="name"
				displayKey="name"
				subKey="items"
				allowNewOption={translate("newPortata")}
				showHeaders={true}
				onItemSelected={this.props.onItemSelected}
				searchPlaceHolderText={translate("addPortata")}
			/* confirmText={'Cancella'} */
			/>
		)
		/*
		<SearchableOptions
					ref={ref => this.searchableOptions = ref}
					items={this.props.dish_types.map() || []}
					uniqueKey='label_it'
					displayKey="label_it"
					allowNewOption
					onItemSelected={this.onCategorySelected}
					searchPlaceHolderText={'Cerca o aggiungi...'}
					confirmText={'Cancella'}
				/>
		*/
	}
}

export default DishTypeSelection