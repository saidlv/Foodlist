import React, { PureComponent } from 'react';
import { colors } from '@Global/GlobalProps';
import { StyleSheet, TouchableWithoutFeedback, Animated, Easing } from 'react-native';

type Props = {
	disabled?: boolean
	initialValue?: boolean
	value: boolean
	valueChanged: (value: boolean) => void
}

type State = {
	//value: boolean
	moveSwitch: Animated.Value
	//backgroundColor: Animated.Value<string>
}

const FALSE_COLOR = colors.inactiveGrey
const TRUE_COLOR = colors.blueMenu
const CIRCLE_SIZE = 28
const PADDING = 1
const WIDTH = 50
const FALSE_VALUE = PADDING
const TRUE_VALUE = WIDTH - PADDING * 2 - CIRCLE_SIZE

class SwitchComponent extends PureComponent<Props, State> {
	constructor(props: Props) {
		super(props)
		//let value = props.value || props.initialValue || false
		this.state = {
			//value: value,
			moveSwitch: new Animated.Value(props.value ? TRUE_VALUE : FALSE_VALUE)
			//backgroundColor: new Animated.Value>(value ? TRUE_VALUE : FALSE_VALUE)
		}
	}

  /* componentDidUpdate(prevProps: Props, prevState: State) {
    //console.log(prevProps.value, this.props.value, prevState.value, this.state.value)
    if(prevProps.value != this.props.value) {
        this.setState({
            value: this.props.value
        })
    }
  } */

  /* static getDerivedStateFromProps(props: Props, state: State) {
    //console.log("Bugo", props.value, state.value)
    if(props.value != state.value) {
      return {
        value: props.value
      }
    }
  } */

	handleSwitch = () => {
		let value = !this.props.value
    /* this.setState({
      value: value
    }) */
		this.props.valueChanged(value)
		this.animate(value)
	}

	animate = (value: boolean) => {
		Animated.timing(this.state.moveSwitch, {
			toValue: value ? TRUE_VALUE : FALSE_VALUE,
			duration: 200,
			useNativeDriver: false
		}).start()
    /* Animated.spring(this.state.moveSwitch, {
      toValue: value ? CIRCLE_SIZE / PADDING : -CIRCLE_SIZE / PADDING,
      useNativeDriver: true
    }) */
	}

	render() {
		//console.log("render")
    /* const interpolatedColorAnimation = this.state.backgroundColor.interpolate({
      inputRange: [-75, 75],
      outputRange: [FALSE_COLOR, TRUE_COLOR]
    }); */

		return (
			<TouchableWithoutFeedback onPress={this.handleSwitch}>
				<Animated.View style={[styles.container, {
					backgroundColor: this.props.value ? TRUE_COLOR : FALSE_COLOR
				}]}>
					<Animated.View style={[styles.circle, {
						left: this.state.moveSwitch
					}]} />
				</Animated.View>
			</TouchableWithoutFeedback>
		)
	}
}

const styles = StyleSheet.create({
	container: {
		width: WIDTH,
		height: 31,
		borderRadius: 25.5,
		padding: PADDING,
		borderWidth: 0.5,
		borderColor: 'rgba(0,0,0,0.1)',
		position: 'relative'
	},
	circle: {
		backgroundColor: "#fff",
		width: CIRCLE_SIZE,
		height: CIRCLE_SIZE,
		borderRadius: 14,
		borderColor: 'rgba(0,0,0,0.1)',
		borderWidth: 0.5,
		shadowRadius: 2,
		shadowOffset: {
			width: 0,
			height: 2
		},
		shadowOpacity: 0.2,
		elevation: 1,
		position: 'absolute',
		top: PADDING
	}
});

export default SwitchComponent;
