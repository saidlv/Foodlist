import React from 'react';
import 'react-native';
import Switch from './index';

import renderer from 'react-test-renderer';

it('renders Switch view', () => {
	expect.assertions(2);

	const first = renderer.create(<Switch value={true} valueChanged={() => { }} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<Switch value={false} valueChanged={() => { }} />).toJSON();
	expect(second).toMatchSnapshot();

});
