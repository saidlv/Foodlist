import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { shallowEqual, useSelector } from 'react-redux';
import { ReduxState } from '@App/Redux/StateFormat';
import { Text } from 'react-native';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { translate } from '@FoodListCore/I18n';
import SessionManager from '@FoodListCore/Services/SessionManager';
import { colors, margins, resetNavigation } from '@FoodListCore/Global/GlobalProps';
import FLIcon, { FLIconProps } from '@FoodListCore/Components/FLIcon';
import { Divider, Menu } from 'react-native-paper';
import ProfileImage from '@FoodListCore/Components/ProfileImage';
import { REQUEST_LOGIN_ONLY_EVENT } from '@FoodListCore/Flows/RequestAuth';
import { NetworkNavigation } from '@FoodListCore/Network/NetworkManager';
import { useFLLinkProps } from '@FoodListCore/Components/FLLink';

type MenuContentProps = {
	title: string
} & FLIconProps
const ItemContent = ({ title, ...iconProps }: MenuContentProps) => {
	return (
		<View style={itemStyles.container}>
			<FLIcon size={16} color={colors.foodlist} {...iconProps} />
			<Text selectable={false} style={itemStyles.title}>{title}</Text>
		</View>
	)
}
const itemStyles = StyleSheet.create({
	container: {
		flexDirection: "row",
		alignItems: "center",
		padding: 10,
	},
	title: {
		marginLeft: 8,
	},
})

type MenuItemProps = {
	onPress: () => void
} & MenuContentProps
const MenuItem = ({ onPress, ...contentProps }: MenuItemProps) => {
	return (
		<TouchableRipple onPress={onPress}>
			<ItemContent {...contentProps} />
		</TouchableRipple>
	)
}

type MenuLinkProps = {
	linkProps?: any
} & MenuContentProps
const MenuLink = ({ linkProps, ...contentProps } : MenuLinkProps) => {
	return (
		<View onClick={linkProps.onPress} onPress={linkProps.onPress} {...linkProps}>
			<ItemContent {...contentProps} />
		</View>
	)
}

const foregroundColor = colors.lightGrey

const ToolbarLogin = React.memo(() => {
	const { user, emitter } = useSelector(React.useCallback((state: ReduxState) => {
		return {
			user: state.currentUser,
			emitter: state.emitter,
		}
	}, []), shallowEqual)

	const [menuVisible, setMenuVisible] = React.useState(false)
	const openMenu = React.useCallback(() => setMenuVisible(true), [])
	const closeMenu = React.useCallback(() => setMenuVisible(false), [])

	const useLink = (to: string) => {
		const { onPress, ...props } = useFLLinkProps(to)
		return {
			onPress: (e: any) => {
				onPress(e)
				closeMenu()
			},
			...props,
		}
	}

	const showLogin = React.useCallback(() => {
		emitter.emit(REQUEST_LOGIN_ONLY_EVENT, () => {
			//resetNavigation(NetworkNavigation.navigation!, "Home")
			if(Platform.OS == "web") {
				window.location.href = window.location.href
			}
		})
	}, [])

	const logout = React.useCallback(() => {
		SessionManager.logout()
		if(NetworkNavigation.navigation) {
			resetNavigation(NetworkNavigation.navigation, "Home")
		}
	}, [])

	const profileLinkProps = useLink("/profile")
	const myOrdersLinkProps = useLink("/my-orders")
	const myBookingsLinkProps = useLink("/my-bookings")
	const myAddressesLinkProps = useLink("/my-addresses")
	const paymentMethodsLinkProps = useLink("/payment-methods")

	return (
		<>
			{user ? (
			<View style={{ flexDirection: "column", marginRight: margins.pagePadding }}>
				<TouchableRipple borderless onPress={openMenu} style={styles.userButton}>
					<ProfileImage source={user.photo} />
					<Text selectable={false} style={styles.text}>{user.username}</Text>
					<FLIcon materialIcon="arrow-drop-down" color={foregroundColor} size={18} />
				</TouchableRipple>
				<Menu
					visible={menuVisible}
					contentStyle={{ marginTop: 3 }}
					onDismiss={closeMenu}
					anchor={<View style={styles.fakeAnchor} />}
				>
					<MenuLink title={translate("userProfile")} materialCommunityIcon="account" linkProps={profileLinkProps} />
					<MenuLink title={translate("myOrders")} materialIcon="shopping-bag" linkProps={myOrdersLinkProps} />
					<MenuLink title={translate("myBookings")} materialIcon="book-online" linkProps={myBookingsLinkProps} />
					<MenuLink title={translate("myAddresses")} materialIcon="location-pin" linkProps={myAddressesLinkProps} />
					<MenuLink title={translate("paymentMethods")} materialIcon="payments" linkProps={paymentMethodsLinkProps} />
					<Divider />
					<MenuItem onPress={logout} title={translate("logout")} materialIcon="logout" />
				</Menu>
			</View>
			) : (
				<TouchableRipple onPress={showLogin}>
					<Text style={styles.text}>{translate("login")}</Text>
				</TouchableRipple>
			)}
		</>
	)
});

const styles = StyleSheet.create({
	text: {
		padding: margins.vertical,
		color: foregroundColor,
		fontWeight: "bold",
	},
	userButton: {
		paddingHorizontal: margins.vertical,
		flexDirection: "row",
		alignItems: "center",
		borderRadius: 8,
		paddingVertical: 5,
		backgroundColor: colors.withAlpha(colors.black, 0.1),
	},
	fakeAnchor: {
		width: 1,
		height: 1,
	},
});

export default ToolbarLogin;
