import React from 'react';
import 'react-native';
import ToolbarLogin from './index';

import renderer from 'react-test-renderer';

it('renders ToolbarLogin view', () => {
	//expect(renderer.create(<ToolbarLogin />)).toMatchSnapshot(); //TODO: add ToolbarLogin props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<ToolbarLogin pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<ToolbarLogin pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
