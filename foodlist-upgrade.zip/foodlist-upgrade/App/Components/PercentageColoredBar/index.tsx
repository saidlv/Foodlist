import React from 'react';
import { View, Text } from 'react-native';
import styles from './Style';
import { translate } from '@App/I18n';

/**
 * @param width: [...] width of the colored part for each rating

 * @return a bar colored by the percentage defined in width
 */

type PercentageColoredBarProps = {
	percentage: Array<{
		description: string,
		width: string
	}>
}

export default class PercentageColoredBar extends React.PureComponent<PercentageColoredBarProps> {
	render() {
		return (
			<View>
				{this.props.percentage.map((item, index) => {
					return (<View style={[styles.container, { marginBottom: (index == this.props.percentage.length - 1) ? 0 : 10 }]} key={index}>
						<View style={styles.column}>
							<Text style={styles.bigText}>{(5 - index)} {translate(index == 4 ? "star" : "stars").toUpperCase()}</Text>
							<Text style={styles.smallText}>{item.description.toUpperCase()}</Text>
						</View>
						<View style={styles.barContainer}>
							<View style={{ width: "100%", padding: 4 }}>
								<View style={[{ width: item.width }, styles.percentageBar]} />
							</View>
						</View>
						<Text style={styles.percentageText}>{item.width}</Text>
					</View>
					)
				})}
			</View>
		)
	}
}
