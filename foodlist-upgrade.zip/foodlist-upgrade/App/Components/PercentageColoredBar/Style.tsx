import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		flexDirection: 'row',
		width: '100%',
		justifyContent: 'space-between',
		alignItems: 'center'
	},
	column: {
		flexDirection: 'column',
		flex: 0,
		justifyContent: 'center',
		marginLeft: 22,
		width: 81,
		height: 24
	},
	bigText: {
		fontSize: 10,
		fontWeight: "bold",
		fontStyle: "normal",
		lineHeight: 12,
		letterSpacing: 0,
		color: colors.blackText
	},
	smallText: {
		fontSize: 10,
		fontStyle: "normal",
		lineHeight: 12,
		letterSpacing: 0,
		color: colors.darkGreyText
	},
	barContainer: {
		marginLeft: 16,
		marginRight: 16,
		flex: 1,
		alignItems: 'stretch',
		borderRadius: 4,
		height: 24,
		backgroundColor: colors.lightGrey,
		borderStyle: "solid",
		borderWidth: 1,
		borderColor: colors.darkGreyBorder,
		justifyContent: 'center',
		alignSelf: 'flex-start'
	},
	percentageBar: {
		backgroundColor: colors.orangeBar,
		borderRadius: 2,
		height: 16
	},
	percentageText: {
		width: 45,
		marginRight: 22,
		fontSize: 12,
		fontWeight: "bold",
		textAlign: 'right',
		color: colors.darkGreyText,
		fontStyle: "normal",
		lineHeight: 12,
		letterSpacing: 0,
	}
})
