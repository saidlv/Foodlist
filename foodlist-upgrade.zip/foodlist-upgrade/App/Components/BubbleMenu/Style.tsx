import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	title: {
		width: "100%",
		backgroundColor: colors.lightGrey,
		borderWidth: 1,
		borderStyle: "solid",
		borderColor: colors.darkGreyBorder,
		justifyContent: 'center',
		height: 25
	},
	titleStyle: {
		fontSize: 10,
		fontWeight: "bold",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText,
		marginLeft: 20
	},
	displayer: {
		paddingLeft: 20,
		paddingTop: 14,
		paddingBottom: 14,
		flex: 1,
		flexDirection: 'row',
		display: "flex",
		alignItems: 'center',
		flexWrap: "wrap"
	},
	bubble: {
		backgroundColor: colors.lightGrey,
		borderWidth: 1,
		borderColor: colors.darkGreyBorder,
		borderRadius: 12,
		borderStyle: "solid",
		justifyContent: 'center',
		marginRight: 12,
		marginTop: 6,
		marginBottom: 6,
		paddingTop: 6,
		paddingBottom: 6,
		paddingLeft: 12,
		paddingRight: 12
	},
	bubbleText: {
		fontSize: 10,
		fontWeight: "bold",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText
	}
})
