import React from 'react';
import { View, Text } from 'react-native';
import styles from './Style';
import { translate } from '@App/I18n';

/**
 * @param bubbleInfo: [{title, ['textEl1', 'textEl2', ...]}] json array containing the info that needs to be displayed in the tab

 * @return a top bar containing the content specified by paramater
 */

export type BubbleItem = {
	label_it: string
}

export type BubbleElements = {
	title: string,
	bubbleElements: Array<BubbleItem>
}

type BubbleMenuProps = {
	bubbleInfo: Array<BubbleElements>
}

export default class BubbleMenu extends React.PureComponent<BubbleMenuProps, {}> {
	render() {
		return (
			<View>
				{this.props.bubbleInfo.map((item, index) => {
					return (
						<View key={index}>
							{(item.bubbleElements.length != 0) && (
								<View>
									<View style={styles.title}>
										<Text style={styles.titleStyle}>{item.title}</Text>
									</View>
									<View style={styles.displayer}>
										{item.bubbleElements.map((bubbleItem, index) => {
											return (
												<View key={index} style={styles.bubble}>
													<Text style={styles.bubbleText}>{bubbleItem.label_it}</Text>
												</View>
											)
										})}
									</View>
								</View>
							)}
						</View>
					)
				})}
			</View>
		)
	}
}
