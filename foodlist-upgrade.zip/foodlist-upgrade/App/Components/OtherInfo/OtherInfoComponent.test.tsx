import React from 'react';
import 'react-native';
import OtherInfo from './index';

import renderer from 'react-test-renderer';

it('renders OtherInfo view', () => {
  expect.assertions(3);

  const first = renderer.create(<OtherInfo />).toJSON();
  expect(first).toMatchSnapshot();

  const second = renderer.create(<OtherInfo otherInfo={[]} />).toJSON();
	expect(second).toMatchSnapshot();
	
	const third = renderer.create(<OtherInfo otherInfo={[
		{
			title: "Test",
			bubbleElements: [
				{ label_it: "PIPPO" },
				{ label_it: "PLUTO"}
			]
		}
	]} />).toJSON();
  expect(third).toMatchSnapshot();
});
