import React, { Component } from 'react';
import { View, Text } from 'react-native';
import { colors } from '@Global/GlobalProps';

/**
 * @param min: starting value
 * @param max: max value
 * @param current: current value
 * @return graphical representation of the progress
 */

type ProgressIndicatorProps = {
	current: number,
	min: number,
	max: number
}

export default class ProgressIndicator extends React.PureComponent<ProgressIndicatorProps> {
	constructor(props: ProgressIndicatorProps) {
		super(props)
	}
	render() {
		let current = this.props.current - this.props.min
		let end = this.props.max - this.props.min
		let perc = current / end * 100
		if (perc < 0) {
			perc = 0
		}
		if (perc > 100) {
			perc = 100
		}
		return (
			<View style={{ flexDirection: "row", width: "100%" }}>
				<View style={{ flex: 1 }}>
					<View style={{ width: "100%", borderRadius: 4, minHeight: 8, backgroundColor: colors.greyBorder }}>
						<View style={{ width: perc + "%", backgroundColor: colors.red, minHeight: 8, borderRadius: 4 }}></View>
					</View>
				</View>
			</View>
		);
	}
}
