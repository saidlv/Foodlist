import { currentLocale, translate } from '@App/I18n';
import { getMomentTime, HOUR_FORMAT, momentIsToday, SERVER_DATETIME_FORMAT, SERVER_DATE_FORMAT, todayDay } from '@FoodListCommon/DateManager';
import { buildArray, colors, momentFromDateAndTime, toFixed, toUpperLowerCase } from '@FoodListCommon/utils';
import DropdownMenu, { CellComponent } from '@FoodListCore/Components/DropdownMenu';
import FormActionButton from '@FoodListCore/Components/FormActionButton';
import SheetPopup from '@FoodListCore/Components/SheetPopup';
import TimeIcon from '@FoodListCore/Components/TimeIcon';
import { margins } from '@FoodListCore/Global/GlobalProps';
import moment from 'moment';
import React, { useMemo, useState, useCallback, useEffect } from 'react';
import { Dimensions, Text, View } from 'react-native';
import { RadioButton } from 'react-native-paper';

type Props = {
	visible: boolean
	maxDaysBefore?: number
	onDateChanged: (date: moment.Moment | null) => void
	onClose: () => void
	showNowOption?: boolean
}

const getTime = () => {
	const now = moment()
	return now.clone().add(60 - now.get("minutes"), "minutes")
}

const getDayLabel = (date: moment.Moment) => {
	if(momentIsToday(date)) {
		return translate("today", { weekday: date.format("D MMMM") })
	} else if(momentIsToday(date.clone().subtract(1, "day"))) {
		return translate("tomorrow", { weekday: date.format("D MMMM") })
	}
	return toUpperLowerCase(date.format("dddd D MMMM"))
}

const DatetimePickerPopup = React.memo((props: Props) => {
	const { visible } = props

	const [nowSelected, setNowSelected] = useState(false)
	const [date, setDate] = useState<string>(getTime().format(SERVER_DATE_FORMAT))
	const [time, setTime] = useState<string>(getTime().format("HH:mm"))
	//const [timePickerVisible, setTimePickerVisible] = useState(false) 

	const onSave = useCallback(() => {
		if(nowSelected) {
			props.onDateChanged(null)
		} else {
			props.onDateChanged(moment(date + " " + time, SERVER_DATETIME_FORMAT))
		}
	}, [date, time, nowSelected])

	const [dropdownWidth, dropdownMaxHeight] = useMemo(() => {
		const window = Dimensions.get("window")
		const width = (window.width - 10) / 2 - margins.pagePadding
		const maxHeight = window.height * 0.85
		return [width, maxHeight]
	}, [])

	const days = useMemo(() => {
		let key = 0
		const date = getTime()
		const options = []
		const startsFromTomorrow = moment().format(SERVER_DATE_FORMAT) != getTime().format(SERVER_DATE_FORMAT)
		const numDays = (props.maxDaysBefore || 6) - (startsFromTomorrow ? 1 : 0) //altrimenti se sono passate le 23 gli viene fuori anche il 7° giorno da oggi che non deve succedere
		while(key <= numDays) {
			options.push({
				label: getDayLabel(date),
				key: (key++).toString(),
				value: date.format(SERVER_DATE_FORMAT)
			})
			date.add(1, "day")
		}
		return options
	}, [props.maxDaysBefore])

	const hourOptions = useMemo(() => {
		if(getTime().format(SERVER_DATE_FORMAT) == date) {
			const min = getTime()
			const hour = min.get("hours")
			//const minutes = min.get("minutes")
			return buildArray(24-hour, (index => {
				const val = toFixed(index + hour, 2) || ""
				return {
					key: val,
					label: val,
					value: val
				}
			}))
		}
		return buildArray(24, (index => {
			const val = toFixed(index, 2) || ""
			return {
				key: val,
				label: val,
				value: val
			}
		}))
	}, [date])



	useEffect(() => {
		setNowSelected(false)
	}, [props.visible])

	if(!visible) return <></>

	const hour = time.substr(0, 2)
	const minutes = time.substr(3, 2)

	return (
		<>
		<SheetPopup
			visible={visible}
			actions={{
				onTapOutside: props.onClose
			}}
			fitContent
			enablePanning
		>
			<View style={{ /* height: "100%", */ flexDirection: "column", paddingVertical: 10 }}>
				<View>
					<RadioButton.Group
						value={nowSelected ? "now" : "future"}
						onValueChange={(value) => setNowSelected(value == "now")}
					>
						<RadioButton.Item
							value={"now"}
							label={translate("now")}
							mode="android"
							color={colors.blueMenu}
						/>
						<RadioButton.Item
							value={"future"}
							label={"Programma per dopo"}
							mode="android"
							color={colors.blueMenu}
						/>
					</RadioButton.Group>
				</View>
				<View style={{ flexDirection: "row", height: 40, marginHorizontal: margins.pagePadding, marginTop: 10, opacity: nowSelected ? 0.5 : 1 }}>
					<View style={{ flex: 1, marginRight: 5 }}>
						<DropdownMenu
							initialLabel={getDayLabel(moment(date, SERVER_DATE_FORMAT))}
							style={{ height: "100%" }}
							dropdownStyle={{ width: dropdownWidth }}
							onValueChange={(date) => setDate(date)}
							options={days}
						/>
					</View>
					<View style={{ flex: 1, marginLeft: 5, flexDirection: "row", alignItems: "center" }}>

						{/* <CellComponent
							label={time || translate("now")}
							style={{ height: "100%" }}
							onPress={() => setTimePickerVisible(true)}
						/> */}
						<TimeIcon time={moment(time, HOUR_FORMAT)} outline color={colors.greyIcon} size={20} />
						<View style={{ flex: 1, marginLeft: 5 }}>
							<DropdownMenu
								style={{ height: "100%" }}
								initialLabel={time.substr(0, 2)}
								dropdownStyle={{ width: dropdownWidth/2 - 15 }}
								onValueChange={(hour) => setTime(hour + ":" + minutes)}
								options={hourOptions}
							/>
						</View>
						<View style={{ flex: 1, marginLeft: 2 }}>
							<DropdownMenu
								style={{ height: "100%" }}
								dropdownStyle={{ width: dropdownWidth/2 - 15 }}
								initialLabel={time.substr(3, 2)}
								onValueChange={(minutes) => setTime(hour + ":" + minutes)}
								options={buildArray(4, (index => {
									const val = toFixed(index * 15, 2) || ""
									return {
										key: val,
										label: val,
										value: val
									}
								}))}
							/>
						</View>
					</View>
				</View>
				<View style={{flex: 0, paddingTop: 10, paddingHorizontal: margins.pagePadding }}>
					<FormActionButton
						noPadding
						full
						title={translate("save")}
						onPress={onSave}
					/>
				</View>
				{/* <DateTimePicker
					mode="time"
					date={(time ? getMomentTime(time) : moment()).toDate()}
					isVisible={timePickerVisible}
					locale={currentLocale(true)}
					confirmTextIOS={translate("confirm")}
					cancelTextIOS={translate("cancel")}
					headerTextIOS={translate("selectTime")}
					is24Hour={true}
					minimumDate={date == todayDay() ? new Date() : undefined}
					minuteInterval={5}
					onConfirm={(selectedDate) => {
						setTimePickerVisible(false)
						const time = moment(selectedDate).format(HOUR_FORMAT)
						setTime(time)
					}}
					onCancel={() => setTimePickerVisible(false)}
				/> */}
			</View>
		</SheetPopup>
		</>
	);

});

export default DatetimePickerPopup;
