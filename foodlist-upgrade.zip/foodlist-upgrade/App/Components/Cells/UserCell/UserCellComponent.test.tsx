import React from 'react';
import 'react-native';
import UserCell from './index';

import renderer from 'react-test-renderer';

it('renders UserCell view', () => {
  expect(renderer.create(<UserCell item={{id: 1, username: "Pippo"}} />)).toMatchSnapshot(); //TODO: add UserCell props with random values

  /*
  //if view displays different outputs when passing different values as props use:

  expect.assertions(2); // increase '2' if you add more assertions

  const first = renderer.create(<UserCell pippo={true} />).toJSON();
  expect(first).toMatchSnapshot();

  const second = renderer.create(<UserCell pippo={false} />).toJSON();
  expect(second).toMatchSnapshot();
  */
});
