import React from 'react';
import { userImage } from '@Global/GlobalProps';
import { User } from '@Models/User';
import CellContainer from '../CellContainer';
import ResultListItem from '@App/Components/ResultListItem';
import { getCount } from '../CommonFunctions';
import SmallFollowButton from '@App/Components/FollowButton/SmallFollowButton';

type UserCellProps = {
	item: User
}

const getName = (item: User) => {
	let strings: Array<string> = []
	if (item.first_name) {
		strings.push(item.first_name + " ")
	}
	if (item.last_name) {
		strings.push(item.last_name + " ")
	}
	return strings.join("").trim()
}

const twoLines = (item: User): boolean => {
	return !!item.first_name || !!item.last_name
}

export default class UserCell extends React.PureComponent<UserCellProps> {
	render() {
		const item = this.props.item
		return (
			<CellContainer>
				<ResultListItem
					source={userImage(item.photo ?? undefined, true)}
					afterTitle={getName(item)}
					type={2}
					twoLines={twoLines(item)}
					title={item.username}
					secondLine={getCount(item)}
					thirdLine={(item.user_level && item.user_level.label_it) || ""}
					showCategory={false}
					rightView={() => (
						<SmallFollowButton
							userName={item.username}
							userId={item.id}
							following={item.following_user ?? false}
							noPadding
						/>
					)}
					onPress={(show) => { show("ProfilePage", { user_id: item.id, item: item }) }} />
			</CellContainer>
		)
	}
}