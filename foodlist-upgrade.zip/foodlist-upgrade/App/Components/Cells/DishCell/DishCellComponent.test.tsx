import React from 'react';
import 'react-native';
import DishCell from './index';

import renderer from 'react-test-renderer';
import { Dish } from '@Models/Dish';

it('renders DishCell view', () => {
  expect(renderer.create(<DishCell item={{} as Dish} />)).toMatchSnapshot(); //TODO: add DishCell props with random values

  /*
  //if view displays different outputs when passing different values as props use:

  expect.assertions(2); // increase '2' if you add more assertions

  const first = renderer.create(<DishCell pippo={true} />).toJSON();
  expect(first).toMatchSnapshot();

  const second = renderer.create(<DishCell pippo={false} />).toJSON();
  expect(second).toMatchSnapshot();
  */
});
