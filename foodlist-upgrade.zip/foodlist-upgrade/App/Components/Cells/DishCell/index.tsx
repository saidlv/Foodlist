import React from 'react';
import { Dish } from '@Models/Dish';
import CellContainer from '../CellContainer';
import ResultListItem from '@App/Components/ResultListItem';
import { imageFood, formatPrice, getDishRestaurant } from '@FoodListCore/Global/GlobalProps';
import { getCount, formatCategories } from '../CommonFunctions';
import { translate } from '@App/I18n';
import { printableDistance } from '@FoodListCore/Global/CommonStuff/CommonFunctions';

type DishCellProps = {
	item: Dish,
	hideDescription?: boolean,
	onPress?: (dish: Dish) => void,
	callbackOpenCell?: () => void
}

export default class DishCell extends React.PureComponent<DishCellProps> {
	render() {
		const item = this.props.item
		return (
			<CellContainer>
				<ResultListItem
					source={imageFood(item, true)}
					hideDescription={this.props.hideDescription}
					title={item.name}
					type={1}
					rating={item.reviews_rating || 0}
					secondLine={getCount(item)}
					thirdLine={translate("ofRestaurant")}
					thirdLineBold={getDishRestaurant(item)?.name}
					blueText={formatPrice(item.price)}
					bottomRightText={printableDistance(item.distance)}
					categories={item.description}
					showCategory={true}
					onPress={(show) => {
						if (this.props.onPress !== undefined && this.props.onPress(item)) {
							//console.log("Handled")
						} else {
							show("DishInfo", { id: item.id, dish: item, callbackOpenCell: this.props.callbackOpenCell })
						}
					}}
					callbackOpenCell={this.props.callbackOpenCell}
					warningText={item.available ? undefined : translate("notAvailable").toUpperCase()}
				/>
			</CellContainer>
		)
	}
}