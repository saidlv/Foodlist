import { translate } from "@App/I18n"
import { Category } from "@Models/Category"
import { Restaurant } from "@Models/Restaurant"
import { Dish } from "@Models/Dish"
import { User } from "@Models/User"

export const formatCategories = (categories: Category[] | undefined) => {
	let labels = (categories || []).map((item) => {
		return item.label_it
	})
	let stringCategories = labels.join(", ")
	return stringCategories.length == 0 ? "" : stringCategories.toUpperCase()
}

const getInt = (num: string | number | undefined) => {
	if(num) {
		const str = num.toString().replace(String.fromCharCode(8206), "").replace(".", "")
		const a = parseInt(str, 10)
		/* if(isNaN(a)) {
			return parseInt(str.substring(1), 10)
		} */
		return a
	}
	return 0
}

export const stringReviewsCount = (count: number) => {
	return count.toString() + " " +  ((count == 1) ? translate("review") : translate("reviews")).toUpperCase()
}

export const getRestaurantCount = (item: Restaurant) => {
	return item.total_reviews_count ?? 0
	//return getInt(item.tripadvisor_number) + getInt(item.google_number) + getInt(item.the_fork_number) + getInt(item.facebook_number) + (item.reviews_count || 0)
}

export const getCount = (item: Restaurant | Dish | User) => {
	let count = 0
	if("total_reviews_count" in item) {
		count = getRestaurantCount(item)
	}
	else if (item.reviews_count) {
		count = item.reviews_count
	}
	return stringReviewsCount(count)
}
