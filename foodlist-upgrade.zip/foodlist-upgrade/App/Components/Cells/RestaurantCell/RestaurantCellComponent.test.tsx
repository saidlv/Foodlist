import React from 'react';
import 'react-native';
import RestaurantCell from './index';

import renderer from 'react-test-renderer';
import { Restaurant } from '@Models/Restaurant';

it('renders RestaurantCell view', () => {
  expect(renderer.create(<RestaurantCell item={{} as Restaurant} />)).toMatchSnapshot(); //TODO: add RestaurantCell props with random values

  /*
  //if view displays different outputs when passing different values as props use:

  expect.assertions(2); // increase '2' if you add more assertions

  const first = renderer.create(<RestaurantCell pippo={true} />).toJSON();
  expect(first).toMatchSnapshot();

  const second = renderer.create(<RestaurantCell pippo={false} />).toJSON();
  expect(second).toMatchSnapshot();
  */
});
