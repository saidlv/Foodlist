import React from 'react';
import { Restaurant } from '@Models/Restaurant';
import CellContainer from '../CellContainer'
import { RestaurantInfos } from '@FoodListCore/Components/RestaurantHeader';
import { useNavigation } from '@react-navigation/core';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { StyleSheet, View } from 'react-native';
import FLImage from '@FoodListCore/Components/FLImage';
import { imageRestaurant, margins } from '@FoodListCore/Global/GlobalProps';

//WARNING: this props are used in RestaurantItem and also RestaurantCell
type RestaurantItemProps = {
	item: Restaurant,
	callbackOpenCell?: () => void
	onPress?: (item: Restaurant) => void,
}

export const RestaurantItem = React.memo((props: RestaurantItemProps) => {
	const navigation = useNavigation()
	const item = props.item
	const onPress = React.useCallback(() => {
		const { item } = props
		if (props.onPress !== undefined && props.onPress(item)) {
			//console.log("Handled")
		} else {
			navigation.push("NewRestaurant", { id: item.id, restaurant: item, callbackOpenCell: props.callbackOpenCell })
		}
	}, [])

	return (
		<TouchableRipple onPress={onPress} style={styles.cell}>
			<FLImage source={imageRestaurant(props.item, true)} style={styles.image} />
			<View style={{ flex: 1 }}>
				<RestaurantInfos
					restaurant={item}
					route={null}
					showCategories
					showOpenNow
				/>
			</View>
		</TouchableRipple>
	)
})

const styles = StyleSheet.create({
	cell: {
		flexDirection: "row",
		alignItems: "center",
		paddingHorizontal: margins.pagePadding,
		paddingVertical: margins.vertical,
	},
	image: {
		marginRight: margins.pagePadding,
		width: 64,
		height: 64,
		borderRadius: 10,
	},
})

export class RestaurantCell extends React.PureComponent<RestaurantItemProps> {
	render() {
		return (
			<CellContainer>
				<RestaurantItem
					item={this.props.item}
					callbackOpenCell={this.props.callbackOpenCell}
					onPress={this.props.onPress}
				/>
			</CellContainer>
		)
	}
}

export default RestaurantCell;
