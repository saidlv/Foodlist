import React, { ReactNode } from 'react';
import {StyleSheet, View} from 'react-native';
import { colors } from '@FoodListCore/Global/GlobalProps';

type Props = {
	children: ReactNode
}

const CellContainer = (props: Props) => {
  return (
		<View style={styles.fullWidth}>
			<View>
				{props.children}
			</View>
			<View style={styles.border} />
		</View>
	)
};

const styles = StyleSheet.create({
  fullWidth: {
		width: "100%"
	},
	border: {
		borderStyle: "solid",
		height: 1,
		backgroundColor: colors.timesGreyBorder,
		marginLeft: 20,
		paddingRight: 20
	}
});

export default React.memo(CellContainer)
