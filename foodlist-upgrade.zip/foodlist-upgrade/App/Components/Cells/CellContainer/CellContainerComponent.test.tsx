import React from 'react';
import 'react-native';
import CellContainer from './index';

import renderer from 'react-test-renderer';
import { Text, View } from 'react-native';

it('renders CellContainer view', () => {
  expect(renderer.create(<CellContainer>
		<View>
			<Text>CIAO PIPPO</Text>
		</View>
	</CellContainer>)).toMatchSnapshot();
});
