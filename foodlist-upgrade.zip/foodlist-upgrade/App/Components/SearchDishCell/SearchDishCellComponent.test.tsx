import React from 'react';
import 'react-native';
import SearchDishCell from './index';

import renderer from 'react-test-renderer';

it('renders SearchDishCell view', () => {
	//expect(renderer.create(<SearchDishCell />)).toMatchSnapshot(); //TODO: add SearchDishCell props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<SearchDishCell pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<SearchDishCell pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
