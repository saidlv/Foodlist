import GalleryHeader from '@FoodListCore/Components/GalleryHeader';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { printableDistance } from '@FoodListCore/Global/CommonStuff/CommonFunctions';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import { DishInfos } from '@FoodListCore/Pages/NewDishPage';
import { Dish } from '@Models/Dish';
import { useNavigation } from '@react-navigation/core';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

type Props = {
	dish: Dish
	changeVerticalScrollEnabled?: (enabled: boolean) => void
}

const SearchDishCell = React.memo(({ dish, changeVerticalScrollEnabled }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	const navigation = useNavigation()
	const onPress = useCallback(() => {
		navigation.navigate("DishInfo", { dish })
	}, [])
	return (
		<View style={styles.padding}>
			<View style={styles.cell}>
				<View style={{ borderRadius: 6, overflow: "hidden"}}>
					<TouchableRipple
						onPress={onPress}
					>
						<GalleryHeader
							disableFullscreen
							item={dish}
							type="dish"
							galleryHeight={160}
							carouselProps={React.useMemo(() => ({
								onPress,
								changeVerticalScrollEnabled
							}), [])}
						/>
						<View style={styles.content}>
							<DishInfos dish={dish} reviewsDisabled initialPrice={dish.price} discountedPrice={dish.price} />
						</View>
					</TouchableRipple>
				</View>
			</View>
		</View>
	);
});

const styles = StyleSheet.create({
	padding: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: margins.pagePadding / 2
	},
	cell: {
		borderRadius: 6,
		backgroundColor: colors.white,
		...CommonStyle.shadow
	},
	content: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: margins.vertical,
	},
	row: {
		flexDirection: "row",
		alignItems: "center",
	},
	restName: {
		flex: 1,
	},
});

export default SearchDishCell;
