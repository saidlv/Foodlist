import React, { useEffect } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { REQUEST_LOGIN_ONLY_EVENT, REQUEST_LOGIN_AND_PHONE_EVENT, REQUEST_PHONE_EVENT } from '@FoodListCore/Flows/RequestAuth';
import AddPhoneNumberPage from '@FoodListCore/Pages/AddPhoneNumberPage';
import InsertCodePage from '@FoodListCore/Pages/InsertCodePage';
import SheetPopup from '@FoodListCore/Components/SheetPopup';
import LoginComponent from '@FoodListCore/Components/LoginPage';
import ForgotPassword from '@FoodListCore/Pages/ForgotPassword';
import CompleteSocialRegistrationPage from '@FoodListCore/Pages/CompleteSocialRegistrationPage';
import { RestaurantParamList } from '@FoodListCore/Flows/Restaurant';
import { shallowEqual, useSelector } from 'react-redux';
import FLIcon from '@FoodListCore/Components/FLIcon';
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import { ReduxState } from '@App/Redux/StateFormat';
import { User } from '@Models/User';
import IconButton from '@FoodListCore/Components/IconButton';

const ModalLogin = React.memo(() => {

	const { user, emitter } = useSelector(React.useCallback((state: ReduxState) => {
		return {
			user: state.currentUser,
			emitter: state.emitter,
		}
	}, []), shallowEqual)

	const self = React.useMemo(() => ({
		route: null as null | {
			params: RestaurantParamList["CompleteSocialRegistration"],
		},
		confirmCodeParams: null as null | RestaurantParamList["ConfirmCode"],
		onLoginSuccessful: null as (null | (() => void)),
		onPhoneVerified: null as (null | (() => void)),
	}), [])

	const [loginShown, setShowLogin] = React.useState(false)

	const [selectedPage, setSelectedPage] = React.useState<"" | "forgot" | "complete" | "insert_phone" | "confirm_code">("")

	const showLogin = React.useCallback(() => {
		setSelectedPage("")
		setShowLogin(true)
	}, [])
	const hideLogin = React.useCallback(() => {
		setShowLogin(false)
		self.onLoginSuccessful = null
		self.onPhoneVerified = null
	}, [])

	const showForgotPassword = React.useCallback(() => {
		setSelectedPage("forgot")
	}, [])
	const showCompleteRegistration = React.useCallback((params) => {
		self.route = {
			params,
		}
		setSelectedPage("complete")
	}, [])
	const showNextPage = React.useCallback((loggedUser?: User) => {
		console.log("onLoginSuccessful")
		self.onLoginSuccessful?.()
		self.onLoginSuccessful = null
		if(self.onPhoneVerified) {
			if((loggedUser?.verified && loggedUser?.phone)) {
				setSelectedPage("")
				self.onPhoneVerified()
				hideLogin()
			} else {
				self.onLoginSuccessful = self.onPhoneVerified
				self.onPhoneVerified = null
				setSelectedPage("insert_phone")
			}
		} else {
			setSelectedPage("")
			hideLogin()
		}
	}, [])

	useEffect(() => {
		const loginOnlyCb = (successCb: () => void) => {
			console.log("login only")
			self.onLoginSuccessful = successCb
			showLogin()
		}
		const requestPhoneCb = (successCb: () => void) => {
			console.log("requestPhone")
			setSelectedPage("insert_phone")
			self.onLoginSuccessful = successCb
			setShowLogin(true)
		}
		const loginAndPhoneCb = (successCb: () => void) => {
			console.log("loginAndPhone")
			setSelectedPage("")
			self.onPhoneVerified = successCb
			//self.onLoginSuccessful = () => requestPhoneCb(successCb)
			showLogin()
		}
		console.log("subscribe")
		emitter.on(REQUEST_LOGIN_ONLY_EVENT, loginOnlyCb)
		emitter.on(REQUEST_PHONE_EVENT, requestPhoneCb)
		emitter.on(REQUEST_LOGIN_AND_PHONE_EVENT, loginAndPhoneCb)
		return () => {
			console.log("unsubscribe")
			emitter.unsubscribe(REQUEST_LOGIN_ONLY_EVENT, loginOnlyCb)
			emitter.unsubscribe(REQUEST_PHONE_EVENT, requestPhoneCb)
			emitter.unsubscribe(REQUEST_LOGIN_AND_PHONE_EVENT, loginAndPhoneCb)
		}
	}, [])

	const closeButton = React.useMemo(() => (
		<IconButton onPress={hideLogin} style={{ alignSelf: "flex-end" }}>
			<FLIcon materialIcon="close" size={18} color={colors.devilGrey} />
		</IconButton>
	), [hideLogin])

	const showBackButton = !!selectedPage && selectedPage != "insert_phone"
	return (
		<>
			<SheetPopup
				visible={loginShown}
				close={hideLogin}
				header={showBackButton && (
					<TouchableOpacity style={styles.row} onPress={() => setSelectedPage(selectedPage == "confirm_code" ? "insert_phone" : "")}>
						<FLIcon materialIcon="arrow-back-ios" color={colors.blueMenu} />
						<Text style={styles.backText}>{translate("back")}</Text>
					</TouchableOpacity>
				)}
				hideHeader={!showBackButton}
			>
				<View style={styles.loginContainer}>
				{selectedPage == "forgot" ? (
					<ForgotPassword
						navigation={{
							goBack: () => setSelectedPage(""),
						}}
					/>
				) : selectedPage == "complete" ? (
					<CompleteSocialRegistrationPage
						route={self.route}
					/>
				) : selectedPage == "insert_phone" ? (
					<AddPhoneNumberPage
						header={<View style={{ marginTop: margins.vertical, marginRight: margins.vertical, marginBottom: -5 }}>{closeButton}</View>}
						navigation={{
							replace: (_, params) => {
								self.confirmCodeParams = params
								setSelectedPage("confirm_code")
							},
							goBack: () => {},
						}}
						route={{ params: { destination: { name: "Fake", params: {} } } }}
					/>
				) : selectedPage == "confirm_code" ? (
					<InsertCodePage
						navigation={{
							replace: showNextPage,
							goBack: showNextPage,
						}}
						route={{ params: self.confirmCodeParams }}
					/>
				) : (
					<LoginComponent
						headerView={(
							<>
								<View style={{ marginTop: -5, marginRight: -5 }}>{closeButton}</View>
								<View style={styles.header}>
									<FLIcon foodlistIcon="menu-logo" color={colors.foodlist} size={22} />
								</View>
							</>
						)}
						showNextPage={showNextPage}
						onForgotPassword={showForgotPassword}
						showCompleteRegistration={showCompleteRegistration}
					/>
				)}
				</View>
			</SheetPopup>
		</>
	);
});

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		alignItems: "center",
	},
	backText: {
		fontWeight: "bold",
		color: colors.blueMenu,
	},
	loginContainer: {
		maxWidth: 360,
	},
	header: {
		alignItems: "center",
		marginBottom: 10,
		marginTop: 10,
	},
});

export default ModalLogin;
