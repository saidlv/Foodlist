import React from 'react';
import { View, Text } from 'react-native';
import SectionedMultiSelect from 'react-native-sectioned-multi-select';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { colors } from '@Global/GlobalProps';
import { translate } from '@App/I18n';
import Styles from './Styles';
import { FilteredKeys } from '@Models/FilteredKeys';

/**
 * @param items: array items
 * @param uniqueKey: key of unique value inside each item, default: id
 * @param displayKey: key to display, default: name
 * @param subKey: subKey, needed when sectioned
 * @param showHeaders: headers for sections
 * @param selectText: placeholder
 * @param searchPlaceholderText: search placeholder
 * @param onItemSelected: callback(selectedItemKey)
 * @param selectedItem: selectedItemKey
 * @param noResultsText: optional
 * @param noItemsText: optional
 */

const searchIcon = <Icon name="review" size={16} color={colors.greyText} style={{ marginLeft: 15, marginRight: 10 }} />
const noCommon = (title: string) => {
	return (
		<View style={{ marginTop: 20, alignItems: 'center', justifyContent: 'center' }}>
			<Text>{title}</Text>
		</View>
	)
}

/**
 * @param allowNewOption: if true add an item which is what the user is writing
 */

/**
 * NOTE: this file is plenty of workarounds to enable a strong typechecking for key props
 * The type 'FilteredKeys' is not enough for TypeScript to understand what I defined but is enough to have a strong typechecking in the files that use this component
 * so inside the definition of SearchableOptions I used "as unknown as ..." to force typescript to understand property types as I defined them here in props
 */
type SearchableOptionsProps<T, P, UniqueKeyType> = {
	items: T[],
	displayKey: string & FilteredKeys<T, string> & FilteredKeys<P, string>,
	uniqueKey: string & FilteredKeys<T, UniqueKeyType>,
	subKey?: string & FilteredKeys<T, Array<P>>,
	allowNewOption?: string,
	selectText?: string,
	showHeaders?: boolean,
	onItemSelected: (item: UniqueKeyType) => void,
	searchPlaceHolderText: string,
	noResultsText?: string,
	noItemsText?: string,
	searchPlaceholderTextColor?: string,
	hideConfirm?: boolean
}

/**
 * @param T: item type (single items element)
 * @param UniqueKeyType: type of unique key
 * @param P: subItem type, type of T[subKey] items
 */
export default class SearchableOptions<T, UniqueKeyType, P = T> extends React.PureComponent<SearchableOptionsProps<T, P, UniqueKeyType>> {
	fontFamily = { fontFamily: 'System' }
	searchableOptions: SectionedMultiSelect<T> | null = null
	
	componentDidMount() {
		const key = this.getDisplayKey();
		//console.log(key, this.props.items);
		this.props.items.sort((a, b) => {
			const first = a[key] as unknown as string
			const second = b[key] as unknown as string
			return (first.toLowerCase() > second.toLowerCase()) ? 1 : -1
		})
	}
	getDisplayKey() {
		return this.props.displayKey
	}
	getSubKey() {
		return this.props.subKey
	}

	filter = (query: string, items?: T[]) => {
		const key = this.getDisplayKey();
		var output: T[] = []
		for (var i in items) {
			const item = items[parseInt(i)];
			const displayValue = item[key] as unknown as string

			let subItems
			let subKey = this.getSubKey()
			if (subKey) {
				subItems = item[subKey] as unknown as Array<P>
				let subItemsResult = {
					[key]: displayValue,
					[subKey]: [],
					[this.props.uniqueKey]: item[this.props.uniqueKey]
				} as unknown as T
				const filteredtems = subItemsResult[subKey] as unknown as Array<P>
				subItems.forEach((subItem) => {
					const subItemText = subItem[key] as unknown as string
					if (subItemText.toLowerCase().includes(query.toLowerCase())) {
						filteredtems.push(subItem);
					}
				})
				output.push(subItemsResult)
			} else {
				if (displayValue.toLowerCase().includes(query.toLowerCase())) {
					output.push(item);
				}
			}
		}

		if (this.props.allowNewOption && this.props.subKey) {
			let newOption = {
				[key]: this.props.allowNewOption,
				[this.props.subKey]: [{
					[key]: query
				}]
			} as unknown as T
			output = [newOption].concat(output);
		}
		return output;
	}

	toggleSelector = () => {
		this.searchableOptions?._toggleSelector();
	}

	render() {
		return (
			<SectionedMultiSelect<T>
				ref={ref => this.searchableOptions = ref}
				items={this.props.items}
				uniqueKey={this.props.uniqueKey}
				displayKey={this.getDisplayKey()}
				subKey={this.props.subKey}
				selectText={this.props.selectText}
				showChips={false}
				showDropDowns
				expandDropDowns
				single
				readOnlyHeadings={this.props.showHeaders}
				onSelectedItemsChange={(selections) => {
					//console.log("Selezioni", selections, selections[0], typeof selections[0])
					this.props.onItemSelected(selections[0])
				}}
				modalWithSafeAreaView={true}
				colors={{
					primary: colors.darkGreyText,
					cancel: colors.greyText,
					itemBackground: colors.greyBorder
				}}
				searchPlaceholderText={this.props.searchPlaceHolderText}
				filterItems={this.filter}
				itemFontFamily={this.fontFamily}
				subItemFontFamily={this.fontFamily}
				searchTextFontFamily={this.fontFamily}
				confirmFontFamily={this.fontFamily}
				styles={Styles}
				searchIconComponent={searchIcon}
				noResultsComponent={noCommon(this.props.noResultsText || translate("noResult"))}
				noItemsComponent={noCommon(this.props.noItemsText || translate("noData"))}
				/* searchPlaceholderTextColor={this.props.searchPlaceholderTextColor}  */
				modalWithTouchable={true}
				hideConfirm={true}
			/>
		)
	}
}
