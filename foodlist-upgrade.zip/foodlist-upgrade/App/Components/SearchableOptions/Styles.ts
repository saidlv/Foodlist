import { colors } from "@FoodListCore/Global/GlobalProps";

export default {
	subItemText: {
		paddingHorizontal: 10,
		paddingLeft: 15,
		paddingVertical: 5,
		color: colors.black
	},
	/* selectedItemText: {
		color: colors.primary
	}, */
	container: {
		marginTop: 'auto',
		marginBottom: 'auto',
		flex: 0,
		minHeight: 400
	},
	selectToggle: {
		height: 0,
		opacity: 0
	},
	selectToggleText: {
		fontSize: 13,
		flex: 1,
		flexGrow: 1,
		minWidth: 115
	},
	subItem: {
		paddingRight: 10
	},
	itemText: {
		color: colors.black,
		fontWeight: 'bold',
		fontSize: 15
	},
	item: {
		padding: 10,
		paddingVertical: 10
	},
	scrollView: {
		padding: 0,
		margin: 0,
		paddingHorizontal: 0
	},
	chipsWrapper: {
		flex: 0,
		flexWrap: 'nowrap'
	}
}