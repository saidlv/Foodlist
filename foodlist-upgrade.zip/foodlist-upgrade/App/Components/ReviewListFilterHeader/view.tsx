import React from 'react';
import { View, Text } from 'react-native';
import InlineSubMenu, { InlineMenuItem } from '@Components/InlineSubMenu';
import TouchableBubbleMenu from '@Components/TouchableBubbleMenu';
import PercentageColoredBar from '@Components/PercentageColoredBar';
import infoBoxStyle from '@Components/InfoBox/InfoBoxStyle'
import StarRating from '@Components/StarRating';
import { colors } from '@Global/GlobalProps';

import styles from '@FoodListCore/Global/CommonStuff/ReviewStyle'
import { Rating } from '@Models/Rating';
import { ReviewsListActions } from '@Models/ReviewsListActions';
import { ReviewDistribution } from '@Models/Review';
import { translate } from '@App/I18n';
import { round } from '@FoodListCore/Global/CommonStuff/CommonFunctions';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';

type ProfileOptions = {
	isProfile: true
}
type CommonOptions = {
	notShowFilter?: boolean
	isDish?: boolean
	itemsInlineSubMenu?: InlineMenuItem[]
}
export type ProfileReviewsFilterOptions = CommonOptions & ProfileOptions
export type InfoReviewsFilterOptions = CommonOptions & {
	isProfile?: boolean
	percentageStarReviews?: ReviewDistribution
	numberReviews: number
	rating?: Rating
	dishRating?: number
}
export type ReviewsFilterOptions = ProfileReviewsFilterOptions | InfoReviewsFilterOptions

type ReviewsListFilterHeaderPageProps = {
	options: ReviewsFilterOptions
	activeButton: number,
	categoryCallback: (index: number) => void,
	activeBubble: number[],
	actions: ReviewsListActions,
	starCallback: (index: number) => void
}

export default class ReviewsListFilterHeaderPage extends React.PureComponent<ReviewsListFilterHeaderPageProps> {
	options: ReviewsFilterOptions

	constructor(props: ReviewsListFilterHeaderPageProps) {
		super(props)
		this.options = props.options
	}
	render() {
		return (
			<View>
				{(!this.options.isProfile) && (
					<View>
						<View style={[styles.header, { marginBottom: -12, marginTop: 10 }]}>
							<Icon name="foodlist" color={colors.foodlist} size={16} />
							<View style={{ flexDirection: "row", alignItems: "center", marginTop: 10, marginBottom: -4 }}>
								<StarRating size={18} rating={(this.options.rating?.rating ?? this.options.dishRating)!} color={colors.starColor} />
								<Text style={[styles.bigText, { fontSize: 20, marginLeft: 10, marginBottom: 0 }]}>{this.options.rating?.roundedRating ?? round(this.options.dishRating ?? 0, 1)}</Text>
							</View>
							{(this.options.numberReviews == 1) && (
								<Text style={styles.smallText}>{this.options.numberReviews} {translate("review").toUpperCase()}</Text>
							)}
							{(this.options.numberReviews != 1) && (
								<Text style={styles.smallText}>{this.options.numberReviews} {translate("reviews").toUpperCase()}</Text>
							)}
						</View>

						{(!this.options.isDish) && (
							<View style={styles.infoView}>
								<View style={infoBoxStyle.flexRow}>
									<View style={infoBoxStyle.halfWidth}>
										<View style={infoBoxStyle.contentContainer}>
											<View style={infoBoxStyle.oppositeRow}>
												<Text style={styles.inlineTitle}>{translate("service")}</Text>
												<View style={infoBoxStyle.inlineContent}>
													<StarRating size={12} color={colors.starColor} rating={this.options.rating!.serviceRating} />
												</View>
											</View>
										</View>
									</View>
									<View style={infoBoxStyle.halfWidth}>
										<View style={infoBoxStyle.contentContainer}>
											<View style={infoBoxStyle.oppositeRow}>
												<Text style={styles.inlineTitle}>{translate("quality")}</Text>
												<View style={infoBoxStyle.inlineContent}>
													<StarRating size={12} color={colors.starColor} rating={this.options.rating!.qualityRating} />
												</View>
											</View>
										</View>
									</View>
								</View>
								<View style={infoBoxStyle.flexRow}>
									<View style={infoBoxStyle.halfWidth}>
										<View style={infoBoxStyle.secondLineContainer}>
											<View style={infoBoxStyle.oppositeRow}>
												<Text style={styles.inlineTitle}>{translate("location")}</Text>
												<View style={infoBoxStyle.inlineContent}>
													<StarRating size={12} color={colors.starColor} rating={this.options.rating!.locationRating} />
												</View>
											</View>
										</View>
									</View>
									<View style={infoBoxStyle.halfWidth}>
										<View style={infoBoxStyle.secondLineContainer}>
											<View style={infoBoxStyle.oppositeRow}>
												<Text style={styles.inlineTitle}>{translate("price")}</Text>
												<View style={infoBoxStyle.inlineContent}>
													<StarRating size={12} color={colors.starColor} rating={this.options.rating!.priceRating} />
												</View>
											</View>
										</View>
									</View>
								</View>
							</View>
						)}

						<View style={styles.marginTopBetween}>
							<PercentageColoredBar
								percentage={[
									{ width: this.options.percentageStarReviews?.[5] + "%", description: translate("excellent") },
									{ width: this.options.percentageStarReviews?.[4] + "%", description: translate("veryGood") },
									{ width: this.options.percentageStarReviews?.[3] + "%", description: translate("good") },
									{ width: this.options.percentageStarReviews?.[2] + "%", description: translate("decent") },
									{ width: this.options.percentageStarReviews?.[1] + "%", description: translate("terrible") }
								]}
							/>
						</View>
					</View>
				)}

				{(!this.options.notShowFilter) && (
					<View style={(!this.options.isProfile) ? styles.marginTopBetween : {}}>
						{(!this.options.isDish) && (
							<InlineSubMenu
								selected={this.props.activeButton}
								categoryCallback={this.props.categoryCallback}
								items={this.options.itemsInlineSubMenu!}
							/>
						)}
						<View style={(!this.options.isDish) ? styles.marginTopBetween : {}}>
							<TouchableBubbleMenu
								selected={this.props.activeBubble}
								bubbleElements={[
									{ text: translate("allReviews"), clickable: true, callback: this.props.starCallback },
									{ text: "5 " + translate("stars"), clickable: true, callback: this.props.starCallback },
									{ text: "4 " + translate("stars"), clickable: true, callback: this.props.starCallback },
									{ text: "3 " + translate("stars"), clickable: true, callback: this.props.starCallback },
									{ text: "2 " + translate("stars"), clickable: true, callback: this.props.starCallback },
									{ text: "1 " + translate("star"), clickable: true, callback: this.props.starCallback }
								]}
							/>
						</View>
					</View>
				)}
			</View>
		)
	}
}
