import React from 'react';
import ReviewListFilterHeaderPage, { ReviewsFilterOptions } from './view';

import UserManager from '@Network/UserManager';
import { ReviewsListActions } from '@Models/ReviewsListActions';
import { ReviewType } from '@Models/ReviewType';

/**
* @param activeButton: index of the active button in the inline menu
* @param activeBubble: index of the active bubble in the star filter
* @param callbackStar
* @param categoryCallback
*/

type ReviewListFilterHeaderProps = {
	actions: ReviewsListActions
	options: ReviewsFilterOptions
	initialTypeFilter?: ReviewType
	initialRatingFilter?: string
}

type ReviewListFilterHeaderState = {
	activeButton: number,
	activeBubble: Array<number>,
	filtersActive: boolean,
	rating: string,
	type: ReviewType,
	loadingReviews: boolean,
}

const getButtonIndex = (typeFilter: ReviewType | undefined): number => {
	if(typeFilter) {
		if(typeFilter == "restaurants") {
			return 1
		}
		if(typeFilter == "dishes") {
			return 2
		}
	}
	return 0
}

const getRatingFilterBubble = (rating: string | undefined): number[] => {
	if(rating) {
		const splitted = rating.split(",")
		return splitted.map(item => {
			return 5 - (parseInt(item) - 1)
		})
	}
	return [0]
}

export default class ReviewListFilterHeader extends React.PureComponent<ReviewListFilterHeaderProps, ReviewListFilterHeaderState> {
	manager: UserManager

	constructor(props: ReviewListFilterHeaderProps) {
		super(props);
		this.manager = new UserManager()

		this.state = {
			type: props.initialTypeFilter || "all",
			activeButton: getButtonIndex(props.initialTypeFilter),
			activeBubble: getRatingFilterBubble(props.initialRatingFilter),
			filtersActive: false,
			rating: props.initialRatingFilter || "",
			loadingReviews: false
		}
	}

	categoryCallback = (index: number) => {
		let category: ReviewType;
		if (this.props.options.isProfile) {
			switch (index) {
				case 0:
					category = "all";
					break;
				case 1:
					category = "restaurants";
					break;
				case 2:
					category = "dishes"
					break;
				default:
					category = "all"
			}
		} else {
			switch (index) {
				case 0:
					category = "all";
					break;
				case 1:
					category = "service";
					break;
				case 2:
					category = "location"
					break;
				case 3:
					category = "quality";
					break;
				case 4:
					category = "price"
					break;
				default:
					category = "all"
			}
		}

		this.setState({
			type: category,
			activeButton: index
		}, async () => {
			this.props.actions.filterCallback(this.state.type, this.state.rating)
		})
	}

	starCallback = (index: number) => {
		let newRating: string
		if(index == 0) {
			newRating = ""
		} else {
			const value = 5 - (index - 1)
			const valueStr = value.toString()
			const { rating } = this.state
			if(rating) {
				const splitted = rating.split(",")
				const itemIndex = splitted.indexOf(valueStr)
				if(itemIndex == -1) {
					splitted.push(valueStr)
				} else {
					splitted.splice(itemIndex, 1)
				}
				newRating = splitted.join(",")
			} else {
				newRating = valueStr
			}
		}

		this.setState({
			rating: newRating,
			activeBubble: getRatingFilterBubble(newRating),
		}, async () => {
			this.props.actions.filterCallback(this.state.type, this.state.rating)
		})
	}

	render() {
		return (
			<ReviewListFilterHeaderPage
				activeButton={this.state.activeButton}
				activeBubble={this.state.activeBubble}
				actions={this.props.actions}
				options={this.props.options}
				starCallback={this.starCallback}
				categoryCallback={this.categoryCallback}
			/>
		)
	}
}

