import React from 'react';
import { View, Text, TextStyle, StyleSheet, ViewStyle } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import { colors } from '@Global/GlobalProps';
import FollowButton from '@Components/FollowButton/BiggerFollowButton';
import { Unsubscribe, followEvent, genericFollowEvents } from '@FoodListCore/Services/EventEmitter';
import { translate } from '@App/I18n';
import { isCurrentUser, followEmitter } from '@App/Redux/ReduxHelper';

/**
 * @param number: number
 * @param title: label
 * @return
 */

type SingleIndicatorProps = {
	number: number,
	title: string,
	style: ViewStyle,
}

class SingleIndicator extends React.PureComponent<SingleIndicatorProps, {}> {
	render() {
		let style = {
			fontSize: 10,
			color: colors.white,
			alignSelf: 'center',
			flex: 0
		}
		return (
			<View style={[{ flexDirection: 'column', flex: 0 }, this.props.style]}>
				<Text style={{ ...style, fontSize: 16, fontWeight: 'bold' } as TextStyle}>{this.props.number}</Text>
				<Text style={style as TextStyle}>{this.props.title}</Text>
			</View>
		)
	}
}

/**
 * @param reviews_count
 * @param following_count
 * @param followers_count
 * @param followingId
 * @param following
 * @param showFollowers
 * @param showFollowing
 * @return FollowLine
 */

type FollowLineProps = {
	followers_count: number,
	following: boolean,
	reviews_count: number,
	following_count: number,
	showFollowing: () => void,
	showFollowers: () => void,
	userName: string,
	followingId: number
}

type FollowLineState = {
	followers_count: number,
	following_count: number,
	following: boolean,
}

export default class FollowLine extends React.PureComponent<FollowLineProps, FollowLineState>{
	emitter = followEmitter()
	unsubscribe: Unsubscribe
	unsubscribeGeneric?: Unsubscribe

	constructor(props: FollowLineProps) {
		super(props)
		this.state = {
			followers_count: props.followers_count,
			following_count: props.following_count,
			following: props?.following
		}
		this.unsubscribe = this.emitter.on(followEvent(props.followingId), (following: boolean) => {
			const count = this.state.followers_count + (following ? +1 : -1)
			this.setState({
				following: following,
				followers_count: count
			})
		})
		if (isCurrentUser(this.props.followingId)) {
			this.unsubscribeGeneric = this.emitter.on(genericFollowEvents(), (following: boolean) => {
				this.setState({
					following_count: this.state.following_count + (following ? +1 : -1)
				})
			})
		}
	}

	componentWillUnmount() {
		this.unsubscribe()
		this.unsubscribeGeneric?.()
	}

	render() {
		return (
			<View style={{ marginHorizontal: 20, marginBottom: 20, alignItems: 'center' }}>
				{!!this.state.followers_count &&
					<View style={{ flexDirection: 'row', marginBottom: 20, minWidth: 200 }}>
						<SingleIndicator style={{}} number={this.props.reviews_count} title={translate("reviews").toUpperCase()} />
						<TouchableOpacity style={{ flex: 1, paddingHorizontal: 10 }} onPress={this.props.showFollowers}>
							<SingleIndicator style={{}} number={this.state.followers_count} title={translate("followers").toUpperCase()} />
						</TouchableOpacity>
						<TouchableOpacity onPress={this.props.showFollowing}>
							<SingleIndicator style={{}} number={this.state.following_count} title={translate("following").toUpperCase()} />
						</TouchableOpacity>
					</View>
				}
				<FollowButton
					style={{ flex: 0, minWidth: 200 }}
					userName={this.props.userName}
					userId={this.props.followingId}
					following={this.state.following}
					showEditProfile
				/>
			</View>
		);
	}
}
