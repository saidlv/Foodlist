import { colors } from '@FoodListCore/Global/Constants';
import React from 'react';
import GoogleAutocomplete, { usePlacesWidget } from "react-google-autocomplete";

type Props = {
	onPositionSelected: (latitude: number, longitude: number, address: string) => void
}

const PlacesAutocomplete = React.memo((props: Props) => {
	const { ref } = usePlacesWidget({
		onPlaceSelected: (place) => {
			const location = place.geometry?.location
			if(location) {
				props.onPositionSelected(location.lat(), location.lng(), place.formatted_address || "")
			}
			console.log(place, location?.lat(), location?.lng())
		},
		options: {
			types: ["geocode"],
			componentRestrictions: { country: "it" },
		},
	})

	return (
		<input ref={ref} placeholder="Inserisci il tuo indirizzo" style={styles.input} />
	)
});

const styles = {
	input: {
		padding: 15,
		fontSize: 18,
	},
};

export default PlacesAutocomplete;
