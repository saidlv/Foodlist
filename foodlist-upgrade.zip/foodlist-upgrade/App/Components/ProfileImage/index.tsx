import React from 'react';
import { userImage } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';
import { Photo } from '@Models/Photo';
import FLImage from '@FoodListCore/Components/FLImage';

type ProfileImageProps = {
	source?: Photo | null,
	customSize?: number,
}

export default class ProfileImage extends React.PureComponent<ProfileImageProps> {
	constructor(props: ProfileImageProps) {
		super(props);
	}

	getImage() {
		//console.log(this.props.source, this.props.customSize)
		return userImage(this.props.source, true);
	}

	render() {
		return (
			<FLImage
				style={[
					styles.userImage,
					!!this.props.customSize ? { height: this.props.customSize, width: this.props.customSize, borderRadius: this.props.customSize / 2 } : {}
				]}
				source={this.getImage()}
			/>
		)
	}
}

const styles = StyleSheet.create({
	userImage: {
		width: 32,
		height: 32,
		borderRadius: 16
	},
})
