import React from 'react';
import { Text, ViewStyle, TextStyle, StyleProp } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './Style';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { colors } from '@FoodListCore/Global/GlobalProps';
/**
 * @param full: boolean flag that represents wheter the button needs to be full of red color or white inside
 * @param onPress: on click callback
 * @param title: name of the button
 * @param noPadding: removes padding

 * @return graphical representation of the button used on forms like the auth ones, and search ones
 */

type FormActionButtonProps = {
	title: string,
	full?: boolean,
	customStyle?: StyleProp<ViewStyle>,
	customTextStyle?: TextStyle,
	enabled?: boolean,
	noPadding?: boolean,
	onPress: () => void,
}

type FormActionButtonState = {

}

export default class FormActionButton extends React.PureComponent<FormActionButtonProps, FormActionButtonState> {
	constructor(props: FormActionButtonProps) {
		super(props)
		//this.props.enabled = true;
	}
	fullStyle() {
		return this.props.full === true && this.props.enabled !== false;
	}
	render() {
		return (
			<TouchableRipple
				borderless
				disabled={this.props.enabled === false}
				style={[styles.button, this.fullStyle() ? styles.fullButton : styles.emptyButton, this.props.customStyle, this.props.noPadding ? styles.noPadding : null, { overflow: "hidden" }]}
				onPress={this.props.onPress}
				underlayColor={colors.darkRed}
			>
				<Text style={[styles.title, this.fullStyle() ? styles.fullTitle : styles.emptyTitle, this.props.customTextStyle]}>{this.props.title}</Text>
			</TouchableRipple>
		);
	}
}
