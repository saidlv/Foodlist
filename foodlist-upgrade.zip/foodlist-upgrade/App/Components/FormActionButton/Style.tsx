import { colors, fontSizes } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	button: {
		height: 48,
		marginHorizontal: 20,
		marginVertical: 10,
		justifyContent: 'center',
		alignItems: 'center',
		borderRadius: 4,
		borderStyle: "solid",
		borderWidth: 2,
		borderColor: colors.foodlist
	},
	noPadding: {
		marginHorizontal: 0,
		marginVertical: 0
	},
	fullButton: {
		backgroundColor: colors.foodlist,
		borderColor: colors.foodlist,
		borderWidth: 0
	},
	emptyButton: {
		backgroundColor: colors.greyBackground,
		borderColor: colors.foodlist
	},
	title: {
		fontSize: fontSizes.formButtonTitle,
		fontWeight: "bold",
		fontStyle: "normal",
		letterSpacing: 0,
		textAlign: "center"
	},
	fullTitle: {
		color: colors.white
	},
	emptyTitle: {
		color: colors.foodlist
	}
})
