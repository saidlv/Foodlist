import React from 'react';
import { colors, when } from '@Global/GlobalProps';
import { connect } from 'react-redux';
import { View, Text } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { ReduxState } from '@Redux/StateFormat';
import { Notification } from '@Models/Notification';
import { CommonNavigation } from '@RouteParams/Common';
import { useNavigation } from '@react-navigation/native';
import { Pluto } from '@Models/Pluto';
import { userLogged } from '@FoodListCore/Redux/ReduxHelper';

type NotificationIconProps = {
	notifications?: Notification[]
}

type Props = NotificationIconProps & {
	navigation: CommonNavigation<Pluto>
}

export const getUnreadCount = (notifications: Notification[]) => {
		const value = notifications.reduce((acc, item) => {
			return acc + ((item.read_at == null) ? 1 : 0);
		}, 0)
		if (value < 100) return value;
		return "99+";
}

class NotificationIcon extends React.PureComponent<Props> {
	getBadge() {
		return getUnreadCount(this.props.notifications || [])
	}
	hasBadge() {
		return this.getBadge() != 0;
	}
	badgeIcon() {
		return (
			<View style={{ backgroundColor: colors.blueMenu, borderRadius: 20, paddingVertical: 1, paddingHorizontal: 4, position: "absolute", right: 13, top: 8 }}>
				<Text style={{ color: "white", fontSize: 10, fontWeight: 'bold' }}>{this.getBadge()}</Text>
			</View>
		)
	}
	componentDidMount() {
		this.props.navigation.addListener('focus', this.onFocus)
	}
	onFocus = () => {
		this.forceUpdate()
	}
	componentWillUnmount() {
		this.props.navigation.removeListener('focus', this.onFocus)
	}
	render() {
		//return <></>
		if(!userLogged()) return (<View/>)
		return (
			<TouchableOpacity onPress={() => {
				this.props.navigation.push("Notifications", {})
			}}
				style={{ height: "100%", minWidth: 30, alignItems: "center", justifyContent: "center" }}
			>
				<Icon name="notify" size={16} color="#fff" style={{ paddingHorizontal: 20 }} />
				{this.hasBadge() && this.badgeIcon()}
			</TouchableOpacity>
		)
	}
}


const _NotificationIcon = function (props: NotificationIconProps) {
	let navigation: CommonNavigation<Pluto> = useNavigation()
	return <NotificationIcon {...props} navigation={navigation} />
}

export default connect((state: ReduxState) => {
	return {
		notifications: state.notifications
	}
})(_NotificationIcon)
