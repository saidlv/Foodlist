import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

type Props = {
	item: EarnedPoints
}

export type EarnedPoints = {
	points: string,
	text: string,
	color?: string
	description?: string
}

const EarnedPointsCell = React.memo(({ item }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<View style={styles.cell}>
			<View style={styles.row}>
				<View style={[styles.circle, item.color ? { backgroundColor: item.color } : {}]}>
					<Text style={styles.points}>{item.points}</Text>
				</View>
				<View style={styles.textContainer}>
					<Text style={styles.text}>{item.text}</Text>
					{item.description ? <Text style={styles.description}>{item.description}</Text> : <></>}
				</View>
			</View>
		</View>
	);
});

const styles = StyleSheet.create({
	cell: {
		//marginHorizontal: margins.pagePadding,
		//marginVertical: margins.pagePadding / 2,
		backgroundColor: colors.white,
		borderRadius: 4,
		padding: margins.pagePadding,
		//...CommonStyle.shadow,
	},
	row: {
		flexDirection: "row",
		alignItems: "center",

	},
	circle: {
		backgroundColor: colors.foodlist,
		paddingVertical: 5,
		paddingHorizontal: 10,
		borderRadius: 5,
		minWidth: 50,
		alignItems: "center",
	},
	textContainer: {
		flex: 1,
		marginLeft: 15,
	},
	text: {
		fontSize: 16,
	},
	description: {
		fontSize: 12,
	},
	points: {
		color: colors.white,
		fontWeight: "bold",
		fontSize: 16,
	}
});

export default EarnedPointsCell;
