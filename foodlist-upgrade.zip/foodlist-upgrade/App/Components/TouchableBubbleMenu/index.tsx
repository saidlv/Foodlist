import React, { ReactChild } from 'react';
import { View, ScrollView, Text, StyleSheet } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './Style';

import { when, colors } from '@Global/GlobalProps'

/**
 * @param bubbleInfo: [{text, clickable, callback}] json array containing the info that needs to be displayed in the tab

 * @return a top bar containing the content specified by paramater
 */

type TouchableBubbleMenuProps = {
	bubbleElements: { text: string, clickable: boolean, callback: (index: number) => void }[],
	selected: number[],
}

export default class TouchableBubbleMenu extends React.PureComponent<TouchableBubbleMenuProps> {

	render() {
		return (
			<ScrollView
				contentContainerStyle={{ paddingLeft: 20, paddingRight: 8 }}
				horizontal={true}
				showsHorizontalScrollIndicator={false}
			>
				{this.props.bubbleElements.reduce<ReactChild[]>((result, item, index) => {
					if (item.clickable) {
						result.push(
							<TouchableOpacity
								key={index}
								style={[styles.bubble, this.props.selected.indexOf(index) != -1 ? { backgroundColor: colors.blueMenu } : {}]}
								onPress={() => { item.callback(index) }}
							>
								<Text
									style={[styles.bubbleText, when(this.props.selected.indexOf(index) != -1, { color: colors.white })]}
								>{item.text.toUpperCase()}</Text>
							</TouchableOpacity>
						)
					} else {
						result.push(
							<View key={index} style={[styles.bubble, styles.inactiveBubble]}>
								<Text style={styles.bubbleText}>{item.text}</Text>
							</View>
						)
					}

					return result;
				}, [])}
			</ScrollView>
		)
	}
}
