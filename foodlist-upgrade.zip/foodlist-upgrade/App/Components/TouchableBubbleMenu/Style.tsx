import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	bubble: {
		borderWidth: 1,
		borderStyle: "solid",
		borderColor: colors.blueMenu,
		borderRadius: 12,
		alignItems: 'center',
		justifyContent: 'center',
		display: 'flex',
		height: 24,
		width: 72,
		marginRight: 12
	},
	bubbleText: {
		fontSize: 10,
		fontWeight: "bold",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blueMenu,
		marginTop: 6,
		marginBottom: 6,
		marginLeft: 15,
		marginRight: 15,
		width: "100%",
		textAlign: 'center'
	},
	inactiveBubble: {
		opacity: 0.25
	}
})
