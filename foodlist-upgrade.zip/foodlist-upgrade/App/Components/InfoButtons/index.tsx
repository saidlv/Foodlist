import React, { useCallback, useState } from 'react';
import { View, Text, ViewStyle } from 'react-native';
import { colors, alert, error } from '@Global/GlobalProps';
import BigButton from '@Components/FollowButton/BigButton';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { Dish } from '@Models/Dish';
import { Restaurant } from '@Models/Restaurant';
import { translate } from '@App/I18n';
import requestAuth from "@FoodListCore/Flows/RequestAuth"
import { StackNavigationProp } from '@react-navigation/stack';
import { ParamList } from '@FoodListCore/Flows/Restaurant/params';
import FavouriteButton from '@FoodListCore/Components/FavouriteButton';

type InfoButtonsProps = {
	writeReviewCallback: () => void,
	isRestaurant: boolean,
	reviewWritten: boolean,
	item: Dish | Restaurant | null,
	navigation: StackNavigationProp<ParamList>
}

type InfoButtonsState = {
	isRestaurant: boolean,
	id: number | null,
	isFavourite: boolean,
	loading: boolean,
}

export default class InfoButtons extends React.PureComponent<InfoButtonsProps, InfoButtonsState> {
	constructor(props: InfoButtonsProps) {
		super(props)

		this.state = {
			loading: false,
			isFavourite: props?.item?.is_favourite || false,
			id: props?.item?.id || null,
			isRestaurant: props.isRestaurant
		};
	}
	render() {
		return (
			<View style={{ flex: 1, flexDirection: 'row', paddingHorizontal: 20, marginBottom: 20 }}>
				<BigButton style={{ flex: 1, marginRight: 10 }}
					color={colors.white}
					textColor={colors.blueMenu}
					onPress={() => {
						if(requestAuth(this.props.navigation, true)) {
							this.props.writeReviewCallback()
						}
					}}
				>
					<Text><Icon name="review" size={16} />&nbsp; {(this.props.reviewWritten) ? translate("alreadyReviewed") : translate("doReview")}</Text>
				</BigButton>
				<FavouriteButton
					style={{ flex: 1, marginRight: 10 }}
					isDish={!this.state.isRestaurant}
					item={this.props.item}
				/>
			</View>
		)
	}
}