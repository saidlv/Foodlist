import React, { Component } from 'react';
import { View, Text } from 'react-native';
import styles from './Style';
import FLSwitch from '@Components/FLSwitch';

/*
@param title
@param value: initial value
@param valueChanged: callback(newValue)
 */

type SwitchOptionProps = {
	title: string,
	value: boolean,
	valueChanged: (value: boolean) => void
}

type SwitchOptionState = {
	value: boolean,
}

export default class SwitchOption extends React.PureComponent<SwitchOptionProps, SwitchOptionState> {
	constructor(props: SwitchOptionProps) {
		super(props)
		this.state = {
			value: props.value,
		}
	}

	componentDidUpdate(prevProps: SwitchOptionProps) {
		if (this.props.value != prevProps.value) {
			this.setState({
				value: this.props.value
			})
		}
	}

	valueChanged = (value: boolean) => {
		this.props.valueChanged(value)
		this.setState({
			value: value
		})
	}

	render() {
		return (
			<View style={[styles.container, { paddingVertical: 8, paddingRight: 20 }]}>
				<View style={styles.textContainer}>
					<Text style={[styles.title, { paddingVertical: 8 }]} numberOfLines={1} ellipsizeMode='tail'>{this.props.title}</Text>
					<FLSwitch value={this.state.value} valueChanged={this.valueChanged} />
				</View>
			</View>
		)
	}
}
