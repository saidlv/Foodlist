import React from 'react'
import { Text, View } from 'react-native'
import OptionChooser from "./GenericChooser"
import { Day } from '@Models/Day'
import { colors, when } from '@Global/GlobalProps'
import CommonStyle from '@FoodListCore/Global/CommonStyle'
import { translate } from '@App/I18n'

type Props = {
	title: string
	times: Day[]
	onTimeChange: (times: Day[]) => void
}

const TimeChooser = ({ times, title, onTimeChange }: Props) => (
	<OptionChooser
		title={title}
		customModal={(navigation) => {
			navigation.navigate("InsertTimes", { data: times })
		}}
		customLabel={() => {
			onTimeChange(times)
			return (
				<View style={{ flexDirection: 'column', justifyContent: 'flex-end' }}>
					{times.map((item: Day, index: number) => {
						return (
							<View key={index} style={[{ flexDirection: 'row', flex: 1, justifyContent: 'space-between', alignItems: 'center', paddingVertical: 2 }, when(index != 0, CommonStyle.borderTop)]}>
								<Text>{item.day}</Text>
								<View style={{ marginLeft: 10, flexDirection: 'column' }}>
									{item.times?.map((itemH, indexH) => {
										return (
											<View key={indexH}>
												<Text>{itemH?.timeString}</Text>
											</View>
										)
									})}
									{(item?.times?.length == 0) && (
										<Text style={{ color: colors.greyInfoText }}>{translate("closed")}</Text>
									)}
								</View>
							</View>
						)
					})}
				</View>
			)
		}}
	/>
)

export default TimeChooser