import React, { ReactNode } from 'react';
import { View, Text } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './Style';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { colors, when } from '@Global/GlobalProps';
import { useNavigation } from '@react-navigation/native';
import { CommonNavigation } from '@RouteParams/Common';
import { Pluto } from '@Models/Pluto';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';

type OptionChooserProps = {
	title: string,
	disabled?: boolean,
	customModal: (navigation: CommonNavigation<Pluto>) => void,
	customLabel: () => ReactNode,
}

type Props = OptionChooserProps & {
	navigation: CommonNavigation<Pluto>
}

class OptionChooser extends React.PureComponent<Props> {
	componentDidMount() {
		this.props.navigation.addListener('focus', this.onFocus)
	}

	onFocus = () => {
		//console.log("force update")
		this.forceUpdate()
	}

	componentWillUnmount() {
		this.props.navigation.removeListener('focus', this.onFocus)
	}

	showModal = () => {
		this.props.customModal(this.props.navigation)
	}
	render() {
		//console.log("render chooser")
		return (
			<TouchableRipple
				disabled={this.props.disabled}
				onPress={this.showModal}
				style={[styles.container]}
			>
				<View style={[styles.textContainer, when(this.props.disabled, { opacity: 0.3 })]}>
					<Text style={[styles.title]} numberOfLines={1}>{this.props.title}</Text>
					{this.props.customLabel()}
				</View>
				<Icon style={styles.arrow} name="arrow-right" color={colors.greyArrow} size={12} />
			</TouchableRipple>
		)
	}
}
export default function (props: OptionChooserProps) {
	const navigation = useNavigation<CommonNavigation<Pluto>>()
	return <OptionChooser {...props} navigation={navigation} />
}