import React, { PureComponent } from 'react'
import { Text } from 'react-native'
import OptionChooser from "./GenericChooser"
import ActionSheet from '@alessiocancian/react-native-actionsheet'
import styles from './Style';
import { PrintableItem } from '@Models/PrintableItem';
import { mapById } from '@Global/GlobalProps';
import { ItemsMap } from '@Models/ItemsMap';

type Props = {
	title: string
	options: PrintableItem[]
	isDish?: boolean
	isCategories?: boolean
	noSelectionText?: string
	initialSelections?: PrintableItem[]
	onSelectionChange: (selected: PrintableItem[]) => void
}

type State = {
	mappedOptions: ItemsMap<PrintableItem>
	selectedIds: PrintableItem[]
}

export default class MultiselectChooser extends PureComponent<Props, State> {
	actionSheet: ActionSheet | null = null

	constructor(props: Props) {
		super(props)
		this.state = {
			mappedOptions: mapById(props.options || []),
			selectedIds: props.initialSelections || []
		}
	}

	getRightLabel = () => {
		let keys = this.state.selectedIds.map((item) => {
			return item?.label_it
		})
		if (keys.length == 0) {
			return this.props.noSelectionText || "Nessuno"
		} else {
			return keys.join(", ")
		}
	}

	render() {
		const { props } = this
		return (
			<>
				<OptionChooser
					title={props.title}
					customModal={(navigation) => {
						navigation.navigate('FilterOptionPage', {
							title: this.props.title,
							options: this.props.options,
							isCategories: this.props.isCategories,
							isDish: this.props.isDish,
							selections: this.state.selectedIds,
							onItemChanged: ((newArray: PrintableItem[]) => {
								this.setState({
									selectedIds: newArray.concat()
								})
								this.props.onSelectionChange?.(newArray)
							}).bind(this)
						})
					}}
					customLabel={() => (
						<Text
							style={styles.optionText}
							numberOfLines={1}
							ellipsizeMode='tail'
						>{this.getRightLabel()} </Text>
					)}
				/>
			</>
		)
	}
}