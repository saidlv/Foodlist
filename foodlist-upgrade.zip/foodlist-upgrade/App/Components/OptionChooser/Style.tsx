import { colors } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		flex: 1,
		flexDirection: 'row',
		paddingVertical: 16,
		width: '100%',
		height: 'auto',
		minHeight: 48,
		backgroundColor: colors.white,
		justifyContent: 'space-between',
		alignItems: 'center'
	},
	textContainer: {
		flex: 1,
		flexDirection: 'row',
		flexGrow: 1,
		justifyContent: 'space-between',
		overflow: 'hidden'
	},
	arrow: {
		paddingHorizontal: 20
	},
	title: {
		flex: 0,
		fontSize: 14,
		fontWeight: "500",
		color: colors.blackText,
		paddingHorizontal: 20
	},
	optionText: {
		flex: 1,
		flexGrow: 1,
		fontSize: 14,
		color: colors.blackText,
		justifyContent: 'center',
		textAlign: 'right'
	},
})
