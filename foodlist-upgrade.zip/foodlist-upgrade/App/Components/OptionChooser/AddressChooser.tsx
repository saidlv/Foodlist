import React from 'react'
import { Text } from 'react-native'
import OptionChooser from "./GenericChooser"
import { Address } from "@Models/Address"

type Props = {
	title: string
	address: Address
}

const AddressChooser = ({ address, title }: Props) => {
	return (
		<OptionChooser
			title={title}

			customModal={(navigation) => {
				navigation.navigate("ImproveAddress", { data: address })
			}}

			customLabel={() => {
				return (
					<Text style={{ flex: 1, textAlign: 'right' }} numberOfLines={1}>
						{address.address} {address.house_number}, {address.city} {address.cap}
					</Text>
				)
			}}
		/>
	)
}

export default AddressChooser