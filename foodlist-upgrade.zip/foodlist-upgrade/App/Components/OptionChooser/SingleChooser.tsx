import React, { PureComponent } from 'react'
import { Text } from 'react-native'
import OptionChooser from "./GenericChooser"
import ActionSheet from '@alessiocancian/react-native-actionsheet'
import styles from './Style';
import { translate } from '@App/I18n';

type Props = {
	title: string
	options: string[]
	initialIndex?: number
	onSelectionChange: (option: string, index: number) => void
}

type State = {
	selectedIndex: number
}

export default class SingleChooser extends PureComponent<Props, State> {
	actionSheet: ActionSheet | null = null

	constructor(props: Props) {
		super(props)
		this.state = {
			selectedIndex: props.initialIndex ?? 0
		}
	}

	getOptions = () => {
		return [translate("cancel")].concat(this.props.options)
	}

	getRightLabel = () => {
		return this.props.options[this.state.selectedIndex]
	}

	render() {
		const { props } = this
		return (
			<>
				<OptionChooser
					title={props.title}
					customModal={() => {
						this.actionSheet?.show()
					}}
					customLabel={() => (
						<Text style={styles.optionText} numberOfLines={1} ellipsizeMode='tail'>{this.getRightLabel()}</Text>
					)}
				/>
				<ActionSheet
					ref={o => (this.actionSheet = o)}
					options={this.getOptions()}
					cancelButtonIndex={0}
					onPress={index => {
						if (index > 0) {
							let realIndex = index - 1
							this.props.onSelectionChange?.(this.props.options?.[realIndex], realIndex)
							this.setState({
								selectedIndex: realIndex
							})
						}
					}}
				/>
			</>
		)
	}
}