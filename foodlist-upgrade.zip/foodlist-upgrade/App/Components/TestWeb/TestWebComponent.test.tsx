import React from 'react';
import 'react-native';
import TestWeb from './index';

import renderer from 'react-test-renderer';

it('renders TestWeb view', () => {
	//expect(renderer.create(<TestWeb />)).toMatchSnapshot(); //TODO: add TestWeb props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<TestWeb pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<TestWeb pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
