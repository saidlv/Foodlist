import colors from '@FoodListCommon/colors';
import { buildArray } from '@FoodListCommon/utils';
import Line from '@FoodListCore/Components/Line';
//import { BottomSheet, BottomSheetBackdrop, BottomSheetFlatList, BottomSheetModal } from '@FoodListCore/Components/SheetPopup';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, StyleSheet, Text, View } from 'react-native';

export interface TestWebActions {

}

type Props = {
	actions: TestWebActions
}

const snapPoints = ["30%", "70%"]

const TestWeb = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	const bottomSheetRef = React.useRef<BottomSheetModal>(null)
	const onPress = useCallback(() => {
		bottomSheetRef.current?.present()
	}, [])

	const onSelect = useCallback(() => {
		bottomSheetRef.current?.close()
	}, [])
	return (
		<>
			<View style={[styles.box, CommonStyle.shadow]}><Text>Header</Text></View>
			<View style={{ flex: 1 }}>
			<FlatList
				data={buildArray(20, (index) => ({ index }))}
				renderItem={({ item }) => {
					return (
						<TouchableRipple onPress={onPress} borderless style={[{ backgroundColor: colors.white, padding: 20, margin: 20, borderRadius: 8 }, CommonStyle.shadow]}>
							<Text style={{ fontSize: 20 }}>Mostra il robo {item.index}</Text>
						</TouchableRipple>
					)
				}}
			/>
			</View>
			<View style={[styles.box, CommonStyle.shadow]}><Text>Ciao pippo</Text></View>
			{/* <BottomSheetModal
				ref={bottomSheetRef}
				snapPoints={snapPoints}
				backdropComponent={(props) => <BottomSheetBackdrop {...props} appearsOnIndex={1} />}
			>
				<Text style={{ padding: 20, textAlign: "center", fontSize: 20, fontWeight: "bold" }}> Ciao Pippo</Text>
				<BottomSheetFlatList
					data={[{
						title: "Fai qualcosa"
					}, {
						title: "Fai qualcos altro"
					}, {
						title: "Scherzavo è sempre uguale"
					}]}
					ItemSeparatorComponent={Line}
					keyExtractor={(_, i) => i.toString()}
					renderItem={({ item }) => (
						<TouchableRipple
							onPress={onSelect}
							style={styles.cell}
						>
							<Text>{item.title}</Text>
						</TouchableRipple>
					)}
				/>
			</BottomSheetModal> */}
		</>
	);
});

const styles = StyleSheet.create({
	cell: {
		padding: 10
	},
	box: {
		padding: 10,
		backgroundColor: colors.white,
		alignItems: "center",
	}
});

export default TestWeb;
