import styles from './InfoBoxStyle';
import React, { Component } from 'react';
import StarRating from '@Components/StarRating';
import { Text, View } from 'react-native';
import { colors } from '@Global/GlobalProps';
import { Review } from '@Models/Review';
import { translate } from '@App/I18n';

type InfoBoxLocaliProps = {
	item: Review
}

export default class InfoBoxLocali extends React.PureComponent<InfoBoxLocaliProps> {
	render() {
		return (
			<>
				<View style={styles.flexRow}>
					<View style={styles.halfWidth}>
						<View style={styles.contentContainer}>
							<View style={styles.oppositeRow}>
								<Text style={styles.inlineTitle}>{translate("service")}</Text>
								<View style={styles.inlineContent}>
									<StarRating size={12} color={colors.greyText} rating={this.props.item.rating_service} />
								</View>
							</View>
						</View>
					</View>
					<View style={styles.halfWidth}>
						<View style={styles.contentContainer}>
							<View style={styles.oppositeRow}>
								<Text style={styles.inlineTitle}>{translate("quality")}</Text>
								<View style={styles.inlineContent}>
									<StarRating size={12} color={colors.greyText} rating={this.props.item.rating_quality} />
								</View>
							</View>
						</View>
					</View>
				</View>
				<View style={styles.flexRow}>
					<View style={styles.halfWidth}>
						<View style={styles.secondLineContainer}>
							<View style={styles.oppositeRow}>
								<Text style={styles.inlineTitle}>{translate("location")}</Text>
								<View style={styles.inlineContent}>
									<StarRating size={12} color={colors.greyText} rating={this.props.item.rating_location} />
								</View>
							</View>
						</View>
					</View>
					<View style={styles.halfWidth}>
						<View style={styles.secondLineContainer}>
							<View style={styles.oppositeRow}>
								<Text style={styles.inlineTitle}>{translate("price")}</Text>
								<View style={styles.inlineContent}>
									<StarRating size={12} color={colors.greyText} rating={this.props.item.rating_price} />
								</View>
							</View>
						</View>
					</View>
				</View>
			</>
		);
	}
};
