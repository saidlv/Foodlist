import styles from './InfoBoxStyle';
import React from 'react';
import { Text, View } from 'react-native';
import { when, formatPrice, isDefined } from '@Global/GlobalProps';
import { Review } from '@Models/Review';
import { translate } from '@App/I18n';
import { getDishSectionName } from '@FoodListCommon/menu';

type InfoBoxPiattiProps = {
	item: Review
}

export default class InfoBoxPiatti extends React.PureComponent<InfoBoxPiattiProps> {
	render() {
		let showPrice = isDefined(this.props.item?.price) && this.props.item.price != 0;
		return (
			<View style={styles.flexRow}>
				<View style={showPrice ? styles.halfWidth : { width: "100%" }}>
					<View style={[styles.contentContainer, styles.singleLine]}>
						<View style={styles.oppositeRow}>
							<Text style={styles.inlineTitle}>{translate("portata")}</Text>
							<View style={[styles.inlineContent, when(!showPrice, { justifyContent: 'flex-start', alignItems: 'flex-start' })]}>
								<Text style={[styles.inlineText, when(!showPrice, { paddingLeft: 10 })]} numberOfLines={0}>{getDishSectionName(this.props.item.dish)}</Text>
							</View>
						</View>
					</View>
				</View>
				{this.props.item?.price != null && this.props.item?.price != undefined && showPrice && (
					<View style={styles.halfWidth}>
						<View style={[styles.contentContainer, styles.singleLine]}>
							<View style={styles.oppositeRow}>
								<Text style={styles.inlineTitle}>{translate("price")}</Text>
								<View style={styles.inlineContent}>
									<Text style={styles.inlineText}>{formatPrice(this.props.item.price)}</Text>
								</View>
							</View>
						</View>
					</View>
				)}
			</View>
		);
	}
}