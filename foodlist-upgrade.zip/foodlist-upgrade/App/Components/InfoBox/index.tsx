import InfoBoxLocali from './InfoBoxLocali';
import InfoBoxPiatti from './InfoBoxPiatti';

import React from 'react';
import { Review } from '@Models/Review';

type InfoBoxProps = {
	item: Review
}

export default class InfoBox extends React.PureComponent<InfoBoxProps, {}> {
	render() {
		let box;
		if (this.props.item.feed_type == "DISH") {
			box = <InfoBoxPiatti item={this.props.item} />;
		} else {
			box = <InfoBoxLocali item={this.props.item} />;
		}

		return box;
	}
}
