import { colors } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
	halfWidth: {
		width: '50%'
	},
	oppositeRow: {
		flex: 1,
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center'
	},
	inlineTitle: {
		alignSelf: "center",
		fontWeight: '400',
		fontSize: 11,
		textAlignVertical: 'center',
		color: colors.greyInfoText
	},
	inlineContent: {
		alignSelf: "center",
		flex: 1,
		justifyContent: 'flex-end',
		alignItems: 'flex-end'
	},
	inlineText: {
		fontWeight: '700',
		fontSize: 11,
		textAlign: 'right',
		textAlignVertical: 'center',
		color: colors.greyInfoText
	},
	secondLineContainer: {
		paddingTop: 0,
		paddingLeft: 12,
		paddingRight: 12,
		paddingBottom: 9
	},
	contentContainer: {
		paddingHorizontal: 12,
		paddingTop: 9,
		paddingBottom: 7
	},
	singleLine: {
		paddingBottom: 9
	},
	flexRow: {
		flex: 1,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center'
	}
});
