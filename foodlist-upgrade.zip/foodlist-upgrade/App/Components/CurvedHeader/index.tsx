import React, { Component } from 'react';
import { FlatList, Image, Platform, Text, View, Dimensions, ImageSourcePropType, ImageURISource, } from 'react-native';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import Svg, { G, Path } from 'react-native-svg';
import { colors, when } from '@Global/GlobalProps';

import { ImageSource } from '@Models/ImageSource';

const WIDTH = Dimensions.get('window').width
const curve = "M4.13106242e-14,0 C62.5,28.6666667 125,43 187.5,43 C250,43 312.5,28.6666667 375,0 L375,45 L0,45 L4.13106242e-14,0 Z"

/**
 * @param source: image
 * @param customHeight: custom height, default 220
 * @param backgroundColor: the background color of the main view
 */

type CurvedHeaderProps = {
	source?: ImageSource,
	overImage?: ImageSource,

	overImageHeight?: number,
	customHeight?: number,
	backgroundColor?: string,
}

export default class CurvedHeader extends React.PureComponent<CurvedHeaderProps, {}> {
	getSvgY() {
		return Math.ceil(WIDTH / 375 * 45)
	}
	hasImage() {
		return this.props.source != undefined
	}
	getImage() {
		return this.props.source == undefined ? {} : this.props.source
	}
	getOverImage() {
		return this.props.overImage == undefined ? {} : this.props.overImage
	}
	getOverImageHeight() {
		return this.props.overImageHeight == undefined ? this.getHeight() : this.props.overImageHeight
	}
	getHeight() {
		return this.props.customHeight == undefined ? 220 : this.props.customHeight
	}
	getBackgroundColor() {
		return this.props.backgroundColor == undefined ? '#fff' : this.props.backgroundColor
	}
	render() {
		return (
			<View style={[{
				position: 'relative', minHeight: this.getHeight(), maxHeight: this.getHeight(),
				width: "100%", flex: 0, flexDirection: 'row', overflow: 'hidden'
			}, when(!this.hasImage(), { backgroundColor: colors.foodlist })]}>
				<Image
					// @ts-ignore
					source={this.getImage()}
					style={{
						position: 'absolute',
						height: this.getHeight(),
						width: '100%',
						justifyContent: 'center',
						zIndex: 0
					}}
				/>
				<View style={{ alignSelf: 'flex-end', zIndex: 2, marginBottom: -2 }}>
					<Svg width={WIDTH} height={this.getSvgY()} viewBox="0 0 375 45">
						<Path d={curve} /* width="375"  height="43"*/ fill={this.getBackgroundColor()} />
					</Svg>
				</View>
				<View style={{ position: 'absolute', alignItems: "center", justifyContent: "center", width: "100%", height: this.getHeight(), zIndex: 3 }}>
					<Image 
						// @ts-ignore
						source={this.getOverImage()}
						style={{
							height: this.getOverImageHeight(),
							resizeMode: 'contain'
						}}
					/>
				</View>
			</View>
		)
	}
}
