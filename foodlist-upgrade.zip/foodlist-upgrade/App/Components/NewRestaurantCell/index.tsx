import React from 'react';
import { colors } from '@Global/GlobalProps';
import { ImageBackground, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { spacing as margins } from "@FoodListCore/Global/Constants"
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { Restaurant } from '@Models/Restaurant';
import { renderUrlField } from '@FoodListCore/Components/WebReviews';
import RestaurantCellContent from '@FoodListCore/Components/Cells/NewRestaurantCell';
import { RestaurantInfosProps } from '@FoodListCore/Components/RestaurantHeader';
import { useNavigation } from '@react-navigation/core';
import { CommonNavigation } from '@App/RouteParams/Common';
import { Dish } from '@Models/Dish';
import { useDishModal } from '@FoodListCore/Components/DishPopup';
import DishSearchCell from '@FoodListCore/Components/DishSearchCell';

export interface NewRestaurantCellActions {
	onPress: () => void
	changeVerticalScrollEnabled: (enabled: boolean) => void
	customDishPress?: (dish: Dish, restaurant: Restaurant) => void
}

type Props = {
	item: Restaurant
	mode: "bookings" | "orders" | "explore"
	actions: NewRestaurantCellActions
	infoProps?: Partial<RestaurantInfosProps>
}

const NewRestaurantCell = React.memo((props: Props) => {
	const { item, actions } = props
	const hasFoodListOrders = item.orders_platform_available == 2
	const hasFoodListBookings = item.bookings_platform_available == 2

	const navigation = useNavigation<CommonNavigation<any>>()

	const { setVisibleDish, DishModal } = useDishModal()

	return (
		<View style={styles.padding}>
			<View style={[styles.cell, CommonStyle.shadow]}>
				<View style={styles.rounded}>
				<TouchableRipple
					onPress={actions.onPress}
				>
					<RestaurantCellContent
						item={item}
						disableFullscreen
						restaurantInfosProps={props.infoProps}
						carouselProps={React.useMemo(() => ({
							onPress: actions.onPress,
							changeVerticalScrollEnabled: actions.changeVerticalScrollEnabled,
						}), [])}
					/>
					{(item.dishes && item.dishes?.length > 0) && (
						<View style={styles.relative}>
						<ScrollView
							horizontal
							scrollEnabled={Platform.OS != "web"}
							showsHorizontalScrollIndicator={false}
						>
							<View
								onStartShouldSetResponder={() => true}
								//onTouchEnd={actions.onPress}
								style={styles.dishesScrollContainer}
							>
							{item.dishes.map(dish => {
								return (
									<React.Fragment key={dish.id.toString()}>
										<DishSearchCell
											dish={dish}
											onPress={() => {
												if(Platform.OS == "web") {
													setVisibleDish(dish)
												} else if(actions.customDishPress) {
													actions.customDishPress(dish, item)
												} else {
													navigation.push("DishInfo", { dish, onRestaurantPress: actions.onPress })
												}
											}}
										/>
									</React.Fragment>
								)
							})}
							</View>
						</ScrollView>
						{Platform.OS == "web" && (
						<View style={styles.showMore}>
							<ImageBackground style={styles.showMoreShadow} source={require("@FoodListCore/Assets/Images/right-shadow.png")}>
								<Text style={styles.showMoreText}>Mostra altro</Text>
							</ImageBackground>
						</View>
						)}
						</View>
					)}
					<View style={styles.paddingVertical}>
						{props.mode == "orders" && !hasFoodListOrders && renderUrlField(item.g_orders, null, { backgroundColor: colors.inactiveGrey, paddingRight: 4, marginRight: 10 })}

						{props.mode == "bookings" && !hasFoodListBookings && renderUrlField(item.g_bookings, null, { backgroundColor: colors.inactiveGrey, paddingRight: 4, marginRight: 10 })}
					</View>
				</TouchableRipple>
				</View>
			</View>
			{DishModal}
		</View>
	);
});


const styles = StyleSheet.create({
	padding: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: margins.pagePadding / 2,
	},
	cell: {
		borderRadius: 6,
		backgroundColor: colors.white,
	},
	row: {
		flexDirection: "row",
		alignItems: "center",
	},
	dishesScrollContainer: {
		paddingLeft: margins.pagePadding,
		paddingRight: margins.pagePadding - 8,
		flexDirection: "row",
	},
	rounded: {
		borderRadius: 6,
		overflow: "hidden",
	},
	relative: {
		position: "relative",
	},
	showMore: {
		position: "absolute",
		right: 0,
		height: "100%",
	},
	showMoreShadow: {
		height: "100%",
		justifyContent: "center",
	},
	showMoreText: {
		alignSelf: "center",
		color: colors.blueMenu,
		fontWeight: "bold",
		zIndex: 100,
		marginLeft: margins.pagePadding * 2,
		paddingHorizontal: margins.pagePadding,
	},
	paddingVertical: {
		paddingVertical: 5,
	},
});

export default NewRestaurantCell;
