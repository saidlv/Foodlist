import React from 'react';
import { FlatList } from 'react-native-gesture-handler';
import { Restaurant } from '@Models/Restaurant';
import { Dish } from '@Models/Dish';
import { User } from '@Models/User';
import { CommonNavigation, CommonParamList } from '@RouteParams/Common';
import { useNavigation } from '@react-navigation/native';
import { Pluto } from '@Models/Pluto';
import { ListRenderItem, FlatListProps } from 'react-native';

export type CommonListProps<T> = Partial<FlatListProps<T>> & {
	items: T[],
	scrollable?: boolean,
}

type ListMenuProps<T> = CommonListProps<T> & {
	renderItem: ListRenderItem<T>
}

type Props<T> = ListMenuProps<T> & {
	navigation: CommonNavigation<Pluto>
}

class ListMenu<T> extends React.PureComponent<Props<T>> {
	show = (page: keyof CommonParamList, item: Restaurant | Dish | User, isUser: boolean) => {
		let id = item.id
		this.props.navigation.push(page, isUser ? { user_id: id, item: item } : { id: id, item: item })
	}
	render() {
		return (
			<FlatList<T>
				initialNumToRender={2}
				maxToRenderPerBatch={2}
				keyboardShouldPersistTaps={'handled'}
				scrollEnabled={!!this.props.scrollable || false}
				contentContainerStyle={{ paddingTop: 10 }}
				data={this.props.items}
				keyExtractor={(_, index) => {
					return index + ''
				}}
				{...this.props}
			/>
		);
	}
}


export default function GenericList <T>(props: ListMenuProps<T>) {
	let navigation = useNavigation<CommonNavigation<Pluto>>()
	return <ListMenu<T> {...props} navigation={navigation} />
}