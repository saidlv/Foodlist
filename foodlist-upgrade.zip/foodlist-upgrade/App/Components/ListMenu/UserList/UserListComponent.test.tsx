import React from 'react';
import 'react-native';
import UserList from './index';

import renderer from 'react-test-renderer';

it('renders UserList view', () => {
  expect(renderer.create(<UserList items={[]} />)).toMatchSnapshot(); //TODO: add UserList props with random values

  /*
  //if view displays different outputs when passing different values as props use:

  expect.assertions(2); // increase '2' if you add more assertions

  const first = renderer.create(<UserList pippo={true} />).toJSON();
  expect(first).toMatchSnapshot();

  const second = renderer.create(<UserList pippo={false} />).toJSON();
  expect(second).toMatchSnapshot();
  */
});
