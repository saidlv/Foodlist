import React from 'react'
import GenericList, { CommonListProps,} from '..'
import UserCell from "@Components/Cells/UserCell"
import { User } from "@Models/User"

export default function UserList (props: CommonListProps<User>)  {
	return <GenericList<User> {...props}
		renderItem={({ item }) => {
			return <UserCell item={item} />
		}}
	/>
}