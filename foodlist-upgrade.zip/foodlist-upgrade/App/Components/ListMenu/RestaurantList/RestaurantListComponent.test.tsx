import React from 'react';
import 'react-native';
import RestaurantList from './index';

import renderer from 'react-test-renderer';

it('renders RestaurantList view', () => {
  expect(renderer.create(<RestaurantList items={[]} />)).toMatchSnapshot(); //TODO: add RestaurantList props with random values

  /*
  //if view displays different outputs when passing different values as props use:

  expect.assertions(2); // increase '2' if you add more assertions

  const first = renderer.create(<RestaurantList pippo={true} />).toJSON();
  expect(first).toMatchSnapshot();

  const second = renderer.create(<RestaurantList pippo={false} />).toJSON();
  expect(second).toMatchSnapshot();
  */
});
