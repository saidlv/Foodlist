import React from 'react'
import RestaurantCell from "@Components/Cells/RestaurantCell"
import { Restaurant } from '@Models/Restaurant'
import GenericList, { CommonListProps,} from '../'

type Props = CommonListProps<Restaurant> & {
	callbackOpenCell?: () => void
}

export default function RestaurantList (props: Props)  {
	return <GenericList<Restaurant> {...props}
		renderItem={({ item }) => {
			return <RestaurantCell item={item} callbackOpenCell={props.callbackOpenCell} />
		}}
	/>
}