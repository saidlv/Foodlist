
import React from 'react'
import { Dish } from '@Models/Dish'
import GenericList, { CommonListProps } from '../'
import DishCell from '@Components/Cells/DishCell'

type Props = CommonListProps<Dish> & {
	hideDescription?: boolean
	onItemSelected?: (item: Dish) => void
	callbackOpenCell?: () => void
}

export default function DishList (props: Props)  {
	return <GenericList<Dish> {...props}
		renderItem={({ item }) => {
			return <DishCell item={item} hideDescription={props.hideDescription} onPress={props.onItemSelected} callbackOpenCell={props.callbackOpenCell} />
		}}
	/>
}