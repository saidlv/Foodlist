import React, { ReactChild } from 'react';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import { View, Text, ActivityIndicator, Image } from 'react-native';
import styles from './Style';
import { colors, when } from '@Global/GlobalProps';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';

import { RequestResponse } from '@Models/RequestResponse';
import { translate } from '@App/I18n';

/**
 * @param request: function which returns the promise of the request
 * @param onResponse: callback(body)
 * @param noData: bool
 * @param noDataText: string
 * @param onRetry: callback
 * @param error: error text, only when error present
 * @param showLogo
 * @param dontStart
 * @return graphical representation of the loadingview and loading gesture handler
 */

//TODO: maybe something should be required
export interface AutoLoadingActions<T> {
	request?: () => Promise<RequestResponse<T>>
	onResponse?: (response: RequestResponse<T>) => void
	onRetry?: () => void
}

type CommonProps<T> = {
	actions?: AutoLoadingActions<T>
  /*
   * @deprecated use actions property
   */
	request?: () => Promise<RequestResponse<T>>
  /*
   * @deprecated use actions property
   */
	onResponse?: (response: RequestResponse<T>) => void
  /*
   * @deprecated use actions property
   */
	onRetry?: () => void

	noData?: boolean,
	error?: string | null,
	loading?: boolean,
	showLogo?: boolean,
	retryComponent?: ReactChild,
	noDataText?: string | null,
	noDataComponent?: ReactChild,
	dontStart?: boolean
}

type HandleRequest = {

}

type DontStart = {
	dontStart: true

}

type AutoLoadingViewProps<T> = CommonProps<T> & (HandleRequest | DontStart)

type AutoLoadingViewState = {
	shouldHandleLoad: boolean,
	loading: boolean,
	error: boolean,
}

export default class AutoLoadingView<T> extends React.PureComponent<AutoLoadingViewProps<T>, AutoLoadingViewState> {
	actions: AutoLoadingActions<T>

	constructor(props: AutoLoadingViewProps<T>) {
		super(props)
		this.actions = props.actions || {
			request: props.request,
			onResponse: props.onResponse,
			onRetry: props.onRetry
		}
		let shouldHandleLoad = !props.dontStart && !!this.actions?.request
		this.state = {
			loading: shouldHandleLoad,
			shouldHandleLoad: shouldHandleLoad,
			error: false
		}
		shouldHandleLoad && this.load()
	}
	load() {
		this.actions.request?.().then((body) => {
			if (body.error) {
				this.showError()
			} else {
				this.actions.onResponse?.(body)
				this.setState({
					loading: false,
					error: false
				})
			}
		})
			.catch((error) => {
				//this.showError(error)
				this.showError()
			})
	}
	showError() {
		this.setState({
			loading: false,
			error: true
		})
	}

	retry() {
		if (this.state.shouldHandleLoad) {
			this.setState({
				loading: true,
				error: false
			})
			this.load()
		} else {
			this.actions.onRetry?.()
		}
	}
	noData() {
		let noData = (!this.hasError() && !this.isLoading() && this.props.noData)
		return noData
	}
	hasError() {
		return this.state.error || (!!this.props.error && this.props.error != "")
	}
	isLoading() {
		return this.state.loading || this.props.loading
	}
	render() {
		if (!this.isLoading() && !this.hasError() && !this.props.noData) {
			return <View />
		}
		return (
			<View style={[styles.container]}>
				{this.props.showLogo && !this.hasError() &&
					<View style={{ flex: 1, justifyContent: 'center' }}>
						<ActivityIndicator hidesWhenStopped={true} style={when(!this.isLoading(), { display: 'none' })} animating={this.state.loading || this.props.loading} size="large" color={colors.blackOverlay} />
					</View>
				}
				{!this.props.showLogo &&
					<ActivityIndicator hidesWhenStopped={true} style={when(!this.isLoading(), { display: 'none' })} animating={this.state.loading || this.props.loading} size="large" color={colors.blackOverlay} />
				}
				{(this.hasError()) &&
					<View style={[styles.errorContainer, when(this.props.showLogo, { flex: 1 })]}>
						<Text style={styles.error}>{this.props.error || translate("defaultError")}</Text>
						{(this.state.shouldHandleLoad || this.actions.onRetry) && !this.props.retryComponent &&
							<TouchableOpacity style={styles.retryButton} onPress={this.retry.bind(this)}>
								<Text style={styles.retryText}>Riprova</Text>
							</TouchableOpacity>
						}
						{!this.state.shouldHandleLoad && typeof this.props.retryComponent === "string" &&
							<TouchableOpacity style={styles.retryButton} onPress={this.actions.onRetry}>
								<Text style={styles.retryText}>{this.props.retryComponent}</Text>
							</TouchableOpacity>
						}
					</View>
				}
				{this.noData() && (
					<View style={styles.errorContainer}>
						{!this.props.noDataComponent &&
							<Text style={styles.error}>{this.props.noDataText || translate("noResult")}</Text>
						}
						{this.props.noDataComponent && this.props.noDataComponent}
					</View>
				)}
				{this.props.showLogo &&
					<Icon name="menu-logo" style={{ marginBottom: 60 }} color={colors.foodlist} size={18} />
				}
			</View>
		);
	}
}
