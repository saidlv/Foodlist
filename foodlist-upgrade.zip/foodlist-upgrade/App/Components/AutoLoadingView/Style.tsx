import { colors } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet, Platform, Dimensions } from 'react-native';

export default StyleSheet.create({
	container: {
		position: "absolute",
		top: 0,
		bottom: 0,
		left: 0,
		right: 0,
		flex: 1,
		justifyContent: "center",
		zIndex: 100000,
		backgroundColor: colors.greyBackground,
		alignItems: 'center',
		paddingBottom: 40
	},
	errorContainer: {
		alignSelf: 'center',
		justifyContent: 'center'
	},
	error: {
		fontSize: 16,
		marginHorizontal: 20,
		textAlign: 'center'
	},
	retryButton: {
		flexDirection: 'row',
		alignItems: 'center',
		alignSelf: 'center',
		marginTop: 5
	},
	retryText: {
		fontWeight: 'bold',
		fontSize: 16,
		color: colors.blueMenu
	}
})
