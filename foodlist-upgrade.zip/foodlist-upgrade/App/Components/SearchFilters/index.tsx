import ActionSheet, { ActionSheetCustom } from '@alessiocancian/react-native-actionsheet';
import { DEFAULT_SEARCH_RADIUS } from '@FoodListCore/Network/OrderManager';
import { ReduxState } from '@App/Redux/StateFormat';
import { SearchNavigation } from '@App/RouteParams/Search';
import { formatDecimal, formatPrice } from '@FoodListCommon/prices';
import { I18nKey } from '@FoodListCommon/Translations';
import FLIcon from '@FoodListCore/Components/FLIcon';
//import Gradient from '@FoodListCore/Components/Gradient';
import IconButton from '@FoodListCore/Components/IconButton';
import Line from '@FoodListCore/Components/Line';
import SheetPopup, { BottomSheetFlatList } from '@FoodListCore/Components/SheetPopup';
import StarRating from '@FoodListCore/Components/StarRating';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { colors, margins, showError } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { RestaurantCategory } from '@Models/Category';
import { useNavigation } from '@react-navigation/core';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, StyleSheet, Text, View, ScrollView, TextInput, ViewStyle, Keyboard, Platform, ActivityIndicator, FlatList, FlatListProps } from 'react-native';
import { shallowEqual, useDispatch, useSelector } from 'react-redux';
import BText from '../BText';
import GlobalManager from '@App/Network/GlobalManager';
import { setRestaurantCategories } from '@App/Redux/Actions';
import { RadioButton } from 'react-native-paper';
import RadioHandler from '@FoodListCore/Components/RadioHandler';
import { INITIAL_SEARCH_RADIUS } from '@App/Redux/StateFormat/FiltersFormat';

export type Mode = "delivery" | "takeaway" | "booking" | "explore-restaurants" | "explore-dishes"

export const isExploreTab = (mode: Mode) => {
	return mode == "explore-restaurants" || mode == "explore-dishes"
}

type Props = {
	mode: Mode
	vertical?: boolean
	onFiltersChanged: (filters: object) => void
}

type ButtonProps = {
	onPress: () => void
	children: React.ReactNode
	active?: boolean
	showDropdown?: boolean
	style?: ViewStyle
	vertical?: boolean
	disabled?: boolean
}
const Button = React.memo(({ onPress, children, active, style, showDropdown, ...props }: ButtonProps) => {
	return (
		<View style={[props.vertical ? styles.verticalButtonContainer : styles.buttonContainer, active ? styles.selectedCell : null, style]}>
			<TouchableRipple
				onPress={onPress}
				disabled={props.disabled}
				style={styles.rippleContainer}
			>
				{(active || showDropdown) ? (
					<View style={styles.row}>
						<View style={[styles.row, { flexGrow: 1 }]}>
						{children}
						</View>
						<FLIcon materialIcon={showDropdown ? "arrow-drop-down" : "close"} style={styles.dropdowIcon} color={showDropdown ? colors.dark : colors.darkBlue} size={16} />
					</View>
				) : children}
			</TouchableRipple>
		</View>
	)
})
type SortBy = "popularity" | "reviews_rating" | "distance"
type SortOption = { labelKey: I18nKey, value: SortBy | "first_available" }
const filterOptions: SortOption[] = [{ labelKey: "firstAvailable", value: "first_available" }, { labelKey: "valutation", value: "reviews_rating" }, { labelKey: "distance", value: "distance" }]
const exploreFilterOptions: SortOption[] = [{ labelKey: "bestNear", value: "popularity"}, { labelKey: "valutation", value: "reviews_rating" }, { labelKey: "distance", value: "distance" }]

const ratingOptions = [4.5, 4, 3.5]

export type Filters = {
	free_delivery?: 0 | 1
	/** search text */
	name?: string
	foodlist_sort_by_first?: boolean
	order_by?: SortBy
	explore_order_by?: SortBy
	/** comma separated ids: "11,32,10" */
	categories?: string
	open_now?: 1
	distance?: number
	min_rating?: number
}

const mapRedux = (state: ReduxState) => {
	return {
		restCategories: state.restCategories || []
	}
}

export const radiusNumOptions = [2, 5, 10, 15, 20, 30, 50, /* null */]
export const radiusOptionLabel = (radius: number | null, showMax?: boolean) => {
	return radius ? (showMax ? "max " : "") + translate("kmDistance", { value: radius }) : translate("everywhere")
}

const BUTTONS_DISTANCE = 8
const ANIMATION_DURATION = 300

export type FiltersRefType = {
	filters: Filters,
	setRadius: (radius: number | null) => void
}
const SearchFilters = React.memo(React.forwardRef<FiltersRefType, Props>((props: Props, ref) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	const filters = useMemo(() => ({
		foodlist_sort_by_first: true,
		distance: DEFAULT_SEARCH_RADIUS,
		explore_order_by: exploreFilterOptions[0].value,
	} as Filters), [])
	//const [loading, setLoading] = useState(false)

	const [radius, setRadius] = useState<number | null>(DEFAULT_SEARCH_RADIUS)

	React.useImperativeHandle(ref, () => ({
		filters,
		setRadius: (radius) => {
			filters.distance = radius || undefined
			setRadius(radius)
		},
	}))

	const [searchText, setSearchText] = useState("")

	const navigation = useNavigation<SearchNavigation<"NewSearch">>()
	
	const [freeDelivery, setFreeDelivery] = useState(false)
	const [openNow, setOpenNow] = useState(false)
	const [minRating, _setMinRating] = useState<number | null>(null)
	const [activeSort, _setActiveSort] = useState(filterOptions[0])
	const [activeExploreSort, _setActiveExploreSort] = useState(exploreFilterOptions[0])
	const isExplore = isExploreTab(props.mode)
	const currentSort = isExplore ? activeExploreSort : activeSort

	const [showSearch, setShowSearch] = useState(false)

	//REFS
	const actionSheet = useRef<ActionSheet>(null)
	const ratingActionSheet = useRef<ActionSheet>(null)
	const inputAnimation = useRef(new Animated.Value(0)).current
	const inputRef = useRef<TextInput>(null)
	const scrollRef = useRef<ScrollView>(null)

	const { restCategories } = useSelector(mapRedux, shallowEqual)
	const dispatch = useDispatch()

	const [showCategories, setShowCategories] = useState(false)
	const [selectedCategories, setSelectedCategories] = useState<RestaurantCategory[]>([])

	const [categoriesSearchText, setCategoriesSearchText] = useState("")

	const shownCategories = useMemo(() => {
		if(categoriesSearchText) {
			const searchText = categoriesSearchText.toLowerCase()
			return restCategories.filter(item => item.label_it.toLowerCase().indexOf(searchText) != -1)
		}
		return restCategories
	}, [restCategories, categoriesSearchText])

	const hasCategories = restCategories.length > 0

	const scrollToStart = useCallback(() => {
		setTimeout(() => {
			scrollRef.current?.scrollTo({ x: -1000, y: 0, animated: true })
		})
	}, [scrollRef])

	const onSearchPress = useCallback(() => {
		setShowSearch(true)

		inputRef.current?.focus()
		Animated.timing(inputAnimation, {
			toValue: 1,
			duration: ANIMATION_DURATION,
			useNativeDriver: false,
		}).start()
	}, [])

	const sendFiltersUpdate = useCallback(() => {
		props.onFiltersChanged(filters)
	}, [filters, props.onFiltersChanged])
	const onSearchBlur = useCallback(() => {
		if((filters.name || "") != searchText) {
			filters.name = searchText
			sendFiltersUpdate()
		}
		Animated.timing(inputAnimation, {
			toValue: 0,
			duration: ANIMATION_DURATION,
			useNativeDriver: false,
		}).start(() => {
			Keyboard.dismiss()
			setShowSearch(false)
		})
	}, [searchText, sendFiltersUpdate])
	const showFilters = useCallback(() => {
		navigation.navigate("RestaurantFilter")
	}, [])
	const showOrderBy = useCallback(() => {
		actionSheet.current?.show()
	}, [])
	const showCategory = useCallback(() => {
		setCategoriesSearchText("")
		setShowCategories(true)
		if(!hasCategories) {
			const globalMagaer = new GlobalManager()
			globalMagaer.getRestaurantCategories().then(res => {
				dispatch(setRestaurantCategories(res.data?.response || []))
			}).catch(err => {
				showError(err)
				setShowCategories(false)
			})
		}
	}, [hasCategories])
	const setMinRating = useCallback((value: number | null) => {
		_setMinRating(value)
		if(value) {
			filters.min_rating = value
			scrollToStart()
		} else {
			delete filters.min_rating
		}
		sendFiltersUpdate()
	}, [scrollToStart])
	const changeFreeDelivery = useCallback(() => {
		const newValue = !freeDelivery
		setFreeDelivery(newValue)
		filters.free_delivery = newValue ? 1 : undefined
		sendFiltersUpdate()
		if(newValue) {
			scrollToStart()
		}
	}, [freeDelivery, sendFiltersUpdate])

	const changeOpenNow = useCallback(() => {
		const newValue = !openNow
		setOpenNow(newValue)
		filters.open_now = newValue ? 1 : undefined
		sendFiltersUpdate()
		if(newValue) {
			scrollToStart()
		}
	}, [openNow, sendFiltersUpdate])

	const clearText = useCallback(() => {
		setSearchText("")
		filters.name = ""
		sendFiltersUpdate()
	}, [sendFiltersUpdate])
	const setActiveSort = useCallback((option: SortOption) => {
		if(isExplore) {
			_setActiveExploreSort(option)
			if(option.value == "first_available") {
				//this shouldn't happen
				filters.order_by = "distance"
			} else {
				filters.explore_order_by = option.value
			}
		} else {
			_setActiveSort(option)
			if(option.value == "first_available") {
				filters.order_by = "distance"
				filters.foodlist_sort_by_first = true
			} else	{
				filters.order_by = option.value
				delete filters.foodlist_sort_by_first
			}
		}
		
		if(option.value != "distance" && !filters.distance) {
			filters.distance = 10
			setRadius(10)
		}
		sendFiltersUpdate()
	}, [isExplore])

	const updateCategories = useCallback((newCategories: RestaurantCategory[]) => {
		filters.categories = newCategories.map(item => item.id).join(",")
		setSelectedCategories(newCategories)
		sendFiltersUpdate()
		scrollToStart()
	}, [scrollToStart])
	const addCategory = useCallback((category: RestaurantCategory) => {
		setShowCategories(false)
		const newCategories = selectedCategories.concat(category)
		updateCategories(newCategories)
	}, [selectedCategories])
	const removeCategory = useCallback((category: RestaurantCategory) => {
		setShowCategories(false)
		const newCategories = selectedCategories.filter(item => item.id != category.id)
		updateCategories(newCategories)
	}, [selectedCategories])

	const radiusSheet = useRef<ActionSheet>(null)
	const showRadiusFilter = useCallback(() => {
		radiusSheet.current?.show()
	}, [])
	const showRatingOptions = useCallback(() => {
		ratingActionSheet.current?.show()
	}, [])
	const changeText = useCallback((text: string) => {
		setSearchText(text)
		if((filters.name || "") != text) {
			filters.name = text
			sendFiltersUpdate()
		}
	}, [])

	const options = isExplore ? exploreFilterOptions : filterOptions
	const sortOptions = useMemo(() => {
		return [...options.map(item => translate(item.labelKey)), translate("cancel")]
	}, [options])
	const radiusOptions = useMemo(() => {
		return [...radiusNumOptions.map(radius => radiusOptionLabel(radius)), translate("cancel")]
	}, [])

	const setSort = useCallback((index) => {
		const options = isExplore ? exploreFilterOptions : filterOptions
		if(index < options.length) {
			setActiveSort(options[index])
		}
	}, [props.mode])
	const setRadiusFilter = React.useCallback((distance: number) => {
		setRadius(distance)
		filters.distance = distance || undefined
		sendFiltersUpdate()
	}, [])

	useEffect(() => {
		scrollToStart()
	}, [props.mode])

	const ratingsSideOptions = React.useMemo(() => {
		return [{ id: -1, value: -1 }].concat(ratingOptions.map(val => ({ id: val, value: val })))
	}, [])

	const searchInput = (
		<>
			<FLIcon materialIcon="search" size={18} />
			<TextInput
				ref={inputRef}
				value={searchText}
				style={styles.searchInput}
				onBlur={onSearchBlur}
				placeholder={translate("searchRestaurantOrDishPlaceholder")}
				clearButtonMode="always"
				returnKeyType="search"
				onChangeText={changeText}
				/>
			{(!!searchText && searchText.length > 0 && Platform.OS != "ios") && (
				<IconButton onPress={() => changeText("")} style={{ alignSelf: "center", padding: 5, marginLeft: 5, marginRight: margins.pagePadding - 5 }}>
					<FLIcon materialCommunityIcon="close-circle" color={colors.greyArrow} size={16} />
				</IconButton>
			)}
		</>
	)

	//const isEnd = scrollRef.current?.
	return (
		<View style={[styles.container, props.vertical ? [styles.column, { height: "100%" }] : null]}>
			{!props.vertical && (
			<Animated.View style={{ flexDirection: "row", justifyContent: "center", paddingVertical: 5, opacity: showSearch ? 1 : 0 /* inputAnimation.interpolate({ inputRange: [0, 1], outputRange: [0, 1] }) */, width: !showSearch ? 0 : inputAnimation.interpolate({ inputRange: [0, 1], outputRange: ["30%", "100%"] }), height: "100%" }}>
				<View style={[styles.searchContainer, { marginLeft: margins.pagePadding, height: "100%" }]}>
					{searchInput}
				</View>
				<IconButton onPress={onSearchBlur} style={{ alignSelf: "center", padding: 5, marginLeft: 5, marginRight: margins.pagePadding - 5 }}>
					<FLIcon materialIcon="close" size={20} />
				</IconButton>
			</Animated.View>
			)}
			<ScrollView
				style={styles.fullWidth}
				horizontal={!props.vertical}
				showsHorizontalScrollIndicator={props.vertical}
				ref={scrollRef}
				contentContainerStyle={Platform.OS == "web" ? styles.fullWidth : null}
			>
				<View style={[styles.scrollContainer, props.vertical ? styles.column : null]}>
					{props.vertical ? (
						<View style={[styles.searchContainer, { marginVertical: 10, marginHorizontal: 10, minHeight: 40 }]}>
							{searchInput}
						</View>
					) : (
						<Button onPress={onSearchPress} style={[searchText ? styles.selectedCell : undefined, { opacity: showSearch ? 0 : 1 }]}>
							<View style={styles.row}>
								<FLIcon materialIcon="search" size={18} />
								{!!searchText && (
									<>
										<BText style={styles.searchValue}>{searchText}</BText>
										<View style={{ marginVertical: -10, marginRight: -5, marginLeft: 5 }}>
											<IconButton onPress={clearText}>
												<FLIcon materialIcon="close" size={16} />
											</IconButton>
										</View>
									</>
								)}
							</View>
						</Button>
					)}

					{!!minRating && !props.vertical && (
						<Button active onPress={() => setMinRating(null)}>
							<Icon name="star-full" color={colors.starColor} size={16} />
							<BText selectable={false} style={styles.selectedMinRating}>{formatDecimal(minRating, 1, true)}+</BText>
						</Button>
					)}


					{(props.mode != "booking" && !isExplore) && (freeDelivery && !props.vertical) && (
						<Button vertical={props.vertical} onPress={changeFreeDelivery} active>
							<BText style={[styles.filterText, styles.activeText]}>{translate(props.mode == "delivery" ? "freeDelivery" : "freeTakeaway").toUpperCase()}</BText>
						</Button>
					)}
					{(props.mode == "explore-restaurants" && openNow) && (
						<Button vertical={props.vertical} onPress={changeOpenNow} active>
							<BText style={[styles.filterText, styles.activeText]}>{translate("openNow_option").toUpperCase()}</BText>
						</Button>
					)}

					{props.mode != "explore-dishes" && selectedCategories.map((item) => {
						return (
							<Button vertical={props.vertical} key={item.id} active onPress={() => removeCategory(item)}>
								<BText style={styles.selectedCategoryText}>{item.label_it}</BText>
							</Button>
						)
					})}

					{/* <Button vertical={props.vertical} onPress={showFilters}>
						<FLIcon materialIcon="filter-alt" size={18} />
					</Button> */}
					{props.vertical ? (
						<View style={styles.verticalButtonContainer}>
							<BText style={[styles.filterText, { padding: 10 }]}>{translate("sortBy").toUpperCase()}</BText>
							<RadioHandler<SortOption>
								values={options}
								initialSelection={activeSort}
								actions={{
									valueSelected: (_, item) => setActiveSort(item),
									cellProps: (item) => ({
										title: translate(item.labelKey),
										style: {
											paddingHorizontal: 5,
										},
										lightStyle: true,
										titleStyle: styles.radioLabel,
									}),
								}}
								hideSeparators
							/>
						</View>
					) : (
						<Button
							vertical={props.vertical}
							onPress={showOrderBy}
							showDropdown={!props.vertical}
							disabled={props.vertical}
						>
							<View style={[styles.vertical, props.vertical ? { alignItems: "flex-start" } : null]}>
								<BText style={styles.filterText}>{translate("sortBy").toUpperCase()}</BText>
								<BText style={styles.activeSort}>{translate(currentSort.labelKey)}</BText>
							</View>
						</Button>
					)}
					{props.mode != "delivery" && !props.vertical && (
						<Button vertical={props.vertical} onPress={showRadiusFilter} showDropdown>
							<View style={styles.vertical}>
								<BText style={{ fontSize: 12 }}>{translate("distance").toUpperCase()}</BText>
								<BText style={styles.activeSort}>{radiusOptionLabel(radius, true)}</BText>
							</View>
						</Button>
					)}
					{(props.mode != "booking" && !isExplore) && (!freeDelivery || props.vertical) && (
						<Button vertical={props.vertical} onPress={changeFreeDelivery} active={freeDelivery}>
							<BText style={[styles.filterText, freeDelivery ? styles.activeText : null]}>{translate(props.mode == "delivery" ? "freeDelivery" : "freeTakeaway").toUpperCase()}</BText>
						</Button>
					)}
					{(props.mode == "explore-restaurants" && !openNow) && (
						<Button vertical={props.vertical} onPress={changeOpenNow}>
							<BText style={styles.filterText}>{translate("openNow_option").toUpperCase()}</BText>
						</Button>
					)}
					{props.mode != "explore-dishes" && (
						<Button vertical={props.vertical} onPress={showCategory} showDropdown>
							<BText style={styles.filterText}>{translate("categories").toUpperCase()}</BText>
						</Button>
					)}
					{props.vertical ? (
						<>
						<View style={styles.verticalButtonContainer}>
							<BText style={[styles.filterText, { padding: 10 }]}>{translate("minValutation").toUpperCase()}</BText>
							<RadioHandler<{ value: number, id: number }>
								values={ratingsSideOptions}
								initialSelection={ratingsSideOptions[0]}
								actions={{
									valueSelected: (_, item) => setMinRating(item?.value == -1 ? null : item?.value),
									cellProps: (item) => ({
										style: {
											paddingHorizontal: 5,
										},
										lightStyle: true,
										customContent: item.id == -1 ? (
											<Text>Nessuna</Text>
										) : (
											<View style={styles.row}>
												<StarRating rating={item.value} size={16} />
												<BText style={{ marginLeft: 10, color: colors.blueMenu, fontSize: 14 }}>{formatDecimal(item.value, 1, true)}+</BText>
											</View>
										)
									}),
								}}
								hideSeparators
							/>
						</View>
						{props.mode != "delivery" && (
						<View style={styles.verticalButtonContainer}>
							<BText style={[styles.filterText, { padding: 10 }]}>DISTANZA MASSIMA</BText>
							<RadioHandler<{ value: number, id: number, label: string }>
								values={radiusNumOptions.map(km => ({ id: km, value: km, label: radiusOptionLabel(km) }))}
								initialValue={radius}
								actions={{
									valueSelected: (_, item) => setRadiusFilter(item?.value),
									cellProps: (item) => ({
										style: {
											paddingHorizontal: 5,
										},
										lightStyle: true,
										title: item.label,
										titleStyle: styles.radioLabel,
									}),
								}}
								hideSeparators
							/>
						</View>
						)}
						</>
					) : (
						<Button vertical={props.vertical} onPress={showRatingOptions} showDropdown>
							<BText style={styles.filterText}>{translate("minValutation").toUpperCase()}</BText>
						</Button>
					)}
					
					{/* <Button vertical={props.vertical} onPress={showFilters}>
						<BText style={styles.filterText}>ALTRI FILTRI</BText>
					</Button> */}
				</View>
			</ScrollView>
			{/* <View style={{ position: "absolute", right: 0, width: 40, height: "100%" }}>
				<Gradient color="#dddddd" minOpacity="0" direction="horizontal-reverse" linear />
			</View> */}
			<ActionSheet
				ref={radiusSheet}
				options={radiusOptions}
				cancelButtonIndex={radiusOptions.length - 1}
				onPress={useCallback((index) => {
					if(index < radiusNumOptions.length) {
						const distance = radiusNumOptions[index]
						setRadiusFilter(distance)
					}
				}, [])}
			/>
			<ActionSheet
				options={sortOptions}
				ref={actionSheet}
				cancelButtonIndex={3}
				onPress={setSort}
			/>
			<ActionSheetCustom
				options={React.useMemo(() => ([
					...ratingOptions.map(item => (
						<View style={styles.row}>
							<StarRating rating={item} size={16} />
							<BText style={{ marginLeft: 10, color: colors.blueMenu, fontSize: 16 }}>{formatDecimal(item, 1, true)}+</BText>
						</View>
					)),
					translate("nothing_female"),
					translate("cancel"),
				]), [])}
				ref={ratingActionSheet}
				title={translate("minValutation")}
				cancelButtonIndex={4}
				onPress={useCallback((index) => {
					if(index == 4) return
					if(index < options.length) {
						setMinRating(ratingOptions[index])
					} else {
						setMinRating(null)
					}
				}, [props.mode])}
			/>
			{showCategories && (
				<SheetPopup
					visible={showCategories}
					actions={{ onTapOutside: () => setShowCategories(false) }}
					enablePanning
					webNoPadding
					headerText={translate("categories")}
				>
					<View style={styles.categoriesSearchContainer}>
						<FLIcon materialIcon="search" size={18} color={colors.darkGreyText} />
						<TextInput
							style={styles.categoriesSearchInput}
							placeholder={translate("searchPlaceholder")}
							onChangeText={setCategoriesSearchText}
						/>
					</View>
					<Line />
					{hasCategories ? (
						<BottomSheetFlatList
							keyboardShouldPersistTaps="handled"
							data={shownCategories}
							style={{ backgroundColor: colors.greyBackground }}
							ItemSeparatorComponent={Line}
							keyExtractor={item => item.id?.toString()}
							renderItem={({item}) => {
								const isSelected = selectedCategories.indexOf(item) != -1
								return (
									<TouchableRipple style={[styles.cell, isSelected ? styles.selectedCell : null]} onPress={() => isSelected ? removeCategory(item) : addCategory(item)}>
										<BText style={{ flex: 1}}>{item.label_it}</BText>
										{isSelected && (
											<FLIcon materialIcon="close" size={16} />
										)}
									</TouchableRipple>
								)
							}}
						/>
					) : (
						<View style={{ padding: margins.pagePadding }}>
							<ActivityIndicator size="large" />
						</View>
					)}
				</SheetPopup>
			)}
		</View>
	);
}));

const styles = StyleSheet.create({
	container: {
		backgroundColor: colors.white,
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "center",
	},
	column: {
		flexDirection: "column",
		width: "100%",
		paddingLeft: 0,
		paddingRight: 0,
	},
	searchInput: {
		flex: 1,
		height: "100%",
		paddingLeft: 10,
		marginRight: 8,
		paddingVertical: 5,
	},
	searchContainer: {
		flexDirection: "row",
		flex: 1,
		alignItems: "center",
		backgroundColor: "#eee",
		paddingLeft: 10,
		borderRadius: 40,
		borderWidth: 1,
		borderColor: colors.greyBorder,
	},
	scrollContainer: {
		flexDirection: "row",
		paddingLeft: margins.pagePadding,
		paddingRight: margins.pagePadding - BUTTONS_DISTANCE,
		paddingVertical: 5,
	},
	rippleContainer: {
		padding: 10,
		justifyContent: "center",
		flexGrow: 1,
	},
	buttonContainer: {
		borderRadius: 20,
		overflow: "hidden",
		//backgroundColor: "#fcfcfc",
		borderColor: colors.greyBorder,
		borderWidth: 1,
		marginRight: BUTTONS_DISTANCE,
		alignItems: "stretch",
	},
	verticalButtonContainer: {
		borderRadius: 20,
		marginHorizontal: 10,
		marginBottom: BUTTONS_DISTANCE,
		borderWidth: 1,
		borderColor: colors.greyBorder,
		overflow: "hidden",
	},
	activeButton: {
		backgroundColor: colors.blueMenu,
		/* borderWidth: 3,
		marginLeft: -2,
		marginVertical: -2,
		marginRight: BUTTONS_DISTANCE - 2, */
		borderColor: "transparent",
	},
	filterText: {
		fontSize: 12,
	},
	vertical: {
		flexDirection: "column",
		paddingLeft: 2,
		marginVertical: -10,
		alignItems: "center",
	},
	activeSort: {
		fontSize: 11,
		color: colors.greyInfoText,
		marginTop: -2,
	},
	row: {
		flexDirection: "row",
		alignItems: "center",
	},
	dropdowIcon: {
		marginLeft: 3,
		marginRight: -3
	},
	searchValue: {
		marginLeft: 5,
		color: colors.greyInfoText,
		fontStyle: "italic",
	},
	cell: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: margins.vertical,
		flexDirection: "row",
		alignItems: "center",
	},
	selectedCell: {
		backgroundColor: colors.withAlpha(colors.blueMenu, 0.15)
	},
	categoriesSearchContainer: {
		marginHorizontal: margins.pagePadding,
		backgroundColor: colors.withAlpha(colors.black, 0.08),
		borderRadius: 20,
		marginBottom: 10,
		marginTop: Platform.OS == "web" ? 10 : 0,
		flexDirection: "row",
		alignItems: "center",
		paddingLeft: 10,
	},
	categoriesSearchInput: {
		paddingRight: 15,
		paddingLeft: 7,
		paddingVertical: 7,
		flex: 1,
	},
	activeText: {
		color: colors.darkBlue,
		fontWeight: "bold",
	},
	actionTitle: {
		//fontSize: 16,
		fontWeight: "bold",
	},
	selectedCategoryText: {
		color: colors.darkBlue,
		marginRight: 3,
	},
	selectedMinRating: {
		marginLeft: 5,
		color: colors.darkBlue,
		fontWeight: "bold"
	},
	radioLabel: {
		fontSize: 14,
		fontWeight: "300",
	},
	fullWidth: { width: "100%" },
});

export default SearchFilters;
