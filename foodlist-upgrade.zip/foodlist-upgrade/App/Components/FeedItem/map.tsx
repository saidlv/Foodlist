import { length, getDishRestaurant } from "@Global/GlobalProps"
import { Review } from "@Models/Review"
import { Photo } from "@Models/Photo"
import { Restaurant } from "@Models/Restaurant"
import { Dish } from "@Models/Dish"
import { restAddress } from "@FoodListCore/Global/GlobalProps"


const getRating = (item: Review) => {
	if (item.rating) {
		return item.rating
	}
	let rating = item.rating_service + item.rating_quality + item.rating_location + item.rating_price
	rating = rating / 4
	return rating
}
const getAddress = (item: Review) => {
	if (item.restaurant) {
		return restAddress(item.restaurant)
	} else if (item.dish) {
		return getDishRestaurant(item.dish)?.name
	}
	return ""
}
const tryGetPhoto = (photos: Photo[], thumb?: boolean) => {
	if (length(photos) > 0) {
		return {
			uri: thumb ? photos[0].thumbUrl : photos[0].fullUrl
		}
	}
	return
}
const getPhoto = (item: Review, reviewItem: Restaurant | Dish | undefined, thumb?: boolean) => {
	let photos = tryGetPhoto(item?.photos || [], thumb)
	/* if (photos == null) {
		photos = tryGetPhoto(reviewItem?.photos || [], thumb)
	} */
	return photos
}

const map = (item: Review): Review => {
	let reviewItem = item.restaurant || item.dish
	let isDish = item.feed_type == "DISH"
	item.userImage = item.user?.photo ?? undefined,
	//item.rating = getRating(item),
	item.thumbReviewImage = getPhoto(item, reviewItem, true)
	item.reviewImage = getPhoto(item, reviewItem, false),
	item.full_address = getAddress(item) ?? "",
	item.name = reviewItem?.name,
	item.price = item.dish?.price,
	item.isDish = isDish,
	item.likes = item.likes || []

	return item;
}

export default map