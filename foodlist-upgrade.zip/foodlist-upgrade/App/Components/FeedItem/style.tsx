import commonStyle from '@FoodListCore/Global/CommonStyle';
import { StyleSheet } from 'react-native';
import { margins, colors } from '@FoodListCore/Global/GlobalProps';

export default StyleSheet.create({
	listItem: {
		padding: margins.pagePadding / 2,
		paddingHorizontal: margins.pagePadding,
	},
	box: {
		backgroundColor: "#fff",
		borderRadius: 6,
		...commonStyle.shadow
	},
	imageContainer: {
		backgroundColor: "#e0e6ea",
		marginBottom: 12,
		minHeight: 180,
		flex: 1,
	},
	contentContainer: {
		paddingHorizontal: 12,
		paddingBottom: 7
	},
	title: {
		fontSize: 18,
		fontWeight: "500",
		color: '#000',
		flex: 1
	},
	address: {
		fontSize: 12,
		color: '#000',
		fontWeight: '500'
	},
	inlineAddress: {
		marginLeft: 7,
		fontSize: 12,
	},
	distance: {
		fontSize: 10,
		color: colors.greyInfoText,
		marginLeft: 5,
	},
	description: {
		color: colors.darkGreyText,
		fontSize: 12,
		fontStyle: 'italic',
		marginTop: 6
	},
	topRow: {
		marginVertical: 12,
		marginHorizontal: 12,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'stretch',
		flex: 0
	},
	postType: {
		backgroundColor: colors.blueMenu,
		color: "#fff",
		fontWeight: "500",
		padding: 5,
		paddingLeft: 12,
		paddingRight: 12,
		borderRadius: 1000,
	},
	dishColor: {
		backgroundColor: colors.red
	},
	whiteText: {
		color: "#fff",
		fontWeight: "600",
		fontSize: 12
	},
	postedByText: {
		fontWeight: "600",
		paddingRight: 12,
		fontSize: 14
	},
	flexRow: {
		flex: 1,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'center'
	},
	flexColumn: {
		flex: 1,
		flexDirection: 'column'
	},
	backgroundImage: {
		width: '100%',
		height: '100%',
	},
	ratingRow: {
		flex: 1,
		flexDirection: 'row',
		width: "100%",
		justifyContent: 'space-between',
		alignItems: 'center'
	},
	rating: {
		alignSelf: "flex-start",
		color: colors.red,
		fontWeight: '900'
	},
	userImage: {
		width: 32,
		height: 32,
		borderRadius: 18
	},
	kitchenKind: {
		fontWeight: '700',
		fontSize: 10,
		textAlignVertical: 'center',
		color: colors.greyText
	},
	greyText: {
		fontSize: 12,
		fontWeight: '900',
		color: colors.greyText,
		textAlignVertical: 'center',
		paddingLeft: 6,
		paddingRight: 24
	},
	commentsText: {
		paddingRight: 22
	},
	infoBox: {
		//minHeight: 40,
		backgroundColor: colors.greyBox
	},
	inline: {
		flex: 0,
		flexDirection: 'row',
		alignItems: 'center'
	},
	bottomRowContainer: {
		paddingVertical: 10,
		paddingHorizontal: 12
	},
	postTime: {
		paddingBottom: 4,
		paddingTop: 4,
		fontWeight: "normal",
		fontSize: 11,
	},
	detailLineContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		marginBottom: 4,
		paddingHorizontal: 12,
		paddingVertical: 7,
		backgroundColor: colors.lighterGrey,
	},
	showDetail: {
		flex: 0,
		marginLeft: 10,
		backgroundColor: colors.blueMenu,
		paddingHorizontal: 16,
		paddingVertical: 8,
		borderRadius: 20,
		justifyContent: 'center',
		...commonStyle.hardShadow
	},
	redDetail: {
		backgroundColor: colors.red
	},
	reviewItemImage: {
		width: 40,
		height: 40,
		marginRight: 10,
		borderRadius: 4,
	},
});
