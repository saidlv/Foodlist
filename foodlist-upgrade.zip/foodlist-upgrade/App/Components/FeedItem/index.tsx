import React from 'react';
import { colors, when, error, length } from '@Global/GlobalProps';
import { Text, View } from 'react-native';
import { TouchableWithoutFeedbackFixed as TouchableWithoutFeedback } from '@FoodListCore/Components/TouchableFixed';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import styles from './style';
import FirebaseAnalytics from "@Services/FirebaseAnalytics";
import ProfileImage from '@Components/ProfileImage';
import { connect } from 'react-redux';
import ActionSheet from '@alessiocancian/react-native-actionsheet';
import ReviewManager from "@FoodListCore/Network/ReviewManager"
import { User } from '@Models/User';

import { Review, ReviewStatus } from '@Models/Review';
import { ReduxState } from '@Redux/StateFormat';
import { CommonNavigation } from '@RouteParams/Common';
import { useNavigation } from '@react-navigation/native';
import { translate } from '@App/I18n';
import { Pluto } from '@Models/Pluto';
import Trans from '@Components/Trans'
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import FLImage from '@FoodListCore/Components/FLImage';
import { Restaurant } from '@Models/Restaurant';
import { dishImage, getDishRestaurant, imageFood, imageRestaurant, showConfirm } from '@FoodListCore/Global/GlobalProps';
import ReviewContent, { getReviewDateString } from '@FoodListCore/Components/ReviewContent';
import { getDishSectionName } from '@FoodListCommon/menu';
import ReviewLikeButton from '@FoodListCore/Components/ReviewLikeButton';
import { printableDistance } from '@FoodListCore/Global/CommonStuff/CommonFunctions';

const getUserLikeText = () => {
	return <Text style={{ color: colors.blackText }}/>
}

const getLikeText = (item: Review) => {
	let likes = item.likes
	let len = length(likes)

	if (len == 0) {
		return ""
	} else {
		let firstLike = getUserLikeText()
		if (len == 1) {
			return (<Trans i18nKey="likedBy" values={{ person: likes[0].user.username }}>
				{firstLike}
			</Trans>)
		} else if (len == 2) {
			let secondLike = getUserLikeText()
			return (<Trans i18nKey="likedByAnd" values={{ firstPerson: likes[0].user.username, secondPerson: likes[1].user.username }}>
				{firstLike}
				{secondLike}
			</Trans>)
		} else {
			return (<Trans i18nKey="likedByAndOther" values={{ firstPerson: likes[0].user.username, num: len - 1 }}>
				{firstLike}
			</Trans>)
		}
	}
}

const getLike = (item: Review) => {
	return (<Text style={[styles.kitchenKind, { marginBottom: 8, fontSize: 12 }, when(length(item.likes) == 0, { display: 'none' })]}>
		{getLikeText(item)}
	</Text>)
}

/**
 * @param item: review
 * @param showDetail: se true press sulla cella apre i dettagli
 * @param hideButton: se true nasconde il bottone per dettagli ristorante/piatto
 */

type FeedItemProps = {
	item: Review,
	disableUserPress?: boolean,
	showDetail?: boolean,
	hideButton?: boolean,
	callbackShouldReload?: (arg?: boolean) => void
	callbackUpdateData?: (item: Review) => void,
	current_user?: User,
}

type FeedItemState = {
	item: Review,
	loadingLike: boolean,
	myReview?: boolean
	canDelete?: boolean
	canEdit?: boolean
}

type Props = FeedItemProps & { navigation: CommonNavigation<Pluto> }

class FeedItem extends React.PureComponent<Props, FeedItemState> {
	manager: ReviewManager
	actionSheet: ActionSheet | null = null

	optionArray = [
		translate("cancel"),
		translate("edit"),
		translate("delete"),
	]

	constructor(props: Props) {
		super(props)
		this.manager = new ReviewManager();
		const approved = props.item?.post_status_id == ReviewStatus.Approved
		this.state = {
			item: props.item,
			loadingLike: false,
			canDelete: !approved && !props.item?.previous_approved,
			canEdit: !approved || !(props.item.booking_id || props.item.order_id)
		}
		const { canDelete, canEdit } = this.state
		this.optionArray = (canDelete && canEdit) ? [
			translate("cancel"),
			translate("edit"),
			translate("delete"),
		] : (canEdit ? [
			translate("cancel"),
			translate("edit")
		] : [
			translate("cancel")
		])
	}

	/* static getDerivedStateFromProps(props: FeedItemProps, state: FeedItemState) {

		if (props.item != state.item) {
			return {
				item: props.item
			}
		}
		return null
	} */

	componentDidMount() {
		this.props.navigation.addListener('focus', this.onFocus)

		if (this.props.item.user_id == this.props.current_user?.id) {
			this.setState({ myReview: true })
		} else {
			this.setState({ myReview: false })
		}
		//this.setState({ item: this.props.item });
	}

	onFocus = () => {
		this.forceUpdate()
	}

	componentWillUnmount() {
		this.props.navigation.removeListener('focus', this.onFocus)
	}

	onLikesUpdated = (item: Review) => {
		console.log("onLikesUpdated", !!this.props.callbackUpdateData)
		this.props.callbackUpdateData?.(item)
		this.setState({
			item: {
				...item
			}
		});
	}

	isUpdatedPage = false
	callbackUpdateData = (item?: Review) => {
		console.log('callBackUpdateData', item?.likes);
		this.isUpdatedPage = true
		this.setState({
			item: {
				...this.state.item,
				likes: item?.likes || [],
				comments: item?.comments || [],
			}
		})
	}

	goToDetail = (item: Review) => {
		if (this.props.showDetail)
			this.props.navigation.push("ReviewDetail", {
				data: item,
				callbackShouldReload: this.props.callbackShouldReload,
				disableUserPress: this.props.disableUserPress,
				callbackUpdateData: this.callbackUpdateData
			})
	}

	showLikesList = (item: Review) => {
		this.props.navigation.push("UserListPage", { "followers": false, likes: true, "data": item.likes, id: this.props.current_user?.id });
	}
	showDish = () => {
		const item = this.state.item?.dish
		if (!item) return
		this.props.navigation.push("DishInfo", {
			dish: item,
		})
	}
	showRest = (restaurant?: Restaurant) => {
		const rest = restaurant || this.state.item?.restaurant
		const id = rest?.id
		if (!id) return
		this.props.navigation.push("NewRestaurant", { id, restaurant: rest! })
	}
	showProfile = () => {
		if (!this.props.disableUserPress) {
			this.props.navigation.push("ProfilePage", { user_id: this.state.item?.user?.id })
		}
	}
	isDish = () => {
		if (this.state.item == null) return false;
		return this.state.item.isDish;
	}

	modifyReview = () => {
		const { item } = this.state
		const { navigation, callbackShouldReload } = this.props
		if (this.state?.item?.restaurant_id) {
			navigation.navigate("FastReview", {
				edit_review: item,
				restaurant: item.restaurant,
				reviewMode: "restaurant",
				isEdit: true,
				callbackShouldReload,
			})
		} else {
			navigation.navigate("FastReview", {
				edit_review: item,
				dish: item.dish,
				restaurant: getDishRestaurant(item.dish),
				reviewMode: "dish",
				isEdit: true,
				callbackShouldReload,
			})
		}
	}

	deleteReview = () => {
		const {item} = this.state
		showConfirm(translate("deleteReview"), translate("sureToDeleteReview"), () => {
			if (item.restaurant_id) {
				this.manager.deleteRestaurantReview(item.restaurant_id, item.id).then(() => {
					this.props.callbackShouldReload?.(true)
				}).catch(error)
			} else {
				this.manager.deleteDishReview(item.dish_id, item.id).then(() => {
					this.props.callbackShouldReload?.(true)
				}).catch(error)
			}
		})
	}

	render() {
		const { item } = this.state
		const isDish = this.isDish()

		//console.log("render feeditem", item.likes.length, this.isUpdatedPage)
		return (
			<View style={styles.listItem}>
				<TouchableWithoutFeedback onPress={() => {
					FirebaseAnalytics.feedDetailPressed(item)
					this.goToDetail(item)
				}}>
					<View style={styles.box}>
						<View>
							<View style={[styles.flexRow, { flex: 1, justifyContent: 'space-between', alignItems: 'center' }]}>
								<TouchableOpacity style={[styles.topRow]} onPress={this.showProfile} disabled={this.props.disableUserPress}>
									<>
									<ProfileImage source={item.userImage} />
									{/*<View style={[styles.userImage, {backgroundColor: colors.blueMenu}]} /> */}
									<View style={{ marginLeft: 12, flexDirection: 'column', justifyContent: 'space-between' }}>
										<Text style={[styles.postedByText]}>{item?.user?.username}</Text>
										<Text style={[styles.kitchenKind, { alignSelf: 'flex-start' }]}>{item?.user?.user_level?.label_it}</Text>
									</View>
									</>
								</TouchableOpacity>

								{(this.state.myReview) && (
									<View style={{ transform: [{ rotate: '90deg' }] }}>
										<TouchableOpacity style={{ paddingHorizontal: 12, paddingVertical: 20 }} onPress={() => { this.actionSheet?.show() }}>
											<Icon name="more" size={4} color={colors.greyText} />
										</TouchableOpacity>
									</View>
								)}
							</View>

							{item.thumbReviewImage && (
								<View style={styles.imageContainer}>
									<FLImage
										style={styles.backgroundImage}
										fullImage={item.reviewImage}
										source={item.thumbReviewImage}
										openFullscreen
										showFull
									/>
								</View>
							)}
							<TouchableRipple
								style={styles.detailLineContainer}
								onPress={isDish ? this.showDish : () => this.showRest()}
							>
									<>
									<FLImage 
										style={styles.reviewItemImage}
										source={isDish ? imageFood(item.dish!, true) : imageRestaurant(item.restaurant!, true)}
									/>
									<View style={{ flex: 1, marginRight: 10 }}>
										<Text style={styles.title}>{item.name}</Text>

										{isDish ? (
											<Text style={styles.address}>{getDishSectionName(item.dish)}</Text>
										) : (
											<View style={styles.flexRow}>
												<Text style={[styles.address, { flex: 1 }]} numberOfLines={1}>{item.full_address}</Text>
												<Text numberOfLines={1} style={styles.distance}>{printableDistance(item.distance)}</Text>
											</View>
										)}
									</View>
									{isDish && !this.props.hideButton &&
										<Icon name="food" color={colors.red} size={16} />
									}
									{!isDish && !this.props.hideButton &&
										<Icon name="rest" color={colors.blueMenu} size={14} />
									}
									</>
							</TouchableRipple>

							<View style={styles.contentContainer}>
								<View style={styles.ratingRow}>
									{isDish && (
										<TouchableRipple
											onPress={() => {
												FirebaseAnalytics.feedDishRestaurantPressed(item);
												this.showRest(getDishRestaurant(item?.dish))
											}}
											borderless
											style={{ backgroundColor: colors.lighterGrey, paddingVertical: 5, paddingHorizontal: 10, borderRadius: 20, marginTop: 4, overflow: "hidden", flexDirection: "row", alignItems: "center" }}
										>
											<Icon name="rest" color={colors.blueMenu} size={10} />
											<Text style={styles.inlineAddress}>
												{item.full_address}
											</Text>
											<Text style={styles.distance}>{printableDistance(item.distance)}</Text>
											{/* <Trans i18nKey={"ofRestaurantWithParams"} values={{ address: this.state.item.full_address }}>
												<Text style={styles.address}>
													
												</Text>
											</Trans> */}
										</TouchableRipple>
									)}
								</View>
								<View style={{ marginTop: 10 }}>
									<ReviewContent review={item} />
								</View>
							</View>
							<View style={styles.bottomRowContainer}>
								<TouchableOpacity hitSlop={{ top: 10, bottom: 5, left: 10, right: 10 }} onPress={() => {
									this.showLikesList(item)
								}}>
									{getLike(item)}
								</TouchableOpacity>
								<View style={styles.ratingRow}>
									<View style={styles.flexRow}>
										<ReviewLikeButton
											navigation={this.props.navigation}
											item={item}
											onUpdate={this.onLikesUpdated}
											//isUpdatedPage={this.isUpdatedPage}
										/>
										<TouchableOpacity hitSlop={{ top: 5, bottom: 10, left: 10, right: 10 }} onPress={() => {
											FirebaseAnalytics.feedCommentPressed(item)
											this.goToDetail(item)
										}}>
											<View style={styles.inline}>
												<Icon name="comment" size={16} color={colors.greyText} />
												<Text style={[styles.greyText, styles.commentsText]}>{length(item.comments)}</Text>
											</View>
										</TouchableOpacity>
										{/*<Icon name="share" size={14} color={colors.greyText} />*/}
									</View>
									<Text style={[styles.kitchenKind, styles.postTime]}>{getReviewDateString(item)}</Text>
								</View>
							</View>
						</View>
					</View>
				</TouchableWithoutFeedback>

				<ActionSheet
					ref={o => (this.actionSheet = o)}
					options={this.optionArray}
					cancelButtonIndex={0}
					destructiveButtonIndex={2}
					title={!this.state.canEdit ? translate(this.state.item.booking_id ? "bookingReviewApproved" : "orderReviewApproved") : !this.state.canDelete ? translate("reviewApproved") : undefined}
					message={!this.state.canEdit ? translate("cannotEditOrderReview") : !this.state.canDelete ? translate("cannotDeleteReview") : undefined}
					onPress={index => {
						if (index == 1) {
							this.modifyReview()
						} else if (index == 2) {
							this.deleteReview()
						}
					}}
				/>

			</View>
		)
	}
}

const _FeedItem = function (props: FeedItemProps) {
	let navigation: CommonNavigation<Pluto> = useNavigation()
	return <FeedItem {...props} navigation={navigation} />
}

export default connect((state: ReduxState) => {
	return {
		current_user: state.currentUser
	}
})(_FeedItem)
