import React from 'react';
import 'react-native';
import Trans from './index';

import renderer from 'react-test-renderer';
import { Text } from 'react-native';

it('renders Trans view', () => {
  expect(renderer.create(
		<Text style={{ color: "#000" }}>
			<Trans i18nKey={"likedByAnd"} values={{ firstPerson: "PIPPO", secondPerson: "PLUTO" }}>
				<Text style={{ color:"#00f" }}/>
				<Text style={{ color:"#f00" }}/>
			</Trans>
		</Text>
	)).toMatchSnapshot(); //TODO: add Trans props with random values

  /*
  //if view displays different outputs when passing different values as props use:

  expect.assertions(2); // increase '2' if you add more assertions

  const first = renderer.create(<Trans pippo={true} />).toJSON();
  expect(first).toMatchSnapshot();

  const second = renderer.create(<Trans pippo={false} />).toJSON();
  expect(second).toMatchSnapshot();
  */
});
