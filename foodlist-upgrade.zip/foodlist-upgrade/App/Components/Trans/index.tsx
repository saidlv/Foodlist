import React, { ReactChild } from 'react';
import { Trans } from 'react-i18next';
import { I18nKey } from '@App/I18n';


type TransViewProps = {
	children: ReactChild[] | ReactChild,
	i18nKey: I18nKey,
	values?: Object
}

const TransComponent = (props: TransViewProps) => {
  return <Trans i18nKey={props.i18nKey} values={props.values}>
		{props.children}
	</Trans>;
};

export default TransComponent;
