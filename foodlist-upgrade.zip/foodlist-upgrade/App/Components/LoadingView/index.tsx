import React from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './Style';
import { colors } from '@Global/GlobalProps';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { translate } from '@App/I18n';

/**
 * @param visible: boolean flag that represents wheter the loading is visibile or not
 * @param error: boolean when true shows an error (even if visible = false)
 * @param retry: func to call when users press retry
 * @return graphical representation of the loadingview
 */

type LoadingViewProps = {
	error?: boolean
	visible: boolean
	retry?: () => void
}

type LoadingViewState = {
	visible: boolean
}

export default class LoadingView extends React.PureComponent<LoadingViewProps, LoadingViewState> {

	constructor(props: LoadingViewProps) {
		super(props);
		this.state = { visible: props.visible };
	}

  /* componentWillReceiveProps(props) {
    if(props.visible != this.state.visible) {
      this.setState({visible: props.visible})
    }
  } */

	static getDerivedStateFromProps(nextProps: LoadingViewProps, prevState: LoadingViewState) {
		if (nextProps.visible != prevState.visible) {
			return { visible: nextProps.visible }
		}
		return null
	}

	render() {
		if (this.state.visible === false) return null;
		return (
			<View style={styles.container}>
				<ActivityIndicator hidesWhenStopped={true} animating={!this.props.error} size="large" color={colors.blackOverlay} />
				{(this.props.error) &&
					<View style={styles.errorContainer}>
						<Text style={styles.error}>{translate("defaultError")}</Text>
						<TouchableOpacity style={styles.retryButton}>
							<Text style={styles.retryText} onPress={this.props.retry}>Riprova </Text>
							<Icon name="share" color={colors.blueMenu} size={14} />
						</TouchableOpacity>
					</View>
				}
			</View>
		);
	}
}
