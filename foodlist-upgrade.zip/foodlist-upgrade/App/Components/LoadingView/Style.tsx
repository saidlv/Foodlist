import { colors } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet, Platform, Dimensions } from 'react-native';

export default StyleSheet.create({
	container: {
		width: Dimensions.get('window').width,
		height: Dimensions.get('window').height,
		flex: 1,
		justifyContent: "center",
		position: "absolute",
		zIndex: 100000,
		backgroundColor: colors.overlayColor
	},
	errorContainer: {
		alignSelf: 'center',
		justifyContent: 'center'
	},
	error: {
		fontSize: 16
	},
	retryButton: {
		flexDirection: 'row',
		alignItems: 'center',
		alignSelf: 'center',
		marginTop: 5
	},
	retryText: {
		fontWeight: 'bold',
		fontSize: 16,
		color: colors.blueMenu
	}
})
