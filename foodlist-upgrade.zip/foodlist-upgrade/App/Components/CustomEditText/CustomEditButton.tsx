import React from 'react';
import { colors, when } from '@Global/GlobalProps';
import commonStyle from '@FoodListCore/Global/CommonStyle';
import { View, Text } from 'react-native';
import styles from './CustomEditTextStyle';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import { IconName } from '@FoodListCore/Iconfont/IconName';
/**
 * @param title: title of the field (above the input)
 * @param placeholder: placeholder of the input
 * @param icon: name of the lateral icon
 * @param pressed: callback

 * @return graphical representation of the edittext with icon and title of mockups
 */

type CustomEditButtonProps = {
	disabled: boolean,
	pressed: () => void,
	standalone: boolean,
	icon: IconName,
	placeholder: string,
	textColor: string,
}

export default class CustomEditButton extends React.PureComponent<CustomEditButtonProps, {}> {
	render() {
		return (
			<TouchableRipple underlayColor={colors.inactiveGrey} disabled={this.props.disabled} onPress={() => { this.props.pressed() }}
				style={[styles.container, when(this.props.standalone, styles.rounded), styles.noTitle, this.props.disabled ? { backgroundColor: colors.inactiveGrey } : commonStyle.shadow, { height: 36 }]}>
				<View style={styles.rowContainer}>
					<View style={[styles.iconContainer, styles.noTitleIcon]}>
						<Icon style={styles.icon} color={this.props.disabled ? colors.greyArrow : colors.greyText} size={16} name={this.props.icon} />
					</View>
					<View style={styles.textContainer}>
						<View style={styles.inputBox}>
							<Text numberOfLines={1} style={[styles.input, styles.noTitleInput, { height: "auto", paddingRight: 10 }, when(!!this.props.textColor, { color: this.props.textColor }), when(this.props.disabled, { color: colors.greyArrow })]}>{this.props.placeholder}</Text>
						</View>
					</View>
				</View>
			</TouchableRipple>
		);
	}
}
