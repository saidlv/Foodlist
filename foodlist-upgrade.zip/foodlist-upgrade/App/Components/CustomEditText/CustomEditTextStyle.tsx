import { colors, fontSizes } from '@Global/GlobalProps';
import React from 'react';
import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
	rowContainer: {
		//height : 70,
		flexDirection: "row",
	},
	container: {
		backgroundColor: colors.white,
		paddingVertical: 0,
		justifyContent: 'center',
		//flex : 0
		//height: 70
	},
	rounded: {
		borderRadius: 4,
		marginTop: 10
	},
	noTitle: {
		height: 48,
		marginTop: 0
	},
	iconContainer: {
		justifyContent: 'center',
		width: 64,
		alignItems: "center"
	},
	noTitleIcon: {
		width: 50
	},
	textContainer: {
		flex: 1,
		alignSelf: 'center',
		flexDirection: "column",
		//backgroundColor: 'green',
		minHeight: 70,
		justifyContent: 'center'
	},
	title: {
		marginBottom: 5,
		//backgroundColor: 'red',
		color: colors.greyText,
		fontSize: 10,
		fontWeight: "bold"
	},
	facoltative: {
		flex: 1,
		color: colors.greyText,
		opacity: 0.75,
		//height: 15,
		fontSize: 10,
		marginRight: 20,
		textAlign: "right",
		fontWeight: "bold"
	},
	icon: {
		justifyContent: 'center'
	},
	flag: {
		width: 20,
		height: 14
	},
	input: {
		flex: 1,
		//height: 26,
		//backgroundColor: 'yellow',
		padding: 0,
		alignSelf: 'stretch',
		fontSize: 18,
		fontWeight: "normal",
		fontStyle: "normal",
		color: "black"
	},
	inputBox: {
		flexDirection: "row",
		alignItems: "stretch"
	},
	actionView: {
		alignSelf: "center",
		paddingVertical: 10,
		paddingLeft: 5,
		paddingRight: 10
	},
	enabledAction: {
		alignSelf: "center",
		color: colors.blueMenu
	},
	disabledAction: {
		alignSelf: "center",
		color: colors.separator
	},
	noTitleInput: {
		color: colors.greyText,
		alignSelf: "center",
		fontSize: 16
	},
	isError: {
		borderColor: 'red',
		borderWidth: 2
	}
})
