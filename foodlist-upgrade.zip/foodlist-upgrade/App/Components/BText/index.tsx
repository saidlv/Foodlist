import React from 'react';
import { Text, TextProps } from 'react-native';

/**
 * Abbreviation of Button Text: makes the text unselectable
 */
const BText = (props: TextProps & { children: React.ReactNode }) => {
	return (
		<Text selectable={false} {...props} />
	);
}

export default BText;
