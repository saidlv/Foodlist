import React from 'react';
import 'react-native';
import BText from './index';

import renderer from 'react-test-renderer';

it('renders BText view', () => {
	//expect(renderer.create(<BText />)).toMatchSnapshot(); //TODO: add BText props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<BText pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<BText pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
