import React, { Component } from 'react';
import { View, Text, ViewStyle } from 'react-native';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { colors } from '@FoodListCore/Global/GlobalProps';

/**
 * @param rating: stars to color, allows 1/2 stars
 * @param size: size to give to the stars
 * @return graphical representation of the rating
 */

type StarRatingProps = {
	rating: number,
	modeFull?: boolean,
	activeColor?: string,
	inactiveColor?: string,
	color?: string,
	editable?: boolean,
	size: number,
	marginLeft?: number,
	onChange?: (n: number) => void

	showLiteral?: boolean
}

type StarRatingState = {
	rating: number,
}

export default class StarRating extends React.PureComponent<StarRatingProps, StarRatingState> {
	constructor(props: StarRatingProps) {
		super(props)
		this.state = {
			rating: props.rating || 0
		}
	}
	getIconName(starNumber: number) {
		let toTen = parseInt((this.state.rating * 2).toFixed(0))
		if (this.props.modeFull == true || starNumber * 2 <= toTen) {
			return "star-full";
		} else if (starNumber * 2 - 1 <= toTen) {
			return "star-half";
		}
		return "star-empty";
	}
	getColor(n: number) {
		if (this.props.modeFull == true) {
			//console.log(this.state.rating, n)
			return this.state.rating >= n ? this.props.activeColor : this.props.inactiveColor;
		}
		else return this.props.color
	}
	getStar(n: number) {
		return (
			<Icon onPress={this.props.editable && n >= 0 ? () => this.setRating(n) : undefined}
				key={n}
				name={this.getIconName(n)}
				size={this.props.size}
				style={{ marginLeft: this.props.marginLeft }}
				color={this.getColor(n)} />
		)
	}
	componentDidUpdate(prevProps: StarRatingProps) {
		if (prevProps.rating != this.props.rating) {
			this.setState({
				rating: this.props.rating
			})
		}
	}
	setRating(n: number) {
		if (this.props.editable == true) {
			this.setState({ rating: n });
			if (this.props.onChange != null) this.props.onChange(n);
		}
	}
	render() {
		var stars: Element[] = [];
		for (var n = 1; n <= 5; n++) {
			stars.push(this.getStar(n))
		}
		return (
			<View style={{ flexDirection: 'row', justiftyContent: "center", alignItems: "center" } as ViewStyle}>
				{stars}
				{this.props.showLiteral && (
					<Text style={{ color: colors.greyText, fontSize: this.props.size }}> ({this.state.rating.toFixed(1)})</Text>
				)}
			</View>
		);
	}
};
