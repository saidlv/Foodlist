import { colors } from '@Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	infoTabView: {
		backgroundColor: colors.white,
		borderWidth: 1,
		borderStyle: "solid",
		borderColor: colors.greyBorder,
		flex: 1,
		minHeight: 48,
		flexDirection: "row",
		alignItems: "center",
		width: "100%",
		display: 'flex'
	},
	tabButtonPosition: {
		height: 24,
		marginRight: 20
	},
	tabImageMargin: {
		marginLeft: 20,
		marginRight: 16
	},
	textTabStyle: {
		marginRight: 20,
		marginTop: 10,
		marginBottom: 10,
		fontSize: 14,
		fontWeight: "500",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.blackText
	}
});
