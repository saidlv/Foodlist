import React, { ReactChild } from 'react';
import { View, Text } from 'react-native';
import RoundedButton from '@Components/RoundedButton';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import styles from './Style';
import { colors } from '@Global/GlobalProps';
import { IconName } from '@FoodListCore/Iconfont/IconName';


export type TabInfo = {
	iconName: IconName,
	title: string | undefined,
	buttonText: string,
	callback: (title: string) => void
}

type TabInfoDisplayProps = {
	tabInfo: TabInfo[]
}

export default class TabInfoDisplay extends React.PureComponent<TabInfoDisplayProps> {
	render() {
		return (
			<>
				{this.props.tabInfo.reduce<ReactChild[]>(function (result, item, index) {
					if (item.title) {
						result.push(<View key={index} style={styles.infoTabView}>
							{(item.iconName == "mail") && (
								<Icon
									name={item.iconName}
									size={12}
									color={colors.greyText}
									style={styles.tabImageMargin}
								/>
							)}
							{(item.iconName != "mail") && (
								<Icon
									name={item.iconName}
									size={16}
									color={colors.greyText}
									style={styles.tabImageMargin}
								/>
							)}
							<View style={{ flex: 1 }}>
								<Text numberOfLines={1} style={styles.textTabStyle}>{item.title}</Text>
							</View>
							<View style={styles.tabButtonPosition}>
								<RoundedButton
									text={item.buttonText.toUpperCase()}
									full={true}
									height={24}
									borderRadius={12}
									bottom={false}
									onPress={() => {
										if (item.title) {
											item.callback(item.title)
										}
									}}
								/>
							</View>
						</View>);
					}
					return result;
				}, [])}
			</>
		)
	}
}
