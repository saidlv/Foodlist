import React from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import { colors } from '@Global/GlobalProps';
import { connect } from 'react-redux';
import followButtonHoc, { FollowWrappedProps } from './FollowButtonHoc';
import { translate } from '@App/I18n';

export default followButtonHoc((props: FollowWrappedProps) => {
	return (
		<View style={props.style}>
			<TouchableOpacity
				hitSlop={{ top: 10, right: 10, left: 10, bottom: 10 }}
				onPress={props.onPress}
			>
				{props.loading && <ActivityIndicator animating={true} size="small" />}
				{!props.loading && (
					<Text style={[styles.text, props.isFollowing ? styles.following : styles.notFollowing]}>
						{props.isFollowing ? translate("alreadyFollow") : translate("follow")}
					</Text>
				)}
			</TouchableOpacity>
		</View>
	)
})

const styles = StyleSheet.create({
	text: {
		fontSize: 10,
		fontWeight: '700',
		textShadowOffset: { width: 1, height: 1 },
		textShadowRadius: 1
	},
	following: {
		color: colors.greyInfoText,
		textShadowColor: colors.withAlpha(colors.greyInfoText, 0.15)
	},
	notFollowing: {
		color: colors.blueMenu,
		textShadowColor: colors.withAlpha(colors.blueMenu, 0.15)
	}
})