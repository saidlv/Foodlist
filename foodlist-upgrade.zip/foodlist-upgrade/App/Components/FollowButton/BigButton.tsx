import React from 'react';
import { Text, ActivityIndicator, View, ViewStyle } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './BiggerFollowButtonStyle';
import { when } from '@Global/GlobalProps';
import { colors } from '@Global/GlobalProps';

const defaultAccentColor = colors.blueMenu
/*
 * @param children: content of the text
 * @param reverse: false -> blue, true -> white
 * @param color: 
 */

type BiggerFollowButtonProps = {
	color?: string,
	onPress: () => void,
	reverse?: boolean,
	loading?: boolean,
	leftItem?: boolean,
	textColor?: string,
	style?: ViewStyle
}

export default class BiggerFollowButton extends React.PureComponent<BiggerFollowButtonProps, {}> {
	render() {
		const accentColor = this.props.color || defaultAccentColor
		return (
			<TouchableOpacity onPress={this.props.onPress} style={[styles.followButton(accentColor), when(!!this.props.reverse, styles.followButtonReverse()), this.props.style]}>
				{!this.props.loading && (
					<View style={{ flexDirection: 'row', alignItems: 'center' }}>
						{this.props.leftItem}
						<Text style={!this.props.reverse ? styles.followButtonText(this.props.textColor) : styles.followButtonTextReverse(accentColor)}>{this.props.children}</Text>
					</View>
				)}
				{this.props.loading &&
					<ActivityIndicator animating={true} size="small" color={this.props.reverse ? accentColor : this.props.textColor || colors.white} />
				}
			</TouchableOpacity>
		)
	}
}