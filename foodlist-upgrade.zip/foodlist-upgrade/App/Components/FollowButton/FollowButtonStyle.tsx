import globalStyle from '@FoodListCore/Global/CommonStyle';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	followButton: {
		paddingHorizontal: 20,
		height: 24,
		marginRight: 15,
		alignSelf: "flex-end",
		borderRadius: 12,
		...globalStyle.shadow
	},
	followButtonText: {
		fontWeight: "bold",
		fontStyle: "normal",
		letterSpacing: 0,
		textAlign: "center",
		fontSize: 10
	},
})
