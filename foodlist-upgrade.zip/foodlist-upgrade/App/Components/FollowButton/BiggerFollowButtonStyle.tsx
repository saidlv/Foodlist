import { colors } from '@Global/GlobalProps';
import globalStyle from '@FoodListCore/Global/CommonStyle';
import { ViewStyle, TextStyle } from 'react-native';

const _accentColor = colors.blueMenu

export default {
	followButton: (accentColor = _accentColor): ViewStyle => ({
		backgroundColor: accentColor,
		paddingHorizontal: 20,
		paddingVertical: 5,
		borderRadius: 50,
		alignItems: 'center',
		justifyContent: 'center',
		minHeight: 40,
		...globalStyle.hardShadow
	}),
	followButtonReverse: (): ViewStyle => ({
		backgroundColor: colors.white
	}),
	followButtonText: (color = colors.white): TextStyle => ({
		color: color,
		fontWeight: 'bold',
		textAlign: 'center'
	}),
	followButtonTextReverse: (accentColor = _accentColor): TextStyle => ({
		color: accentColor,
		fontWeight: 'bold',
		textAlign: 'center'
	}),
}
