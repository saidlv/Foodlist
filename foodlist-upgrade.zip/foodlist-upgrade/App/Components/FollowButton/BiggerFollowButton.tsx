import React from 'react';
import { View, Text, ViewStyle } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './BiggerFollowButtonStyle';
import { colors } from '@Global/GlobalProps'
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import BigButton from './BigButton';
import { CommonNavigation } from '@RouteParams/Common';
import { useNavigation } from '@react-navigation/native';
import followButtonHoc, { FollowWrappedProps } from './FollowButtonHoc';
import { translate } from '@App/I18n';
import { Pluto } from '@Models/Pluto';

/*
 * @param showEditProfile: se id e user_id sono uguali mostra l'edit profilo
 */

type Props = FollowWrappedProps & {
	navigation: CommonNavigation<Pluto>
}

class BiggerFollowButton extends React.PureComponent<Props> {
	editProfile = () => {
		this.props.navigation.push("EditProfile")
	}
	render() {
		let isCurrentUser = this.props.currentUserId == this.props.userId
		return (
			<View style={this.props.style}>
				{!isCurrentUser && (
					<BigButton onPress={this.props.onPress} loading={this.props.loading} reverse={this.props.isFollowing}>
						{this.props.isFollowing ? translate("alreadyFollow") : translate("follow")}&nbsp; <Icon name={this.props.isFollowing ? "remove-user" : "add-user"} />
					</BigButton>
				)}
				{isCurrentUser && this.props.showEditProfile && (
					<TouchableOpacity onPress={this.editProfile} style={styles.followButton(colors.white)}>
						<Text style={styles.followButtonText(colors.blueMenu)}>{translate("editProfile")}&nbsp; <Icon name="edit-profile" size={12} /></Text>
					</TouchableOpacity>
				)}
			</View>
		)
	}
}

const _BiggerFollowButton = function (props: FollowWrappedProps) {
	let navigation: CommonNavigation<Pluto> = useNavigation()
	return <BiggerFollowButton {...props} navigation={navigation} />
}

export default followButtonHoc(_BiggerFollowButton)
