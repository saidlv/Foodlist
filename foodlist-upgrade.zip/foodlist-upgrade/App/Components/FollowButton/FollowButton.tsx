import React from 'react';
import { View, ActivityIndicator } from 'react-native';
import styles from './FollowButtonStyle';
import FormActionButton from "@Components/FormActionButton"
import { when } from '@Global/GlobalProps';
import followButtonHoc, { FollowWrappedProps } from './FollowButtonHoc';
import { translate } from '@App/I18n';


export default followButtonHoc((props: FollowWrappedProps) => {
	return (
		<View>
			{props.loading && (
				<View style={{ marginRight: 20 }}>
					<ActivityIndicator animating={true} size="small" />
				</View>
			)}
			{!props.loading && (props.currentUserId != props.userId) && (
				<FormActionButton
					onPress={props.onPress}
					noPadding={props.noPadding}
					full={!props.isFollowing} title={(!props.isFollowing) ? translate("follow") : translate("alreadyFollow")}
					customTextStyle={styles.followButtonText}
					customStyle={[styles.followButton, when(props.noPadding, { marginRight: 0 })]}
				/>
			)}
		</View>
	);
})
