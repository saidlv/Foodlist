import React, { PureComponent } from 'react';
import { Alert, ViewStyle } from 'react-native';
import UserManager, { FollowResponse, UnfollowResponse } from "@Network/UserManager"
import { connect } from 'react-redux'
import { error } from '@Global/GlobalProps';
import { ReduxState } from '@Redux/StateFormat';
import { RequestResponse } from '@Models/RequestResponse';
import { Unsubscribe, followEvent } from '@FoodListCore/Services/EventEmitter';
import requestAuth from '@FoodListCore/Flows/RequestAuth';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { ParamList } from '@FoodListCore/Flows/Restaurant';

/**
 * @param followingId: user to follow
 * @return graphical representation of the button used on forms like the auth ones, and search ones
 */

const mapRedux = (state: ReduxState) => {
	return {
		currentUserId: state.currentUser?.id,
		emitter: state.emitter
	}
}

export type ExternalProps = {
	userName: string
	userId: number
	following: boolean
	noPadding?: boolean,
	showEditProfile?: boolean
	style?: ViewStyle,
}

export type FollowButtonProps = ExternalProps & {
	navigation: StackNavigationProp<ParamList>
	//actions: FollowButtonActions
} & ReturnType<typeof mapRedux>

type FollowButtonState = {
	isFollowing?: boolean,
	loading: boolean,
}

export type FollowWrappedProps = FollowButtonState & FollowButtonProps & {
	onPress: () => void
}

type FollowUnfollowRequest = (id: number) => Promise<RequestResponse<FollowResponse | UnfollowResponse>>

export default function _followButtonHoc(WrappedComponent: React.ComponentType<FollowWrappedProps>): React.FC<ExternalProps> {
	class FollowButton extends React.PureComponent<FollowButtonProps, FollowButtonState> {
		//actions: FollowButtonActions
		manager = new UserManager()
		unsubscribe: Unsubscribe

		constructor(props: FollowButtonProps) {
			super(props)
			this.state = {
				isFollowing: props.following,
				loading: false
			}
			this.unsubscribe = this.props.emitter.on(followEvent(this.props.userId), (following: boolean) => {
				//console.log("On change", following)
				this.setState({
					isFollowing: following
				})
			})
			//this.actions = props.actions
		}

		componentWillUnmount() {
			this.unsubscribe()
		}

		showError = (err: string) => {
			this.setState({
				loading: false
			})
			error(err)
		}

		handleFollow = (request: FollowUnfollowRequest, following: boolean) => {
			if(!requestAuth(this.props.navigation)) return
			if (!this.props.userId) return
			this.setState({
				loading: true
			})

			request(this.props.userId).then((response) => {
				if (response.success) {
					this.setState({
						isFollowing: following,
						loading: false
					})
					this.props.emitter.emit(followEvent(this.props.userId), following)
				} else {
					this.showError(response.error ?? "Si è verificato un errore");
				}
			}) //.catch(this.showError)
		}

		follow = () => {
			this.handleFollow(this.manager.follow, true)
		}

		unfollow = () => {
			this.handleFollow(this.manager.unfollow, false)
		}

		onPress = () => {
			if (this.state.isFollowing) {
				Alert.alert('Vuoi smettere di seguire ' + this.props.userName + '?', '',
					[{
						text: 'Conferma',
						onPress: () => {
							this.unfollow()
						},
						style: "destructive"
					}, {
						text: 'Annulla',
						onPress: () => { },
						style: 'default'
					}],
					{ cancelable: true }
				);
			} else {
				this.follow()
			}
		}

		render() {
			return <WrappedComponent {...this.props} {...this.state} onPress={this.onPress} />
		}
	}

	// @ts-ignore
	return connect(mapRedux)((props) => {
		const navigation = useNavigation()
		return (
			<FollowButton {...props} navigation={navigation} />
		)
	})
}