import React, { Component } from 'react';
import { colors } from '@Global/GlobalProps';
import { View, Platform } from 'react-native';

const spacerSize = 1000

/**
 * @param color: customColor
 */

type ScrollViewBounceFixProps = {
	color?: string,
}

export default class ScrollViewBounceFix extends React.PureComponent<ScrollViewBounceFixProps> {
	render() {
		return (
			<View>
				{(Platform.OS == 'ios') && (
					<View style={{
						backgroundColor: this.props.color || colors.foodlist,
						height: spacerSize,
						position: 'absolute',
						top: -spacerSize,
						left: 0,
						right: 0
					}}
					/>
				)}
			</View>
		)
	}
}
