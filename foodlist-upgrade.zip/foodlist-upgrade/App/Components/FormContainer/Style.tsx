import commonStyle from '@FoodListCore/Global/CommonStyle';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	backdrop: {
		position: "absolute",
		top: 0,
		bottom: 0,
		left: 0,
		right: 0,
		backgroundColor: 'rgba(0,0,0,0.2)'
	},
	container: {
		flex: 1,
		alignItems: 'center',
		flexDirection: 'row',
		justifyContent: 'center',
		alignSelf: 'center',
		marginHorizontal: 20,
		marginTop: "auto",
		marginBottom: "auto"
	},
	modal: {
		backgroundColor: "#fff",
		borderRadius: 6,
		flex: 1,
		flexDirection: 'column',
		minWidth: 200,
		minHeight: 50,
		paddingVertical: 10,
		...commonStyle.hardShadow
	}
})
