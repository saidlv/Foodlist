import React from 'react';
import { View, Modal, SafeAreaView } from 'react-native';
import { TouchableWithoutFeedbackFixed as TouchableWithoutFeedback } from '@FoodListCore/Components/TouchableFixed';
import style from "./Style";

/**
 * @param children: html children, the content of the form
 * @return graphical representation of the form for tablet or phone based on device
 */

type FormContainerProps = {
	children: React.ReactChild,
}

type FormContainerState = {
	visible: boolean
}

export default class FormContainer extends React.PureComponent<FormContainerProps, FormContainerState> {
	constructor(props: FormContainerProps) {
		super(props)
		this.state = {
			visible: false
		}
	}
	closeModal = () => {
		this.setState({
			visible: false
		})
	}
	showModal = () => {
		this.setState({
			visible: true
		})
	}
	render() {
		return (
			<Modal
				animationType="fade"
				visible={this.state.visible}
				presentationStyle="overFullScreen"
				transparent={true}
				onRequestClose={this.closeModal}
			>
				<TouchableWithoutFeedback onPress={this.closeModal}>
					<View style={style.backdrop} />
				</TouchableWithoutFeedback>
				<SafeAreaView style={style.container} /* forceInset={{bottom: 'always'} */>
					<View style={style.modal}>
						{this.props.children}
					</View>
				</SafeAreaView>
			</Modal>
		)
	}
}
