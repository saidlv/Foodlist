import { DeepLinkingData } from "@Services/ShareManager";
import SplashScreen from "react-native-splash-screen";
import { CommonParamList } from "./RouteParams/Common";

export const getStateFromPath = (path: string) => {
	if (path) {
		let commonProps = {
			deepLinking: true,
		};

		let splitted_path = path.split("/")
		let splitted_ids: string[]
		switch (splitted_path[0]) {

			case 'restaurant':
				return getRestaurantState({
					...commonProps,
					id: parseInt(splitted_path[1])
				});

			case 'dish':
				return getDishState({
					...commonProps,
					id: parseInt(splitted_path[1])
				});

			case 'user':
				return getUserState({
					...commonProps,
					user_id: parseInt(splitted_path[1])
				});

			case 'dish_review':
				splitted_ids = splitted_path[1].split('_');
				return getReviewState({
					...commonProps,
					data: {
						feed_type: 'DISH',
						id: parseInt(splitted_ids[0]),
						dish: {
							id: parseInt(splitted_ids[1])
						}
					}
				});

			case 'restaurant_review':
				splitted_ids = splitted_path[1].split('_');
				return getReviewState({
					...commonProps,
					data: {
						feed_type: 'RESTAURANT',
						id: parseInt(splitted_ids[0]),
						restaurant: {
							id: parseInt(splitted_ids[1])
						}
					}
				})
		}
	}
}

const getCommonState = (lastRoute: { name: keyof CommonParamList, params: DeepLinkingData }) => {
	SplashScreen.hide()
	return {
		routes: [{
			name: "TabBarPage",
			state: {
				routes: [{
					name: "Home",
					state: {
						routes: [{
							name: "FeedPage"
						}, lastRoute]
					}
				}]
			}
		}]
	}
}

const getReviewState = (params: DeepLinkingData) => {
	return getCommonState({
		name: "ReviewDetail",
		params: params
	});
}

const getRestaurantState = (params: DeepLinkingData) => {
	return getCommonState({
		name: "NewRestaurant",
		params: params
	});
}

const getDishState = (params: DeepLinkingData) => {
	return getCommonState({
		name: "DishInfo",
		params: params
	});
}

const getUserState = (params: DeepLinkingData) => {
	return getCommonState({
		name: "ProfilePage",
		params: params
	});
}