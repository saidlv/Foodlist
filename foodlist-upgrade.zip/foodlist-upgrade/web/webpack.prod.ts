// web/webpack.config.js

import { WEBAPP_BASEURL } from "./env";
import { loaders } from "./webpack.common";

const path = require('path');
const webpack = require('webpack');
const HtmlWebPackPlugin = require('html-webpack-plugin');

const appDirectory = path.resolve(__dirname, '../');

module.exports = {
	mode: 'production',
	entry: [
		// load any web API polyfills
		// path.resolve(appDirectory, 'polyfills-web.js'),
		// your web-specific entry file
		path.resolve(appDirectory, 'index.web.ts'),
	],
	//devtool: PRODUCTION ? false : 'inline-sourcemap',

	// configures where the build ends up
	output: {
		filename: 'app-web-9.js',
		path: path.resolve(appDirectory, 'web/public'),
	},

	// ...the rest of your config

	module: {
		rules: loaders(),
	},

	plugins: [
		new HtmlWebPackPlugin({
			template: path.resolve(appDirectory, '/web/index.html'),
			inject: true,
			filename: "index.html",
			publicPath: `/${WEBAPP_BASEURL}/`,
			baseUrl: `/${WEBAPP_BASEURL}/`,
		}),
		new webpack.HotModuleReplacementPlugin(),
		new webpack.DefinePlugin({
			//'process.env.VERSION': JSON.stringify(pkg.version),
			'process.browser': true,
			'__DEV__': true,
			'__WEBAPP_BASEURL__': JSON.stringify(WEBAPP_BASEURL),
			'__DEFAULT_IMAGES_BASEURL__': JSON.stringify(`https://foodlist.eu/${WEBAPP_BASEURL}/DefaultImages/`),
		}),
	],

	resolve: {
		// This will only alias the exact import "react-native"
		alias: {
			'react-native$': 'react-native-web',
			'react-native-maps': 'react-native-web-maps',
		},
		// If you're working on a multi-platform React Native app, web-specific
		// module implementations should be written in files using the extension
		// `.web.js`.
		extensions: ['.web.js', '.web.ts', '.web.tsx', '.js', '.tsx', '.jsx', '.ts'],
	}
}