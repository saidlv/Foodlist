// web/webpack.config.js
import { loaders } from "./webpack.common";

const path = require('path');
const webpack = require('webpack');
const HtmlWebPackPlugin = require('html-webpack-plugin');
const appDirectory = path.resolve(__dirname, '../');
const ReactRefreshWebpackPlugin = require('@pmmmwh/react-refresh-webpack-plugin');

module.exports = {
	mode: 'development',
	entry: [
		// load any web API polyfills
		// path.resolve(appDirectory, 'polyfills-web.js'),
		// your web-specific entry file
		path.resolve(appDirectory, 'index.web.ts'),
	],
	devtool: 'inline-sourcemap',

	// configures where the build ends up
	output: {
		filename: 'bundle.web.js',
		path: path.resolve(appDirectory, 'web/public'),
	},

	// ...the rest of your config

	module: {
		rules: loaders(true),
	},

	plugins: [
		new HtmlWebPackPlugin({
			template: path.resolve(appDirectory, '/web/index.html'),
			inject: true,
			filename: "index.html",
			publicPath: '/',
		}),
		//new webpack.HotModuleReplacementPlugin(),
		new ReactRefreshWebpackPlugin(),
		new webpack.DefinePlugin({
			//'process.env.VERSION': JSON.stringify(pkg.version),
			'process.browser': true,
			'__DEV__': true,
			'__WEBAPP_BASEURL__': JSON.stringify(""),
			'__DEFAULT_IMAGES_BASEURL__': JSON.stringify(`https://localhost:3001/DefaultImages/`),
		}),
	],

	devServer: {
		contentBase: path.resolve("./web/public"),

		historyApiFallback:{
			rewrites: [
        { from: /^\/app/, to: '/index.html' },
      ],
		},
		host: "localhost",
		port: 3001,
		publicPath: '/',
	},

	resolve: {
		// This will only alias the exact import "react-native"
		alias: {
			'react-native$': 'react-native-web',
			'react-native-maps': 'react-native-web-maps',
		},
		// If you're working on a multi-platform React Native app, web-specific
		// module implementations should be written in files using the extension
		// `.web.js`.
		extensions: ['.web.js', '.web.ts', '.web.tsx', '.js', '.tsx', '.jsx', '.ts'],
	}
}