
const path = require('path');
const webpack = require('webpack');

module.exports = {
	target: 'node',
	entry: [
		path.resolve(__dirname, "/web/server.ts"),
	],
	externals: {
		'any-promise': 'Promise',
	},
	output: {
		filename: "index.bundle.js",
		path: path.resolve(__dirname, "../dist"),
	},
	plugins: [
		new webpack.DefinePlugin({
		}),
	],
	module: {
		rules: [
			{
				test: /\.(tsx|ts|js)$/,
				use: {
					loader: 'babel-loader',
				},
			},
		],
	},
	resolve: {
		extensions: [".ts", ".tsx", ".js"],
	},
}
