import { WEBAPP_BASEURL } from "./env";

import Koa from 'koa';
import serve from 'koa-static';
import mount from 'koa-mount';
import Router from 'koa-router';
import fs from "fs";

const app = new Koa();
const router = new Router()

const PORT = 3118

//const rootPath = path.join(__dirname, "web")

router.get([`/${WEBAPP_BASEURL}`, `/${WEBAPP_BASEURL}/*`], ctx => {
	ctx.type = 'html';
	ctx.body = fs.createReadStream('./web/public/index.html');
})

app.use(mount(`/${WEBAPP_BASEURL}`, serve('./web/public')))
app.use(router.routes())
app.use(router.allowedMethods())

app.listen(PORT);
console.log(`Listening on port ${3118}`)
