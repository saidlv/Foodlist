
export const WEBAPP_BASEURL = "it"
