import { SearchParamList } from '@App/RouteParams/Search';
import { ParamList as UserParamList } from '@FoodListCore/Flows/User';

export type WebPages = SearchParamList & UserParamList & {
	Test: {}
	OnlineMenu: {
		restaurant_id?: number
	} | undefined
	Home: {} | undefined
	DeleteAccount: {} | undefined
}
