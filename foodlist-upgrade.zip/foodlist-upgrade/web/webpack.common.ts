
// This is needed for webpack to compile JavaScript.
// Many OSS React Native packages are not compiled to ES5 before being
// published. If you depend on uncompiled packages they may cause webpack build
// errors. To fix this webpack can be configured to compile to the necessary
// `node_module`.
const babelLoaderConfiguration = (isDev?: boolean) => ({
	test: /\.(js|ts|jsx|tsx)$/,
	// Add every directory that needs to be compiled by Babel during the build.
	/* include: [
		path.resolve(appDirectory, 'index.web.ts'),
		path.resolve(appDirectory, 'App.tsx'),
		path.resolve(appDirectory, 'src'),
		path.resolve(appDirectory, 'node_modules'),
		path.resolve(appDirectory, 'node_modules/react-native-uncompiled'),
	], */
	use: {
		loader: 'babel-loader',
		options: {
			cacheDirectory: true,
			// The 'metro-react-native-babel-preset' preset is recommended to match React Native's packager
			presets: [
				'module:metro-react-native-babel-preset',
			],
			// Re-write paths to import only the modules needed by the app
			plugins: [
				'react-native-web',
				[
					"module-resolver",
					{
						"root": [
							"./"
						],
						"alias": {
							"@App": "./App",
							"@Models": "./foodlist-common/Models",
							"@FoodListCore": "./foodlist-core/App",
							"@FoodListCommon": "./foodlist-common",
							"@config": "./App/Config",

							"@Redux": "./App/Redux",
							"@Assets": "./App/Assets",
							"@Services": "./App/Services",
							"@Global": "./App/Global",
							"@Network": "./App/Network",
							"@Components": "./App/Components",
							"@Pages": "./App/Pages",
						}
					}
				],
				...(isDev ? [
					//development plugins
					require.resolve("react-refresh/babel")
				] : [
					//production plugins
				]),
			],
		},
	},
});

// This is needed for webpack to import static images in JavaScript files.
const imageLoaderConfiguration = {
	test: /\.(gif|jpe?g|png|svg)$/,
	use: {
		loader: 'file-loader',
		options: {
			name: '[name].[ext]',
			esModule: false,
		},
	},
};

export const loaders = (isDev?: boolean) => ([
	babelLoaderConfiguration(isDev),
	imageLoaderConfiguration,
	{
		test: /\.ttf$/,
		loader: "file-loader", // or directly file-loader
		//include: path.resolve(__dirname, "node_modules/react-native-vector-icons"),
	},
])
