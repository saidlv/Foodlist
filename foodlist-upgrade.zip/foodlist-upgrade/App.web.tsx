import I18nManager from '@App/I18n'
import React, { useEffect } from "react";
import { store } from '@Redux/Reducer';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Provider } from 'react-redux';
import { DefaultTheme, Provider as PaperProvider } from "react-native-paper"
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import { getPathFromState, LinkingOptions, NavigationContainer, PathConfig } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import TestWeb from '@App/Components/TestWeb';
import { Toolbar } from 'react-native-material-ui';
import FLIcon from '@FoodListCore/Components/FLIcon';
import { CommonRoutes } from '@App/CommonRoutes';
import ToolbarLogin from '@App/Components/ToolbarLogin';
import AuthManager from '@FoodListCore/Network/AuthManager';
import SessionManager from '@FoodListCore/Services/SessionManager';
import { UserRoutes } from 'foodlist-core';
import { NetworkNavigation } from '@FoodListCore/Network/NetworkManager';
import ModalLogin from '@App/Components/ModalLogin';
import { fixLinkingPath } from '@FoodListCore/Global/WebHelpers';
import FLLink from '@FoodListCore/Components/FLLink';
import { WebPages } from 'web/pagesAndParams';

import "@Assets/Images/favicon.png"
import WebHome from '@App/Pages/WebHomePage';
import DeleteAccount from '@App/Pages/DeleteAccountPage';

const paperTheme = {
	...DefaultTheme,
	colors: {
		...DefaultTheme.colors,
		primary: colors.foodlist,
		accent: colors.blueMenu,
		notification: colors.blueMenu,
	},
	dark: false,
}

type SearchConfigMap = {
	[routeName in keyof WebPages]?: string | PathConfig;
}

const screensMap: SearchConfigMap = {
	Home: "",
	NewSearch: "search",
	Test: "test",
	NewRestaurant: {
		path: "r/:id",
		parse: {
			restaurant: () => null,
		},
	},
	ProfilePage: "profile",
	MyOrders: "my-orders",
	OrderDetail: "my-orders/:order_id",
	BookingHistory: "my-bookings",
	BookingHistoryDetail: "my-bookings/:booking_id",
	AddressPage: "my-addresses",
	NewOrderOnline: "order/:restaurant_id",
	PdfMenu: "r/:restaurant_id/menu-p",//TODO: mettere quello giusto
	Menu: "r/:restaurant_id/menu",
	BookTable: "book/:restaurant_id",
	PaymentMethods: "payment-methods",
	DeleteAccount: "delete-account",
}
const fixedPath = (path: string) => {
	const res = fixLinkingPath(path)
	if(res == "/") return ""
	return res
}
Object.keys(screensMap).map((key) => {
	const item = screensMap[key]
	if(typeof item == "string") {
		screensMap[key] = fixedPath(item)
	} else {
		screensMap[key] = {
			...item,
			path: fixedPath(item.path),
		}
	}
})

const linking: LinkingOptions = {
	prefixes: [],
	config: {
		screens: screensMap,
	},
	getPathFromState: (state, options) => {
		const cleanState = {
			...state,
			routes: state.routes.map(route => {
				if(!route.params) {
					return route
				}

				const cleanParams: object = {}
				for(const param in route.params) {
					// @ts-ignore
					const value = route.params[param]
					if(typeof value !== "object" && typeof value !== "function") {
						// @ts-ignore
						cleanParams[param] = value
					}
				}
				return {
					...route,
					params: cleanParams,
				}
			}),
		}
		return getPathFromState(cleanState, options)
	},
}

const Stack = createStackNavigator<WebPages>()

export default function App() {
	useEffect(() => {
		I18nManager.init()
		const authManager = new AuthManager()
		authManager.loginSilently().then(() => {
			//console.log("logged")
		})
		.catch((err) => {
			console.log("SilentLogin error", err)
			SessionManager.logout()
		})
	}, [])

	return (
		<SafeAreaProvider>
		<Provider store={store}>
		<PaperProvider theme={paperTheme}>
			<NavigationContainer
				linking={linking}
			>
				<ModalLogin />
				<Stack.Navigator
					screenOptions={{
						cardStyle: {
							flex: 1,
						},
						header: React.useCallback((params) => {
							NetworkNavigation.navigation = params.navigation
							return (
							<Toolbar
								style={{
									container: {
										backgroundColor: colors.foodlist,
										zIndex: 1000,
									},
								}}
								leftElement={<FLLink to="/"><FLIcon foodlistIcon="menu-logo" style={{ marginLeft: margins.pagePadding }} color={colors.white} size={18} /></FLLink>}
								rightElement={<ToolbarLogin />}
							/>
							)
						}, []),
					}}
					initialRouteName="Home"
				>
					{/* <Stack.Screen
						name="NewSearch"
						component={NewSearchPage}
						options={{
							headerShown: false,
						}}
					/> */}
					<Stack.Screen
						name="Home"
						component={WebHome}
					/>
					{CommonRoutes()}
					{UserRoutes(true)}
					{/* <Stack.Screen
						name="NewOrderOnline"
						component={NewMenuPage}
						options={{
							headerShown: false,
						}}
					/> */}
					<Stack.Screen
						name="Test"
						component={TestWeb}
					/>
					<Stack.Screen
						name="DeleteAccount"
						component={DeleteAccount}
						options={{
							headerShown: false,
						}}
					/>
				</Stack.Navigator>
			</NavigationContainer>
		</PaperProvider>
		</Provider>
		</SafeAreaProvider>
	)
}