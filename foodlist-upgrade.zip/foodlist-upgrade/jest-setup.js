jest.mock('react-native-languages', () => ({
  language: 'en',
  languages: ['en'],
}));