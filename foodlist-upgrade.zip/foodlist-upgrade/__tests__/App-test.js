/**
 * @format
 */

import 'react-native';
import React from 'react';

// Note: test renderer must be required after react-native.
import renderer from 'react-test-renderer';


it('Can Test', () => {
  const foo = () => { return true }
  expect(foo()).toBe(true)
});


/**
 * @summary Test divisi per funzionalità 
 * 
 * 
 * @event Follow user
 v il bottone deve cambiare da non seguito a seguito
 v se sono sulla pagina dell'utente il numero di seguaci deve aumentare di 1
 v se ho il mio profilo aperto in un'altra tab il numero di seguiti dovrebbe aumentare di 1
 * 
 * @event Unfollow user
 v deve essere richiesta la conferma
 v se confermo il bottone deve cambiare da seguito a non seguito
 v se non confermo non succede niente
 v se sono sulla pagina dell'utente il numero di seguaci deve diminuire di 1
 v se ho il mio profilo aperto in un'altra tab il numero di seguiti dovrebbe diminuire di 1
 * 
 * @event callback Follow/Unfollow
 v Se apro un utente che non seguo da una lista (search/users, notifiche, UserListPage) e lo seguo, tornando indietro alla lista deve mostrarmi che lo seguo,
 v se lo seguivo e lo smetto di seguire tornando indietro deve mostrarmi che non lo seguo,
 v se lo seguivo, lo smetto di seguire e lo torno a seguire tornando indietro deve mostrarmi che lo seguo,
 v se non lo seguivo, lo seguo e lo smetto di seguire, tornando indietro deve mostrarmi che lo seguo.
 v Se dalla lista dei miei seguiti tolgo il follow deve aggiornare il numero
 */