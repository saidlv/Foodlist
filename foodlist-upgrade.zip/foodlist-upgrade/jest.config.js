module.exports = {
  verbose: true,
  preset: "react-native",
  setupFiles: [
    "./jest-setup.js"
  ]
};
