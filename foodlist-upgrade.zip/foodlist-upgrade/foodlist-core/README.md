# FoodList Core

This project contains common code shared between RestaurantApps and FoodList.

To use this project you need to configure the following aliases:
- `@Models` : ./node_modules/foodlist-common/Models
- `@FoodListCore` : ./node_modules/foodlist-core/App
- `@config` : custom location containing `app.ts` and `network.ts` (see ExampleConfig)
- `@Redux` : link to the folder containing your Redux Reducer
- `@Assets` : link to a folder containing `./Custom/written-logo.png` (note: this will probably change soon)

#### Example config for `tsconfig.ts` (inside `"compilerOptions"`)

```
	"paths": {
		"@Models/*": ["./node_modules/foodlist-common/Models/*"],
		"@FoodListCore/*": ["./node_modules/foodlist-core/App/*"],
		"@config/*": ["./App/Config/*"],
		"@Redux/*": ["./App/Redux/*"],
		"@Assets/*": ["./App/Assets/*"]
	},
```

#### Example config for `.babelrc`

```
{
	"plugins": [
		[
			"module-resolver",
			{
				"root": [
					"./"
				],
				"alias": {
					"@Models": "./node_modules/foodlist-common/Models",
					"@FoodListCore": "./node_modules/foodlist-core/App",
					"@config": "./App/Config",
					
					"@Redux": "./App/Redux",
					"@Assets": "./App/Assets",
				}
			}
		]
	]
}
```


#### Install peer dependencies

```
npm i @react-navigation/stack@^5.6.2 @react-navigation/native@^5.2.3 redux@^4.0.5 react-redux@^7.2.0 react-native-vector-icons@^6.6.0 react-native-paper@^3.10.1 react-native-keyboard-aware-scroll-view@^0.9.1 react-native-gesture-handler@^1.6.1 rn-fetch-blob@^0.12.0 react-native-sha256@^1.3.6 underscore@^1.10.2 react-native-android-open-settings@^1.3.0 i18next@^19.4.4 @alessiocancian/react-native-actionsheet@^2.4.2 react-native-fs@^2.16.6 react-native-image-picker@^2.3.1 react-native-image-resizer@^1.2.1 react-native-localize@^1.4.0 react-native-status-bar-height@^2.5.0 react-native-svg@^12.1.0 react-native-screens@^2.7.0 react-native-permissions@^2.1.4 react-native-safe-area-context@^0.7.3 moment@^2.25.3 @react-native-community/segmented-control@^2.0.0 @react-native-community/async-storage@^1.10.0 @react-native-community/masked-view@^0.1.10 react-native-fast-image@^8.1.5 react-native-pdf@^6.1.2 @invertase/react-native-apple-authentication@^2.1.0 @react-native-community/google-signin@^5.0.0 react-native-fbsdk@^2.0.0
```