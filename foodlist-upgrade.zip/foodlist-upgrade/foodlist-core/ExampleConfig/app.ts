import { AuthNavigation } from "@FoodListCore/RouteParams/Auth"
import { StackNavigationProp } from "@react-navigation/stack"
import { ReactChild } from "react"
import { ThemeColorsType } from "./types"

export const ThemeColors: ThemeColorsType = {
	pagePadding: 40,
	lightStatusBar: false,
	primary: '#ff00ff',
	secondary: '#ffff00',

	inlineButtonIcons: null, //default primary
	inlineButtonArrow: null, //default blackText
	headerGradient: null, //uses secondary color if null
	infoTabButtons: null, //default secondary color
	infoTabIcons: null, //default grey
	editTextIcons: null, //default grey
	timesTint: null, //default blueMenu
	inlineSubMenuTint: null,//default blueMenu
	priceTint: null,//default blueMenu
	orderHeadersBackground: null,//default grey
	orderHeadersText: null,//default black
	radioButtonsTint: null, //default blueMenu
	bookPageTint: null, //default blueMenu

	configureButtonsTint: null, //default primary
	configureButtonsText: null, //default white
	addToCartButtonsTint: null, //default secondary
	addToCartButtonsText: null, //default white

	menuSectionHeaderTint: null, // default secondary
	menuSectionHeaderText: null, //default white

	ovverrideBlueMenu: null, //UNSAFE
	backgroundColor: null, //default greyBackground, UNSAFE

	topBarBackground: "#fff",
	topBarTintColor: "#000",
	bottomBarBackground: "#fff",
	bottomBarActiveTint: "#d1202f",
	bottomBarInactiveTint: "#555",
}

export const AppSchema = "warn-foodlistcore-warn"
export const GoogleWebClientId = "455758928490-s3efqhv7j3e7rji33p3c2d00h5rnf310.apps.googleusercontent.com"

export const AppData: {
	app_source_prefix: string,
	name: string
	restaurants: { id: number, name: string }[]
} = {
	name: "Warn-FoodListCore-Warn",
	app_source_prefix: "order-prefix-for-stats-and-notifications",
	restaurants: []
}