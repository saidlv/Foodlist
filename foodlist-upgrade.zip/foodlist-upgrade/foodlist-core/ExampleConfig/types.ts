import { StackNavigationProp } from "@react-navigation/stack"
import { ReactChild } from "react"

export type CustomConfig = {
	showReviewImages?: boolean
	requiresLogin?: boolean
	isManagerApp?: boolean
	hideFavouriteButtons?: boolean
	hideReviewButtons?: boolean
	hideRateYourOrder?: boolean
	customSideBarButtons?: (navigation: StackNavigationProp<any>) => ReactChild
}

export type ThemeColorsType = {
	pagePadding?: number,
	lightStatusBar: boolean,
	primary: string,
	secondary: string,

	inlineButtonIcons?: string | null, //default primary
	inlineButtonArrow?: string | null, //default blackText
	headerGradient?: string | null, //uses secondary color if null
	infoTabButtons?: string | null, //default secondary color
	infoTabIcons?: string | null, //default grey
	editTextIcons?: string | null, //default grey
	timesTint?: string | null, //default blueMenu
	inlineSubMenuTint?: string | null,//default blueMenu
	priceTint?: string | null,//default blueMenu
	orderHeadersBackground?: string | null,//default grey
	orderHeadersText?: string | null,//default black
	radioButtonsTint?: string | null, //default blueMenu
	bookPageTint?: string | null, //default blueMenu

	configureButtonsTint?: string | null, //default primary
	configureButtonsText?: string | null, //default white
	addToCartButtonsTint?: string | null, //default secondary
	addToCartButtonsText?: string | null, //default white

	loginPage?: {
		hideLoginWithFoodlist?: boolean
		lowercaseButtons?: boolean
		/** default 60 */
		logoHeight?: number

		disabledButtonTint?: string
		disabledButtonTitle?: string
		activeButtonTint?: string
		activeButtonTitle?: string
		activeButtonBorder?: string
		activeButtonBorderSize?: number
		inactiveButtonTint?: string
		inactiveButtonTitle?: string
		inactiveButtonBorder?: string
		inactiveButtonBorderSize?: number
	}

	menuSectionHeaderTint?: string | null, // default secondary
	menuSectionHeaderText?: string | null, //default white

	ovverrideBlueMenu?: string | null, //UNSAFE
	backgroundColor?: string | null, //default greyBackground, UNSAFE

	topBarBackground: string,
	topBarTintColor: string,
	bottomBarBackground: string,
	bottomBarActiveTint: string,
	bottomBarInactiveTint: string,
}