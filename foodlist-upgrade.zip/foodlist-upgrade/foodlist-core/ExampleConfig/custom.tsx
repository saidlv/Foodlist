import { CustomConfig } from "./types";

export default {} as CustomConfig