export default {
	//base_url: "http://192.168.1.100:3000/"
	"base_url": "https://foodlist.eu/",
	"api_path": "test-api",
	"stripe_publishable_key": "",
}