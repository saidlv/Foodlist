import i18next from 'i18next'
import { initReactI18next } from 'react-i18next';
import * as RNLocalize from "react-native-localize";

import en from '@FoodListCommon/Translations/locales/en';
import it from '@FoodListCommon/Translations/locales/it';

//import { initReduxTranslations } from '@FoodListCore/Redux/ReduxHelper'
import moment from 'moment';
import { toUpperLowerCase } from '@FoodListCommon/utils';

export type I18nKey = keyof typeof it

export type Locale = {
	languageCode: string;
	scriptCode?: string | undefined;
	countryCode: string;
	languageTag: string;
	isRTL: boolean;
}

type ParamsType = {
	[key: string]: string | number
}

export const getDays = () => {
	const res = moment.weekdays()
	return (res.splice(1, 7).concat(res)).map(item => toUpperLowerCase(item))
}

export class GlobalTimeVars {

	static dayArray: string[] = getDays()

	static init = () => {
		moment.locale("it")
		//moment.locale(currentLocale(true))
		GlobalTimeVars.dayArray = getDays()
	}
}

export default class I18nManager {

	static init = () => {
		const locale = I18nManager.currentLocale()
		i18next.use(initReactI18next).init({
			lng: locale,
			initImmediate: true,
			resources: {
				it: {
					translation: it
				},
				en: {
					translation: en
				}
			},
			fallbackLng: "it"
		}).then(() => {
			//console.log("I18n manager started with locale:", locale)
			/**
			 * Put here initialization of translated constants
			 */
			GlobalTimeVars.init()
			//console.log("GlobalTimeVars init")
			//initReduxTranslations()
		});
	}

	static currentLocale = (withState?: boolean): string => {
		let locale = RNLocalize.getLocales()[0]
		
		let response: string
		if (withState) {
			response = locale.languageTag;
		} else {
			response = locale.languageCode
		}
		return response;
	}

	static translate = (key: I18nKey, params?: ParamsType): string => {
		if(i18next.exists(key)) {
			return i18next.t(key, params);
		} else return "!!! Missing translation for " + key + " !!!"
	}
}

export const translate = (key: I18nKey, params?: ParamsType): string => {
	return I18nManager.translate(key, params)
}

export const translateNum = (num: number, singularKey: I18nKey, pluralKey: I18nKey, additionalParams?: ParamsType) => {
	const params = {
		num,
		...additionalParams
	}
	if(num != 1) {
		return I18nManager.translate(pluralKey, params)
	}
	return I18nManager.translate(singularKey, params)
}

export const currentLocale = (withState?: boolean): string => {
	return I18nManager.currentLocale(withState)
}