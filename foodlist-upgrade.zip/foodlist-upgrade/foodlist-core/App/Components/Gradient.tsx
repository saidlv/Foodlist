import React from 'react';
import { colors } from '@FoodListCore/Global/GlobalProps';
import { StyleSheet, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

type Direction = "vertical" | "horizontal" | "horizontal-reverse" | "vertical-reverse"

type Props = {
	color?: string
	minOpacity?: string
	/**
	 * @default: vertical
	 */
	direction?: Direction
	linear?: boolean
}

const getGradientProps = (direction: Direction) => {
	const props = {
		x0: "0",
		x1: "0",
		y0: "0",
		y1: "0",
	}
	if(direction == "horizontal") {
		props.x1 = "1"
	} else if(direction == "horizontal-reverse") {
		props.x0 = "1"
	} else if(direction == "vertical") {
		props.y1 = "1"
	} else if(direction == "vertical-reverse") {
		props.y0 = "1"
	}
	return props
}

const Gradient = (props: Props) => {
	const gradientColor = props.color || colors.foodlist
	const isReverse = props.direction == "horizontal-reverse" || props.direction == "vertical-reverse"
	return (
		<View style={{flex: 1, alignItems: "stretch", width: "100%"}}>
			<Svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
				<Defs>
					<LinearGradient id="grad" {...getGradientProps(props.direction || "vertical")}>
						<Stop offset="0" stopColor={gradientColor} stopOpacity={isReverse ? props.minOpacity || "0.4" : "1"} />
						{!props.linear ? (
							<Stop offset={isReverse ? "0.3" : "0.2"} stopColor={gradientColor} stopOpacity="0.9" />
						) : <></>}
						<Stop offset="1" stopColor={gradientColor} stopOpacity={isReverse ? "1" : props.minOpacity || "0.4"} />
					</LinearGradient>
				</Defs>
				<Rect
					x="0"
					y="0"
					width="100"
					height="100"
					fill="url(#grad)"
				/>
			</Svg>
		</View>
	);
};

const styles = StyleSheet.create({

});

export default Gradient;
