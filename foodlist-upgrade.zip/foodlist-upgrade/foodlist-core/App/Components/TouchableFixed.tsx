import React from 'react';
import { TouchableOpacity as RNTouchableOpacity, TouchableWithoutFeedback, Platform, TouchableOpacityProps, TouchableWithoutFeedbackProps } from 'react-native';
import { TouchableOpacity as GHTouchableOpacity, TouchableWithoutFeedback as GHTouchableWithoutFeedback } from 'react-native-gesture-handler';
import { debounce } from 'underscore';

type TouchableFixedProps = {
	fixAndroidModals?: boolean,
	children: React.ReactChild
} & (
	TouchableOpacityProps | TouchableWithoutFeedbackProps
)

/**
 * not debounced version
 */
export const TouchableOpacity = (props: TouchableFixedProps) => {
	return props.fixAndroidModals && Platform.OS == "android" ? (
		<GHTouchableOpacity
			{...props}
		/>
	) : (
		<RNTouchableOpacity
			{...props}
		/>
	)
}

export default class TouchableFixed extends React.Component<TouchableFixedProps> {
	onPress?: (e: any) => void

	constructor(props: TouchableFixedProps) {
		super(props)
		this.onPress = this.props.onPress && debounce(this.props.onPress, 500, true)
	}
	render() {
		return (
			<TouchableOpacity
				{...this.props}	
				onPress={this.onPress}
			/>
		)
	}
}

const TouchableWithoutFeedbackComponent = Platform.OS == "android" ? GHTouchableWithoutFeedback : TouchableWithoutFeedback

export class TouchableWithoutFeedbackFixed extends React.Component<TouchableFixedProps> {
	onPress?: (e: any) => void

	constructor(props: TouchableFixedProps) {
		super(props)
		this.onPress = this.props.onPress && debounce(this.props.onPress, 500, true)
	}
	render() {
		const Comp = this.props.fixAndroidModals ? TouchableWithoutFeedbackComponent : TouchableWithoutFeedback
		return <Comp
			{...this.props}
			onPress={this.onPress}
		/>
	}
} 