import colors from '@FoodListCommon/colors';
import { regex } from '@FoodListCore/Global/Constants';
import { translate } from '@FoodListCore/I18n';
import { getCurrentUser } from '@FoodListCore/Redux/ReduxHelper';
import React from 'react';
import { StyleSheet, ViewStyle } from 'react-native';
import FLEditText from './Input/FLEditText';


type Props = {
	onChange?: (text: string, valid: boolean) => void
	style?: ViewStyle
}

const InsertName = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	const user = getCurrentUser()
	return (
		<FLEditText
			actions={{
				onChangeText: props.onChange,
				getErrorMessage: () => {
					return translate("insertNameSurname")
				},
			}}
			inputContainerConfig={{
				style: [styles.nameInput, props.style],
			}}
			textInputProps={{
				title: translate("refName"),
				defaultValue: (user?.first_name) ? (user?.first_name ?? "") + " " + (user?.last_name ?? "") : "",
				placeholder: translate("suggestName"),
			}}
			regex={regex.NAME_SURNAME}
		/>
	);
});

const styles = StyleSheet.create({
	nameInput: {
		borderTopWidth: 1,
		borderBottomWidth: 1,
		borderColor: colors.greyBorder,
	},
});

export default InsertName;
