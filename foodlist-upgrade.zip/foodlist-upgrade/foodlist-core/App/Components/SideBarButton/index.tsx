import React from 'react';
import { colors, themeColors, margins } from '@FoodListCore/Global/GlobalProps';
import { StyleSheet, Text, View } from 'react-native';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import Line from '../Line';

export interface SideBarButtonActions {
	onPress: () => void
}

type Props = {
	label: string,

	actions: SideBarButtonActions
}

const SideBarButton = (props: Props) => {
	return (
		<>
			<TouchableRipple onPress={props.actions.onPress} style={styles.container}>
				<Text style={styles.text}>{props.label}</Text>
			</TouchableRipple>
			<Line />
		</>
	);
};

const styles = StyleSheet.create({
	container: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 15,
		backgroundColor: colors.white,
	},
	text: {
		fontSize: 16 
	}
});

export default SideBarButton;
