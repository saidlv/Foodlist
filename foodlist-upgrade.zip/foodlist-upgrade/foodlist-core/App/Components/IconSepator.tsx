import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import FLIcon, { FLIconProps } from './FLIcon';
import Line from './Line';

type Props = {
	lineColor?: string
} & FLIconProps

const lineColor = colors.withAlpha(colors.blueMenu, 0.5)

const IconSepator = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<View style={{ flexDirection: "row", alignItems: "center", flex: 1, marginBottom: 5 }}>
			<Line color={lineColor} style={{ flex: 1, height: 2, marginRight: 0 }} />
			<View style={{ borderRadius: 20, borderColor: props.lineColor || lineColor, borderWidth: 2, padding: 2 }}>
				<FLIcon {...props} />
			</View>
			<Line color={lineColor} style={{ flex: 1, height: 2, marginLeft: 0 }} />
		</View>
	)
});

const styles = StyleSheet.create({

});

export default IconSepator;
