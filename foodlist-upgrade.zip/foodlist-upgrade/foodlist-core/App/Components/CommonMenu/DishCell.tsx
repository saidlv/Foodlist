import { DishOrderableResult, itemOrderable, notOrderableString } from "@FoodListCommon/orders";
import { formatPrice, getDiscountedPrice, getMenuDiscountedPrice } from "@FoodListCommon/prices";
import CommonStyle from "@FoodListCore/Global/CommonStyle";
import { colors, margins, realImageFood, themeColors } from "@FoodListCore/Global/GlobalProps";
import { translate } from "@FoodListCore/I18n";
import { ReduxState } from "@FoodListCore/Redux/StateFormat";
import { MenuDish } from "@Models/MenuSection";
import { OrderInfo } from "@Models/OrderInfo";
import { OrderItem } from "@Models/OrderItem";
import React from "react"
import { Platform, StyleSheet, Text, View } from "react-native";
import { shallowEqual, useSelector } from "react-redux";
import DishPrice from "../Discount/Price";
import DishReviews, { DishHeader } from "../DishReviews";
import FLImage from "../FLImage";
import ReviewsButton from "../ReviewsButton";
import SheetPopup from "../SheetPopup/index";
import { TouchableRipple } from "../TouchableRipple";

type Props = {
	item: MenuDish
	onPress: (item: MenuDish) => void
	order?: OrderInfo
}

const getQta = (dish: MenuDish, orderItems: OrderItem[] | undefined) => {
	if(!orderItems) { return 0 }
	return orderItems.reduce((acc, item) => {
		if(item.dish?.id == dish.id) {
			return acc + item.quantity
		}
		return acc
	}, 0)
}

const DishCell = React.memo(({ item, count, ...props }: Props & { count: number, purchasable?: boolean, result?: DishOrderableResult }) => {
	const image = realImageFood(item, true)

	//console.log("update dish", item.name, count)

	const [reviewsShown, showReviews] = React.useState(false)
	const discountedPrice = props.order ? getDiscountedPrice(item, props.order) : getMenuDiscountedPrice(item)

	const closeReviews = React.useCallback(() => {
		showReviews(false)
	}, [])

	const available = props.purchasable && item.available
	return (
		<View style={[styles.container, available ? null : { opacity: 0.7 }, CommonStyle.shadow]}>
		<TouchableRipple
			disabled={!available}
			borderless
			style={styles.cell}
			onPress={() => props.onPress(item)}
		>
			<View style={count > 0 ? styles.leftBand : styles.leftMargin} />
			<View style={styles.row}>
				<View style={styles.content}>
					<Text style={styles.name}><Text style={styles.qta}>{count > 0 ? `${count}x ` : ""}</Text>{item.name}</Text>
					{!!item.description && (
						<Text style={styles.description} numberOfLines={3}>{item.description}</Text>
					)}

					{!!item.reviews_rating && (
						<ReviewsButton
							onPress={() => showReviews(true)}
							rating={item.reviews_rating}
							reviewsCount={item.reviews_count || 0}
							size="small"
						/>
					)}
					<Text style={styles.price}>
						<DishPrice
							initialPrice={item.price || 0}
							discountedPrice={discountedPrice || 0}
						/>
					</Text>
					{!available && (
						<Text style={styles.notAvailableText}>{(props.result && notOrderableString(props.result, translate)) || translate("notAvailable").toUpperCase()}</Text>
					)}
				</View>
				{!!image && (
					<FLImage source={image} style={styles.image} resizeMode="detect" />
				)}
			</View>
		</TouchableRipple>
		{reviewsShown && (
			<SheetPopup
				visible={reviewsShown}
				close={closeReviews}
				header={<DishHeader dish={item} />}
			>
				<DishReviews dish={item} hideHeader />
			</SheetPopup>
		)}
		</View>
	)
})

export const NormalDishCell = (props: Props) => {
	return <DishCell {...props} count={0} purchasable={true} />
}

const OrderDishCell = React.memo((props: Props & { restaurantId: number }) => {
	const { restaurantId, item } = props
	const { count } = useSelector(React.useCallback((state: ReduxState) => {
		const cart = state.orderItems[restaurantId]
		return {
			count: getQta(item, cart),
		}
	}, [item, restaurantId]), shallowEqual)

	const [available, result] = itemOrderable(item, props.order?.day?.date!)

	return <DishCell {...props} count={count} purchasable={available} result={result} />
})

const isWeb = Platform.OS == "web"
const styles = StyleSheet.create({
	container: {
		margin: margins.pagePadding / 2,
		borderRadius: 8,
		backgroundColor: colors.white,
	},
	cell: {
		flexGrow: 1,
		flexDirection: "row",
		borderRadius: 8,
	},
	qta: {
		color: colors.foodlist,
	},
	leftBand: {
		width: 3,
		marginRight: margins.vertical - 3,
		backgroundColor: colors.foodlist,
		alignSelf: "stretch",
	},
	leftMargin: {
		marginRight: margins.vertical,
	},
	row: {
		flex: 1,
		flexDirection: "row",
		padding: margins.vertical,
		paddingLeft: 0,
	},
	content: {
		padding: 5,
		flex: 1,
		flexDirection: "column",
	},
	image: {
		alignSelf: "center",
		marginLeft: 10,
		height: isWeb ? 100 : 84,
		width: isWeb ? 100 : 84,
		borderRadius: 8,
		overflow: "hidden",
		resizeMode: "contain",
	},
	name: {
		fontSize: 16,
		fontWeight: "bold",
	},
	description: {
		color: colors.greyText,
		fontSize: isWeb ? 14 : 13,
		marginTop: Platform.OS == "web" ? 8 : 3,
		marginBottom: Platform.OS == "web" ? 5 : 0,
	},
	price: {
		color: themeColors.priceTint,
		marginTop: 5,
		fontWeight: "bold",
		fontSize: 15,
	},
	notAvailableText: {
		color: colors.darkRed,
		marginTop: 3,
	},
})

export default OrderDishCell;
