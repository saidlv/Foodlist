import React, { useCallback, useMemo, useState } from 'react';
import { Platform, SectionListProps, Text, View, StyleSheet } from 'react-native';
import SheetPopup from '@FoodListCore/Components/SheetPopup';
import DishReviews from '@FoodListCore/Components/DishReviews';
import DishCell, { NormalDishCell } from './DishCell';
import AutoLoadingView, { AutoLoadingActions } from '@FoodListCore/Components/AutoLoadingView';
import { GetMenuRestaurantResponse } from '@FoodListCore/Network/RestaurantManager';
import { groupByKey } from '@FoodListCommon/index';
import { loadPreviousCart } from '@FoodListCore/Redux/ReduxHelper';
import { MenuDiscounts } from '@Models/Discount';
import { translate } from '@FoodListCore/I18n';
import { itemOrderable, notOrderableString } from '@FoodListCommon/orders';
import { filterSection } from '@FoodListCommon/utils';
import { MenuDish, MenuSection } from '@Models/MenuSection';
import { Dish } from '@Models/Dish';
import RestaurantManager from '@FoodListCore/Network/RestaurantManager';
import { OrderInfo } from '@Models/OrderInfo';
import { useEffect } from 'react';
import MultiColumnsSectionList from '../MultiColumnsSectionList';
import { themeColors, spacing } from '@FoodListCore/Global/Constants';
import Modal from '@FoodListCore/Components/SheetPopup/index.web';
import AddToCart from '../AddToCart';
import { CART_WIDTH, useShowSideCart } from '@FoodListCore/Global/WebHelpers';
import DishPopup, { CommonDishHeader } from '../DishPopup';

type Section = {
	title: string
	data: Dish[]
	detail?: string
}

export interface CommonMenuActions {
	openDish: (dish: Dish) => void,
	onMenuLoaded?: (menu: MenuSection[], discounts: MenuDiscounts | undefined) => void
}

type Props = {
	actions?: CommonMenuActions
	restId: number
	sectionListProps?: Partial<SectionListProps<Dish>>
	searchText?: string
} & ({
	isOrder?: false
} | {
	isOrder: true
	order: OrderInfo
})

const filterSectionsFunc = (sections: MenuSection[], searchText?: string, order?: OrderInfo): Section[] => {
	return sections.reduce<Section[]>((acc, section) => {
		const dishes = searchText ? filterSection(section, searchText) : section.dishes
		if(dishes.length > 0) {
			const [orderable, result] = order ? itemOrderable(section, order.day.date) : [true, null]
			if(orderable) {
				acc.push({
					title: section.name,
					data: dishes,
				})
			} else {
				acc.push({
					title: section.name,
					data: [],
					detail: notOrderableString(result, translate)
				})
			}
		}
		return acc
	}, [])
}

const CommonMenu = React.memo((props: Props) => {
	const { isOrder, restId, searchText, actions } = props
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	const self = useMemo(() => ({
		discounts: undefined as MenuDiscounts | undefined,
		searchText,
		menu: [] as MenuSection[],
		order: props.isOrder ? props.order : undefined
	}), [])
	const [loading, setLoading] = useState(true)
	const [visibleSections, setVisibleSections] = useState<Section[]>([])
	const [showDishReviews, setShowDishReviews] = useState<Dish | null>(null)

	const filterSections = useCallback((sections: MenuSection[]) => {
		return filterSectionsFunc(sections, self.searchText, self.order)
	}, [self])

	const loadingActions: AutoLoadingActions<GetMenuRestaurantResponse> = useMemo(() => ({
		request: () => {
			const manager = new RestaurantManager(restId)
			return manager.getMenuRestaurant(restId, isOrder ? true : false)
		},
		onResponse: (res) => {
			const menu = res?.data?.response?.[0]
			if(menu) {
				self.discounts = menu.discounts
				const mappedDishDiscounts = groupByKey(menu.discounts?.dish_discounts || [], "dish_id")

				const sections: MenuSection[] = menu.ordered.map(item => ({
					name: item.section?.label_it,
					...item.section,
					id: item.section_id,
					dishes: (item.section?.dishes ?? []).map(item => {
						const _item = item as MenuDish
						_item.discounts = mappedDishDiscounts[item.id]
						return _item
					})
				})).filter(item => {
					return item.dishes.length > 0
				})

				if(isOrder) {
					loadPreviousCart(restId, sections).then().catch((err) => {
						console.log("Errore carrlelo", err)
					})
					//aggiorno anche gli sconti sui piatti che ho già sul carrello
					//updateCartDishDiscounts(restId, menu.discounts?.dish_discounts || [])
				}

				self.menu = sections
				actions?.onMenuLoaded?.(sections, self.discounts)
				setVisibleSections(filterSections(sections))
			} else {
				//menu not found, list empty
				actions?.onMenuLoaded?.([], undefined)
			}
			setLoading(false)
		}
	}), [filterSections])

	/* const { currentCart } = useSelector(React.useCallback((state: ReduxState) => {
		return {
			currentCart: state.orderItems[restId]
		}
	}, [restId]), shallowEqual) */

	useEffect(() => {
		self.searchText = searchText
		setVisibleSections(filterSections(self.menu))
	}, [props.searchText])

	const [shownDish, setShownDish] = useState<Dish | null>(null)

	const onDishPress = React.useCallback((dish: Dish) => {
		if(Platform.OS == "web") {
			setShownDish(dish)
		} else {
			actions?.openDish(dish)
		}
	}, [])

	const closeDishModal = React.useCallback(() => {
		setShownDish(null)
	}, [])

	const showSideCart = useShowSideCart() && props.isOrder && !loading

	return (
		<View style={styles.full}>
			<MultiColumnsSectionList
				sections={visibleSections}
				numColumns={Platform.OS == "web" ? 2 : 1}
				singleColumnThreshold={1000}
				/* onViewableItemsChanged={(info) => {
					const first = info.viewableItems?.[0]
					if(first && state.visibleSections.indexOf(first.section) > 0 || (first.index || 0) > 0) {
						console.log(first.section?.title)
						setSection(first.section?.title)
					} else {
						setSection("")
					}
				}}*/
				contentContainerStyle={[styles.contentContainer, { paddingRight: showSideCart ? CART_WIDTH : 0 }]}
				keyboardDismissMode="on-drag"
				keyboardShouldPersistTaps="handled"

				ListEmptyComponent={React.useMemo(() => ((
					<View style={{ marginTop: 40, minHeight: 100 }}>
						{loading ? (
							<AutoLoadingView
								actions={loadingActions}
							/>
						) : (
							<Text style={{ textAlign: "center" }}>{translate(props.isOrder ? "noPurchasableDish" : "noResults")}</Text>
						)}
					</View>
				)), [])}

				initialNumToRender={7}

				/* onScrollToIndexFailed={(err) => {
					console.log("scrollToIndexFailed", err)
				}} */
				renderSectionHeader={React.useCallback((info) => {
					return (
						<Text style={styles.header}>{info.section.title}</Text>
					)
				}, [])}
				renderSectionFooter={React.useCallback((info) => {
					if(info.section.detail) {
						return <Text style={styles.footerText}>{info.section.detail}</Text>
					}
					return <View style={styles.footer} />
				}, [])}
				stickySectionHeadersEnabled={true}
				//rowStyle={sideCartStyle}

				//@ts-ignore trust me, it exists
				ListHeaderComponentStyle={showSideCart ? styles.listHeaderStyle : undefined}
				renderItem={({ item }) => {
					if(props.isOrder) {
						return (
							<DishCell
								item={item}
								restaurantId={restId}
								onPress={onDishPress}
								order={props.order}
							/>
						)
					}
					return (
						<NormalDishCell
							item={item}
							onPress={onDishPress}
						/>
					)
					/* return (
						<DishCell
							item={info.item}
							additionalProps={props.isOrder ? {
								restaurant_id: restId,
								for_orders: true,
								orderInfo: props.order
							} : {
								restaurant_id: restId,
								for_orders: false
							}}
							onPress={() => actions?.openDish(info.item)}
							orderItems={currentCart}
							showDishReviews={() => setShowDishReviews(info.item)}
						/>
					) */
				}}
				{...props.sectionListProps}
			/>
			{!!showDishReviews && (
				<SheetPopup
					visible={!!showDishReviews}
					actions={{
						onTapOutside: () => setShowDishReviews(null)
					}}
					enablePanning
				>
					<DishReviews dish={showDishReviews} />
				</SheetPopup>
			)}
			<Modal
				visible={!!shownDish}
				close={closeDishModal}
				header={<CommonDishHeader dish={shownDish} />}
			>
				{shownDish && (isOrder ? (
					<AddToCart
						dish={shownDish}
						rest_id={restId} close={closeDishModal}
						order={props.isOrder ? props.order : undefined}
					/>
				) : (
					<DishPopup dish={shownDish} />
				))}
			</Modal>
		</View>
	);
});

const isWeb = Platform.OS == "web"

const styles = StyleSheet.create({
	header: {
		paddingHorizontal: spacing.pagePadding,
		/* borderColor: colors.greyBorder,
		borderBottomWidth: 0,
		borderTopWidth: 1, */
		paddingVertical: 10,
		backgroundColor: themeColors.menuSectionHeaderTint,
		color: themeColors.menuSectionHeaderText,
		fontWeight: "bold",
		fontSize: 16,
		marginBottom: spacing.pagePadding / 2,
		borderBottomLeftRadius: isWeb ? 5 : 0,
		borderBottomRightRadius: isWeb ? 5 : 0,
	},
	contentContainer: {
		flexGrow: 1,
		paddingBottom: spacing.pagePadding / 2,
		width: "100%",
		maxWidth: spacing.maxPageWidth,
		marginLeft: "auto",
		marginRight: "auto",
	},
	footer: {
		paddingBottom: spacing.pagePadding / 2,
	},
	footerText: {
		padding: spacing.pagePadding,
		marginVertical: spacing.pagePadding / 2,
	},
	full: {
		flex: 1,
		position: "relative",
	},
	listHeaderStyle: {
		zIndex: 10,
		marginRight: -CART_WIDTH,
	},
});

export default CommonMenu;
