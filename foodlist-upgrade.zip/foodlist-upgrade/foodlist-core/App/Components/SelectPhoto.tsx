import { translate } from '@FoodListCore/I18n';
import SelectPhotoService, { PickedCB, PICKER_TYPES } from '@FoodListCore/Services/SelectPhoto';
import React, { useCallback, useMemo, useState } from 'react';
import { useRef } from 'react';
import { useImperativeHandle } from 'react';
import { StyleSheet } from 'react-native';
import ActionSheet from '@alessiocancian/react-native-actionsheet';

type Props = {
	hasImage: boolean
	onRemoveImage: () => void
	onImagePicked: PickedCB
}

export type SelectPhotoRef = {
	show: () => void
}

const pickerService = new SelectPhotoService()

const SelectPhoto = React.memo(React.forwardRef<SelectPhotoRef, Props>(({ hasImage, onRemoveImage, onImagePicked }, ref) => {
	const actionSheet = useRef<ActionSheet>(null)

	useImperativeHandle(ref, () => ({
		show: () => {
			actionSheet.current?.show()
		}
	}))

	const options = useMemo(() => {
		if(hasImage) {
			return [translate("camera"), translate("library"), translate("removeImage"), translate("cancel")]
		}
		return [translate("camera"), translate("library"), translate("cancel")]
	}, [hasImage])

	const pickImage = useCallback((index: number) => {
		if(index > 1) return
		pickerService.pickImage(index == 0 ? PICKER_TYPES.CAMERA : PICKER_TYPES.LIBRARY, onImagePicked)
	}, [])

	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<>
			<ActionSheet
				ref={actionSheet}
				options={options}
				cancelButtonIndex={hasImage ? 3 : 2}
				destructiveButtonIndex={hasImage ? 2 : undefined}
				onPress={useCallback((index) => {
					if(!hasImage) {
						pickImage(index)
					} else {
						if(index == 2) {
							onRemoveImage()
						} else {
							pickImage(index)
						}
					}
				}, [hasImage])}
			/>
		</>
	);
}));

const styles = StyleSheet.create({

});

export default SelectPhoto;
