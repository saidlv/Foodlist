import React from 'react';
import { margins, stringDefined, imagesFood, imageFood } from '@FoodListCore/Global/GlobalProps';
import { StyleSheet, Text, View } from 'react-native';
import { Dish } from '@Models/Dish';
import Gallery from '@FoodListCore/Components/Gallery';

type Props = {
	dish: Dish,
}

const DishInfo = (props: Props) => {
	return (
		<View>
			<Text style={styles.title}>{props.dish.name}</Text>
			<Gallery
				gallery={imagesFood(props.dish, false)}
				galleryThumb={imagesFood(props.dish, true)}
				first={imageFood(props.dish, false)}
				firstThumb={imageFood(props.dish, true)}
			/>
			{stringDefined(props.dish.description) && (
				<Text style={styles.description}>{props.dish.description}</Text>
			)}
		</View>
	);
};

const styles = StyleSheet.create({
	title: {
		margin: margins.pagePadding,
		fontSize: 24,
		fontWeight: "bold",
		textAlign: "center"
	},
	description: {
		marginTop: 20,
		marginHorizontal: margins.pagePadding
	},
});

export default DishInfo;
