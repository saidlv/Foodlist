import { colors } from '@FoodListCore/Global/GlobalProps';
import React from 'react';
import { Image, ImageSourcePropType, StyleSheet, View } from 'react-native';
import { TouchableRipple } from '../TouchableRipple';

type Props = {
	logo: ImageSourcePropType
	onPress: () => void
}

const SocialButton = (props: Props) => {
	return (
		<View style={styles.container}>
			<TouchableRipple
				onPress={props.onPress}
				style={styles.ripple}
			>
				<Image
					source={props.logo}
					style={{
						height: 50,
						width: 50
					}}
					width={50}
					height={50}
				/>
			</TouchableRipple>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		marginHorizontal: 10,
		backgroundColor: colors.lightGrey,
		borderRadius: 100,
		overflow: "hidden"
	},
	ripple: {
		padding: 5
	}
});

export default SocialButton;
