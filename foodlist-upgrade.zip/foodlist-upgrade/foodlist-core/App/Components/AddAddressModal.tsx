import React, { useCallback, useState } from 'react';
import { colors, regex } from '@FoodListCore/Global/GlobalProps';
import { StyleSheet, Text, View } from 'react-native';
import { getCurrentUser } from '@FoodListCore/Redux/ReduxHelper';
import { translate } from '@FoodListCore/I18n';
import { margins, showError } from '@FoodListCore/Global/GlobalProps';
import { ActivityIndicator, TextInput } from 'react-native-paper';
import UserManager from '@FoodListCore/Network/UserManager';
import { UserAddress } from '@Models/UserAddress';
import { useMemo } from 'react';
import SheetPopup, { BottomSheetScrollView } from './SheetPopup';
import LightButton from './LightButton';

export interface AddAddressModalActions {
	onAddressCreated: (newAddress: UserAddress) => void
	close: () => void
}

type Props = {
	actions: AddAddressModalActions
	visible: boolean
	initialValues?: Partial<UserAddress>
}

const marginVertical = {
	marginBottom: 5
}

export const AddAddress = React.memo((props: Props) => {
	const { actions, visible } = props

	const [values, setValues] = useState<Partial<UserAddress>>(props.initialValues || {})
	const [canAdd, setCanAdd] = useState(false)
	const [loading, setLoading] = useState(false)

	const _this = useMemo(() => ({ sending: false }), []) //per evitare che partano 2 richieste (lo state sarebbe troppo lento ad aggiornarsi)

	const modalActions = useMemo(() => {
		return {
			onClose: () => actions.close(),
			onConfirm: () => {
				const newAddress = values
				const user = getCurrentUser()
				if(!user || _this.sending) return

				_this.sending = true
				setLoading(true)
				const manager = new UserManager()
				manager.createAddress(user?.id, "", newAddress.doorbell_name, newAddress.address, newAddress.house_number, newAddress.city, newAddress.cap, newAddress.intern, newAddress.notes).then((res) => {
					const address = res.data?.response
					if(address) {
						if(!user.addresses) {
							user.addresses = []
						}
						user.addresses.push(address)
						actions.onAddressCreated(address)
						actions.close()
					} 
				})
				.catch((err) => {
					showError(err)
				}).finally(() => {
					_this.sending = false
					setLoading(false)
				})
			}
		}
	}, [values])
	
	const updateValue = useCallback((value: string, key: keyof UserAddress) => {
		values[key] = value
		setCanAdd (!!values.address && !!values.cap && !!values.city && !!values.house_number && !!values.doorbell_name)
	}, [values])
	return (
		<>
		<BottomSheetScrollView

			style={styles.padding}
			/* visible={visible}
			title={translate("addAddress")}
			actions={modalActions}
			confirmDisabled={!canAdd}
			loading={loading} */
		>
			<View style={[styles.row, marginVertical]}>
				<TextInput
					mode="outlined"
					style={{ flex: 2 }}
					label="Indirizzo *"
					defaultValue={values.address}
					onChangeText={(text) => updateValue(text, "address")}
				/>
				<TextInput
					mode="outlined"
					style={{ flex: 1, marginLeft: 10 }}
					label="Civico *"
					defaultValue={values.house_number}
					keyboardType="numbers-and-punctuation"
					onChangeText={(text) => updateValue(text, "house_number")}
				/>
			</View>

			<View style={[styles.row, marginVertical]}>
				<TextInput
					mode="outlined"
					style={{ flex: 2 }}
					label="Città *"
					defaultValue={values.city}
					onChangeText={(text) => updateValue(text, "city")}
				/>
				<TextInput
					mode="outlined"
					style={{ flex: 1, marginLeft: 10 }}
					label="CAP *"
					maxLength={5}
					defaultValue={values.cap}
					keyboardType="numeric"
					onChangeText={(text) => updateValue(text, "cap")}
				/>
			</View>

			<TextInput
				mode="outlined"
				style={marginVertical}
				label="Nome sul campanello *"
				onChangeText={(text) => updateValue(text, "doorbell_name")}
			/>

			<TextInput
				style={marginVertical}
				mode="outlined"
				label="Scala, piano, interno (opzionale)"
				onChangeText={(text) => updateValue(text, "intern")}
			/>

			<TextInput
				mode="outlined"
				label="Note (opzionale)"
				onChangeText={(text) => updateValue(text, "notes")}
			/>

			{loading ? (
				<ActivityIndicator style={{ marginVertical: margins.pagePadding }} />
			) : (
				<LightButton
					onPress={modalActions.onConfirm}
					style={{ backgroundColor: colors.foodlist, marginTop: margins.pagePadding }}
					disabled={!canAdd}
				>
					<Text style={{ color: colors.white, fontSize: 18 }}>{translate("save").toUpperCase()}</Text>
				</LightButton>
			)}

		</BottomSheetScrollView>
		</>
	);
});

const AddAddressModal = React.memo((props: Props) => {
	return (
		<SheetPopup
			visible={props.visible}
			actions={{
				onTapOutside: props.actions.close
			}}
		>
			<AddAddress
				{...props}
			/>
		</SheetPopup>
	)
})

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		alignItems: "center"
	},
	padding: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 12
	}
});

export default AddAddressModal;
