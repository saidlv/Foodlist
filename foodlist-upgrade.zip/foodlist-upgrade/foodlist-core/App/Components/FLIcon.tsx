import Icon, { MaterialCommunityIconName, MaterialIconName, MaterialIcon, MaterialCommunityIcon } from '@FoodListCore/Iconfont/FoodListIconfont';
import { IconName } from '@FoodListCore/Iconfont/IconName';
import React, { useCallback, useMemo, useState } from 'react';
import { ViewStyle } from 'react-native';
import { StyleSheet } from 'react-native';
import { IconProps } from 'react-native-vector-icons/Icon';

export type FLIconProps = {
	color?: string
	size?: number
	style?: ViewStyle
	foodlistIcon?: IconName
	materialIcon?: MaterialIconName
	materialCommunityIcon?: MaterialCommunityIconName
} & ({
	foodlistIcon: IconName
} | {
	materialIcon: MaterialIconName
} | {
	materialCommunityIcon: MaterialCommunityIconName
})

const getIcon = (props: FLIconProps) : [React.FunctionComponent<IconProps>, string] => {
	if(props.foodlistIcon) return [Icon, props.foodlistIcon]
	if(props.materialIcon) return [MaterialIcon, props.materialIcon]
	return [MaterialCommunityIcon, props.materialCommunityIcon]
}

const FLIcon = React.memo((props: FLIconProps) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	const [IconComponent, iconName] = getIcon(props)
	return (
		<IconComponent selectable={false} {...props} name={iconName} />
	);
});

const styles = StyleSheet.create({

});

export default FLIcon;
