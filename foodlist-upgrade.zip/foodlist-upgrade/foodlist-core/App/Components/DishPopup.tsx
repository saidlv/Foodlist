import { getMenuDiscountedPrice } from '@FoodListCommon/prices';
import { colors, spacing, themeColors } from '@FoodListCore/Global/Constants';
import { realImageFood } from '@FoodListCore/Global/GlobalProps';
import InlineDishOptions from '@FoodListCore/Pages/NewDishPage/InlineDishOptions';
import { Dish } from '@Models/Dish';
import React from 'react';
import { StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import DishPrice from './Discount/Price';
import FLImage from './FLImage';
import SheetPopup from './SheetPopup/index.web';

type Props = {
	dish: Dish
}

export const CommonDishHeader = React.memo(({ dish }: { dish: Dish | null | undefined }) => {
	return (
		<>
			<Text style={styles.name}>{dish?.name}</Text>
			<Text style={styles.sectionName}>{dish?.section?.label_it}</Text>
		</>
	)
})

export const CommonDishPopup = React.memo(({ dish }: Props) => {
	const image = realImageFood(dish, true)
	const fullImage = realImageFood(dish, false)

	const { width } = useWindowDimensions()
	const maxWidth = width - spacing.pagePadding * 4
	const imageWidth = Math.min(maxWidth, 400)
	const imageHeight = imageWidth * 3 / 4
	return (
		<>
			{!!image && (
				<FLImage
					source={image}
					fullImage={fullImage}
					style={[styles.image, { width: imageWidth, height: imageHeight}]}
					showFull
					resizeMode="detect"
				/>
			)}

			{!!dish.description && (
				<Text style={styles.description}>{dish.description}</Text>
			)}
		</>
	);
});

export const useDishModal = () => {
	const [isVisible, setVisible] = React.useState(false)
	const [visibleDish, setDish] = React.useState<Dish | null>(null)

	const setVisibleDish = React.useCallback((dish: Dish) => {
		setVisible(true)
		setDish(dish)
	}, [])
	const close = React.useCallback(() => {
		setVisible(false)
	}, [])

	const DishModal = (
		<SheetPopup
			visible={isVisible}
			close={close}
			header={<CommonDishHeader dish={visibleDish} />}
		>
			{visibleDish && <DishPopup dish={visibleDish} />}
		</SheetPopup>
	)
	return {
		setVisibleDish,
		DishModal,
	}
}

const DishPopup = React.memo(({ dish }: Props) => {
	return (
		<View style={styles.container}>
			<CommonDishPopup dish={dish} />

			<Text style={styles.price}>
				<DishPrice
					initialPrice={dish.price || 0}
					discountedPrice={getMenuDiscountedPrice(dish) || 0}
				/>
			</Text>

			{dish.options_link && dish.options_link.length > 0 && (
				<View style={styles.marginTop}>
					<InlineDishOptions options={dish.options_link} />
				</View>
			)}
		</View>
	)
})

const styles = StyleSheet.create({
	container: {
		paddingHorizontal: spacing.pagePadding,
		paddingTop: spacing.vertical,
		paddingBottom: spacing.pagePadding,
		backgroundColor: colors.greyBackground,
	},
	name: {
		fontSize: 20,
		fontWeight: "bold",
	},
	sectionName: {
		marginTop: 3,
		marginBottom: 5,
		fontWeight: "500",
	},
	image: {
		borderRadius: 10,
		marginLeft: "auto",
		marginRight: "auto",
		marginTop: spacing.vertical,
	},
	description: {
		color: colors.greyText,
		marginTop: spacing.vertical,
	},
	price: {
		marginTop: 15,
		fontSize: 24,
		fontWeight: "bold",
		color: themeColors.priceTint,
		textAlign: "center",
	},
	marginTop: {
		marginTop: spacing.vertical,
	},
});

export default DishPopup;
