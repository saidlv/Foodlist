import { colors, themeColors } from '@FoodListCore/Global/GlobalProps';
import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	container: {
		borderBottomWidth: 1,
		borderColor: colors.greyBorder
	},
	buttonStyle: {
		marginRight: 20,
		alignItems: 'center',
		justifyContent: 'center'
	},
	textButtonStyle: {
		fontSize: 12,
		height: 25,
		fontWeight: "bold",
		fontStyle: "normal",
		letterSpacing: 0,
		color: colors.greyTextSubMenu
	},
	headerWrapper: {
		borderBottomColor: themeColors.inlineSubMenuTint,
		borderBottomWidth: 4,
		alignItems: 'center',
		justifyContent: 'center'
	},
	textActiveButton: {
		color: colors.blackText,
		height: 21
	}
});
