import React from 'react';
import { View, ScrollView, Text, TextStyle, ViewStyle } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import styles from './Style';

import { when, margins } from '@FoodListCore/Global/GlobalProps'

/**
 * @param selected: number of the button that needs to be active by default
 * @param items: {text, callback} array containg the text inside the buttons and the callback to call on press

 * @return a top bar containing the content specified by paramater
 */

export type InlineMenuItem = {
	text: string,
	callback?: (index: number) => void
}

export const mapStringsToItems = (strItems: string[]): InlineMenuItem[] => {
	return strItems.map(value => ({
		text: value
	}))
}

type InlineMenuProps = {
	items: InlineMenuItem[],
	nonFilter?: boolean,
	inactiveTextColor?: string
	selected: number,
	categoryCallback?: (index: number) => void
	styles?: {
		selectedText: TextStyle,
		container: ViewStyle
	}
}

export default class InlineMenu extends React.PureComponent<InlineMenuProps> {
	render() {
		return (
			<ScrollView style={[styles.container, this.props.styles?.container]} contentContainerStyle={{ paddingLeft: margins.pagePadding }} horizontal={true} showsHorizontalScrollIndicator={false}>
				{this.props.items.map((item, index) => {
					return (
						<TouchableOpacity
							key={index}
							style={styles.buttonStyle}
							onPress={() => {
								item.callback?.(index)
								this.props.categoryCallback?.(index)
							}}>
							<View style={when(this.props.selected == index, styles.headerWrapper)}>
								<Text style={[styles.textButtonStyle, when(!!this.props.inactiveTextColor, { color: this.props.inactiveTextColor}), when(this.props.selected == index, [styles.textActiveButton, this.props.styles?.selectedText])]}>{item.text}</Text>
							</View>
						</TouchableOpacity>
					)
				})}
			</ScrollView>
		)
	}
}
