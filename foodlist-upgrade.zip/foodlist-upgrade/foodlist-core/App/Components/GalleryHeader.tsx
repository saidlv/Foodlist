import { spacing } from '@FoodListCore/Global/Constants';
import { colors, getDishGalleryImages, getRestaurantGalleryImages, margins } from '@FoodListCore/Global/GlobalProps';
import { useListWidth } from '@FoodListCore/Global/WebHelpers';
import { Dish } from '@Models/Dish';
import { Restaurant } from '@Models/Restaurant';
import { User } from '@Models/User';
import React, { useMemo } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { CarouselProps } from 'react-native-banner-carousel-updated/out/Carousel';
import FLImage from './FLImage';
import ImageCarousel from './ImageCarousel';
import ShadowProfileImage from './ShadowProfileImage';

type Props = {
	galleryHeight?: number
	disableFullscreen?: boolean
	item: Restaurant | Dish | User
	type: "restaurant" | "dish" | "user"
	/* carouselProps: {
		images: ImageSource[]
		thumbImages: ImageSource[]
	} */
	carouselProps?: Partial<CarouselProps>
	children?: React.ReactNode
	rightComponent?: React.ReactNode
}

const GalleryHeader = React.memo((props: Props) => {
	const { item, type } = props
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	const carouselProps = useMemo(() => {
		if(type == "dish") {
			return getDishGalleryImages(item as unknown as Dish)
		} else if(type == "restaurant") {
			return getRestaurantGalleryImages(item as unknown as Restaurant)
		} else {
			//TODO: implement for users
			return getRestaurantGalleryImages(item)
		}
	}, [item, type])

	const headerHeight = props.galleryHeight || 240
	const large = !props.disableFullscreen
	const imageSize = large ? 120 : Platform.OS == "web" ? 120 : 80

	const memoStyles = React.useMemo(() => {
		const topMargin = -imageSize + 20
		return StyleSheet.create({
			carousel: {
				position: "absolute",
				width: "100%",
				backgroundColor: colors.greyBackground,
				height: headerHeight,
				...(large ? {
					borderBottomLeftRadius: 10,
					borderBottomRightRadius: 10,
					overflow: "hidden",
				} : null),
			},
			bottom: {
				marginTop: headerHeight,
				paddingHorizontal: margins.pagePadding,
			},
			topMargin: {
				marginTop: topMargin,
			},
		})
	}, [headerHeight, large])

	const width = useListWidth()

	return (
		<View style={styles.relative}>
			<View style={memoStyles.carousel}>
				{(props.disableFullscreen && Platform.OS == "web") ? (
					<FLImage
						style={{ height: headerHeight, width }}
						source={carouselProps.thumbImages?.[0]}
						fullImage={carouselProps.images?.[0]}
						showFull={!carouselProps.isDefault}
					/>
				) : (
					<ImageCarousel
						{...carouselProps}
						hideDots
						height={headerHeight}
						carouselProps={props.carouselProps}
						disableFullscreen={props.disableFullscreen}
					/>
				)}
			</View>
			<View style={memoStyles.bottom}>
				<View style={styles.profileContainer}>
					<View style={memoStyles.topMargin}>
						<ShadowProfileImage item={item} type={type} disableFullscreen={props.disableFullscreen} size={imageSize} />
					</View>
					<View style={memoStyles.topMargin}>
						{props.rightComponent}
					</View>
				</View>
				{props.children}
			</View>
		</View>
	);
});

const styles = StyleSheet.create({
	relative: {
		position: "relative",
	},
	profileContainer: {
		flexDirection: "row",
		alignItems: "flex-end",
		justifyContent: "space-between",
	},
});

export default GalleryHeader;
