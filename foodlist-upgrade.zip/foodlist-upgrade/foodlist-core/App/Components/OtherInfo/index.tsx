import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import commonStyles from '@FoodListCore/Global/CommonStuff/PageStyle';

import BubbleMenu, { BubbleElements } from '@FoodListCore/Components/BubbleMenu';
import { translate } from '@FoodListCore/I18n';

type Props = {
	otherInfo?: BubbleElements[]
}

const OtherInfoComponent = (props: Props) => {
  return (
		<View style={styles.margin}>
			{!!props.otherInfo && (props.otherInfo.length != 0) && (
				<BubbleMenu bubbleInfo={props.otherInfo} />
			)}
			{(!props.otherInfo || props.otherInfo.length == 0) && (
				<Text style={commonStyles.noInfoText}>{translate("noOtherInfo")}</Text>
			)}
		</View>
	);
};

const styles = StyleSheet.create({
	margin: {
		marginTop: 20,
		marginBottom: 20
	}
});


export default OtherInfoComponent;

