import React, { useRef, useState } from 'react';
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import { StyleSheet, View, Text, ViewStyle } from 'react-native';
import Menu, { MenuItem } from '@alessiocancian/react-native-material-menu';
import MaterialIcon from "react-native-vector-icons/MaterialIcons"
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';

export type Option<T> = {
	label: string,
	value: T,
	key?: string
}

type Props<T> = {
	onValueChange: (value: T) => void
	options: Option<T>[]
	initialLabel?: string
	labelColor?: string
	style?: ViewStyle
	dropdownStyle?: ViewStyle
	autoHeight?: boolean
	fixAndroidModals?: boolean
}

type CellProps = {
	label: string
	labelColor?: string
	onPress: () => void
	style?: ViewStyle
	autoHeight?: boolean
	fixAndroidModals?: boolean
}
export const CellComponent = (props: CellProps) => {
	return (
		<View style={[styles.cell, props.style]}>
			<TouchableRipple
				style={[styles.ripple, { height: props.autoHeight ? "auto" : "100%" }]}
				onPress={props.onPress}
				fixAndroidModals={props.fixAndroidModals}
			>
				<Text style={{ marginRight: 5, color: props.labelColor || colors.black }}>{props.label}</Text>
				<MaterialIcon name="arrow-drop-down" size={18} />
			</TouchableRipple>
		</View>
	)
}

const DropdownMenu = <T extends any>(props: Props<T>) => {
	const menuRef = useRef<Menu>(null)
	const [label, setLabel] = useState(props.initialLabel || props.options[0].label)
	const showMenu = () => {
		menuRef.current?.show()
	}
	const optionSelected = (option: Option<T>) => {
		setLabel(option.label)
		menuRef.current?.hide()
		props.onValueChange(option.value)
	}
 	return (
		<Menu
			ref={menuRef}
			style={props.dropdownStyle}
			
			button={(
				<CellComponent
					label={label}
					onPress={showMenu}
					labelColor={props.labelColor}
					fixAndroidModals={props.fixAndroidModals}
					style={props.style}
					autoHeight={props.autoHeight}
				/>
			)}
		>
			{props.options.map((item, index) => {
				/* return (
					<MenuItem
						key={item.key || index}
						onPress={() => optionSelected(item)}
					>{item.label}</MenuItem>
				) */
				return (
					<TouchableRipple
						key={item.key || index}
						onPress={() => optionSelected(item)}
					>
						<Text style={styles.item}>{item.label}</Text>
					</TouchableRipple>
				)
			})}
		</Menu>
	);
};

const styles = StyleSheet.create({
	cell: {
		borderRadius: 5,
		borderWidth: 1,
		borderColor: "#999",
	},
	ripple: {
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "space-between",
		paddingVertical: 5,
		paddingHorizontal: 10
	},
	item: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 14,
	},
});

export default DropdownMenu;
