import colors from '@FoodListCommon/colors';
import { getDiffStringFromNow } from '@FoodListCommon/DateManager';
import { translate } from '@FoodListCore/I18n';
import { reverseGetDelay } from '@FoodListCore/Pages/ReviewOrderPage/delays';
import { DishReview, OrderReview, Review } from '@Models/Review';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import StarRating from './StarRating';

type GenericReview = OrderReview | Review | DishReview 
type OptionalGenericReview = GenericReview | null | undefined
type ReviewField = keyof OrderReview | keyof Review | keyof DishReview

type Props = {
	review: OptionalGenericReview
}

export const getReviewDateString = (review: OptionalGenericReview) => {
	if(!review?.content_updated_at) return ""
	const date = getDiffStringFromNow(review?.content_updated_at, translate)
	return review.content_updated_at != review.created_at ? translate("updatedDate", { date }) : date
}

const OptionallyShowRow = React.memo((props: { text: string, field: ReviewField, item: OptionalGenericReview }) => {
	const { field, text, item } = props
	// @ts-ignore
	const value = item?.[field]
	if(value) {
		return (
			<View style={styles.row}>
				<Text style={{ fontSize: 16 }}>{text} &nbsp;</Text>
				<StarRating rating={value} color={colors.starColor} size={16} />
			</View>
		)
	}
	return <></>
})

const isOrderVerified = (review: DishReview | Review | null | undefined) => {
	if(review) {
		if("order_id" in review) {
			return !!review.order_id
		}
		if("order_row_id" in review) {
			return !!review.order_row_id
		}
	}
	return false
}

const ReviewContent = React.memo(({ review }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])

	const orderVerified = isOrderVerified(review)
	return (
		<>
			{orderVerified ? (
				<Text style={{ color: colors.darkFoodlist, fontWeight: "bold", marginTop: -3, marginBottom: 3 }}>{translate("orderVerified")}</Text>
			) : (
				<></>
			)}
			{/** Dish fields */}
			<OptionallyShowRow item={review} text={translate("quality")} field="rating" />
			<OptionallyShowRow item={review} text={translate("price")} field="price_rating" />

			{/** Order review fields */}
			<OptionallyShowRow item={review} text={translate("location")} field="rating_location" />
			<OptionallyShowRow item={review} text={translate("service")} field="rating_service" />
			<OptionallyShowRow item={review} text={translate("punctuality")} field="rating_punctuality" />


			{review && "delta_time" in review && review.rating_punctuality && (review.delta_time || review.delta_time === 0) && (
				<Text style={styles.delayText}>{review.delta_time === 0 ? translate("onTime") : review.delta_time < 0 ? `${translate("early")}:` : review.delta_time > 0 ? `${translate("late")}:` : ""} {reverseGetDelay(review.delta_time)}</Text>
			)}
			
			{/* <OptionallyShowRow item={review} text={translate("quality")} field="rating_quality" />
			<OptionallyShowRow item={review} text={translate("price")} field="rating_price" /> */}

			{!!review?.content && (
				<Text style={styles.reviewText}>{review.content}</Text>
			)}
		</>
	);
});

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		alignItems: "center",
	},
	reviewText: {
		marginTop: 10,
		fontSize: 14,
		color: colors.greyInfoText,
	},
	delayText: {
		marginTop: 5,
		fontStyle: "italic",
		fontSize: 13,
	},
});

export default ReviewContent;
