import { colors, formatPrice, themeColors } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import { MenuDish } from '@Models/MenuSection';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useSelector } from 'react-redux';
import FLIcon from './FLIcon';
import IconButton from './IconButton';
import SmallButton from './SmallButton';
import { TouchableRipple } from './TouchableRipple';

export interface AddRemoveRowActions {
	onAddPressed: () => void,
	onRemovePressed: () => void,
	onDeleteAllPressed: () => void,
	onConfigurePressed: () => void,
	onEditPressed?: () => void
}

type Props = {
	showConfigureButton?: boolean
	actions: AddRemoveRowActions
	//item: MenuDish
	orderQuantity: number
	totalPrice: number
	hasOptions: boolean
}

const AddRemoveRow = React.memo(({ hasOptions, actions, showConfigureButton, orderQuantity, totalPrice }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])

	//const hasOptions = item.options_link.length > 0
	const showConfigure = (showConfigureButton && hasOptions)
	return (
		
		<View style={{flexDirection: 'row', marginTop: 7, alignItems: "center", justifyContent: "space-between" }}>
		{showConfigure ? (
			<View style={styles.row}>
				<SmallButton
					iconProps={{
						materialCommunityIcon: "food",
						size: 16,
						style: {
							marginRight: 5 
						}
					}}
					onPress={actions.onConfigurePressed}
					backgroundColor={themeColors.configureButtonTint}
					textColor={themeColors.configureButtonText }
					title={translate("menuConfigure")}
				/>
				{(orderQuantity > 0) && (
					<Text style={{ fontWeight: "bold", fontSize: 17, marginHorizontal: 10, textAlign: "center", color: colors.foodlist }}>x{orderQuantity}</Text>
				)}
			</View>
		) : (
			<View style={styles.row}>
				<View style={{ marginRight: 10, opacity: orderQuantity <= 0 ? 0.25 : 1 }}>
					{/* <SmallButton
						icon={"remove-circle"}
						backgroundColor={themeColors.addToCartButtonTint}
						textColor={themeColors.addToCartButtonText}
						title={translate("remove")}
						
					/> */}
					<IconButton
						//style={styles.button}
						//disabled={orderQuantity <= 0}
						onPress={actions.onRemovePressed}
						//borderless
					>
						<FLIcon materialIcon="remove-circle-outline" color={colors.darkBlue} size={24} />
					</IconButton>
				</View>
				<Text style={{ fontWeight: "bold", fontSize: 17, minWidth: 20, marginHorizontal: 5, textAlign: "center", color: colors.foodlist, opacity: orderQuantity <= 0 ? 0 : 1 }}>x{orderQuantity}</Text>
				<View style={{ marginLeft: 10 }}>
					{/* <SmallButton
						icon={"add-circle"}
						onPress={this.props.addToCart}
						backgroundColor={themeColors.addToCartButtonTint}
						textColor={themeColors.addToCartButtonText}
						title={"aggiungi"}
					/> */}
					<IconButton
						//style={styles.button}
						onPress={actions.onAddPressed}
						//borderless
					>
						<FLIcon materialIcon="add-circle-outline" color={colors.darkBlue} size={24} />
					</IconButton>
				</View>
				
			</View>
		)}
		{(orderQuantity > 0) && (
			<View style={styles.row}>
				{actions.onEditPressed ? (
					<View style={{ marginRight: 8 }}>
						<IconButton onPress={actions.onEditPressed} >
							<FLIcon materialIcon="edit" color={colors.greyIcon} size={22} />
						</IconButton>
					</View>
				) : <></>}
				<Text style={{ fontWeight: "bold", color: colors.blueMenu, marginRight: 8, fontSize: 16, }}>{formatPrice(totalPrice)}</Text>
				<IconButton onPress={actions.onDeleteAllPressed}>
					<FLIcon materialIcon="delete" color={colors.red} size={22} />
				</IconButton>
			</View>
		)}
	</View>
	);
});

const styles = StyleSheet.create({
	button: {
		backgroundColor: colors.withAlpha(colors.blueMenu, 0.25),
		padding: 6,
		//paddingHorizontal: 22,
		borderRadius: 20,
		alignItems: "center",
		overflow: "hidden",
	},
	row: {
		flexDirection: "row",
		alignItems: "center",
	}
});

export default AddRemoveRow;
