import { ReduxState } from '@FoodListCore/Redux/StateFormat';
import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, View } from 'react-native';
import { shallowEqual, useSelector } from 'react-redux';
import LightButton from './LightButton';
import { colors, margins, showError } from '@FoodListCore/Global/GlobalProps';

import LoadingView from './LoadingView';
import { translate } from '@FoodListCore/I18n';
import Line from './Line';
import { TouchableOpacity } from './TouchableFixed';
import CardDetail from './CardDetail';
import { StripeCardsHandler } from '@FoodListCore/Services/Stripe';
import { UserPageWrapper } from './UserSideMenu';
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import network from '@config/network';
import SheetPopup from './SheetPopup/index.web';
import AddCard, { useAddCard } from '@FoodListCore/Services/Stripe/WebAddCard';
import { StripeCard } from '@Models/StripeCard';
import { ActivityIndicator } from 'react-native-paper';

export interface MyPaymentMethodsActions {

}

type Props = {
	actions: MyPaymentMethodsActions
}

const mapReduxState = (state: ReduxState) => {
	return {
		cards: state.currentUser?.stripe_cards || [],
	}
}

const stripePromise = loadStripe(network.stripe_publishable_key, {
	locale: "it-IT",
})

const PaymentMethodCell = React.memo(({ item } : { item: StripeCard }) => {
	const [loading, setLoading] = React.useState(false)
	const deleteCard = React.useCallback(() => {
		const stripeHandler = new StripeCardsHandler({ setSending: setLoading })
		stripeHandler.deleteCard(item)
	}, [])

	return (
		<View style={styles.cardRow}>
			<CardDetail
				item={item}
			/>
			{loading ? (
				<ActivityIndicator />
			) : (
				<TouchableOpacity
					onPress={deleteCard}
					style={styles.removeButton}
				>
					<Text style={styles.delete}>{translate("remove")}</Text>
				</TouchableOpacity>
			)}
		</View>
	)
}) 

const MyPaymentMethods = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])

	const [sending, setSending] = useState(false)
	const { cards } = useSelector(mapReduxState, shallowEqual)

	const { addCard, AddCardComponent } = useAddCard({ setSending })

	const additionalSeparator = cards.length > 0 ? <Line /> : <></>

	return (
		<Elements stripe={stripePromise}>
		<UserPageWrapper activePage="payments">
		<LoadingView
			visible={sending}
		/>
		<FlatList
			contentContainerStyle={[styles.scrollContainer]}
			data={cards}
			ItemSeparatorComponent={Line}
			ListFooterComponent={(
				<>
					{additionalSeparator}

					<LightButton
						shadow
						style={{ margin: margins.pagePadding, backgroundColor: colors.blueMenu }}
						onPress={addCard}
						materialIcon="add"
						iconProps={{ color: colors.white, size: 18 }}
					><Text selectable={false} style={{ color: colors.white }}>{translate("addCard")}</Text></LightButton>
				</>
			)}
			ListEmptyComponent={(
				<Text style={{ textAlign: "center", padding: margins.pagePadding }}>{translate("noCreditDebitCardInserted")}</Text>
			)}
			keyExtractor={item => item?.id?.toString()}
			renderItem={({ item }) => {
				return (
					<PaymentMethodCell item={item} />
				)
			}}
		/>
		</UserPageWrapper>
		{AddCardComponent}
		</Elements>
	);
});

const styles = StyleSheet.create({
	scrollContainer: {
		//paddingVertical: margins.pagePadding,
		borderRadius: 4,
		backgroundColor: colors.white,
		margin: margins.pagePadding,
		borderColor: colors.greyBorder,
		borderWidth: margins.hairlineWidth,
		overflow: "hidden",
	},
	cardRow: {
		flexDirection: "row",
		alignItems: "center",
		backgroundColor: colors.white,
		padding: margins.pagePadding,
	},
	delete: {
		color: colors.red,
		fontWeight: "bold",
	},
	removeButton: {
		padding: 10,
		marginRight: -10,
	},
});

export default MyPaymentMethods;
