import requestAuth from '@FoodListCore/Flows/RequestAuth';
import NetworkManager from '@FoodListCore/Network/NetworkManager';
import { DishReview, Review } from '@Models/Review';
import { StackNavigationProp } from '@react-navigation/stack';
import React from 'react';
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { FeedType, FeedTypePrefix } from '@Models/FeedType';
import { RequestResponse } from '@Models/RequestResponse';
import { Like } from '@Models/Like';
import { shallowEqual, useSelector } from 'react-redux';
import { ReduxState } from '@FoodListCore/Redux/StateFormat';
import { colors, showError } from '@FoodListCore/Global/GlobalProps';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';

export interface ReviewLikeButtonActions {

}

type Props = {
	/**
	 * If provided requests authentication
	 * If null like button will be disabled when not logged
	 */
	navigation: StackNavigationProp<any> | null
	item: Review | DishReview
	onUpdate?: (item: Review) => void
}

export type PressLikeResponse = {
	response: Like | { status: string }
} | null
class ReviewDetailManager extends NetworkManager {
	constructor() {
		super()
	}

	pressLike(id: number, review_id: number, feedType: FeedType, liked: boolean, likeId?: number): Promise<RequestResponse<PressLikeResponse>> {
		const prefix = feedType == "DISH" ? "dishes" : "restaurants";
		return this._handleLike(prefix, id, review_id, liked, likeId);
	}
	_handleLike(prefix: FeedTypePrefix, id: number, review_id: number, liked: boolean, likeId?: number): Promise<RequestResponse<PressLikeResponse>> {
		const baseUrl = "/" + prefix + "/" + id + "/reviews/" + review_id + "/likes";
		const method = liked ? "POST" : "DELETE";
		const url = liked ? baseUrl : baseUrl + "/" + likeId;
		return super.handleRequest(url, method, { user_id: ":current_user_id" })
	}
}

const reduxMap = (state: ReduxState) => {
	return {
		currentUser: state.currentUser
	}
}

const getLikeIndex = (likes: Like[], id?: number): number => {
	for (let i in likes) {
		if (likes[i].id == id) return parseInt(i);
	}
	return -1;
}

const ReviewLikeButton = React.memo((props: Props) => {
	const self = React.useMemo(() => ({ updating: false }), [])
	const { item } = props
	const { currentUser } = useSelector(reduxMap, shallowEqual)

	const disableButton = !currentUser && !props.navigation

	const [loading, setLoading] = React.useState(false)

	const onPress = React.useCallback(() => {
		if(self.updating || disableButton || !requestAuth(props.navigation!)) return

		const feed_type = "feed_type" in item ? item.feed_type : (item.dish_id ? "DISH" : "RESTAURANT")
		const id = feed_type == "DISH" ? item.dish_id : item.restaurant_id;
		const review_id = item.id;
		const likeArray = (item.likes || []).filter((v) => v.user_id == currentUser?.id);
		const likeObject = likeArray.length > 0 ? likeArray[0] : null;
		let manager = new ReviewDetailManager();
		const aboutToBeLiked = likeObject == null;
		
		setLoading(true)
		self.updating = true

		manager.pressLike(id, review_id, feed_type, aboutToBeLiked, likeObject?.id).then((response) => {
			if(!item.likes) {
				item.likes = []
			}
			
			if (aboutToBeLiked && response.data && 'user_id' in response.data.response) {
				if(currentUser) {
					response.data.response.user = currentUser
					item.likes.push(response.data.response);
				} else {
					throw new Error("Logged user not found")
				}
			} else {
				let i = getLikeIndex(item.likes, likeObject?.id);
				if (i != -1) {
					item.likes.splice(i, 1);
				}
			}
			item.likes = [...item.likes]
			props.onUpdate?.(item)
		}).catch(showError).finally(() => {
			setLoading(false)
			self.updating = false
		});
	}, [disableButton])

	const liked = React.useMemo(() => {
		const filtered = (item.likes || []).filter((v) => v.user_id == currentUser?.id);
		return filtered.length > 0
	}, [item, item.likes])

	return (
		<TouchableOpacity
			/* hitSlop={{ top: 5, bottom: 10, left: 10, right: 10 }} */
			onPress={onPress}
			disabled={disableButton}
		>
			<View style={styles.inline}>
				{loading ? (
					<View style={[styles.inline, { marginRight: 20 }]}>
						<ActivityIndicator size="small" color={colors.blackOverlay} />
					</View>
				) : (
					<View style={styles.inline}>
						<Icon
							name={liked ? 'heart' : 'heart-o'}
							size={16}
							color={liked ? colors.red : colors.greyText}
						/>
						<Text style={liked ? styles.redText : styles.greyText}>{(item.likes || []).length}</Text>
					</View>
				)}
			</View>
		</TouchableOpacity>
	);
});

const styles = StyleSheet.create({
	inline: {
		flex: 0,
		flexDirection: 'row',
		alignItems: 'center'
	},
	redText: {
		fontSize: 12,
		fontWeight: '900',
		color: colors.red,
		textAlignVertical: 'center',
		paddingLeft: 6,
		paddingRight: 24
	},
	greyText: {
		fontSize: 12,
		fontWeight: '900',
		color: colors.greyText,
		textAlignVertical: 'center',
		paddingLeft: 6,
		paddingRight: 24
	},
});

export default ReviewLikeButton;
