import { translate } from "@FoodListCore/I18n"
import { Category } from "@Models/Category"
import { Restaurant } from "@Models/Restaurant"
import { Dish } from "@Models/Dish"
import { User } from "@Models/User"

export const formatCategories = (categories: Category[] | undefined) => {
	let labels = (categories || []).map((item) => {
		return item.label_it
	})
	let stringCategories = labels.join(", ")
	return stringCategories.length == 0 ? translate("categoriesNotAvailable") : stringCategories.toUpperCase()
}

export const getCount = (item: Restaurant | Dish | User) => {
	let count = "0"
	if (item.reviews_count) {
		count = item.reviews_count.toString()
	}
	return count.concat(" " + (count == "1") ? translate("review") : translate("reviews"))
}