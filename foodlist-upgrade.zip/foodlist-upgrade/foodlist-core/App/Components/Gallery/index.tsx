import React from 'react';
import { View, Text } from 'react-native';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';

import { colors } from '@FoodListCore/Global/GlobalProps';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import styles from '@FoodListCore/Global/CommonStuff/PageStyle';
import { GalleryModal } from './GalleryModal';

import { ImageSource } from '@Models/ImageSource';
import ImageBackground from '@FoodListCore/Components/ImageBackground'
import { AbsoluteRipple, TouchableRipple } from '../TouchableRipple';

/**
 * @param gallery: immagini [{source: {uri: ""}}, ...]
 * @param first: immagine mostrata inizialmente (o placeholder)
 * @param hideNumbers: nasconde numero di immagini
 */

type FullScreenGalleryProps = {
	gallery: ImageSource[],
	galleryThumb?: ImageSource[],
	first?: ImageSource,
	firstThumb?: ImageSource,
	hideNumber?: boolean,
}

export default class FullScreenGallery extends React.PureComponent<FullScreenGalleryProps, {}> {

	galleryModal: GalleryModal | null = null

	constructor(props: FullScreenGalleryProps) {
		super(props)
	}

	openGallery = () => {
		if (this.props.gallery.length > 0) {
			this.galleryModal?.show(this.getGallery())
		}
	}
	getGallery = () => {
		return this.props.gallery.map((item, index) => {
			const thumbImage = this.props.galleryThumb?.[index]
			return {
				source: thumbImage ? thumbImage : item,
				fullSource: thumbImage ? item : undefined
			}
		})
	}
	render() {
		const fullImage = this.props.first || this.props.gallery?.[0]
		const thumbImage = this.props.firstThumb || this.props.galleryThumb?.[0]
		return (
			<View style={{ flex: 0 }}>
				<View style={[styles.shadow, { borderRadius: 5, alignItems: 'center', flex: 0, alignSelf: 'center' }]}>
					<ImageBackground source={thumbImage ? thumbImage : fullImage} fullSource={thumbImage ? fullImage : undefined} borderRadius={5} style={{ width: 200, height: 200, backgroundColor: colors.greyBackground, borderRadius: 5, overflow: "hidden" }}>
						{!this.props.hideNumber &&
							<View style={[styles.textInsideProfileImage, styles.flexRow, styles.alignCenter]}>
								<Text style={styles.photoText}>{(this.props.gallery || []).length}</Text>
								<Icon name="photo-1" size={15} color={colors.white} />
							</View>
						}
						<AbsoluteRipple
							onPress={this.openGallery}
						/>
					</ImageBackground>
				</View>
				<GalleryModal ref={ref => this.galleryModal = ref} />
			</View>
		)
	}
}
