import React from 'react';
import { View, Modal, SafeAreaView } from 'react-native';
import PhotoGallery, { GalleryImage as PGalleryImage } from '@FoodListCore/Components/PhotoGallery';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';

export type GalleryImage = PGalleryImage

type State = {
	visible: boolean,
	gallery: GalleryImage[]
	index: number
}

export class GalleryModal extends React.PureComponent<{}, State> {
	state: Readonly<State> = {
		visible: false,
		gallery: [],
		index: 0,
	}

	show = (gallery: GalleryImage[], index?: number) => {
		this.setState({
			visible: true,
			gallery: gallery,
			index: index || 0,
		})
	}
	hideGallery = () => {
		this.setState({
			visible: false
		})
	}
	render() {
		return (
			<Modal
				animationType="slide"
				visible={this.state.visible}
				presentationStyle="fullScreen"
				/* style={{flex: 1}} */
				onRequestClose={this.hideGallery}
			>
				<View style={{ flex: 1, backgroundColor: '#000' }}>
					<SafeAreaView style={{ flex: 1, flexDirection: 'column', alignItems: 'stretch' }}>
						<View style={{ flex: 1, position: 'relative' }}>
							<TouchableOpacity onPress={this.hideGallery} style={{ alignItems: "flex-start" }}>
								<Icon style={{ margin: 16 }} name="close" size={17} color="#fff" />
							</TouchableOpacity>
							<PhotoGallery
								style={{ backgroundColor: '#000' }}
								images={this.state.gallery}
								index={this.state.index}
							/>
						</View>
					</SafeAreaView>
				</View>
			</Modal>
		)
	}
}
