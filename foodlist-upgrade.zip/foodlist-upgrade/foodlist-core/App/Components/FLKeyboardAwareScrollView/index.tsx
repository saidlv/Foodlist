import React, { PureComponent } from 'react';
import { Platform, NativeModules, StatusBarIOS, EmitterSubscription, ViewStyle } from 'react-native'
const { StatusBarManager } = NativeModules;
import FLKeyboardAwareScrollViewView, { FLKeyboardAwareScrollViewViewActions } from './view';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { getStatusBarHeight } from 'react-native-status-bar-height';

/* export interface FLKeyboardAwareScrollViewComponentActions {

} */

type FLKeyboardAwareScrollViewComponentProps = {
	//actions: FLKeyboardAwareScrollViewComponentActions;
	hasNestedScrollView?: boolean,
	contentContainerStyle?: ViewStyle,
	multipleInputs?: boolean,
	disableBounce?: boolean,
	extraScrollHeight: number, // <-- L'ho messo required per ricordarsi che in base a cosa c'è sotto la keyboard aware scroll view si inventa i margini, quindi bisogna fare delle prove e con questo campo aggiustare le cose
}

type FLKeyboardAwareScrollViewComponentState = {
	statusBarHeight?: number
}

class FLKeyboardAwareScrollViewComponent extends PureComponent<FLKeyboardAwareScrollViewComponentProps, FLKeyboardAwareScrollViewComponentState> {

	state: FLKeyboardAwareScrollViewComponentState = {
		statusBarHeight: 0
	}

	keyboardAwareScrollView: KeyboardAwareScrollView | null = null
	statusBarListener: EmitterSubscription | null = null

	actions: FLKeyboardAwareScrollViewViewActions = {
		onKeyboardWillHide: () => {
			if (!this.props.multipleInputs) {
				this.keyboardAwareScrollView?.scrollToPosition(0, 0, false)
			}
		}
	}

	componentDidMount() {

		if (Platform.OS == 'ios') {
			StatusBarManager.getHeight((response: { height: number }) => {
				this.setState({ statusBarHeight: response.height })
			})

			this.statusBarListener = StatusBarIOS.addListener('statusBarFrameWillChange', (statusBarData) => {
				this.setState({ statusBarHeight: statusBarData.frame.height })
			})
		}

	}

	getExtraScrollHeight = (): number => {
		let res = this.props.extraScrollHeight;
		if (res) {
			let statusBar = getStatusBarHeight();

			if (Platform.OS == 'ios') {
				if (statusBar <= 20) {
					//("this.state.statusBarHeight", this.state.statusBarHeight, this.state.statusBarHeight ?? 0)
					if ((this.state.statusBarHeight ?? 0) >= 40) {
						res -= 5;
					} else {
						res -= 25;
					}
				}
			}

			return res;
		}

		return 0;
	}

	render() {
		const { hasNestedScrollView, disableBounce, multipleInputs } = this.props
		return (
			<KeyboardAwareScrollView
				ref={ref => { this.keyboardAwareScrollView = ref }}
				onKeyboardWillHide={this.actions?.onKeyboardWillHide}

				bounces={!hasNestedScrollView && !disableBounce}
				scrollEnabled={!hasNestedScrollView}
				extraHeight={multipleInputs ? -64 : undefined} // This is a workaround, but it works

				contentContainerStyle={this.props.contentContainerStyle}
				extraScrollHeight={this.getExtraScrollHeight()}

				automaticallyAdjustContentInsets={false}
				keyboardShouldPersistTaps="handled"
			>
				{this.props.children}
			</KeyboardAwareScrollView>
		)
	}
}

export default FLKeyboardAwareScrollViewComponent;
