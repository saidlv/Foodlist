import { colors, spacing } from '@FoodListCore/Global/Constants';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import FLLink from './FLLink';

type Props = {
	errorText?: string
}

const LoadFailed = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<View style={styles.restErrorContainer}>
			<Text style={styles.errorText}>{props.errorText || "Impossibile caricare il locale."}</Text>
			<FLLink
				to="/"
			>
				<Text style={styles.linkText}>Torna alla home</Text>
			</FLLink>
		</View>
	);
});

const styles = StyleSheet.create({
	restErrorContainer: {
		paddingHorizontal: spacing.pagePadding,
		paddingVertical: spacing.pagePadding * 3,
		maxWidth: 300,
		marginLeft: "auto",
		marginRight: "auto",
		alignItems: "center",
	},
	errorText: {
		fontSize: 15,
		marginBottom: 8,
	},
	linkText: {
		textDecorationLine: "underline",
		color: colors.blueMenu,
		fontWeight: "600",
		fontSize: 16,
	},
});

export default LoadFailed;
