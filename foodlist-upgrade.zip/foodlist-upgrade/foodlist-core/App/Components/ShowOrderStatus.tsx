import { getMoment, HOUR_FORMAT, RECEIPT_DATETIME_FORMAT, TIME_FIRST_FORMAT } from '@FoodListCommon/DateManager';
import { printOrderDate, printOrderStatus, printOrderTime } from '@FoodListCommon/orders';
import { colors } from '@FoodListCommon/utils';
import { translate } from '@FoodListCore/I18n';
import { Order, OrderStatus, OrderType } from '@Models/Order';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

type Props = {
	order: Order
}

export const getStatusText = (order: Order) => {
	const { status_id, order_type } = order
	const isTakeaway = order_type == OrderType.Takeaway
	return printOrderStatus(status_id, isTakeaway, translate)
}

const ShowOrderStatus = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])

	const { order } = props
	const { status_id, order_type, delivery_time } = order
	const isTakeaway = order_type == OrderType.Takeaway
	const showExpectedTime = (status_id == OrderStatus.Accepted || (status_id == OrderStatus.Delivering && !isTakeaway))
	return (
		<View style={{ marginVertical: 10 }}>
			<Text style={{ marginBottom: 10 }}>Orario richiesto: <Text style={{ color: colors.blueMenu }}>{printOrderDate(order)} <Text style={{ fontWeight: "bold" }}>{printOrderTime(order, translate)}</Text></Text></Text>
			{(status_id == OrderStatus.Delivered) ? (
				<Text style={styles.statusText}>{translate(isTakeaway ? "orderCompleted" : "orderDelivered")}</Text>
			) : (status_id == OrderStatus.Delivering) ? (
				<>
					{isTakeaway ? (
						<>
							<Text style={styles.statusText}>{translate("orderReady")}</Text>
							<Text>{translate("orderReadyMessage")}</Text>
						</>
					) : (
						<>
							<Text style={styles.statusText}>{translate("orderDelivering")}</Text>
						</>
					)}
				</>
			) : (status_id == OrderStatus.Accepted) ? (
				<>
					<Text style={styles.statusText}>{translate("orderAccepted")}</Text>
				</>
			) : (status_id == OrderStatus.Pending) ? (
				<>
					<Text style={styles.statusText}>{translate("orderPending")}</Text>
				</>
			) : (status_id == OrderStatus.Rejected) ? (
				<>
					<Text style={[styles.statusText, { color: colors.red }]}>{translate("orderRejected")}</Text>
					<Text><Text style={{ fontWeight: "bold"}}>{translate("reason")}: </Text> {order.reject_reason}</Text>
				</>
			) : (
				<></>
			)}
			{showExpectedTime && (delivery_time ? (
				<>
					<Text>orario previsto</Text>
					<Text><Text style={styles.time}>{getMoment(delivery_time).format(HOUR_FORMAT)}</Text></Text>
				</>
			) : (
				<Text>Il locale non ha indicato l'orario previsto</Text>
			))}

			{/* <Text style={styles.statusText}>{getStatusText(order.status_id)}</Text> */}
		</View>
	);
});

const styles = StyleSheet.create({
	statusText: {
		fontSize: 18,
		fontWeight: "bold"
	},
	time: {
		fontWeight: "bold",
		fontSize: 18,
		color: colors.blueMenu,
		marginRight: 10
	}
});

export default ShowOrderStatus;
