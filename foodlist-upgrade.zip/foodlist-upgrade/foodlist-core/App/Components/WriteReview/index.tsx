import BigButton from '@FoodListCore/Components/BigButton/BigButton';
import requestAuth from '@FoodListCore/Flows/RequestAuth';
import { colors, showError } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import ReviewManager from '@FoodListCore/Network/ReviewManager';
import { userLogged } from '@FoodListCore/Redux/ReduxHelper';
import { Dish } from '@Models/Dish';
import { Restaurant } from '@Models/Restaurant';
import { Review } from '@Models/Review';
import { useFocusEffect, useNavigation } from '@react-navigation/core';
import { StackNavigationProp } from '@react-navigation/stack';
import React from 'react';
import { useEffect } from 'react';
import { StyleSheet, Text } from 'react-native';
import FLIcon from '../FLIcon';
import config from "@config/custom";

type Props = {
	restaurant: Restaurant
	dish?: Dish
}

const WriteReview = React.memo(({ restaurant, dish }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	const self = React.useMemo(() => ({
		reviewing: false,
		review: undefined as undefined | Review
	}), [])
	const [reviewWritten, setReviewPresent] = React.useState(false)
	const [loading, setLoading] = React.useState(true)
	const loadData = React.useCallback(() => {
		setLoading(true)
		const manager = new ReviewManager()
		manager.getPreviousReview(dish?.id || restaurant?.id, dish ? true : false).then((body) => {
			self.review = body.data?.review
			setReviewPresent(!!self.review)
			//body.data?.review
		}).catch(showError)
		.finally(() => setLoading(false))
	}, [])

	useFocusEffect(React.useCallback(() => {
		/* if(!self.reviewing) {
			loadData()
		} */
		self.reviewing = false
	}, []))

	const navigation = useNavigation<StackNavigationProp<any>>()
	const onPress = React.useCallback(() => {
		if(requestAuth(navigation, true)) {
			self.reviewing = true
			navigation.push("FastReview", {
				restaurant,
				dish,
				//edit_review: self.review,
				reviewMode: dish ? "dish" : "restaurant",
				callbackShouldReload: () => setReviewPresent(true)
			})
		}
	}, [navigation])

	const hideButton = !userLogged() || config.hideReviewButtons

	useEffect(() => {
		if(!hideButton) {
			loadData()
		}
	}, [])

	if(hideButton) {
		return <></>
	}

	return (
		<>
			<BigButton
				color={colors.white}
				textColor={reviewWritten ? colors.darkGreen : colors.blueMenu}
				onPress={onPress}
				loading={loading}
			>
				<Text>
					<FLIcon
						materialCommunityIcon={reviewWritten ? "check-bold" : "tooltip-text-outline"}
						size={16}
					/>&nbsp; {reviewWritten ? translate("alreadyReviewed") : translate("doReview")}</Text>
			</BigButton>
		</>
	);
});

const styles = StyleSheet.create({

});

export default WriteReview;
