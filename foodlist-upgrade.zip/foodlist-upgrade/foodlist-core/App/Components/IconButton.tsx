import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, ViewStyle } from 'react-native';
import FLIcon from './FLIcon';
import { TouchableRipple } from './TouchableRipple';

type Props = {
	children: React.ReactChild
	onPress: () => void
	disabled?: boolean
	style?: ViewStyle
}

const IconButton = React.memo(({ children, onPress, disabled, style }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<TouchableRipple
			onPress={onPress}
			style={[styles.circle, style]}
			borderless
			disabled={disabled}
		>
			{children}
		</TouchableRipple>
	);
});

const styles = StyleSheet.create({
	circle: {
		borderRadius: 100,
		padding: 8,
		overflow: "hidden",
		margin: -3,
	},
});

export default IconButton;
