import { colors } from '@FoodListCommon/utils';
import { UserAddress } from '@Models/UserAddress';
import React from 'react';
import { StyleSheet, Text } from 'react-native';

export interface AddressInfoActions {

}

type Props = {
	address: UserAddress
}

const AddressInfos = React.memo((props: Props) => {
	const { address } = props
	return (
		<>
			<Text style={{ fontWeight: "bold", fontSize: 15 }}>{address.name}{address.name ? " - " : ""}{address.doorbell_name}</Text>
			<Text style={{ fontSize: 15, paddingVertical: 2 }}>{address.address}, {address.house_number}</Text>
			<Text style={{ fontSize: 14, color: "#666" }}>{address.city}, {address.cap}</Text>
			{!!address.notes && <Text style={{ fontSize: 14, color: "#666" }}>{address.notes}</Text>}
		</>
	);
});

const styles = StyleSheet.create({

});

export default AddressInfos;
