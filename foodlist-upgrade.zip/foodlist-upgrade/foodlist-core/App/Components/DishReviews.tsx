import React from 'react';
import { getDishSectionName } from '@FoodListCommon/menu';
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import DishManager from '@FoodListCore/Network/InfoFoodManager';
import ReviewCell, { RowHeader } from '@FoodListCore/Components/ReviewCell';
import { Dish } from '@Models/Dish';
import { ListParams } from '@Models/ListParams';
import { StyleSheet, View } from 'react-native';
import Line from './Line';
import {LoadMoreList} from './LoadMoreList';

type Props = {
	dish: Dish
	hideHeader?: boolean
}

const manager = new DishManager()

export const DishHeader = React.memo(({ dish }: Props) => {
	return (
		<RowHeader item={{ dish, dish_name: dish.name, dish_section_name: getDishSectionName(dish), price: dish.price || 0 }} />
	)
})

const DishReviews = React.memo(({ dish, ...props }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	const loadData = React.useCallback((params: ListParams) => {
		return manager.getReviewsFood(dish.id, params)
	}, [dish])

	//const onPress = useCallback((param: number) => { }, [])
	return (
		<>
		{!props.hideHeader && (
			<>
			<View style={styles.header}>
				<DishHeader dish={dish} />
			</View>
			<Line />
			</>
		)}
		<LoadMoreList
			bottomSheet
			contentContainerStyle={styles.background}
			request={loadData}
			renderItem={({ item }) => {
				return (
					<ReviewCell
						review={item}
					/>
				)
			}}
		/>
		</>
	);
});

const styles = StyleSheet.create({
	background: {
		backgroundColor: colors.greyBackground,
		flexGrow: 1,
		paddingVertical: margins.pagePadding / 2,
	},
	header: {
		paddingHorizontal: margins.pagePadding,
		paddingBottom: 10,
	},
});

export default DishReviews;
