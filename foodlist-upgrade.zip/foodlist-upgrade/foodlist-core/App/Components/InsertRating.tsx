import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import RatingText, { Mode } from './RatingText';
import StarRating from './StarRating';

type Props = {
	title: string
	value: number
	onChange: (value: number) => void
	mode: Mode
}

const InsertRating = React.memo(({ title, value, onChange, mode }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<>
			<Text style={styles.title}>{title}</Text>
			<View style={styles.row}>
				<StarRating rating={value} size={28} editable onChange={onChange} />
				<RatingText style={styles.ratingText} rating={value} mode={mode} />
			</View>
		</>
	);
});

const styles = StyleSheet.create({
	title: {
		fontWeight: "bold",
		fontSize: 16,
		marginTop: 15,
		marginBottom: 5,
	},
	row: {
		flexDirection: "row",
		alignItems: "center",
	},
	ratingText: {
		flex: 1,
		marginLeft: 5,
		textAlign: "right",
	},
});

export default InsertRating;
