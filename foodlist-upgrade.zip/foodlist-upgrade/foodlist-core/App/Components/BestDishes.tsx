import React from 'react';
import { colors, spacing } from '@FoodListCore/Global/Constants';
import { Dish } from '@Models/Dish';
import { StyleSheet, Text, View, ViewStyle } from 'react-native';
import { useDishModal } from './DishPopup';
import DishSearchCell from './DishSearchCell';
import FLIcon from './FLIcon';
import FLLink from './FLLink';
import BText from './BText';
import { StackActions } from '@react-navigation/native';

type Props = {
	dishes: Dish[] | null | undefined
	restaurant_id: number
	style?: ViewStyle
}

const BestDishes = React.memo(({ dishes, restaurant_id, ...props }: Props) => {
	const { setVisibleDish, DishModal } = useDishModal()
	const items = dishes || []
	return (
		<>
			{(items.length > 0) && (
				<View style={[styles.container, props.style]}>
					{items.map(dish => {
						return (
							<React.Fragment key={dish.id?.toString()}>
								<DishSearchCell
									dish={dish}
									onPress={() => setVisibleDish(dish)}
									style={styles.cell}
								/>
							</React.Fragment>
						)
					})}
					<FLLink
						style={styles.link}
						to={`/r/${restaurant_id}/menu`}
						action={StackActions.push("Menu", {
							restaurant_id,
						})}
					>
						<View style={styles.row}>
							{/* <FLIcon materialIcon="restaurant-menu" color={colors.blueMenu} size={18} /> */}
							<BText style={styles.showMenuText}>Mostra tutto il menu</BText>
							<FLIcon materialIcon="restaurant-menu" color={colors.blueMenu} size={18} />
						</View>
					</FLLink>
				</View>
			)}
			{DishModal}
		</>
	);
});

const styles = StyleSheet.create({
	container: {
		alignItems: "center",
		flexDirection: "row",
		flexWrap: "wrap",
	},
	cell: {
		marginTop: 0,
	},
	link: {
		padding: 10,
		alignSelf: "center",
		marginBottom: 8,
	},
	row: {
		display: "flex",
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "center",
	},
	showMenuText: {
		fontWeight: "bold",
		color: colors.blueMenu,
		marginRight: 5,
	},
});

export default BestDishes;
