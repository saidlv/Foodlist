import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { MaterialCommunityIcon, MaterialCommunityIconName, MaterialIconName } from '@FoodListCore/Iconfont/FoodListIconfont';
import { CardBrand } from '@Models/StripeCard';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet } from 'react-native';
import FLImage from './FLImage';

const images = {
	visa: require("@FoodListCore/Assets/Cards/visa.png"),
	unionpay: require("@FoodListCore/Assets/Cards/unionpay.png"),
	mastercard: require("@FoodListCore/Assets/Cards/mastercard.png"),
	amex: require("@FoodListCore/Assets/Cards/amex.png"),
	jbc: require("@FoodListCore/Assets/Cards/jbc.png"),
	discover: require("@FoodListCore/Assets/Cards/discover.png"),
	diners_club: require("@FoodListCore/Assets/Cards/diners_club.png"),
	//cartes_bancaires: require("@FoodListCore/Assets/Cards/cartes_bancaires.png"),
	unknown: require("@FoodListCore/Assets/Cards/unknown.png"),
}

type Props = {
	brand: CardBrand
}

const iconForBrand = (brand: CardBrand) => {
	if(brand == "visa") return images.visa
	if(brand == "mastercard") return images.mastercard
	if(brand == "amex") return images.amex
	if(brand == "unionpay") return images.unionpay
	if(brand == "jcb") return images.jbc
	if(brand == "discover") return images.discover
	if(brand == "diners_club") return images.diners_club
	//if(brand == "cartes_bancaires") return images.cartes_bancaires
	return images.unknown
}

const CreditCardIcon = React.memo(({ brand }: Props) => {
	return (
		<FLImage
			source={iconForBrand(brand)}
			style={styles.image}
			resizeMode="contain"
		/>
	);
});

const styles = StyleSheet.create({
	image: {
		width: 40,
		height: 25,
		resizeMode: "contain",
	}
});

export default CreditCardIcon;
