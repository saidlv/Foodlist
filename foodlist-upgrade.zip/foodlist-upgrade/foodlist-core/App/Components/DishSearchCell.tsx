import React from 'react';
import { Platform, StyleSheet, Text, View, ViewStyle } from 'react-native';
import FLImage from '@FoodListCore/Components/FLImage';
import { getDishSectionName } from '@FoodListCommon/menu';
import { limitStringLength } from '@FoodListCommon/utils';
import { TouchableRipple } from './TouchableRipple';
import { colors, spacing } from '@FoodListCore/Global/Constants';
import { formatPrice } from '@FoodListCommon/prices';
import { imageFood } from '@FoodListCore/Global/GlobalProps';
import { Dish } from '@Models/Dish';
import CommonStyle from '@FoodListCore/Global/CommonStyle';

type DishSearchCellProps = {
	dish: Dish
	onPress: () => void
	style?: ViewStyle
}

const DishSearchCell = ({ dish, onPress, ...props }: DishSearchCellProps) => (
	<View style={[styles.container, Platform.OS == "web" ? CommonStyle.hardShadow : CommonStyle.shadow, props.style]}>
	<TouchableRipple
		style={styles.dishBox}
		onPress={onPress}
		borderless
	>
		<>
		<View style={styles.infos}>
			<View style={styles.row}>
				<Text style={styles.dishName}>{limitStringLength(dish.name, 32)}</Text>
				<Text style={styles.price}>{formatPrice(dish.price)}</Text>
			</View>
			<Text style={styles.dishSection}>{getDishSectionName(dish)}</Text>
		</View>
		<FLImage source={imageFood(dish, true)} style={styles.image} resizeMode="cover" />
		</>
	</TouchableRipple>
	</View>
)

const styles = StyleSheet.create({
	container: {
		marginTop: 10,
		marginBottom: 8,
		marginRight: 8,
		backgroundColor: colors.white,
		borderRadius: 4,
	},
	dishBox: {
		padding: 5,
		paddingLeft: 8,
		//...CommonStyle.shadow,
		//borderColor: colors.greyBorder,
		//borderWidth: spacing.hairlineWidth,
		flexDirection: "row",
	},
	row: {
		flexDirection: "row",
		alignItems: "center",
	},
	infos: {
		flex: 1,
		marginRight: 10,
		justifyContent: "center",
	},
	dishName: {
		flex: 1,
	},
	price: {
		color: colors.blueMenu,
		marginLeft: 5,
		fontSize: 12,
		fontWeight: "bold",
	},
	dishSection: {
		fontSize: 12,
		color: colors.greyInfoText,
	},
	image: {
		width: 40,
		height: 40,
		borderRadius: 4,
	},
});

export default DishSearchCell;
