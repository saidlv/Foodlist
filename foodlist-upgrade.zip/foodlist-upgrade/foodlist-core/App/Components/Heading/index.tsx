import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { ImageSource } from '@Models/ImageSource';
import ScrollViewBounceFix from '../ScrollViewBounceFix';
import { colors } from '@FoodListCore/Global/GlobalProps';
import Header from '../Header';
import FullScreenGallery from '../Gallery';
import styles from '@FoodListCore/Global/CommonStuff/PageStyle';

type Props = {
	title: string
	subTitle?: string
	image: ImageSource
	fullImage: ImageSource
	gallery?: ImageSource[]
	hideNumber?: boolean
	headerColor?: string
	children?: React.ReactNode
}

const Heading = (props: Props) => {
	const { image, fullImage, gallery, title, subTitle} = props
	return (
		<View style={{position: "relative"}}>
			<ScrollViewBounceFix color={props.headerColor} />
			<View style={styles.curvedContainer}>
				<Header source={image} backgroundColor={colors.greyBackground} customColor={props.headerColor} />
			</View>

			<Text style={styles.title}>{title}</Text>
			{subTitle ? (
				<Text style={styles.subTitle}>{subTitle}</Text>
			) : (
				<View style={{marginBottom: 15}} />
			)}
			{props.children}

			<FullScreenGallery
				gallery={gallery ?? [fullImage]}
				galleryThumb={gallery ?? [image]}
				first={fullImage}
				firstThumb={image}
				hideNumber={props.hideNumber}
			/>
		</View>
	);
};

export default Heading;
