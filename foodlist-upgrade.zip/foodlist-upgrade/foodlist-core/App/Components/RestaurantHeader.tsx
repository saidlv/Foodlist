import { printableDistance } from '@FoodListCore/Global/CommonStuff/CommonFunctions';
import { colors, formatPrice, margins, restAddress } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import RestaurantManager from '@FoodListCore/Network/RestaurantManager';
import { ReviewCell } from '@FoodListCore/Components/ReviewCell';
import { isOpenNow } from '@FoodListCore/Services/DateManager';
import { DeliveryRoute } from '@Models/DeliveryRoute';
import { ListParams } from '@Models/ListParams';
import { Restaurant } from '@Models/Restaurant';
import React, { useCallback, useState } from 'react';
import { ViewStyle } from 'react-native';
import { StyleSheet, Text, View } from 'react-native';
import Line from './Line';
import {LoadMoreList} from './LoadMoreList';
import ReviewsButton from './ReviewsButton';
import SheetPopup from './SheetPopup';
import WebReviews from './WebReviews';
import ShadowProfileImage from './ShadowProfileImage';

export type RestaurantInfosProps = {
	restaurant: Restaurant
	route: DeliveryRoute | null
	openReviews?: boolean
	showCategories?: boolean
	showOpenNow?: boolean
	style?: ViewStyle
}

export const RestaurantInfos = React.memo((props: RestaurantInfosProps) => {
	const item = props.restaurant
	const section = props.route

	const [reviewsVisible, setReviewsVisible] = useState(false)
	const showReviews = useCallback(() => {
		setReviewsVisible(true)
	}, [])

	const reviewsRequest = useCallback((params: ListParams) => {
		const manager = new RestaurantManager(item.id)
		return manager.getReviewsRestaurant(item.id, params, "all", "1,2,3,4,5")
	}, [])

	const onlyWeb = !((item.reviews_count || 0) > 0)

	const time = React.useMemo(() => props.showOpenNow ? isOpenNow(item) : null, [item])

	const distance = printableDistance(item.distance)
	return (
		<View style={props.style}>
			<Text style={{ fontSize: 18, fontWeight: "bold" }}>{item.name}</Text>

			<Text style={styles.address}>{distance}{distance ? (<> &bull; </>) : ""}{restAddress(item)}</Text>

			{item.foodlist_score ? (
				<ReviewsButton
					onPress={showReviews}
					disabled={!props.openReviews}
					rating={item.foodlist_score}
					reviewsCount={item.total_reviews_count || 0}
				/>
			) : (
				<></>
			)}

			{section && (
				<Text>
					{section.price ? (
						<Text style={{ color: colors.orangeBar }}>{translate(section.take_away ? "service" : "delivery")}: {formatPrice(section?.price, false)}</Text>
					) : (
						<Text style={{ color: colors.darkGreen }}>{translate(section.take_away ? "freeTakeaway" : "freeDelivery")}</Text>
					)}
					{section.min_price ? (
						<Text style={{ color: colors.starColor }}><Text style={{ color: colors.greyIcon }}>&nbsp; &#x2022; &nbsp;</Text>{translate(("minOrder"))}: {formatPrice(section.min_price, false)}</Text>
					) : (<Text></Text>)}
				</Text>
			)}


			{(props.showCategories && (
				item.restaurant_categories_string ? (
					<Text style={styles.categories}>{item.restaurant_categories_string}</Text>
				) : (item.restaurant_categories && item.restaurant_categories.length > 0) ? (
				<Text style={styles.categories}>
					{item.restaurant_categories?.map((cat, index) => {
						return (
							<Text key={cat.id}>{index > 0 ? <Text> &bull; </Text> : ""}{cat.label_it}</Text>
						)
					})}
				</Text>
			) : <></>))}

			{(time && time.open_now != null) && (
				<View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 3 }}>
					<Text style={[styles.greyLabel, { color: time?.open_now ? colors.green : colors.red }]}>{time?.open_now ? translate("openNow", { timeString: time.time_string ?? "" }) : time.time_string}</Text>
					<View style={{ width: 8, height: 8, borderRadius: 4, marginLeft: 8 }} />
				</View>
			)}

			{reviewsVisible && (
				<SheetPopup
					visible={true}
					actions={{
						onTapOutside: () => setReviewsVisible(false)
					}}
					enablePanning
					fitContent={onlyWeb}
				>
					<View style={{ flex: onlyWeb ? 0 : 1, paddingVertical: onlyWeb ? 10 : 0 }}>
						<WebReviews restaurant={item} reviewsOnly />
						{!onlyWeb ? (
							<>
								<Line />
								<LoadMoreList
									contentContainerStyle={styles.list}
									request={reviewsRequest}
									bottomSheet
									renderItem={({ item }) => {
										return (
											<ReviewCell
												review={item}
											/>
										)
									}}
								/>
							</>
						) : <></>}
					</View>
				</SheetPopup>
			)}
		</View>
	)
})

const RestaurantHeader = React.memo((props: RestaurantInfosProps) => {
	const { restaurant, route } = props
	return (
		<View>
			<View style={styles.header}>
				<ShadowProfileImage item={restaurant} type="restaurant" />
				<View style={{ marginLeft: margins.pagePadding, flex: 1 }}>
					<RestaurantInfos
						route={route}
						restaurant={restaurant}
					/>
				</View>
			</View>

		</View>
	);
});

const styles = StyleSheet.create({
	header: {
		padding: margins.pagePadding,
		flexDirection: "row",
		alignItems: "center"
	},
	address: {
		flex: 1,
		color: colors.darkGreyText,
		fontSize: 13,
		marginBottom: 4,
	},
	row: {
		flexDirection: "row",
		alignItems: "center"
	},
	list: {
		backgroundColor: colors.greyBackground,
		flexGrow: 1,
		paddingVertical: margins.pagePadding / 2
	},
	greyLabel: {
		fontSize: 10,
		fontWeight: "bold",
		color: colors.darkGreyText,
		justifyContent: 'center',
		fontStyle: "normal",
		letterSpacing: 0
	},
	categories: {
		fontSize: 12,
		marginTop: 3,
		color: colors.darkGreyText,
	},
});

export default RestaurantHeader;
