import { dateWithTime, getMomentTime, HOUR_FORMAT, momentIsToday, SERVER_DATETIME_FORMAT } from '@FoodListCommon/DateManager';
import { addAsSoonAsPossible, getTimeOptionsFromDisplayable } from '@FoodListCommon/orders';
import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import { MaterialIcon } from '@FoodListCore/Iconfont/FoodListIconfont';
import { BottomSheetSectionList } from './SheetPopup';
import { DisplayableDeliveryDay } from '@Models/DeliveryRoute';
import { OrderInfo } from '@Models/OrderInfo';
import { printTimeRange, TimeRange } from '@Models/TimeRange';
import moment from 'moment';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Platform, StyleSheet, Text, View, ViewStyle } from 'react-native';
import FLIcon from './FLIcon';
import Line from './Line';
import SheetPopup from './SheetPopup';
import TimeIcon from './TimeIcon';
import { TouchableRipple } from './TouchableRipple';
import { useNavigation } from '@react-navigation/native';

export interface SelectTimeActions {

}

type Props = {
	order: OrderInfo
	availableDays: DisplayableDeliveryDay[]
	style?: ViewStyle
	customPress?: () => void
	hideLines?: boolean
	//onTimeSelected: (range: TimeRange) => void
}

const isWeb = Platform.OS == "web"
export type SelectTimeOptions = {
	title: string | undefined
	day: DisplayableDeliveryDay,
	data: TimeRange[]
}
export const SelectTimeContent = React.memo((props: { options: SelectTimeOptions[], onItemSelected: (time: TimeRange, day: DisplayableDeliveryDay) => void}) => {
	const { options, onItemSelected } = props
	return (
		<View style={{ flex: 1 }}>
			{!isWeb && (
				<>
					<Text style={styles.title}>{translate("selectTime")}</Text>
					<Line />
				</>
			)}
			{/* <BottomSheetFlatList
				data={options}
				keyExtractor={item => item.start}
				renderItem={({ item }) => {
					const time = item
					return (
						<React.Fragment key={time.start}>
							<TouchableRipple
								onPress={() => onItemSelected(time)}
								style={{ paddingHorizontal: margins.pagePadding, paddingVertical: 10, flexDirection: "row" }}
								fixAndroidModals
							>
								<TimeIcon size={18} color={colors.greyIcon} time={moment(time.start, HOUR_FORMAT)} outline />
								<Text style={{ fontWeight: "bold", fontSize: 16, marginLeft: 10 }}>{printTimeRange(time)}</Text>
							</TouchableRipple>
							<Line />
						</React.Fragment>
					)
				}}
			/> */}
			<BottomSheetSectionList
				sections={options}
				data={options}
				stickySectionHeadersEnabled
				renderSectionHeader={(info) => {
					if(options.length <= 1) {
						return <></>
					}
					return (
						<View>
							<Text style={styles.sectionHeader}>{info.section.title}</Text>
							<Line />
						</View>
					)
				}}
				keyExtractor={item => item.as_soon_as_possible ? "asap" : item.start}
				renderItem={({ item, section }) => {
					const time = item
					return (
						<>
							<TouchableRipple
								onPress={() => onItemSelected(time, section.day)}
								style={{ paddingHorizontal: margins.pagePadding, paddingVertical: 10, flexDirection: "row" }}
								fixAndroidModals
							>
								<TimeIcon size={18} color={colors.greyIcon} time={moment(time.start, HOUR_FORMAT)} outline />
								<Text style={{ fontWeight: "bold", fontSize: 16, marginLeft: 10 }}>{printTimeRange(time)}</Text>
							</TouchableRipple>
							<Line />
						</>
					)
				}}
			/>
		</View>
	)
})

const SelectTime = React.memo((props: Props) => {
	const [modalVisible, setModalVisible] = useState(false)

	const { order, availableDays } = props
	const isTakeaway = order.delivery.isTakeaway

	const { options, firstAvailable } = useMemo(() => {
		const items = availableDays.map(day => {
			return {
				title: day.name,
				day,
				data: addAsSoonAsPossible(day, getTimeOptionsFromDisplayable(day))
			}
		}).filter(item => item.data.length > 0)
		return {
			options: items,
			firstAvailable: items[0]?.data?.[0]
		}
	}, [order, availableDays])

	const navigation = useNavigation()

	const [selectedTime, setSelectedTime] = useState<TimeRange | null>(order.hour || firstAvailable)
	const [timeUpdated, setTimeUpdated] = useState(false)

	const onItemSelected = useCallback((item: TimeRange, day: DisplayableDeliveryDay) => {
		setModalVisible(false)
		setSelectedTime(item)
		setTimeUpdated(false)
		order.hour = item
		order.day = day

		navigation?.setParams({
			for_date: item.as_soon_as_possible ? "asap" : dateWithTime(order.day.date, getMomentTime(item.start)).format(SERVER_DATETIME_FORMAT),
		})
		//props.onTimeSelected?.(item)
	}, [])

	useEffect(() => {
		if(options.length == 0) {
			order.hour = null
		} else if(!order.hour && selectedTime) {
			order.hour = selectedTime
			//props.onTimeSelected?.(selectedTime)
		} else if(options.length > 0 && selectedTime && selectedTime.start < firstAvailable.start) {
			if(!order.hour?.as_soon_as_possible) {
				setTimeUpdated(true)
			}
			order.hour = firstAvailable
			setSelectedTime(firstAvailable)
		}
	}, [])
	useEffect(() => {
		if(order.hour && order.hour != selectedTime) {
			setSelectedTime(order.hour)
			setTimeUpdated(false)
		}
	}, [order.hour])
	const onPress = React.useCallback(() => {
		if(props.customPress) {
			props.customPress?.()
		} else {
			setModalVisible(true)
		}
	}, [props.customPress])
	return (
		<>
			<View style={props.style}>
				{!props.hideLines && <Line />}
				<TouchableRipple style={styles.row} onPress={onPress}>
					<View style={styles.textContainer}>
						{options.length == 0 ? (
							<Text style={[styles.text, { color: colors.red }]}>Nessun orario disponibile</Text>
						) : (
							<>
							<Text style={[styles.text, { marginBottom: 1 }]}>{order.day.weekday}</Text>
							<View style={{ flexDirection: "row", alignItems: "center" }}>
								<Text style={[styles.text, { color: colors.blueMenu, fontSize: 16, marginRight: 5 }]}>{printTimeRange(selectedTime)}</Text>
								{!selectedTime?.as_soon_as_possible && (
									<TimeIcon size={16} color={colors.greyIcon} outline time={moment(selectedTime?.start, HOUR_FORMAT)} />
								)}
							</View>

							<View style={{ marginTop: 5  }}>
								<View style={styles.flexRow}>
									<MaterialIcon name={isTakeaway ? "storefront" : "delivery-dining"} size={18} color={colors.foodlist} />
									<Text style={{ marginLeft: 5 }}>{isTakeaway ? translate("take_away") : translate("delivery")}</Text>
								</View>
								<Text style={{ fontSize: 12 }}><Text style={{ fontWeight: "bold", fontSize: 14 }}>{order.delivery.name}{order.delivery.description ? " " : ""}</Text> {order.delivery.description}</Text>
								{timeUpdated && (
									<Text style={{ color: colors.orangeBar, fontSize: 12 }}>Abbiamo aggiornato l'orario di {order.delivery.isTakeaway ? "ritiro" : "consegna"} perchè quello selezionato non era più disponibile</Text>
								)}
							</View>
							</>
						)}
					</View>
					<View style={styles.flexRow}>
						<Text style={{ color: colors.blueMenu, fontWeight: "bold", marginRight: 4 }}>{translate("change")}</Text>
						<FLIcon materialCommunityIcon={props.customPress ? "pencil" : "progress-clock"} color={colors.blueMenu} size={15} />
					</View>
				</TouchableRipple>
				{!props.hideLines && <Line />}
			</View>
			{modalVisible && (
				<SheetPopup
					visible={modalVisible}
					actions={{
						onTapOutside: () => setModalVisible(false)
					}}
					enablePanning
					headerText={translate("selectTime")}
				>
					<SelectTimeContent
						options={options}
						onItemSelected={onItemSelected}
					/>
				</SheetPopup>
			)}
		</>
	);
});

const styles = StyleSheet.create({
	flexRow: {
		flexDirection: "row",
		alignItems: "center",
	},
	row: {
		flexDirection: "row",
		alignItems: "center",
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 7,
		backgroundColor: colors.white
	},
	textContainer: {
		flex: 1,
		marginRight: 10,
	},
	text: {
		fontWeight: "bold",
		fontSize: 15,
	},
	sectionHeader: {
		backgroundColor: colors.greyBackground,
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 5,
		textAlign: "center",
		fontWeight: "bold"
	},
	title: {
		textAlign: "center",
		fontWeight: "bold",
		fontSize: 18,
		padding: margins.pagePadding,
	},
});

export default SelectTime;
