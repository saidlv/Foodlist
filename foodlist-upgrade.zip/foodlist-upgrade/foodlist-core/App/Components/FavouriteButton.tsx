import React, { useCallback, useState } from 'react';
import { View, Text, ViewStyle } from 'react-native';
import { colors, alert, error } from '@FoodListCore/Global/GlobalProps';
import FavouritesManager from "@FoodListCore/Network/FavouritesManager"
import { NavigationProp, useNavigation } from '@react-navigation/native';
import requestAuth from '@FoodListCore/Flows/RequestAuth';
import { Restaurant } from '@Models/Restaurant';
import { Dish } from '@Models/Dish';
import { translate } from '@FoodListCore/I18n';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import BigButton from './BigButton/BigButton';

type FavouriteButtonProps = {
	style?: ViewStyle
	item: Restaurant | Dish
	isDish?: boolean
}

export const changeFavouriteValue = ({ item, isDish, navigation, setFavourite, setLoading }: {
	item: Restaurant | Dish,
	isDish: boolean,
	navigation: NavigationProp<any>,
	setFavourite: (isFavourite: boolean) => void
	setLoading: (loading: boolean) => void
}) => {
	if(!requestAuth(navigation)) return
	if (!item?.id) return
	setLoading(true)
	const newValue = !item.is_favourite
	const isRestaurant = !isDish
	const manager = new FavouritesManager()
	manager.handleFavourite(isRestaurant, item.id, newValue).then((response) => {
		if (response.success && item) {
			item.is_favourite = newValue
			setFavourite(newValue)
			setLoading(false)
		} else {
			const err = response.error || ""
			if(err.includes("must be unique")) {
				alert(translate(isRestaurant ? "restaurantAlreadyFavouriteError" : "dishAlreadyFavouriteError"), "")
				item.is_favourite = true
				setFavourite(true)
			} else if(err.includes("Favourite not found")) {
				alert(translate(isRestaurant ? "restaurantAlreadyNotFavouriteError" : "dishAlreadyNotFavouriteError"), "")
				item.is_favourite = false
				setFavourite(false)
			} else {
				throw new Error(response.error);
			}
		}
	}).catch(error).finally(() => {
		setLoading(false)
	});
}

export const FavouriteButton = React.memo((props: FavouriteButtonProps) => {
	const { item } = props
	const navigation = useNavigation()
	const [isFavourite, setFavourite] = useState(item.is_favourite)
	const [loading, setLoading] = useState(false)
	const onPress = useCallback(() => {
		return changeFavouriteValue({
			item,
			isDish: props.isDish || false,
			navigation,
			setFavourite,
			setLoading,
		})
	}, [])
	return (
		<BigButton style={props.style}
			onPress={onPress}
			loading={loading}
			color={isFavourite ? colors.white : colors.blueMenu}
			textColor={isFavourite ? colors.red : colors.white}
		>
			<Text><Icon name={isFavourite ? "heart" : "heart-o"} />&nbsp; {isFavourite ? translate("alreadyFavourite") : translate("addFavourite")}</Text>
		</BigButton>
	)
})

export default FavouriteButton;
