import FLIcon from "@FoodListCore/Components/FLIcon"
import FLLink from "@FoodListCore/Components/FLLink"
import Line from "@FoodListCore/Components/Line"
import { colors, spacing } from "@FoodListCore/Global/Constants"
import { margins, resetNavigation } from "@FoodListCore/Global/GlobalProps"
import { webStyles } from "@FoodListCore/Global/WebHelpers"
import { translate } from "@FoodListCore/I18n"
import { MaterialIconName } from "@FoodListCore/Iconfont/FoodListIconfont"
import { NetworkNavigation } from "@FoodListCore/Network/NetworkManager"
import SessionManager from "@FoodListCore/Services/SessionManager"
import React from "react"
import { Platform, StyleSheet, Text, TouchableWithoutFeedback, useWindowDimensions, View } from "react-native"
import { TouchableOpacity } from "../TouchableFixed"

type PageKey = "profile" | "orders" | "addresses" | "bookings" | "payments"
const menuOptions: { key: PageKey, label: string, materialIcon: MaterialIconName, destination: string }[] = [{
	key: "profile",
	label: "Profilo",
	materialIcon: "people",
	destination: "/profile",
}, {
	key: "orders",
	label: "Ordini",
	materialIcon: "shopping-bag",
	destination: "/my-orders",
}, {
	key: "bookings",
	label: "Prenotazioni",
	materialIcon: "book-online",
	destination: "/my-bookings",
}, {
	key: "addresses",
	label: "Indirizzi",
	materialIcon: "location-pin",
	destination: "/my-addresses",
}, {
	key: "payments",
	label: "Metodi di pagamento",
	materialIcon: "payments",
	destination: "/payment-methods",
}]

type Props = {
	activePage: PageKey
}
const UserMenu = React.memo(({ activePage }: Props) => {
	const logout = React.useCallback(() => {
		SessionManager.logout()
		if(NetworkNavigation.navigation) {
			resetNavigation(NetworkNavigation.navigation, "Home")
		}
	}, [])
	return (
		<View style={styles.container}>
			<View style={styles.box}>
			{menuOptions.map((menu, index) => {
				return (
					<React.Fragment key={menu.key}>
						{index > 0 && <Line />}
						<FLLink to={menu.destination} style={[styles.linkStyle, activePage == menu.key ? styles.selectedStyle : null]}>
							<FLIcon materialIcon={menu.materialIcon} size={20} color={colors.greyIcon} />
							<Text style={styles.label}>{menu.label}</Text>
						</FLLink>
					</React.Fragment>
				)
			})}
			</View>
			<View style={styles.box}>
				<TouchableOpacity onPress={logout}>
					<View style={styles.linkStyle}>
						<FLIcon materialIcon="logout" size={20} color={colors.greyIcon} />
						<Text style={styles.label}>{translate("logout")}</Text>
					</View>
				</TouchableOpacity>
			</View>
		</View>
	)
})

export const UserPageWrapper = React.memo(({ children, ...props}: Props & { children: React.ReactNode}) => {
	const	showSideMenu = useWindowDimensions().width >= 600

	if(Platform.OS != "web" || !showSideMenu) {
		return (<View style={styles.background}>{children}</View>)
	}
	return (
		<View style={styles.background}>
			<View style={[webStyles.listMaxWidth, styles.wrapper]}>
				<UserMenu {...props} />
				<View style={styles.children}>
					{children}
				</View>
			</View>
		</View>
	)
})

const styles = StyleSheet.create({
	background: {
		flex: 1,
		backgroundColor: colors.greyBackground,
	},
	wrapper: {
		flex: 1,
		flexDirection: "row",
		alignItems: "stretch",
	},
	children: {
		flex: 1,
	},
	container: {
		marginVertical: margins.pagePadding * 2,
		marginHorizontal: margins.pagePadding,
		minWidth: 200,
	},
	linkStyle: {
		display: "flex",
		flexDirection: "row",
		alignItems: "center",
		paddingHorizontal: margins.pagePadding,
		paddingVertical: margins.vertical,
		/* marginVertical: 5,
		borderColor: colors.greyBorder,
		borderWidth: spacing.hairlineWidth,
		borderRadius: 8, */
	},
	box: {
		width: "100%",
		borderRadius: 8,
		overflow: "hidden",
		marginVertical: 5,
		backgroundColor: colors.white,
		borderColor: colors.greyBorder,
		borderWidth: spacing.hairlineWidth,
	},
	selectedStyle: {
		backgroundColor: colors.lighterGrey,
	},
	label: {
		marginLeft: 10,
		alignSelf: "center",
	},
})

export default UserMenu
