import React from 'react';
import { State } from './';
import { colors, userImage, margins } from '@FoodListCore/Global/GlobalProps';
import { StyleSheet, View, Text, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { User } from '@Models/User';
import { translate } from '@FoodListCore/I18n';
import SideBarButton from '@FoodListCore/Components/SideBarButton';
import { StaticData } from '@FoodListCore/Network/StaticData';
import Line from '../Line';
import FLImage from '../FLImage';
import CustomConfig from '@config/custom';

export interface SideBarViewActions {
	onLoginPress: () => void
	onChangeRestaurantPress: () => void
	onTosPress: () => void
	onPrivacyPress: () => void
	onPartnerTosPress: () => void
}

type Props = {
	currentUser: User | undefined,

	actions: SideBarViewActions
	state: Readonly<State>
	navigation: any
}

const isLogged = (user: User | undefined) => {
	return !!user
}

const SideBarView = (props: Readonly<Props>) => {
	const { state, actions, currentUser } = props
	return (
		<SafeAreaView style={styles.background}>
			<ScrollView style={styles.scrollView}>

				{isLogged(props.currentUser) &&
					<View style={{ alignSelf: 'center', alignItems: 'center', marginBottom: 25, marginHorizontal: margins.pagePadding }}>
						<FLImage style={styles.profilePicture} source={userImage(props.currentUser?.photo)} />
						<Text style={{ fontSize: 18, fontWeight: 'bold' }}>
							{props.currentUser?.first_name ? (props.currentUser?.first_name || "") + " " + (props.currentUser?.last_name || "") : ""}
						</Text>
					</View>
				}

				<View style={styles.buttonsContainer}>
					<Line />
					{(StaticData.restaurants.length > 1) &&
						<SideBarButton 
							label={translate("changeRestaurant")} 
							actions={{ onPress: props.actions.onChangeRestaurantPress }} />
					}

					{CustomConfig.customSideBarButtons && CustomConfig.customSideBarButtons(props.navigation)}

					<SideBarButton 
						label={isLogged(currentUser) ? translate("logout") : translate('login')} 
						actions={{ onPress: props.actions.onLoginPress }} />

					{!!CustomConfig.isManagerApp && (
						<SideBarButton
							label={translate("partnerTos")}
							actions={{ onPress: props.actions.onPartnerTosPress }}
						/>
					)}

					<SideBarButton 
						label={translate('tos')} 
						actions={{ onPress: props.actions.onTosPress }} />

					<SideBarButton 
						label={translate('privacyPolicy')} 
						actions={{ onPress: props.actions.onPrivacyPress }} />

				</View>
			</ScrollView>
		</SafeAreaView>
	);
};

const styles = StyleSheet.create({
	background: {
		flex: 1,
		backgroundColor: "#fcfcfc",
		borderColor: colors.greyBorder,
		borderRightWidth: 1
	},
	scrollView: {
		flex: 1
	},
	contentScrollView: {
		flex: 1
	},
	profilePicture: {
		height: 100,
		width: 100,
		borderRadius: 5,
		marginTop: 40,
		marginBottom: 10,
		borderColor: colors.greyBorder,
		borderWidth: 1
	},
	buttonsContainer: {
		marginTop: 20
	}
});

export default SideBarView;
