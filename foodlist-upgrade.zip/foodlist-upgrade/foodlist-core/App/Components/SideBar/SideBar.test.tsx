import React from 'react';
import 'react-native';
import SideBarView from './view';

import renderer from 'react-test-renderer';

it('renders SideBarView view', () => {
	//expect(renderer.create(<SideBarView />)).toMatchSnapshot(); //TODO: add SideBarView props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<SideBarView pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<SideBarView pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
