import React from 'react';
import SideBarView, { SideBarViewActions } from './view';
import { Pluto } from '@Models/Pluto';
import { connect } from 'react-redux';
import { ReduxState } from '@FoodListCore/Redux/StateFormat';
import { User } from '@Models/User';
import { AuthParamList } from '@FoodListCore/RouteParams/Auth';
import SessionManager from '@FoodListCore/Services/SessionManager';
import { StackNavigationProp } from '@react-navigation/stack';
import { Linking } from 'react-native';
import { termsLink, privacyLink, resetNavigation, partnerTermsLink } from '@FoodListCore/Global/GlobalProps';

const reduxMap = (state: ReduxState) => ({
	currentUser: state.currentUser
})

type Props = ReturnType<typeof reduxMap> & {
	navigation: Pluto
	loginPage?: keyof AuthParamList
	onLogout?: () => void | Promise<void>
}

export type State = {

}

class SideBar extends React.PureComponent<Props, State> {
	constructor(props: Props) {
		super(props)
		this.state = {
		
		}
	}

	isLogged = () => {
		return !!this.props.currentUser
	}

	reset = (routeName: keyof AuthParamList) => {
		resetNavigation(this.props.navigation, routeName)
	}

	actions: SideBarViewActions = {
		onLoginPress: async () => {
			if(this.props.onLogout) {
				await this.props.onLogout?.()
			} else {
				SessionManager.logout()
			}
			this.reset(this.props.loginPage || "LoginPage")
		},
		onChangeRestaurantPress: () => {
			this.reset("SelectRestaurant")
		},
		onTosPress: () => {
			Linking.openURL(termsLink)
		},
		onPrivacyPress: () => {
			Linking.openURL(privacyLink)
		},
		onPartnerTosPress: () => {
			Linking.openURL(partnerTermsLink)
		}
	};

	render() {
		return (
			<SideBarView
				actions={this.actions}
				state={this.state}
				navigation={this.props.navigation}
				currentUser={this.props.currentUser}
			/>
		);
	}
}

export default connect(reduxMap)(SideBar);
