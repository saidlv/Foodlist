import React, { useCallback, useMemo, useRef } from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import FLImage from './FLImage';
import { colors, imageFood, imageRestaurant, userImage } from '@FoodListCore/Global/GlobalProps';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { Restaurant } from '@Models/Restaurant';
import { User } from '@Models/User';
import { Dish } from '@Models/Dish';

type Props = {
	item: Restaurant | Dish | User | null | undefined
	type: "restaurant" | "dish" | "user"
	disableFullscreen?: boolean
	/**
	 * @default 80
	 */
	size?: number
}

const ShadowProfileImage = React.memo((props: Props) => {
	const [image, fullImage] = useMemo(() => {
		if(!props.item) return [null, null]
		if(props.type == "restaurant") {
			const item = props.item as unknown as Restaurant
			return [imageRestaurant(item, true), imageRestaurant(item, false)]
		} else if(props.type == "dish") {
			const item = props.item as unknown as Dish
			return [imageFood(item, true), imageFood(item, false)]
		} else {
			const item = props.item as unknown as User
			return [userImage(item.photo, true), userImage(item.photo, false)]
		}
	}, [props.item])

	const imageStyle = useMemo(() => {
		const size = props.size || 80
		return StyleSheet.flatten([styles.image, { width: size, height: size }])
	}, [props.size])
 	return (
		<>
			<View style={Platform.OS == "ios" ? CommonStyle.shadow : {}}>
				<View style={[imageStyle, Platform.OS != "ios" ? CommonStyle.shadow : {}]}>
					<FLImage
						style={imageStyle}
						source={image}
						fullImage={fullImage}
						openFullscreen={!props.disableFullscreen}
					/>
				</View>
			</View>
		</>
	);
});

const styles = StyleSheet.create({
	image: {
		borderRadius: 10,
		backgroundColor: colors.greyBackground,
		overflow: "hidden"
	}
});

export default ShadowProfileImage;
