import ActionSheet from '@alessiocancian/react-native-actionsheet';
import { I18nKey } from '@FoodListCommon/Translations';
import { colors } from '@FoodListCore/Global/Constants';
import { translate } from '@FoodListCore/I18n';
import { ImageForMultipart } from '@Models/ImageForMultipart';
import React, { useCallback, useMemo, useState } from 'react';
import { useRef } from 'react';
import { StyleSheet } from 'react-native';
import SmallButton from './SmallButton';
import { launchCamera, launchImageLibrary, ImagePickerResponse, ImageLibraryOptions } from 'react-native-image-picker';
import LightButton from './LightButton';
import { showError } from '@FoodListCore/Global/GlobalProps';
import ImageResizer from 'react-native-image-resizer';

type Props = {
	onImagePicked: (image: ImageForMultipart | null) => void
}
/**
 * This works using react-native-image-picker v4.x.x
 */

const optionKeys: I18nKey[] = ["camera", "library", "cancel"]

const NewImagePicker = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	const self = useMemo(() => ({
		options: {
			mediaType: "photo",
		} as ImageLibraryOptions,
	}), [])

	const actionSheet = useRef<ActionSheet>(null)
	const onPress = useCallback(() => {
		actionSheet.current?.show()
	}, [])
	const imagePicked = useCallback((res: ImagePickerResponse) => {
		if(res.errorMessage) {
			showError(res.errorMessage)
			return
		}
		if(res.didCancel) {
			showError("Cancelled")
			return
		}
		console.log(res)
		const image = res.assets?.[0]
		const uri = image?.uri
		if(image && uri) {
			ImageResizer.createResizedImage(uri, 1200, 1200, "JPEG", 50, 0, undefined, true).then((res) => {
				props.onImagePicked({
					...res,
					fileName: res.name,
					type: "image/jpg",
				})
			}).catch(showError)
		}
	}, [props.onImagePicked])

	return (
		<>
			<LightButton
				materialIcon="add-a-photo"
				onPress={onPress}
			>{translate("uploadPhoto")}</LightButton>

			<ActionSheet
				ref={actionSheet}
				options={optionKeys.map(key => translate(key))}
				cancelButtonIndex={optionKeys.length - 1}
				onPress={useCallback((index) => {
					if(index == 0) {
						launchCamera(self.options, imagePicked)
					} else if(index == 1) {
						launchImageLibrary(self.options, imagePicked)
					}
				}, [imagePicked])}
			/>
		</>
	);
});

const styles = StyleSheet.create({

});

export default NewImagePicker;
