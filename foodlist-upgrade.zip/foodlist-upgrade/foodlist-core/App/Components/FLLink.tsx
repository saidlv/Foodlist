import { fixLinkingPath } from '@FoodListCore/Global/WebHelpers';
import { resolveHref } from '@FoodListCommon/utils';
import { Link, NavigationAction, useLinkProps, useNavigation } from '@react-navigation/native';
import React from 'react';
import { GestureResponderEvent, Platform, TextProps } from 'react-native';
import { TouchableRipple } from './TouchableRipple';
import { useCallback } from 'react';

type LinkProps = { //copied from @react-navigation/native/lib/typescript/Link.d.ts
	to: string;
	action: NavigationAction;
	target?: string;
	onPress?: (e: React.MouseEvent<HTMLAnchorElement, MouseEvent> | GestureResponderEvent) => void;
} & (TextProps & {
	children: React.ReactNode;
});

/**
 * Wrapper for react-navigation Link component to apply the base_url to the provided path
 */
const FLLink = ({ to, ...props }: LinkProps) => {
	const navigation = useNavigation()
	const onPress = useCallback(() => {
		navigation.dispatch(props.action)
	}, [navigation])

	if(Platform.OS != "web") {
		return (
			<TouchableRipple onPress={onPress} style={props.style} borderless>
				{props.children}
			</TouchableRipple>
		)
	}
	return (
		<Link
			to={resolveHref("/", fixLinkingPath(to))}
			{...props}
		/>
	);
}

export const useFLLinkProps = (to: string, action?: NavigationAction) => {
	return useLinkProps({
		to: resolveHref("/", fixLinkingPath(to)),
		action,
	})
}

export default FLLink;
