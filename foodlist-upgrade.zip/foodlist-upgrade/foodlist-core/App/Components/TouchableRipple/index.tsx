import React, { ReactChildren, ReactNode } from 'react';
import { debounce } from "underscore"
import { RectButton } from "react-native-gesture-handler";
import { Platform } from 'react-native';
import { TouchableRipple as _TouchableRipple } from "react-native-paper";

type Props = Omit<React.ComponentProps<typeof _TouchableRipple>, "touchSoundDisabled"> & {
	children?: ReactNode,
	disabled?: boolean, 
	/**
	 * @deprecated this is now the default option, use fixAndroidModals if you need to use react-native-gesture-handler in Android (to fix bottom-sheet)
	 */
	alwaysPaper?: boolean,
	fixAndroidModals?: boolean
}

export const TouchableRipple = function(props: Props) {
	const onPress = debounce((props.onPress || (() => {})), 500, true)
	return (props.fixAndroidModals && Platform.OS == "android" && !props.alwaysPaper) ? (
		<RectButton
			{...props}
			enabled={!props.disabled}
			children={(
				<>
					{props.children}
				</>
			)}
			onPress={(event) => {
				setTimeout(() => {
					onPress(event)
				})
			}}
			rippleColor={props.rippleColor || "rgba(0,0,0,0.1)"}
			underlayColor={props.underlayColor || "rgba(0,0,0,0.5)"}
		/>
	) : (
		<_TouchableRipple
			{...props}
			children={(
				<>
					{props.children}
				</>
			)}
			onPress={(event) => {
				setTimeout(() => {
					onPress(event)
				})
			}}
			rippleColor={props.rippleColor || "rgba(0,0,0,0.1)"}
			underlayColor={props.underlayColor || "rgba(0,0,0,0.1)"}
		/>
	)
}

export const AbsoluteRipple = (props: Omit<Props, "children">) => {
	return (
		<TouchableRipple
			alwaysPaper
			style={{ position: "absolute", width: "100%", height: "100%" }}
			{...props}
		/>
	)
}