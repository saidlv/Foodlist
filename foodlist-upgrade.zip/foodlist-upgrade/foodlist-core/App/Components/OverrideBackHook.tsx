import { useNavigation } from '@react-navigation/core';
import { useFocusEffect } from '@react-navigation/native';
import { HeaderBackButton, StackNavigationProp } from '@react-navigation/stack';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { BackHandler } from 'react-native';

const useOverrideBackPress = (
	/**
	 * return true to prevent default action
	 */
	handleBackPress: () => boolean | null,
	/**
	 * uses 'useNavigation' if not provided
	 */
	navProp?: StackNavigationProp<any>
) => {
	const navigation = navProp || useNavigation()
	
	useFocusEffect(React.useCallback(() => {
		BackHandler.addEventListener("hardwareBackPress", handleBackPress)
		return () => {
			BackHandler.removeEventListener("hardwareBackPress", handleBackPress)
		}
	}, []))

	useEffect(() => {
		navigation.setOptions({
			headerLeft: (props) => <HeaderBackButton {...props} onPress={handleBackPress} />,
			gestureEnabled: false,
		})
	}, [])
}

export default useOverrideBackPress;
