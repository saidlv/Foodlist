import colors from '@FoodListCommon/colors';
import { I18nKey } from '@FoodListCommon/Translations';
import { translate } from '@FoodListCore/I18n';
import React, { useCallback, useMemo, useState } from 'react';
import { TextStyle } from 'react-native';
import { StyleSheet, Text } from 'react-native';

export type Mode = "quality" | "price" | "quality_male"

type Props = {
	rating: number
	style?: TextStyle
	mode?: Mode
}

const getColor = (rating: number) => {
	switch(rating) {
		case 1: return colors.red
		case 2: return colors.orangeBar
		case 3: return colors.yellow
		case 4: return colors.green
		case 5: return colors.darkGreen
		default: return colors.greyText
	}
}

const getQualityMale = (rating: number): I18nKey => {
	switch(rating) {
		case 1: return "terrible"
		case 2: return "decent"
		case 3: return "good"
		case 4: return "veryGood"
		case 5: return "excellent"
		default: return "selectValue"
	}
}

const getQualityFemale = (rating: number): I18nKey => {
	switch(rating) {
		case 1: return "terrible_f"
		case 2: return "decent_f"
		case 3: return "good_f"
		case 4: return "veryGood_f"
		case 5: return "excellent_f"
		default: return "selectValue"
	}
}

const getPriceText = (rating: number): I18nKey => {
	switch(rating) {
		case 1: return "veryExpensive"
		case 2: return "expensive"
		case 3: return "good"
		case 4: return "veryGood"
		case 5: return "excellent"
		default: return "selectValue"
	}
}

const getTextKey = (rating: number, mode: Mode | undefined) => {
	if(mode == "price") {
		return getPriceText(rating)
	}
	if(mode == "quality_male") {
		return getQualityMale(rating)
	}
	return getQualityFemale(rating)
}

const RatingText = React.memo(({ rating, style, mode }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<Text style={[{ color: getColor(rating), fontWeight: "bold" }, style]}>
			{translate(getTextKey(rating, mode))}
		</Text>
	);
});

const styles = StyleSheet.create({
});

export default RatingText;
