import React from 'react';
import { colors, themeColors, margins, imageFood } from '@FoodListCore/Global/GlobalProps';
import { getOrderItemPrice, getOrderRowPrice, getOrderItemPriceWithoutDiscount, getOrderRowPriceWithoutDiscount } from "@FoodListCommon/prices";
import { StyleSheet, View, Text } from 'react-native';
import { OrderItem } from '@Models/OrderItem';
import { translate } from '@FoodListCore/I18n';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import FLImage from '../FLImage';
import { OrderRow } from '@Models/OrderRow';
import { groupByKey } from '@Models/ItemsMap';
import DishPrice from '../Discount/Price';
import { OrderInfo } from '@Models/OrderInfo';
import { isItemOrderable } from '@FoodListCommon/orders';
import AddRemoveRow, { AddRemoveRowActions } from '../AddRemoveRow';
import { sendCartUpdate } from '@FoodListCore/Redux/ReduxHelper';

export interface OrderSummaryCellActions {
	remove: (item: OrderItem) => void
	/* increment: (item: OrderItem) => void
	decrement: (item: OrderItem) => void */
	edit: (item: OrderItem) => void
}

type Props = {
	actions: OrderSummaryCellActions
	order: OrderInfo
	item: OrderItem & {
		price?: number
	}
	hideButtons?: false
} | {
	hideButtons: true
	item: OrderRow
}

function OrderSummaryCell (props: Props) { //not pure component to update when order edited
	const grouped = "user_options" in props.item ? groupByKey(props.item.user_options ?? [], "option_label") : null
	const { item } = props
	const orderable = (props.hideButtons || !item.dish) ? [true, null] : (item.dish.purchasable && isItemOrderable(item.dish, props.order.day.date))

	const actions: AddRemoveRowActions = React.useMemo(() => {
		return {
			onAddPressed: () => {
				item.quantity++
				sendCartUpdate()
			},
			onRemovePressed: () => {
				if(item.quantity > 1) {
					item.quantity--
					sendCartUpdate()
				} else if(!props.hideButtons) {
					props.actions.remove(props.item)
				}
			},
			onDeleteAllPressed: () => {
				if(!props.hideButtons) {
					props.actions.remove(props.item)
				}
			},
			onConfigurePressed: () => {
				//qua non dovrebbe mai essere chiamato
				console.warn("Configure button should not be shown here")
			},
			onEditPressed: () => {
				if(!props.hideButtons) {
					props.actions.edit(props.item)
				}
			}
		}
	}, [])

	const finalPrice = props.hideButtons ? getOrderRowPrice(props.item) : getOrderItemPrice(props.item, props.item.quantity, props.order)

	return (
		<View style={styles.dishView}>
			<View style={styles.row}>
				{/* <View style={styles.imageContainer}>
					<FLImage style={styles.image} source={imageFood(props.item.dish ?? null, true)} />
				</View> */}
				<View style={styles.dataContainer}>
					<View style={styles.inline}>
						<View style={{flex: 1}}>
							<Text style={styles.nameText}>
								{props.hideButtons && <Text style={styles.primaryText}>{props.item.quantity}× &nbsp;</Text>}
								{item.dish_name || item.dish?.name || translate("dishNotFound")}
							</Text>
						</View>
						<Text style={styles.price}>
							{props.hideButtons ? (
								<DishPrice
									initialPrice={getOrderRowPriceWithoutDiscount(props.item)}
									discountedPrice={finalPrice}
								/>
							) : (
								<>
									{/* <DishPrice
										initialPrice={getOrderItemPriceWithoutDiscount(props.item)}
										discountedPrice={finalPrice}
									/> */}
								</>
							)}
						</Text>
					</View>
					{props.item.notes ? (<Text style={styles.notes}>{props.item.notes}</Text>) : undefined}
					{"options" in props.item && (
						<View style={styles.optionsContainer}>
							{(props.item.options || []).map(item => {
								if(item.values.length > 0) {
									return (
										<View key={item.id}>
											<Text style={styles.optionsText}><Text style={{ fontWeight: "700" }}>{item.option_label}:</Text> {item.values.map(val => val.label).join(", ")}</Text>
										</View>
									)
								}
								return <></>
							})}
						</View>
					)}
					{grouped && (
						<View style={styles.optionsContainer}>
							{Object.keys(grouped).map(key => {
								const item = grouped[key] || []
								return (
									<Text key={key} style={styles.optionsText}><Text style={{ fontWeight: "700" }}>{key}:</Text> {item.map(val => val.value_label).join(", ")}</Text>
								)
							})}
						</View>
					)}
				</View>
			</View>
			{!orderable && (
				<Text style={{ color: colors.red }}>{translate("notAvailableForTheSelectedDate")}</Text>
			)}
			{!props.hideButtons && (
				<AddRemoveRow
					actions={actions}
					orderQuantity={item.quantity}
					totalPrice={finalPrice}
				/>
			)}

			{/* 	<View style={styles.buttonsContainer}>
					{orderable && (
					<View style={{flex: 1, marginRight: 5}}>
						
						<View style={styles.btn}>
							<TouchableRipple
								style={styles.btnRipple}
								onPress={() => props.actions.edit(props.item)}
							>
								<Text style={styles.btnText}>{translate("edit").toUpperCase()}</Text>
							</TouchableRipple>
						</View>
					</View>
					)}
					<View style={{flex: 1, marginLeft: orderable ? 5 : 0 }}>
						<View style={styles.btn}>
							<TouchableRipple
								style={[styles.btnRipple]}
								onPress={() => props.actions.remove(props.item)}
							>
								<Text style={styles.btnText}>{translate("remove").toUpperCase()}</Text>
							</TouchableRipple>
						</View>
					</View>
				</View>
			} */}
		</View>
	);
};

const styles = StyleSheet.create({
	imageContainer: {
		paddingRight: 15,
		alignSelf: 'center'
	},
	image: {
		height: 64,
		width: 64,
		borderRadius: 8
	},
	dataContainer: {
		flex: 1,
		flexDirection: "column",
		justifyContent: "center"
	},
	row: {
		flexDirection: "row",
		justifyContent: "center",
		alignItems: "center"
	},
	dishView: {
		backgroundColor: colors.white,
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 10,
		borderTopWidth: 1,
		borderColor: colors.greyBorder
	},
	inline: {
		flexDirection: 'row',
		justifyContent: "space-between"
	},
	nameText: {
		fontWeight: "700",
		fontSize: 16
	},
	primaryText: {
		color: themeColors.primary
	},
	price: {
		marginLeft: 5,
		color: themeColors.priceTint,
		fontWeight: "bold"
	},
	btn: {
		backgroundColor: colors.lightGrey,
		borderRadius: 20,
		overflow: "hidden"
	},
	btnRipple: {
		padding: 4,
		borderRadius: 20,
		paddingHorizontal: 10,
		minHeight: 30,
		justifyContent: "space-between",
		alignItems: "center",
		alignContent: "center",
		borderWidth: 0.5,
		borderColor: colors.darkGreyBorder,
		flexDirection: "row",
	},
	btnText: {
		color: colors.darkGreyText,
		flex: 1,
		textAlign: "center"
	},
	notes: {
		marginTop: 7,
		color: colors.darkGreyText
	},
	buttonsContainer: {
		marginTop: 10,
		flexDirection: 'row'
	},
	optionsText: {
		color: "#666",
		marginTop: 1,
	},
	optionsContainer: {
		marginTop: 2,
	}
});

export default OrderSummaryCell;
