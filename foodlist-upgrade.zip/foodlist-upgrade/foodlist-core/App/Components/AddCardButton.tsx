import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet } from 'react-native';

export interface AddCardButtonActions {

}

type Props = {
	actions: AddCardButtonActions
}

const AddCardButton = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<>
		</>
	);
});

const styles = StyleSheet.create({

});

export default AddCardButton;
