import { colors } from '@FoodListCore/Global/GlobalProps';
import { translateNum } from '@FoodListCore/I18n';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import StarRating from './StarRating';
import { TouchableRipple } from './TouchableRipple';

type Props = {
	onPress: () => void
	disabled?: boolean
	rating: number
	reviewsCount: number
	/**
	 * Change Star and text size
	 * @default medium
	 */
	size?: "small" | "medium"
}

const ReviewsButton = React.memo((props: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<View style={{ flexDirection: "row", marginBottom: 1 }}>
			<TouchableRipple
				borderless
				disabled={props.disabled}
				style={[styles.row, props.disabled ? null : styles.reviewsContainer]}
				onPress={props.onPress}
			>
				<StarRating rating={props.rating} color={colors.starColor} size={props.size == "small" ? 12 : 14} />
				<Text style={[!props.disabled ? styles.reviewsPressableText : styles.reviewsText, props.size == "small" ? { fontSize: 12 } : null]}>{translateNum(props.reviewsCount, "singleReview", "numReviews")}</Text>
			</TouchableRipple>
		</View>
	);
});

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		alignItems: "center"
	},
	reviewsContainer: {
		paddingVertical: 5,
		paddingLeft: 5,
		paddingRight: 10,
		marginHorizontal: -5,
		borderRadius: 5,
		overflow: "hidden"
	},
	reviewsText: {
		marginLeft: 5,
		fontSize: 12,
	},
	reviewsPressableText: {
		marginLeft: 5,
		fontSize: 13,
		color: colors.blueMenu,
		textDecorationLine: "underline",
	},
});

export default ReviewsButton;
