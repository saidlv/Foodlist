import React from 'react';
import { Platform, StyleProp, StyleSheet, View } from 'react-native';
import Carousel from "react-native-banner-carousel-updated"
import FLImage from './FLImage';
import { ViewStyle } from 'react-native';
import { CarouselProps } from 'react-native-banner-carousel-updated/out/Carousel';
import { GalleryModal } from './Gallery/GalleryModal';
import { ImageSource } from '@Models/ImageSource';
import { useCellWidth, usePageWidth } from '@FoodListCore/Global/WebHelpers';

type Props = {
	images: ImageSource[]
	thumbImages?: ImageSource[]
	hideDots?: boolean
	carouselProps?: Partial<Omit<CarouselProps, "children">>
	disableFullscreen?: boolean
	height: number
}
const isWeb = Platform.OS == "web"

const ImageCarousel = React.memo((props: Props) => {
	//const [modalVisible, setModalVisible] = useState(false)
	const self = React.useMemo(() => ({ index: 0 }), [])
	const galleryRef = React.useRef<GalleryModal>(null)

	const onPageChanged = React.useCallback((index) => {
		self.index = index
		props.carouselProps?.onPageChanged?.(index)
	}, [])
	const onPress = React.useCallback(() => {
		const images = props.images.map((source, index) => ({ source: props.thumbImages?.[index] || source, fullSource: source }))
		galleryRef.current?.show(images, self.index)
	}, [props.images])

	const imageWidth = props.disableFullscreen ? useCellWidth() : usePageWidth()

	return (
		<>
			<Carousel
				autoplay
				autoplayTimeout={4000}
				loop
				pageSize={isWeb ? imageWidth : undefined}
				showsPageIndicator={!props.hideDots}
				{...props.carouselProps}
				onPress={!props.disableFullscreen && !isWeb ? onPress : undefined}
				disableUserInteraction={isWeb && props.disableFullscreen}
				changeVerticalScrollEnabled={isWeb ? undefined : props.carouselProps?.changeVerticalScrollEnabled}
				onPageChanged={onPageChanged}
			>
				{props.images.map((image, index) => {
					const thumb = props.thumbImages?.[index]
					//console.log("image", image, thumb)
					return (
						<React.Fragment key={index}>
							<FLImage
								style={{ height: props.height || "100%", width: isWeb ? imageWidth : "100%", }}
								source={thumb ? thumb : image}
								fullImage={thumb ? image : undefined}
								showFull={true}
							/>
						</React.Fragment>
					)
				})}
			</Carousel>
			<GalleryModal
				ref={galleryRef}
			/>
		</>
	);
});

const styles = StyleSheet.create({

});

export default ImageCarousel;
