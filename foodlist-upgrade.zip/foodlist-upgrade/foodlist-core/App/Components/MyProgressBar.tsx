import { colors } from '@FoodListCore/Global/Constants';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';

type Props = {
	/** between from 0 to 1 */
	progress: number
	color: string
	backgroundColor?: string
}

const MyProgressBar = React.memo(({ progress, color, backgroundColor }: Props) => {
	const percentage = Math.min(Math.round(progress * 100), 100)
	return (
		<View style={styles.background}>
			<View style={[styles.progress, { backgroundColor: color, width: percentage + "%" }]} />
		</View>
	);
});

const styles = StyleSheet.create({
	background: {
		backgroundColor: colors.greyBorder,
		borderRadius: 4,
		height: 4,
		width: "100%",
		overflow: "hidden",
	},
	progress: {
		height: 4,
	},
});

export default MyProgressBar;
