import { DATE_FORMAT, getMoment, HUMAN_DATETIME_FORMAT } from '@FoodListCommon/DateManager';
import { printDiscount } from '@FoodListCommon/prices';
import FLIcon from '@FoodListCore/Components/FLIcon';
import FLImage from '@FoodListCore/Components/FLImage';
import { TouchableRipple } from '@FoodListCore/Components/TouchableRipple';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { colors, formatPrice, margins, when } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import { Coupon } from '@Models/Coupon';
import moment from 'moment';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ProgressBar } from 'react-native-paper';

export interface CouponCellActions {

}

type Props = {
	actions?: CouponCellActions
	coupon: Coupon
	onPress: () => void
	userPoints: number
	useCoupon?: boolean
}

const getExpireString = (coupon: Coupon): { expireColor: string, expireText: string} => {
	let text = "Nessuna scadenza"
	let color = colors.darkGreen
	if(coupon.order_id) {
		text = `Utilizzato il ${getMoment(coupon.order?.for_date).format(DATE_FORMAT)}`
		color = colors.blueMenu
	}
	if(coupon.from && moment(coupon.from) > moment()) {
		text = "Utilizza dal " + moment(coupon.from).format(DATE_FORMAT)
		color = colors.orangeBar
	} else if (coupon.to) {
		if(moment(coupon.to) < moment()) {
			text = "Scaduto"
			color = colors.darkRed
		} else {
			text = "Utilizza entro il " + moment(coupon.to).format(DATE_FORMAT)
			color = colors.orangeBar
		}
	}
	return {
		expireText: text.toUpperCase(),
		expireColor: color
	}
}


const CouponCell = React.memo(({ coupon, onPress, userPoints, useCoupon }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	const buttonDisabled = userPoints < coupon.points
	const add = !!coupon.points
	const used = !!coupon.order_id
	const { expireColor, expireText } = getExpireString(coupon)
	return (
		<View style={[styles.coupon, CommonStyle.shadow]}>
			<View style={styles.row}>
				<View style={styles.logo}>
					<FLIcon foodlistIcon="logo-img" color={colors.white} size={24} />
				</View>
				<View style={styles.headerTextContainer}>
					<Text style={{ fontWeight: "bold", fontSize: 18 }}>{coupon.name}</Text>
					<Text style={{ color: expireColor, fontWeight: "bold", fontSize: 12 }}>{expireText}</Text>
				</View>
			</View>
			{!add && (
				<Text style={[styles.valueText, { marginTop: 10, marginBottom: -5 }]}>BUONO {printDiscount(coupon)}</Text>
			)}
			<Text style={{ marginTop: 10 }}>Valido per gli ordini effettuati tramite FoodList{coupon.minimum_required ? <Text>, con una spesa minima di <Text style={styles.bold}>{formatPrice(coupon.minimum_required)}.</Text></Text> : <Text>.</Text>}</Text>
			{(add || !!coupon.by_foodlist) && (
				<Text style={{ fontSize: 13, color: colors.darkGreyText, marginTop: 3 }}>Utilizzabile solo con pagamenti online.</Text>
			)}
			{add && (
				<>
					<View style={[styles.row, { justifyContent: "space-between", marginTop: 10 }]}>
						<Text style={styles.valueText}>BUONO {printDiscount(coupon)}</Text>
						<Text style={[styles.bold, { color: colors.foodlist }]}>{coupon.points} PUNTI</Text>
					</View>
					<ProgressBar
						progress={buttonDisabled ? (userPoints / coupon.points) : 1}
						style={{ borderRadius: 8, marginTop: 5 }}
					/>
				</>
			)}
			{(add || used || useCoupon) && (
				<TouchableRipple
					fixAndroidModals
					style={[styles.button, when(buttonDisabled, { opacity: 0.3 })]}
					onPress={onPress}
					disabled={buttonDisabled}
				>
					<Text style={styles.buttontext}>{translate(add ? "redeemCoupon" :  used ? "orderDetail" : "useCoupon")}</Text>
				</TouchableRipple>
			)}
		</View>
	);
});

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		alignItems: "center",
	},
	logo: {
		backgroundColor: colors.foodlist,
		borderRadius: 100,
		padding: 10,
	},
	headerTextContainer: {
		marginLeft: 10,
		flex: 1,
	},
	coupon: {
		marginHorizontal: margins.pagePadding,
		marginVertical: margins.pagePadding / 2,
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 10,
		borderRadius: 10,
		backgroundColor: colors.white,
	},
	button: {
		backgroundColor: colors.withAlpha(colors.blueMenu, 0.1),
		borderRadius: 10,
		padding: 10,
		alignItems: "center",
		marginTop: 10,
	},
	buttontext: {
		color: colors.blueMenu,
		fontWeight: "bold",
	},
	valueText: {
		fontWeight: "bold",
		color: colors.darkBlue,
		fontSize: 16,
	},
	bold: {
		fontWeight: "bold",
		color: colors.darkBlue
	}
});

export default CouponCell;
