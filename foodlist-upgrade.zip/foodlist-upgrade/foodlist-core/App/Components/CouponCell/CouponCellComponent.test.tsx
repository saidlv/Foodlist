import React from 'react';
import 'react-native';
import CouponCell from './index';

import renderer from 'react-test-renderer';

it('renders CouponCell view', () => {
	//expect(renderer.create(<CouponCell />)).toMatchSnapshot(); //TODO: add CouponCell props with random values

	/*
	//if view displays different outputs when passing different values as props use:

	expect.assertions(2); // increase '2' if you add more assertions

	const first = renderer.create(<CouponCell pippo={true} />).toJSON();
	expect(first).toMatchSnapshot();

	const second = renderer.create(<CouponCell pippo={false} />).toJSON();
	expect(second).toMatchSnapshot();
	*/
});
