import React, { PureComponent } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, ViewStyle, Image, StyleProp } from 'react-native';
import styles from './Styles';
import { TouchableWithoutFeedbackFixed as TouchableWithoutFeedback } from '@FoodListCore/Components/TouchableFixed';
import { when, isDefined, colors, whenElse, margins, themeColors } from '@FoodListCore/Global/GlobalProps'
import commonStyle from '@FoodListCore/Global/CommonStyle';
import InputTitle from './InputTitle';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import CommonTextInput, { TextInputProps } from './CommonTextInput';
import { CountryModel } from '@Models/Country';
import { IconName } from '@FoodListCore/Iconfont/IconName';
import FLImage from '../FLImage';

export type InputContainerActions = {
	onPress?: () => void,
	focusInput?: () => void,
	clear?: () => void,
	getErrorMessage?: (text?: string) => string
}

export type ActionButtonProps = {
	action: string,
	sendingComment: boolean,
	actionEnabled: boolean,
}

export type InputContainerConfig = {
	standalone?: boolean,
	showClear?: boolean,
	showClearIcon?: boolean,
	icon?: IconName,
	customIconSize?: number,
	selectedCountry?: CountryModel,
	facoltative?: boolean,
	necessary?: boolean,
	inputValue?: string,
	inputPrefix?: string

	actionButtonProps?: ActionButtonProps,

	error?: boolean
	isError?: boolean,
	errorMessage?: string,
	messageOnError?: string,
	style?: StyleProp<ViewStyle>
}

export type InputContainerProps = {
	actions: InputContainerActions,
	textInputProps: TextInputProps,
	config: InputContainerConfig,
}


class InputContainer extends PureComponent<InputContainerProps> {

	componentDidMount() {

	}

	render() {
		let noTitle = this.props.textInputProps.title === undefined;

		let icon: Element | null = null
		if (this.props.config.icon) {
			icon = <Icon style={styles.icon} color={themeColors.editTextIcons} size={this.props.config.customIconSize || 16} name={this.props.config.icon} />
		}

		let flag: Element | null = null
		if (this.props.config.selectedCountry) {
			/* const { width, height } = Image.resolveAssetSource(this.props.config.selectedCountry.image)
			const ratio = height / width
			const displayHeight = 24 * ratio */
			flag = <FLImage resizeMode="contain" style={styles.flag} source={this.props.config.selectedCountry?.image} />
		}

		let iconOrFlag = this.props.config.selectedCountry ? flag : icon

		return (
			<TouchableWithoutFeedback
				onPress={() => {
					if (this.props.actions.onPress !== undefined) {
						this.props.actions.onPress()
					} else {
						this.props.actions.focusInput?.()
					}
				}}
			>
				<View style={[styles.container, when(this.props.config.standalone, [styles.rounded, commonStyle.shadow]), when(noTitle, styles.noTitle), this.props.config.style]}>

					<View style={styles.rowContainer}>

						{isDefined(iconOrFlag) &&
							<View style={[styles.iconContainer, when(noTitle, styles.noTitleIcon)]}>
								{iconOrFlag}
							</View>
						}

						{!isDefined(iconOrFlag) &&
							<View style={{ marginLeft: margins.pagePadding }} />
						}

						<View style={[styles.textContainer]}>

							<InputTitle
								title={this.props.textInputProps.title}
								facoltative={this.props.config.facoltative}
								necessary={this.props.config.necessary}
								input={this.props.config.inputValue ?? ""}

								error={this.props.config.error}
								isError={this.props.config.isError}
								errorMessage={this.props.config.errorMessage}
								messageOnError={this.props.config.messageOnError}
								getErrorMessage={this.props.actions.getErrorMessage}
							/>

							<View style={styles.inputBox}>
								{!!this.props.config.inputPrefix && (
									<View style={{ alignItems: 'center', justifyContent: 'center' }}>
									<Text style={{ fontSize: 16 }}>{this.props.config.inputPrefix}</Text>
								</View>
								)}
								<CommonTextInput {...this.props.textInputProps} />

								{/** Gestisce i prezzi */}
								{this.props.textInputProps.price && (
									<View style={{ height: 26, alignSelf: 'flex-start', alignItems: 'center', justifyContent: 'center' }}>
										<Text style={{ marginLeft: 5, fontSize: 16 }}>€</Text>
									</View>
								)}

								{/** Gestisce l'icona di clear */}
								{((this.props.config.showClearIcon && this.props.config.showClear) && (
									<TouchableOpacity style={styles.actionView} onPress={() => {
										this.props.actions.clear?.()
										this.props.textInputProps.actions?.onChangeText?.("")
									}}>
										<Icon name="close" color={colors.greyText} />
									</TouchableOpacity>
								))}

								{/** Gestisce le action. Il primo gestisce il loading, il secondo il bottone */}
								{(isDefined(this.props.config.actionButtonProps?.action) && this.props.config.actionButtonProps?.sendingComment) && (
									<ActivityIndicator style={styles.actionView} size="small" color={colors.blackOverlay} />
								)}
								{((isDefined(this.props.config.actionButtonProps?.action) && !this.props.config.actionButtonProps?.sendingComment)) && (
									<TouchableOpacity style={styles.actionView} onPress={() => {
										this.props.textInputProps.actions?.onSubmit?.()
									}}>
										<Text style={whenElse(this.props.config.actionButtonProps?.actionEnabled, styles.enabledAction, styles.disabledAction)}>
											{this.props.config.actionButtonProps?.action}
										</Text>
									</TouchableOpacity>
								)}

								{this.props.children}

							</View>

							<View style={[{ width: "100%", height: 2, position: 'absolute', bottom: 0 }, when(this.props.config.error || this.props.config.isError, { backgroundColor: colors.red })]} />

						</View>
					</View>
				</View>
			</TouchableWithoutFeedback>
		);
	}
}

export default InputContainer;
