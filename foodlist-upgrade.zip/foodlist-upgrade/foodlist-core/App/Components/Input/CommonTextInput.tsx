import React, { ReactChild } from 'react';
import { Text, View, TextInput, KeyboardTypeOptions } from 'react-native';
import styles from './Styles'
import { colors, when, alert } from '@FoodListCore/Global/GlobalProps';
import FLEditTextComponent from './FLEditText';
import FLDateEditTextComponent from './FLDateEditText';
import FLItemEditText from './FLItemEditText';
import FLFlagEditText from './FLFlagEditText';

export type CommonTextInputActions = {
	getNextInput?: () => FLEditTextComponent | FLDateEditTextComponent | FLItemEditText | FLFlagEditText | null,
	onSubmit?: () => void,
	onFocus?: () => void,
	onPress?: () => void

	getErrorMessage?: (text?: string) => string,
	textRef?: (ref: TextInput) => void,
}

export type TextInputActions = CommonTextInputActions & {
	onChangeText?: (text: string) => void,
	onTextInputRef?: (ref: TextInput) => void,
}

export type TextInputProps = {
	actions?: TextInputActions,
	title?: string,
	startLowerCase?: boolean,
	autoCorrect?: boolean,
	defaultValue?: string,
	value?: string,
	editable?: boolean,
	secureTextEntry?: boolean,
	keyboardType?: KeyboardTypeOptions,
	placeholder?: string,
	placeholderTextColor?: string,
	fontSize?: number,
	price?: boolean,
	autoCompleteType?: "username" | "email" | "password" //ce ne sono altri
}

const CommonTextInputComponent = (props: TextInputProps) => {
	let noTitle = props.title === undefined

	let inputProps: {
		blurOnSubmit?: boolean,
		pointerEvents?: "none" | "auto" | "box-none" | "box-only" | undefined,
	} = props.actions?.getNextInput ? {
		blurOnSubmit: false
	} : {}
	if (props.editable === false) {
		inputProps.pointerEvents = "none"
	}

	return <TextInput
		onChangeText={(v) => {
			props.actions?.onChangeText?.(v)
		}}
		onSubmitEditing={() => {
			props.actions?.getNextInput?.()?.focusInput()
			props.actions?.onSubmit?.()
		}}
		ref={ref => {
			if (ref) {
				props.actions?.onTextInputRef?.(ref)
			}
		}}
		onFocus={props.actions?.onFocus}

		autoCompleteType={props.autoCompleteType}
		autoCapitalize={!props.startLowerCase ? "sentences" : "none"}
		autoCorrect={props.autoCorrect}
		defaultValue={props.defaultValue/*  || this.input */}
		value={props.value}
		editable={props.editable}
		selectTextOnFocus={props.editable}
		secureTextEntry={props.secureTextEntry}
		keyboardType={props.keyboardType}
		placeholderTextColor={props.placeholderTextColor}
		style={[
			when(noTitle, styles.noTitleInput),
			when(props.fontSize != null, { fontSize: props.fontSize }),
			styles.input,
			when(props.price, { flex: 0, minWidth: 30 }),
		]}
		placeholder={props.placeholder}
		underlineColorAndroid="transparent"
		{...inputProps}
	/>;
};

export default CommonTextInputComponent;
