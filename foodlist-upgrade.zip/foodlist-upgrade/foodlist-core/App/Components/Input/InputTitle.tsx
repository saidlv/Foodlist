import React, { ReactChild } from 'react';
import { Text, View } from 'react-native';
import styles from './Styles'
import { colors } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';

type InputTitleViewProps = {
	title?: string,
	facoltative?: boolean,
	necessary?: boolean,

	error?: boolean,
	isError?: boolean,
	messageOnError?: string,
	errorMessage?: string,

	input?: string,
	getErrorMessage?: (input?: string) => string,
}

const InputTitleComponent = (props: InputTitleViewProps) => {
	var titleBox: ReactChild | null = null
	if (props.title != undefined) {
		titleBox = <Text style={styles.title}>{props.title.toUpperCase()}</Text>
	}

	var facoltativeBox: Element | null = null
	if (props.facoltative) {
		facoltativeBox = <Text style={styles.facoltative}>{translate("facoltative").toUpperCase()}</Text>
	}
	if (props.necessary) {
		facoltativeBox = <Text style={styles.facoltative}>{translate("required")}</Text>
	}

	if (props.error || props.isError) {
		facoltativeBox = <Text style={[styles.facoltative, { color: colors.red, opacity: 1 }]}>
			{(props.isError && props.messageOnError) || props.errorMessage || props.getErrorMessage?.(props.input) || translate("notValid")}
		</Text>
	}

	var titleView = <View style={{ flex: 0, flexDirection: "row" }}>{titleBox}{facoltativeBox}</View>

	return titleView;
};

export default InputTitleComponent;
