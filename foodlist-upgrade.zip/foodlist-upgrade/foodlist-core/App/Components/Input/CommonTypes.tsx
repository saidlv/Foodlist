import { TextInputProps } from "./CommonTextInput";
import { InputContainerConfig, InputContainerActions } from "./InputContainer";

export type CommonControllerTypes = {
	textInputProps: TextInputProps,
	inputContainerConfig: InputContainerConfig,
}

export type CommonViewTypes = CommonControllerTypes & {
	inputContainerActions: InputContainerActions,
}