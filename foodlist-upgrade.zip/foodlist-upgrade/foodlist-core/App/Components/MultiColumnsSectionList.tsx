import { margins } from '@FoodListCore/Global/GlobalProps';
import React from 'react';
import { SectionList, SectionListProps, StyleSheet, useWindowDimensions, View, ViewStyle } from 'react-native';

type Props<T> = {
	numColumns: number
	singleColumnThreshold?: number
	rowStyle?: ViewStyle
} & SectionListProps<T>

const MultiColumnsSectionList = React.forwardRef(<T extends { id?: number }> ({ numColumns: _cols, singleColumnThreshold, rowStyle, ...props }: Props<T>, ref) => {

	const width = useWindowDimensions().width
	const numColumns = (width < (singleColumnThreshold || 100)) ? 1 : _cols

	return (
		<SectionList
			{...props}
			ref={ref}

			renderItem={({ section, index, separators }) => {
				if(index % numColumns !== 0) { return null }
				const items = []
				for (let i = index; i < index + numColumns; i++) {
					if (i >= section.data.length) {
						//add items with flex 1 to make all cells equal size
						items.push(<View style={styles.flex1} key={i} />)
					} else {
						const item = section.data[i]
						items.push(
							<View style={styles.flex1} key={item.id || i}>
								{props.renderItem?.({ section, index: i, item, separators })}
							</View>
						)
					}
				}
				return (
					<View style={[styles.row, rowStyle]}>
						{items}
					</View>
				);
			}}
		/>
	);
})

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		justifyContent: "space-between",
		alignItems: "stretch",
		paddingHorizontal: margins.pagePadding / 2,
	},
	flex1: {
		flex: 1,
	},
});

export default MultiColumnsSectionList;
