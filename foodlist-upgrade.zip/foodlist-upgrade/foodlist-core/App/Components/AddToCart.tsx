import { initialCanSubmit } from '@FoodListCommon/menu';
import { getOrderItemPrice, getOrderItemPriceWithoutDiscount } from '@FoodListCommon/prices';
import CommonStyle from '@FoodListCore/Global/CommonStyle';
import { colors, spacing, themeColors } from '@FoodListCore/Global/Constants';
import { stringDefined, useForceUpdate } from '@FoodListCore/Global/GlobalProps';
import { translate } from '@FoodListCore/I18n';
import { addOrUpdateCart, addToCart, getOrderItemProgressiveId } from '@FoodListCore/Redux/ReduxHelper';
import { Dish } from '@Models/Dish';
import { OrderInfo } from '@Models/OrderInfo';
import { OrderItem } from '@Models/OrderItem';
import React from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import Button from './Button';
import DishPrice from './Discount/Price';
import DishField, { DishFieldActions } from './DishField';
import { CommonDishPopup } from './DishPopup';
import FLIcon from './FLIcon';
import IconButton from './IconButton';

type Props = {
	dish: Dish
	order: OrderInfo | undefined
	rest_id: number
	close?: () => void
}

const AddToCart = React.memo(({ dish, rest_id, ...props }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	const self = React.useMemo(() => ({
		orderItem: {
			dish,
			quantity: 1,
			local_id: getOrderItemProgressiveId(rest_id),
		} as OrderItem,
	}), [])

	const forceUpdate = useForceUpdate()
	const [canSubmit, setCanSubmit] = React.useState(initialCanSubmit(dish))
	const [qta, _setQta] = React.useState(1)
	const setQta = (value: number) => {
		self.orderItem.quantity = value
		_setQta(value)
	}

	const onAddToCart = React.useCallback(() => {
		const { options, notes } = self.orderItem
		if(!stringDefined(notes) && !options) {
			addOrUpdateCart(dish, rest_id, self.orderItem.quantity)
		} else {
			addToCart(self.orderItem, rest_id)
		}

		props.close?.()
	}, [self, dish, rest_id, props.close])

	const dishFieldActions: DishFieldActions = React.useMemo(() => {
		return {
			onSelectionChange: (options) => {
				self.orderItem.options = options
				forceUpdate() //update price if needed
			},
			updateCanSubmit: setCanSubmit,
		}
	}, [self])

	const onChangeNotes = React.useCallback((text: string) => {
		self.orderItem.notes = text
	}, [self])

	const price = getOrderItemPriceWithoutDiscount(self.orderItem)
	const discountedPrice = getOrderItemPrice(self.orderItem, self.orderItem.quantity, props.order)

	return (
		<View style={styles.container}>
			<CommonDishPopup dish={dish} />

			<View style={styles.noMargin}>
				<DishField
					dish={dish}
					actions={dishFieldActions}
					canSelect
				/>
			</View>

			<View style={[styles.notesContainer, CommonStyle.shadow]}>
				<TextInput
					style={styles.textArea}
					placeholder={translate("itemNotesExample")}
					onChangeText={onChangeNotes}
					multiline={true}
					maxLength={255}
				/>
				<Text style={styles.notesLabel}>{translate("notesWithColon").toUpperCase()}</Text>
			</View>

			<View style={styles.qtaRow}>
				<IconButton onPress={() => setQta(Math.max(1, qta - 1))} disabled={qta <= 1}>
					<FLIcon foodlistIcon="remove-circle-o" color={qta > 1 ? colors.foodlist : colors.inactiveGrey} size={24} />
				</IconButton>
				<Text style={styles.qtaText}>{qta}</Text>
				<IconButton onPress={() => setQta(qta + 1)}>
					<FLIcon foodlistIcon="add-circle-o" color={colors.foodlist} size={24} />
				</IconButton>
			</View>
			<Text style={styles.price}>
				<DishPrice initialPrice={price} discountedPrice={discountedPrice} />
			</Text>
			<Button onPress={onAddToCart} disabled={!canSubmit} title={translate(false ? "save" : "addToCartShort")} noMargin /* disabled={!canSubmit} */ />
		</View>
	);
});

const styles = StyleSheet.create({
	container: {
		paddingHorizontal: spacing.pagePadding,
		paddingTop: spacing.vertical,
		paddingBottom: spacing.pagePadding,
		backgroundColor: colors.greyBackground,
	},
	noMargin: {
		marginHorizontal: -spacing.pagePadding,
	},
	qtaRow: {
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "center",
		padding: spacing.pagePadding,
	},
	notesContainer: {
		marginVertical: 20,
		position: "relative",
		backgroundColor: colors.white,
		borderRadius: 10,
	},
	notesLabel: {
		position: "absolute",
		zIndex: 1,
		left: 18,
		top: 10,
		fontWeight: "bold",
	},
	qtaText: {
		fontWeight: "bold",
		fontSize: 24,
		marginHorizontal: 10,
		minWidth: 30,
		textAlign: "center",
	},
	textArea: {
		padding: 20,
		paddingTop: 36,
	},
	price: {
		marginBottom: 15,
		fontSize: 24,
		fontWeight: "bold",
		color: themeColors.priceTint,
		textAlign: "center",
	},
});

export default AddToCart;
