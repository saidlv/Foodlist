import { colors, spacing } from '@FoodListCore/Global/Constants';
import { translate } from '@FoodListCore/I18n';
import { Booking, BookingStatus } from '@Models/Booking';
import React from 'react';
import { StyleSheet, Text, TextStyle } from 'react-native';

type Props = {
	booking: Booking
	/**
	 * Per il manager mostra tutti gli stati, per l'utente normale solo rejected, pending e accepted
	 */
	forManager?: boolean
	style?: TextStyle
}

const ShowBookingStatus = React.memo(({ booking, forManager, ...props }: Props) => {
	const { status_id: status } = booking

	if(status == BookingStatus.Rejected) {
		return (
			<>
				<Text style={[styles.text, styles.rejected, props.style]}>{translate("bookingRejected")}</Text>
				<Text><Text style={{ fontWeight: "bold" }}>{translate("reason")}: </Text> {booking.reject_reason}</Text>
			</>
		)
	}
	return (
		<Text style={[styles.text, props.style]}>
			{status == BookingStatus.Pending ? (
				<Text style={styles.pending}>{translate(forManager ? "notConfirmed" : "waitingConfirm")}</Text>
			) : status == BookingStatus.Canceled ? (
				<Text style={styles.pending}>{translate("bookingCanceled")}</Text>
			) : (!forManager || status == BookingStatus.Accepted) ? (
				<Text style={styles.accepted}>{booking.by_restaurant ? "Prenotazione inserita" : translate("bookingAccepted")}</Text>
			) : status == BookingStatus.NotPresented ? (
				<Text style={styles.pending}>{translate("notPresented")}</Text>
			) : (
				<Text style={styles.accepted}>{translate("clientAccomodated")}</Text>
			)}
		</Text>
	);
});

const styles = StyleSheet.create({
	text: {
		fontWeight: "bold",
	},
	pending: {
		color: colors.orangeBar,
	},
	rejected: {
		color: colors.darkRed,
	},
	orange: {
		color: colors.darkFoodlist,
	},
	accepted: {
		color: colors.darkGreen,
	},
	
});

export default ShowBookingStatus;
