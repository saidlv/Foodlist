import colors from '@FoodListCommon/colors';
import { margins, when } from '@FoodListCore/Global/GlobalProps';
import { ReduxState } from '@FoodListCore/Redux/StateFormat';
import { StripeCardsHandler } from '@FoodListCore/Services/Stripe';
import { useAddCard } from '@FoodListCore/Services/Stripe/WebAddCard';
import { StripeCard } from '@Models/StripeCard';
import React, { useCallback, useState } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { shallowEqual, useSelector } from 'react-redux';
import CardDetail from './CardDetail';
import LightButton from './LightButton';
import Line from './Line';
import LoadingView from './LoadingView';
import SheetPopup, { BottomSheetFlatList } from './SheetPopup';
import { TouchableOpacity } from './TouchableFixed';
import { TouchableRipple } from './TouchableRipple';

type Props = {
	selectedCard: StripeCard | undefined | null
	onSelect: (card: StripeCard | null) => void
}

const mapReduxState = (state: ReduxState) => {
	return {
		cards: state.currentUser?.stripe_cards || []
	}
}
const SelectStripeCard = React.memo(({ selectedCard, onSelect }: Props) => {
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	const [sending, setSending] = useState(false)
	const [modalVisible, setModalVisible] = useState(false)

	const { cards } = useSelector(mapReduxState, shallowEqual)

	const selectCard = useCallback((card?: StripeCard) => {
		onSelect(card || null)
		setModalVisible(false)
	}, [onSelect])
	const onPress = useCallback(() => {
		setModalVisible(true)
	}, [])

	const { addCard, AddCardComponent } = useAddCard({ setSending, onCardAdded: selectCard })
	const showAddCard = React.useCallback(() => {
		if(Platform.OS == "web") {
			setModalVisible(false)
		}
		addCard()
	}, [])
	return (
		<>
			<View style={styles.row}>
				{selectedCard ? (
					<CardDetail
						item={selectedCard}
						hideExpiration
					/>
				) : (
					<Text>Aggiungi carta di credito/debito</Text>
				)}
				<TouchableOpacity
					onPress={onPress}
				>
					<Text style={styles.changeCard}>{selectedCard ? "Cambia" : "Aggiungi"}</Text>
				</TouchableOpacity>
			</View>
			{modalVisible && (
				<SheetPopup
					visible={modalVisible}
					actions={{
						onTapOutside: () => setModalVisible(false)
					}}
				>
					<LoadingView
						visible={sending}
					/>
					<BottomSheetFlatList
						data={cards}
						ItemSeparatorComponent={Line}
						ListHeaderComponent={Line}
						ListFooterComponent={(
							<>
								<Line />
								<LightButton
									onPress={showAddCard}
									style={{ margin: margins.pagePadding}}
								>Aggiungi carta</LightButton>
							</>
						)}
						renderItem={({ item }) => {
							const selected = item.id == selectedCard?.id
							return (
								<TouchableRipple
									onPress={() => selectCard(item)}
									style={[styles.cell, when(selected, styles.selected)]}
								>
									<CardDetail item={item} />
								</TouchableRipple>
							)
						}}
					/>
				</SheetPopup>
			)}
			{AddCardComponent}
		</>
	);
});

const styles = StyleSheet.create({
	row: {
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "space-between",
	},
	changeCard: {
		color: colors.blueMenu,
		fontWeight: "bold",
		paddingVertical: 12
	},
	cell: {
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 10,
	},
	selected: {
		backgroundColor: colors.withAlpha(colors.blueMenu, 0.2)
	},
});

export default SelectStripeCard;
