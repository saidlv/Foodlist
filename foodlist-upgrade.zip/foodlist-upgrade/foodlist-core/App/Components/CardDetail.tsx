import { StripeCard } from '@Models/StripeCard';
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import CreditCardIcon from './CreditCardIcon';


type Props = {
	item: StripeCard
	hideExpiration?: boolean
	/** default 3 */
	bullGroups?: number
}

const CardDetail = React.memo(({ item, hideExpiration }: Props) => {
	const { card } = item
	//use 'self' to store data that don't require a re-render, like 'this' in class components
	//const self = useMemo(() => ({}), [])
	//const [loading, setLoading] = useState(false)
	//const onPress = useCallback((param: number) => { }, [])
	return (
		<View style={styles.row}>
			<CreditCardIcon brand={card.brand} />
			<View	style={styles.text}>
				<Text numberOfLines={1} ellipsizeMode="head" style={styles.code}>&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; {card.last4}</Text>
				{!hideExpiration && (
					<Text>Scadenza: <Text style={styles.bold}>{card.exp_month}/{card.exp_year}</Text></Text>
				)}
			</View>
		</View>
	);
});

const styles = StyleSheet.create({
	text: {
		flex: 1,
		marginHorizontal: 15,
	},
	code: {
		fontSize: 15,
	},
	bold: {
		fontWeight: "bold",
	},
	row: {
		flexDirection: "row",
		alignItems: "center",
		flex: 1,
	},
});

export default CardDetail;
