import NetworkManager, { StatusOnlyResponse, Meta } from '@FoodListCore/Network/NetworkManager';
//import FirebaseAnalytics from "@Services/FirebaseAnalytics"
import { RequestResponse } from '@Models/RequestResponse';
import { ImageForMultipart } from '@Models/ImageForMultipart';
import { RatingForRequest } from '@Models/Rating';
import { FeedTypePrefix } from '@Models/FeedType';
import { Photo } from '@Models/Photo';
import { DishReview, Review } from '@Models/Review';

export type DeleteReviewRespone = StatusOnlyResponse | null

export type GetPreviousReviewResponse = {
	review: Review
} | null
export type UploadReviewPhotoResponse = ReviewResponse | null

export type ModifyRestaurantReviewResponse = {
	review?: Review | null,
	response?: Review
} | null

export type RestaurantReviewResponse = {
	review?: Review | null,
	response?: Review | null,
} | null

export type DishReviewResponse = {
	review?: Review | null,
	response?: DishReview | null,
} | null

export type ModifyDishReviewResponse = {
	review?: Review | null,
	response?: Review
} | null

export type ReviewResponse = {
	response: Review
}

export type ReviewListResponse = {
	count?: number,
	response: Review[],
	meta?: Meta
}

export type DishReviewValues = {
	content: string,
	/**
	 * quality rating
	 */
	rating: number,
	price_rating: number,
	/** not required for edit */
	order_row_id?: number
	/** only for edit, used to remove a photo without uploading another one */
	remove_photo?: boolean
}

export type RestaurantReviewValues = {

}

export default class ReviewManager extends NetworkManager {

	constructor() {
		super()
	}

	deleteRestaurantReview(restaurantId: number, reviewId: number): Promise<RequestResponse<DeleteReviewRespone>> {
		// DELETE a /restaurants/:restaurant_id/reviews/:id
		return super.handleRequest("/restaurants/" + restaurantId + "/reviews/" + reviewId, "DELETE");
	}

	deleteDishReview(dishId: number, reviewId: number): Promise<RequestResponse<DeleteReviewRespone>> {
		return super.handleRequest("/dishes/" + dishId + "/reviews/" + reviewId, "DELETE");
	}

	getPreviousReview(id: number, isDish: boolean): Promise<RequestResponse<GetPreviousReviewResponse>> {
		return super.handleRequest("/users/:current_user_id/reviews/" + (isDish ? "dish/" : "restaurant/") + id, "GET")
	}

	async modifyRestaurantReview(id: number, reviewId: number, rating: RatingForRequest, content: string, imageRemoved: boolean, photo: ImageForMultipart | null): Promise<RequestResponse<ModifyRestaurantReviewResponse>> {
		const params = {
			...rating,
			content: content,
			remove_photo: imageRemoved,
		}
		const response = await super.multipart<ModifyRestaurantReviewResponse>("/restaurants/" + id + "/reviews/" + reviewId, "PUT", photo ? [
			super.parseFile('file', photo),
		] : [], params);
		return response
	}

	async restaurantReview(id: number, rating: RatingForRequest, content: string, photo: ImageForMultipart | null): Promise<RequestResponse<RestaurantReviewResponse>> {
		const params = {
			user_id: ":current_user_id",
			...rating,
			content: content
		}
		const response = await super.multipart<RestaurantReviewResponse>("/restaurants/" + id + "/reviews", "POST", photo ? [
			super.parseFile('file', photo),
		] : [], params);
		return response
	}

	uploadRestaurantPhoto(id: number, source: ImageForMultipart) {
		return this._uploadPhoto<UploadReviewPhotoResponse>(id, "restaurants", source);
	}

	uploadDishPhoto(id: number, source: ImageForMultipart) {
		return this._uploadPhoto<DishReviewResponse>(id, "dishes", source);
	}

	_uploadPhoto<T>(id: number, prefix: FeedTypePrefix, source: ImageForMultipart) {
		const fields = [
			super.parseFile('file', source),
		]
		//console.log('file', fields, source)
		return super.multipart<T>("/uploads/reviews/" + prefix + "/" + id, "POST", fields);
	}

	async dishReview(id: number, values: DishReviewValues, photo: ImageForMultipart | null): Promise<RequestResponse<DishReviewResponse>> {
		//console.log(vote, category, price, content)
		const params = {
			user_id: ":current_user_id",
			...values,
		}
		const response = await super.multipart<DishReviewResponse>("/dishes/" + id + "/reviews", "POST", photo ? [
			super.parseFile('file', photo),
		] : [], params);
		return response
	}

	async modifyDishReview(id: number, reviewId: number, values: DishReviewValues, photo: ImageForMultipart | null): Promise<RequestResponse<ModifyDishReviewResponse>> {
		//console.log(vote, category, price, content)
		const response = await super.multipart<ModifyDishReviewResponse>("/dishes/" + id + "/reviews/" + reviewId, "PUT", photo ? [
			super.parseFile('file', photo),
		] : [], values);
		return response
	}
}
