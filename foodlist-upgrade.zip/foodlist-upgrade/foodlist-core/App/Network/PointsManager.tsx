import NetworkManager from "@FoodListCore/Network/NetworkManager";
import UserManager from "@FoodListCore/Network/UserManager";
import { getCurrentUser } from "@FoodListCore/Redux/ReduxHelper";
import { Coupon } from "@Models/Coupon";

export type SummaryResponse = {
	response: {
		points: number
		used_points: number
		available_coupons: Coupon[]
	}
}

export default class PointsManager extends NetworkManager {
	constructor() {
		super()
	}

	getPoints = async () => {
		const userManager = new UserManager()
		const res = await userManager.getInfoProfile(getCurrentUser()?.id!)
		const user = res.data?.response
		return {
			data: user
		}
	}

	getSummary = () => {
		return super.request<SummaryResponse>("/users/:current_user_id/points-summary", "GET")
	}

	getCoupons = (only_available?: boolean) => {
		return super.request<Coupon[]>("/users/:current_user_id/coupons", "GET", null, {
			only_available
		})
	}

	requestNewCoupon = (coupon_id: number) => {
		return super.request("/users/:current_user_id/coupons/request", "POST", {
			coupon_id
		})
	}

	getHowToEarnPoints = () => {
		return super.request("/points/list", "GET")
	}
}