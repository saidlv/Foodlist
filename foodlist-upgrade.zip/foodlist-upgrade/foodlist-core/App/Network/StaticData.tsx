import { AppData } from '@config/app'

export type RestaurantChoice = {
	name: string
	id: number
}

export class StaticData {
	static appName = AppData.name
	static restaurants: RestaurantChoice[] = AppData.restaurants
}