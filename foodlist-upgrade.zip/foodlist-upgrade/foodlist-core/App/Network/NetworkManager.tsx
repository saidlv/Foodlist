import SessionManager from '@FoodListCore/Services/SessionManager'
import { User } from '@Models/User';
import { RequestResponse } from '@Models/RequestResponse';
import { Platform } from 'react-native';
import { ImageForMultipart, ImageForMultipartRNBlob } from '@Models/ImageForMultipart';
import { Methods } from '@Models/Methods';
import { ReviewDistribution } from '@Models/Review';
import { StackNavigationProp } from "@react-navigation/stack"
import { RatingForRequest } from '@Models/Rating';
import { Pluto } from '@Models/Pluto';
import { Any } from '@Models/Any';
import NetworkConfig from '@config/network'
import { translate } from '@FoodListCore/I18n';
import { store } from '@FoodListCore/Redux/Reducer';
import { resetNavigation } from '@FoodListCore/Global/GlobalProps';
import { resolveHref } from '@FoodListCommon/utils';
//import { REQUEST_LOGIN_ONLY_EVENT } from '@FoodListCore/Flows/RequestAuth';

export type MultipartField = { name: string, data: string | ImageForMultipart }

/*   Se nel path oppure nel body :current_user_id, viene sostituito col currentUser da AsyncStorage
 *   Risposta delle chiamate:
 *   data: payload json della risposta
 *   status: HTTP status della risposta
 *   success: Booleano che a partire dallo status descrive l'andamento della richiesta
 *   user: se la chiamata è autenticata, ritorna il currentUser che ha fatto la richiesta (da asyncstorage)
 */
export class NetworkNavigation {
	static navigation: StackNavigationProp<Pluto, Pluto> | null = null;
}

export const clearEmptyParams = (params: GenericParams) => {
	const newParams: GenericParams = {}
	for(const param in params) {
		const value = params[param]
		if(value) {
			newParams[param] = value
		}
	}
	return newParams
}

export type GenericParams = {
	[key: string]: Any
}

type RequestParams = {
	method: Methods,
	headers: GenericParams,
	body?: string | GenericParams | null
}

export type Meta = {
	reviews_distribution?: ReviewDistribution,
	rating?: number,
	ratings?: RatingForRequest,
	user_review_id?: number,
}

export type StatusOnlyResponse = {
	response: {
		status: string
	}
}

export const showAll = {
	populate: true,
	user_id: ":current_user_id"
}

export default class NetworkManager {

	static BASE_URL: string = NetworkConfig.base_url
	protected BASE_API_URL: string

	constructor() {
		this.BASE_API_URL = resolveHref(NetworkManager.BASE_URL, NetworkConfig.api_path)
	}

	protected reset(): void {
		NetworkNavigation.navigation?.navigate("LoginPage");
	}

	async showLogin() {
		await SessionManager.logout();
		if(Platform.OS == "web") {
			store.getState().emitter.emit("REQUEST_LOGIN_ONLY_EVENT", () => {
				window.location.reload()
			})
		} else {
			NetworkNavigation.navigation?.navigate("LoginPage");
		}
	}

	protected _parsePath(path: string, user: User | null): string {
		if(user?.id !== undefined) {
			return path.replace(":current_user_id", user.id.toString());
		}
		return path.replace(":current_user_id", "");
	}

	protected trimSpacesString(s: string): string {
		return s.trim()
	}

	protected _parseParams(params: RequestParams, token: string) {
		if(token != null) params.headers["Authorization"] = "Bearer " + token;
		return params;
	}

	protected _parseBody(body: GenericParams, user: User | null, nullableParams?: string[]) {
		for(let key in body) {
			if(body[key] != null) {
				if(typeof body[key] === 'string') {
					body[key] = body[key].replace(":current_user_id", user == null ? "" : user.id);          
					body[key] = this.trimSpacesString(body[key])
				}
			} else if(nullableParams && Array.isArray(nullableParams) && nullableParams.indexOf(key) != -1) {
				body[key] = null
			} else {
				delete body[key]
			}
		}
		return body;
	}

	protected _getRequestQuery(queryParams: GenericParams): string {
		let output: string[] = []
		for(let key in queryParams) {
			let value = queryParams[key];

			if(typeof value === 'string') {
				value = this.trimSpacesString(value)
			}

			output.push(key + "=" + value);
		}
		let res: string = "?" + output.join("&");
		return res
	}

	protected async request<T> (path: string, method: Methods, body?: GenericParams | null, queryParams?: GenericParams | null, nullableParams?: string[]): Promise<RequestResponse<T | null>> {
		//return this._invokeRequest(path, "application/json", method, body, queryParams, nullableParams);
		let contentType = 'application/json';
		let isJSON = contentType == 'application/json'

		let params: RequestParams = {
			method: method,
			headers: {
				'Accept': 'application/json',
				'x-app-version': "1.0.0"
			}
		} 

		if(contentType != null) params.headers["Content-Type"] = contentType;
		if(queryParams) {
			path += this._getRequestQuery(queryParams);
		}
		console.log(path)

		let userData = await Promise.all([SessionManager.getCurrentUser(), SessionManager._getToken()])
		const user = userData[0], token = userData[1];
		
		path = this._parsePath(path, user)
		if(token != null) params = this._parseParams(params, token);
		if(params.method == "POST" || params.method == "PUT") {
			params.body = isJSON ? JSON.stringify(this._parseBody(body || {}, user, nullableParams)) : body;
		}
		
		try {
			let response = await fetch(this.BASE_API_URL + path, params);
			const json = await response.json();
			const status = response.status;
			if(status == 401 || status == 403) {
				await this.showLogin()
				return {data: null, status, success: false, error: "Sessione Scaduta"};
			}
			return {data: json, status: status, success: status >= 200 && status < 400, error: json.error, default_error: json.default_error }
		} catch(error) {
			//console.log(path, 500, error)
			console.warn(path, 500, error)
			throw new Error(translate("maintainanceError"))
		}
	}

	/**
	 * Instead of request if server response contains an error handleRequest will throw an error (you will see it inside catch instead of then)
	 */
	protected async handleRequest<T> (path: string, method: Methods, body?: GenericParams | null, queryParams?: GenericParams | null, nullableParams?: string[]) {
		const res = await this.request<T>(path, method, body, queryParams, nullableParams)
		if(!res.success) {
			//throw new Error(res.error)
			throw new Error(res.default_error || res.error)
		}
		return res
	}

	protected parseFile(name: string, source: ImageForMultipart) {
		return {
			name: name,
			data: {
				name: source.fileName,
				fileName: source.fileName,
				type: source.type,
				uri: Platform.OS == 'android' ? source.uri : source.uri.replace('file:/', ''),
			}
		}
	}

	protected toMultipartParams = (params: GenericParams): MultipartField[] => {
		return Object.keys(params).map(key => {
			const item = params[key]
			return {
				name: key,
				data: String(item),
			}
		})
	}

	protected async multipart<T>(path: string, method: Methods, fields: MultipartField[], bodyParams?: GenericParams): Promise<RequestResponse<T>> {
		const token = await SessionManager._getToken()
		const currentUser = await SessionManager.getCurrentUser()
		path = this._parsePath(path, currentUser)
		const allFields = bodyParams ? fields.concat(this.toMultipartParams(this._parseBody(bodyParams, currentUser))) : fields
		const formData = new FormData()
		allFields.forEach(field => {
			formData.append(field.name, field.data)
		})
		console.log(path, allFields)
		return new Promise((resolve, reject) => {
			fetch(this.BASE_API_URL + path, {
				method,
				headers: {
					'Authorization': "Bearer " + token,
					'Content-Type': 'multipart/form-data',
					'Accept': 'application/json',
				},
				body: formData
			}).then(async response => {
				let json = await response.json()
				if(json.error) {
					reject(json.error)
				} else {
					resolve({success: true, status: response.status, data: json})
				}
			}).catch(error => {
				reject(error)
			})
		})
	}

	static getMinVersions = async () => {
		let response = await fetch('https://foodlist.eu/info/ws.json');
		response = await response.json();
		return response;
	}
}
