import NetworkManager, { Meta } from '@FoodListCore/Network/NetworkManager';
import { ListParams } from '@Models/ListParams';
import { RequestResponse } from '@Models/RequestResponse';
import { DishReview, Review } from '@Models/Review';
import { Dish } from '@Models/Dish';

export type GetReviewsFoodResponse = {
	count?: number,
	response: DishReview[],
	meta?: Meta
} | null

export type GetInfoFoodResponse = {
		response: Dish,
		meta: Meta
} | null

export default class DishManager extends NetworkManager {
		constructor() {
				super()
		}
		
		getReviewsFood(id: number, params: ListParams, rating?: string): Promise<RequestResponse<GetReviewsFoodResponse>> {
			return super.handleRequest("/dishes/" + id + "/reviews", "GET", null, {populate: true, user_id: ':current_user_id', rating: rating || "0,1,2,3,4,5", ...params});
		}

		getInfoFood(id: number): Promise<RequestResponse<GetInfoFoodResponse>> {
				//TODO change params /dishes/:id
				//return super.request("/dishes/" + id, "GET");
				return super.handleRequest("/dishes/" + id, "GET", null, {user_id: ":current_user_id", populate: true});
		}
}
