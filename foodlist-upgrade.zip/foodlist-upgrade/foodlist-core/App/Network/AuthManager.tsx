import NetworkManager, { StatusOnlyResponse } from './NetworkManager';
import SessionManager, { SupportedSocial } from "@FoodListCore/Services/SessionManager"
import { RequestResponse, RequestResponseS, ServerResponse } from '@Models/RequestResponse';
import { User } from '@Models/User';
import { Restaurant } from '@Models/Restaurant';
import { Pippo } from '@Models/Pippo';
import { AppData } from '@config/app';

import { GoogleSignin } from "@react-native-community/google-signin";
import { AccessToken } from "react-native-fbsdk-next";
import { GoogleWebClientId } from "@config/app";
import { appleAuth } from "@FoodListCore/Services/AppleAuth";
import AsyncStorage from '@react-native-community/async-storage';
import { Platform } from 'react-native';

export type LoginResponse = {
	response: User & { token: string },
	associated_restaurants: Restaurant[],
	error_code: string
} | null

export type RequestTokenResponse = {
	response: {
		token: string,
		user?: User
		expires_in: string,
		isAdmin: boolean
	}
} | null

export type SocialSignInResponse = {
	/**
	 * only if signed-in with Apple
	 */
	long_lived_token?: string,
	signin_status: number,
	user?: User,
	token?: string,
	email: string,
	associated_restaurants?: Restaurant[],
}


export type ResetPasswordResponse = StatusOnlyResponse | null

export default class AuthManager extends NetworkManager {

	constructor() {
		super()
	}

	login = async (username: string | null, email: string | null, password: string): Promise<RequestResponse<LoginResponse>> => {
		//FirebaseAnalytics.login(username, email);
		let response = await super.request<LoginResponse>("/auth/login", "POST", {
			"username": username,
			"password": password,
			"email": email
		})
		return response;
	}

	async loginWithToken(username: string | null, email: string | null, password: string): Promise<User | undefined> {
		let output_username;

		let response = await this.login(username, email, password)
		let user
		if (response.success) {
			user = response.data?.response;
			output_username = user?.username;
		} else {
			throw new Error(response.data?.error_code);
		}

		let requestTokenresponse = await this.requestToken(output_username!, password);
		await SessionManager.saveToken(requestTokenresponse.data?.response.token ?? "");
		await Promise.all([SessionManager.setCurrentPassword(password), SessionManager.setCurrentUser(user!)]);
		return user
	}

	checkSocialSignin(token: string, social: SupportedSocial) {
		return super.handleRequest<ServerResponse<SocialSignInResponse>>("/auth/social/authorize", "POST", {
			"access_token": token,
			social
		})
	}
	checkAppleSignin(user_id: string, long_lived_token: string) {
		return super.request<ServerResponse<SocialSignInResponse>>("/auth/social/authorize", "POST", {
			apple_long_lived_token: long_lived_token,
			apple_logged_user: user_id,
			social: "apple"
		})
	}

	registerWithSocial(token: string, social: SupportedSocial, username: string, email: string, first_name?: string, last_name?: string) {
		return super.request<ServerResponse<SocialSignInResponse>>("/auth/social/register", "POST", {
			"access_token": token,
			username,
			email,
			social,
			first_name, //required only for Apple Signin
			last_name, //required only for Apple Signin
			"register_with": AppData.name
		})
	}

	requestToken(username: string, password: string): Promise<RequestResponse<RequestTokenResponse>> {
		return super.request<RequestTokenResponse>("/token/request", "POST", {
			"username": username,
			"password": password
		});
	}

	resetPassword = (username: string | null, email: string | null): Promise<RequestResponse<ResetPasswordResponse>> => {
		return super.request<ResetPasswordResponse>("/auth/reset-password", "POST", {
			"username": username,
			"email": email
		})
	}

	_register(username: string, email: string, password: string): Promise<RequestResponse<Pippo>> {
		return super.request("/users", "POST", {
			"username": username,
			"email": email,
			"password": password,
			"register_with": AppData.name
		});
	}

	async register(username: string, email: string, password: string): Promise<RequestResponse<Pippo>> {
		//FirebaseAnalytics.signup(username, email, phone, firstName, lastName, birthDate, gender);

		let response = await this._register(username, email, password)
		
		if (response.success) {
			const user = response.data.response;
			await Promise.all([new Promise((resolve, reject) => { resolve(response) }), SessionManager.setCurrentPassword(password), SessionManager.setCurrentUser(user)]);
			return response;
		} else {
			throw new Error(response.data.error_code);
		}
	}

	registerWithToken = async (username: string, email: string, password: string) => {
		const response = await this.register(username, email, password)
		if (response.success && response.data) {
			const user = response.data.response;
			await Promise.all([SessionManager.setCurrentPassword(password), SessionManager.setCurrentUser(user)]);
		} else {
			throw new Error(response.data?.error_code);
		}

		const requestTokenresponse = await this.requestToken(username, password);
		await SessionManager.saveToken(requestTokenresponse.data?.response.token ?? "");
	}

	requestCode(countryCode: string, phone: string, user_id: number, locale?: string): Promise<RequestResponse<Pippo>> {
		return super.handleRequest("/auth/request-phone-code", "POST", {
			user_id: user_id,
			country_code: countryCode,
			phone: phone,
			locale: locale
		});
	}

	async verifyCode(user_id: number, verificationCode: string): Promise<Pippo> {
		//const scope = this;
		return super.request("/auth/verify-phone-code", "POST", {
			user_id: user_id,
			verification_code: verificationCode
		})
	}

	async getAppleAuth() {
		return await Promise.all([AsyncStorage.getItem(SessionManager.APPLE_SIGNIN_USERID), AsyncStorage.getItem(SessionManager.APPLE_SIGNIN_TOKEN)])
	}

	/**
	 * handles login with FoodList or with social network
	 * !IMPORTANT! you need to logout user if the promise is rejected
	 */
	async loginSilently() {
		return new Promise<SocialSignInResponse | { token: string, username: string }>(async (resolve, reject) => {
			if(Platform.OS == "web") {
				const token = await SessionManager.getSavedToken()
				const user = await SessionManager.getCurrentUser()
				if(user?.id && token) {
					await SessionManager.loadStorageToRedux()
					resolve({ token, username: user.username })
				} else {
					reject()
				}
				return
			}
			const socialLogin = await AsyncStorage.getItem(SessionManager.SOCIAL_LOGIN_KEY) as unknown as SupportedSocial | null
			//console.log("SocialLogin", socialLogin)
			const handleRes = async (res: RequestResponseS<SocialSignInResponse>) => {
				const data = res.data?.response
				//console.log("server response", data, res)
				if(data && data.signin_status == 1 && data.user && data.token) {
					const token = data.token
					await SessionManager.setCurrentUser(data.user)
					await SessionManager.saveToken(token)
					resolve(data)
				} else {
					reject()
				}
			}
			const handleErr = (err: any) => {
				//console.log("error", err)
				reject(err)
			}
			if(socialLogin == "google") {
				GoogleSignin.configure({
					webClientId: GoogleWebClientId
				})
				GoogleSignin.signInSilently().then(res => {
					//console.log("google silent login", res)
					if(res.idToken) {
						this.checkSocialSignin(res.idToken, "google")
						.then(handleRes)
						.catch(handleErr)
					} else {
						reject()
					}
				}, handleErr)
			} else if(socialLogin == "facebook") {
				AccessToken.getCurrentAccessToken().then(res => {
					//console.log("Expiration time: ", res?.expirationTime)
					if(res?.accessToken) {
						this.checkSocialSignin(res.accessToken, "facebook")
						.then(handleRes)
						.catch(handleErr)
					} else {
						reject()
					}
				}).catch(handleErr)
			} else if(socialLogin == "apple") {
				const [userId, long_lived_token] = await this.getAppleAuth()
				if(!userId || !long_lived_token) {
					reject()
				} else {
					//check that the user is still logged and app is authorized
					appleAuth.getCredentialStateForUser(userId ?? "").then(state => {
						if(state == appleAuth.State.AUTHORIZED) {
							this.checkAppleSignin(userId, long_lived_token)
							.then(handleRes)
							.catch(handleErr)
						} else {
							reject()
						}
					})
					.catch(handleErr)
				}
			} else {
				const values = await Promise.all([SessionManager.getCurrentUser(), SessionManager.getCurrentPassword()])
				const user = values[0]
				const password = values[1]
				if (!user || !password || !user.username) {
					reject("not logged")
				} else {
					const authResponse = await this.requestToken(user.username, password)
					if (authResponse && authResponse.success) {
						const data = authResponse.data?.response
						const token = data?.token ?? ""
						if(data?.user) {
							//console.log("user", data.user)
							await SessionManager.setCurrentUser(data?.user)
						}
						await SessionManager.saveToken(token)
						resolve({
							token,
							username: user.username
						})
					} else {
						reject()
					}
				}
			}
		})
	}
}
