import NetworkManager from "./NetworkManager";
import { BookingInfo } from "@Models/BookingInfo";
import { ServerResponse } from "@Models/RequestResponse";
import { Booking } from "@Models/Booking";
import { BookingDay } from "@Models/BookingDay";
import { BookingOption } from "@Models/BookingOption";

export default class BookingManager extends NetworkManager {
	private rest_id: number
	constructor(rest_id: number) {
		super()
		this.rest_id = rest_id
	}

	sendBooking = (bookingInfo: BookingInfo) => {
		return this.request<ServerResponse<Booking>>(`/restaurants/${this.rest_id}/bookings`, "POST", bookingInfo)
	}

	getBookingHours = (day: string) => {
		return this.handleRequest(`/restaurants/${this.rest_id}/booking-hours`, "GET", undefined, { date: day })
	}

	getBookingDays = (id: number = this.rest_id) => {
		return super.handleRequest<ServerResponse<BookingDay[]>>("/restaurants/" + id + "/booking-days?sort_by_from=true", "GET")
	}

	getBookingOptions = (id: number = this.rest_id) => {
		return super.handleRequest<ServerResponse<BookingOption[]>>("/restaurants/" + id + "/booking-options", "GET")
	}
}