import NetworkManager, { Meta } from './NetworkManager';
import { RequestResponse } from '@Models/RequestResponse';
import { Restaurant } from '@Models/Restaurant';
import { ItemsMap } from '@Models/ItemsMap';
import { Dish } from '@Models/Dish';
import { DishType } from '@Models/DishType';
import { ListParams } from '@Models/ListParams';
import { LoadMoreResponse } from '@FoodListCore/Components/LoadMoreList';
import { Menu } from '@Models/Menu';
import { MenuDiscounts } from '@Models/Discount';
import { ReviewType } from '@Models/ReviewType';
import { ReviewListResponse } from './ReviewManager';

export type GetInfoRestaurantResponse = {
	response: Restaurant,
	meta: Meta
} | null

export type GetMenuRestaurantResponse = {
	response: Menu[]
} | null

export type GetDishTypesResponse = {
	dish_types: DishType[]
} | null

export default class RestaurantManager extends NetworkManager {
	restId: number

	constructor(restaurantId: number) {
		super()
		this.restId = restaurantId
		//this.imgBasePath = "@testImages"
	}
	/* getImagePath(relPath) {
			return this.imgBasePath + path
	} */
	getInfoRestaurant(id: number = this.restId): Promise<RequestResponse<GetInfoRestaurantResponse>> {
		//TODO change params /restaurants/:id
		//TODO il menu è in una richiesta a parte, /api/menus/restaurant/:id, intanto cambiare parametri prendendoli da quella richiesta
		//TODO gli orari mi sa che non ci sono ancora
		return super.request("/restaurants/" + id, "GET", null, { populate: true, compact: true });
	}

	loadRestaurant(id: number = this.restId): Promise<RequestResponse<GetInfoRestaurantResponse>> {
		return super.handleRequest("/restaurants/" + id, "GET", null, { user_id: ":current_user_id", populate: true, compact: true, with_dishes: true });
	}

	getMenuRestaurant(id: number = this.restId, onlyPurchasable: boolean): Promise<RequestResponse<GetMenuRestaurantResponse>> {
		//TODO change params /restaurants/:id
		//TODO il menu è in una richiesta a parte, /api/menus/restaurant/:id, intanto cambiare parametri prendendoli da quella richiesta
		//TODO gli orari mi sa che non ci sono ancora
		return super.handleRequest("/menus/ordered/restaurant/" + id + "?populate=true&user_id=:current_user_id" + (onlyPurchasable ? "&only_purchasable=true" : ""), "GET");
	}

	getRestaurantDiscounts(id: number = this.restId) {
		return super.request<MenuDiscounts>("/restaurants/" + id + "/discounts", "GET")
	}

	getDishTypes(id: number = this.restId): Promise<RequestResponse<GetDishTypesResponse>> {
		return super.request("/restaurants/" + id + "/dish_types", "GET")
	}

	getManagedRestaurants = (params: ListParams): Promise<RequestResponse<LoadMoreResponse<Restaurant>>> => {
		return super.request("/restaurants/managed", "GET", null, params)
	}

	updateMinutesBeforeStatus = (value: number) => {
		return super.request(`/restaurants/${this.restId}`, "PUT", {
			order_min_minutes_before: value
		})
	}

	getReviewsRestaurant(id: number, params: ListParams, category: ReviewType, rating: string): Promise<RequestResponse<ReviewListResponse | null>> {
		//TODO change params /restaurants/:id
		//TODO il menu è in una richiesta a parte, /api/menus/restaurant/:id, intanto cambiare parametri prendendoli da quella richiesta
		//TODO gli orari mi sa che non ci sono ancora
		if (category != "all") {
			return super.request("/restaurants/" + id + "/reviews", "GET", null, { populate: true, user_id: ':current_user_id', category: category, rating: rating, ...params });
		} else {
			return super.request("/restaurants/" + id + "/reviews", "GET", null, { populate: true, user_id: ':current_user_id', rating: rating, ...params });
		}
	}
}
