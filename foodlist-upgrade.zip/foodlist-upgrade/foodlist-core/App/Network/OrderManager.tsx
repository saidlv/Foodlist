import NetworkManager, { showAll, StatusOnlyResponse, GenericParams, clearEmptyParams } from './NetworkManager';
import { RequestResponse, ServerResponse } from '@Models/RequestResponse';
import { ListParams } from '@Models/ListParams';
import { OrderType, Order } from '@Models/Order';
import { OrderRow } from '@Models/OrderRow';
import {  OrderItemForRequest } from '@Models/OrderItem';
import { AppData } from '@config/app';
import { getCurrentUser } from '@FoodListCore/Redux/ReduxHelper';
import { UserAddress } from '@Models/UserAddress';
import { Restaurant } from '@Models/Restaurant';

export const DEFAULT_SEARCH_RADIUS = 20

export const IgnoreResponse = {
	status: 200,
	success: true,
	data: {
		ignore: true,
		response: undefined
	},
}

export type SearchRestaurantResponse = {
	response?: Restaurant[]
	reverse_geocoded_address?: UserAddress
} | null

export type AddOrderResponse = {
	response: Order
} | null

export type GetUserOrdersResponse = {
	response: Order[]
} | null

export default class OrderManager extends NetworkManager {
	constructor() {
		super()
	}

	getDeliveryPlaces = (params: { user_address_id?: number, for_date?: string, user_address_full?: string, latitude?: number, longitude?: number, name?: string, from_id?: number, to_id?: number }, loadMoreParams?: ListParams, mode: "delivery" | "takeaway" | "booking" | string = "delivery", filters?: object) => {
		const queryParams = clearEmptyParams({
			...params,
			...loadMoreParams,
			user_id: getCurrentUser()?.id,
			...filters,
		})
		if(mode == "delivery") {
			queryParams.with_delivery = 1
		} else if(mode == "takeaway") {
			queryParams.with_take_away = 1
			queryParams.distance = queryParams.distance || DEFAULT_SEARCH_RADIUS
		} else if(mode == "booking") {
			queryParams.with_bookings = 1
			queryParams.distance = queryParams.distance || DEFAULT_SEARCH_RADIUS
		}
		return super.request<SearchRestaurantResponse>("/search/restaurants" + this._getRequestQuery(queryParams), "GET")
	}

	addOrder = (
		user_id: number, 
		restaurant_id: number, 
		for_date: string | undefined, 
		type: OrderType, notes: string | undefined, 
		address_id: number, 
		order_rows: OrderItemForRequest[], 
		delivery_section_id: number, 
		delivery_section_hour_id: number, 
		ref_name: string,
		payment_method_id: number,
		predictedPrice: string,
		as_soon_as_possible?: boolean,
		coupon_id?: number,
		/** Stripe PaymentMethod id */
		stripeParams?: {
			card_id?: string,
			card_brand?: string,
			card_last4?: string,
		}
		): Promise<RequestResponse<AddOrderResponse>> => {
		return super.request('/restaurants/' + restaurant_id + '/orders', 'POST', {
			user_id,
			ref_name,
			order_type: type,
			for_date,
			as_soon_as_possible,
			address_id,
			order_rows,
			notes,
			delivery_section_id,
			delivery_section_hour_id,
			payment_method_id,
			predicted_total: predictedPrice,
			app_source_prefix: AppData.app_source_prefix,
			coupon_id,
			...stripeParams,
		})
	}

	confirmPayment = (order_id: number) => {
		return super.handleRequest(`/orders/${order_id}/stripe/capture`, "POST")
	}

	getUserOrders = (user_id: number, params: ListParams): Promise<RequestResponse<GetUserOrdersResponse>> => {
		return super.request('/users/' + user_id + '/orders', 'GET', null, params)
	}

	getSingleOrder = (order_id: number) => {
		return super.request<ServerResponse<Order>>(`/users/:current_user_id/orders/${order_id}`, "GET", null, {
			//no_dishes: true
		})
	}
}
