import NetworkManager from '@FoodListCore/Network/NetworkManager';
import { Platform } from "react-native";
import { alert } from '@FoodListCore/Global/GlobalProps'
import DeviceInfo from 'react-native-device-info';
import { RequestResponse } from '@Models/RequestResponse';
import { Notification } from '@Models/Notification';
import { AppSchema } from '@config/app';

type ListNotificationResponse = {
	response: Notification[],
} | null

export type UpsertTokenResponse = {
	response: {
		device_id: string,
		token: string,
		os: "iOS" | "Android",
		created_at: string,
		updated_at: string,
		user_id: number
	}
} | null

export type DropTokenResponse = {

} | null

export default class NotificationsManager extends NetworkManager {

	constructor() {
		super()
	}

	setRead() {
		//return super.request("/notifications/:current_user_id/read_all", "POST").then((response) => {
		return super.handleRequest("/users/:current_user_id/notifications/read-all", "POST")
	}

	async list(): Promise<Notification[]> {
		//let response = await super.request<ListNotificationResponse>("/notifications/:current_user_id?populate=true", "GET")
		let response = await super.request<ListNotificationResponse>("/users/:current_user_id/notifications", "GET")
		try {
			if (response.success) {
				return response.data?.response || [];
			} else {
				throw new Error(response.error);
			}
		} catch (e) {
			alert("Errore", e);
		}
		return []
	}

	getAppIdentifier() {
		return AppSchema.replace("-payment", "")
	}

	getUniqueId() {
		const app_id = this.getAppIdentifier()
		if(app_id == "foodlist-app") {
			return DeviceInfo.getUniqueId()
		}
		return app_id + "_" + DeviceInfo.getUniqueId()
	}

	upsertToken(token: string, is_manager_app?: boolean): Promise<RequestResponse<UpsertTokenResponse>> {
		return super.request("/users/:current_user_id/installations/" + this.getUniqueId(), "PUT", {
			os: Platform.OS == "ios" ? "iOS" : "Android",
			token: token,
			manager_app: is_manager_app
		});
	}

	dropToken(): Promise<RequestResponse<DropTokenResponse>> {
		return super.request("/users/:current_user_id/installations/" + this.getUniqueId(), "DELETE");
	}
}
