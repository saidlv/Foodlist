import NetworkManager, { showAll, StatusOnlyResponse, GenericParams } from './NetworkManager';
import { RequestResponse, ServerResponse } from '@Models/RequestResponse';
import { ImageForMultipart } from '@Models/ImageForMultipart';
import { ListParams } from '@Models/ListParams';
import { User } from '@Models/User';
import { Follow } from '@Models/Follow';
import { Review } from '@Models/Review';
import { ReviewType } from '@Models/ReviewType';
import { UserAddress } from '@Models/UserAddress';
import { getCurrentUser } from '@FoodListCore/Redux/ReduxHelper';
import { BookingInfo } from '@Models/BookingInfo';

export type EditUserResponse = {
	response: User,
	error_code: string
} | null

export type FollowResponse = {
	response: Follow
} | null

export type UnfollowResponse = StatusOnlyResponse | null
export type DropPhotoResponse = StatusOnlyResponse | null

export type GetReviewsResponse = {
	response: {
		restaurants: Review[],
		dishes: Review[],
	}
} | null

export type GetInfoProfileResponse = {
	response: User
} | null

export type GetProfileAndReviewsResponse = [GetReviewsResponse, GetInfoProfileResponse] | null

export type FollowListResponse = {
	response: Follow[]
} | null

export type CreateAddressResponse = {
	response: UserAddress
} | null

export default class UserManager extends NetworkManager {
	constructor() {
		super()
	}

	edit = (id: number, params: GenericParams): Promise<RequestResponse<EditUserResponse>> => {
		return super.request("/users/" + id, "PUT", params, null, ["gender", "first_name", "last_name"]);
	}

	follow = (id: number): Promise<RequestResponse<FollowResponse>> => {
		return this.handleFollow(id, true);
	}

	unfollow = (id: number): Promise<RequestResponse<UnfollowResponse>> => {
		return this.handleFollow(id, false);
	}

	handleFollow = <T extends {}>(user_id: number, following: boolean): Promise<RequestResponse<T | null>> => {
		const method = following ? "POST" : "DELETE";
		return super.request("/followers/user/" + user_id, method, { "follower_id": ":current_user_id" }, { "follower_id": ":current_user_id" });
	}

	uploadPhoto = (source: ImageForMultipart): Promise<RequestResponse<EditUserResponse>> => {
		const fields = [
			super.parseFile('file', source),
		]
		return super.multipart("/uploads/users/:current_user_id", "POST", fields);
	}

	dropPhoto = (): Promise<RequestResponse<DropPhotoResponse>> => {
		return super.request("/uploads/users/:current_user_id", "DELETE");
	}

	getReviews = (id: number, params: ListParams, type: ReviewType, rating: string): Promise<RequestResponse<GetReviewsResponse>> => {
		//TODO: waiting for giovanni
		return super.request('/users/' + id + '/reviews', "GET", null, { populate: true, user_id: ':current_user_id', type: type, rating: rating, ...params })
	}

	getInfoProfile = (id: number): Promise<RequestResponse<GetInfoProfileResponse>> => {
		return super.handleRequest("/users/" + id, "GET", null, showAll)
	}

	getProfileAndReviews = async (id: number, type: ReviewType, rating: string): Promise<RequestResponse<GetProfileAndReviewsResponse>> => {
		let reviews = await this.getReviews(id, { limit: 6, offset: 0 }, type, rating);
		let infoProfile = await this.getInfoProfile(id);
		return {
			data: [reviews.data, infoProfile.data],
			status: Math.max(reviews.status, infoProfile.status),
			success: reviews.success && infoProfile.success,
			user: reviews.user,
			error: reviews.error || infoProfile.error,
		}
		//return Promise.all([this.getReviews(id, {limit: 6, offset: 0}, type, rating), this.getInfoProfile(id)])
	}

	getUserBookings = (params: ListParams, user_id = getCurrentUser()?.id) => {
		return super.request("/users/" + user_id + "/bookings", "GET", undefined, params)
	}

	getSingleBooking = (id: number) => {
		return super.handleRequest<ServerResponse<BookingInfo>>("/users/:current_user_id/bookings/" + id, "GET")
	}

	getFollowers = (id: number, params: ListParams): Promise<RequestResponse<FollowListResponse>> => {
		return super.request('/followers/user/' + id, "GET", null, { populate: true, user_id: ':current_user_id', ...params })
	}
	getFollowing = (id: number, params: ListParams): Promise<RequestResponse<FollowListResponse>> => {
		return super.request('/following/user/' + id, "GET", null, { populate: true, user_id: ':current_user_id', ...params })
	}

	createAddress = (user_id: number, address_name: string, doorbell_name: string, address: string, house_number: string, city: string, cap: string, intern?: string, notes?: string, phone?: string): Promise<RequestResponse<CreateAddressResponse>> => {
		return super.request('/users/' + user_id + '/addresses', 'POST', {
			name: address_name,
			doorbell_name: doorbell_name,
			address: address,
			house_number: house_number,
			city: city,
			cap: cap,
			intern: intern, 
			/* stairway: stairway, 
			plan: plan,  */
			notes: notes,
			phone: phone
		});
	}

	deleteAddress = (address_id: number) => {
		return super.request('/users/:current_user_id/addresses/' + address_id, 'DELETE')
	}

	editAdrress = (user_id: number, address_id: number, address_name: string, doorbell_name: string, address: string, house_number: string, city: string, cap: string, intern: string, stairway: string, plan: string, notes: string, phone?: string, is_default?: boolean): Promise<RequestResponse<CreateAddressResponse>> => {
		return super.request('/users/' + user_id + '/addresses/' + address_id, 'PUT', {
			name: address_name,
			doorbell_name: doorbell_name,
			address: address,
			house_number: house_number,
			city: city,
			cap: cap,
			intern: intern, 
			stairway: stairway, 
			plan: plan, 
			notes: notes,
			phone: phone,
			default: is_default
		})
	}

	addPaymentMethod = (payment_method_id: string) => {
		return super.handleRequest('/users/:current_user_id/stripe/cards', "POST", {
			card_token: payment_method_id
		})
	}

	removePaymentMethod = (payment_method_id: string) => {
		return super.handleRequest(`/users/:current_user_id/stripe/cards/${payment_method_id}`, "DELETE")
	}
}
