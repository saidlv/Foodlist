import NetworkManager, { StatusOnlyResponse } from "./NetworkManager";
import { RestaurantPost } from "@Models/RestaurantPost";
import { ListParams } from "@Models/ListParams";
import { RequestResponse } from "@Models/RequestResponse";
import { RestaurantPostLike } from "@Models/Like";
import { RestaurantPostComment } from "@Models/RestaurantPostComment";

export type GetPostsResponse = {
	response: RestaurantPost
} | null

export type HandleLikeResponse = {
	response: RestaurantPostLike | StatusOnlyResponse
} | null

export type AddCommentResponse = {
	respone: RestaurantPostComment
} | null

export type DeleteCommentResponse = StatusOnlyResponse | null

export default class RestaurantManager extends NetworkManager {
	
	getPosts = (restaurant_id: number, params: ListParams): Promise<RequestResponse<GetPostsResponse>> => {
		return super.request('/restaurants/' + restaurant_id + '/posts', 'GET', null, {
			...params,
			user_id: ':current_user_id'
		})
	}

	handleLike = (restaurant_id: number, post_id: number, liked: boolean, likeId?: number): Promise<RequestResponse<HandleLikeResponse>> => {
		const baseUrl = '/restaurants/' + restaurant_id + '/posts/' + post_id + '/likes'
		const method = liked ? "POST" : "DELETE";
		const url = liked ? baseUrl : baseUrl + "/" + likeId;
		return super.request(url, method, { user_id: ":current_user_id" })
	}

	addComment = (restaurant_id: number, post_id: number, user_id: number, content: string): Promise<RequestResponse<AddCommentResponse>> => {
		return super.request('/restaurants' + restaurant_id + '/posts/' + post_id + 'comments', 'POST', {
			user_id: user_id,
			content: content
		})
	}

	deleteComment = (restaurant_id: number, post_id: number, comment_id: number): Promise<RequestResponse<DeleteCommentResponse>> => {
		return super.request('/restaurants' + restaurant_id + '/posts/' + post_id + 'comments/' + comment_id, 'DELETE')
	}
}