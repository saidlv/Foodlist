import NetworkManager, { showAll, StatusOnlyResponse, GenericParams } from './NetworkManager';
import { RequestResponse } from '@Models/RequestResponse';
import { ListParams } from '@Models/ListParams';
import { OrderType, Order } from '@Models/Order';
import { OrderRow } from '@Models/OrderRow';
import {  OrderItemForRequest } from '@Models/OrderItem';

export type CreatePayPalOrderResponse = {
	response: {
		token: string,
		approve_link: string
	}
} | null

export type CaputurePayPalOrderResponse = StatusOnlyResponse | null

export default class PayPalManager extends NetworkManager {
	constructor() {
		super()
	}

	createPayPalOrder = (order_id: number, schema: string): Promise<RequestResponse<CreatePayPalOrderResponse>> => {
		return super.request('/orders/' + order_id + '/payments/create', 'POST', {
			url_schema: schema
		})
	}

	capturePayPalOrder = (order_id: number) => {
		return super.request('/orders/' + order_id + '/payments/capture', 'POST')
	}
}
