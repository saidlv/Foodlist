import { createIconSetFromIcoMoon } from 'react-native-vector-icons';
import icoMoonConfig from './selection.json';
import { IconProps } from 'react-native-vector-icons/Icon';
import { Component } from 'react';
import { IconName } from './IconName';
import _MaterialIcon from 'react-native-vector-icons/MaterialIcons';
import _MaterialCommunityIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import MaterialIconNames from "react-native-vector-icons/glyphmaps/MaterialIcons.json"
import MaterialCommunityIconNames from "react-native-vector-icons/glyphmaps/MaterialCommunityIcons.json"

type FLIconProps = IconProps & {
	name: IconName
}
class FLIcon extends Component<FLIconProps, any> {}

const Icon: typeof FLIcon = createIconSetFromIcoMoon(icoMoonConfig, 'FoodList-Iconfont', 'FoodList-Iconfont.ttf') as unknown as typeof FLIcon;

export default Icon

export type MaterialIconName = keyof typeof MaterialIconNames
type MaterialIconProps = IconProps & {
	name: MaterialIconName
}
class MaterialIconType extends Component<MaterialIconProps, any> {}
export const MaterialIcon = _MaterialIcon as typeof MaterialIconType


export type MaterialCommunityIconName = keyof typeof MaterialCommunityIconNames
type MaterialCommunityIconProps = IconProps & {
	name: MaterialCommunityIconName
}
class MaterialCommunityIconType extends Component<MaterialCommunityIconProps, any> {}
export const MaterialCommunityIcon = _MaterialCommunityIcon as typeof MaterialCommunityIconType