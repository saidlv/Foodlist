import { User } from "@Models/User"
import { OrderItem } from "@Models/OrderItem"
import { OrderInfo } from "@Models/OrderInfo"
import { ItemsMap } from "@Models/ItemsMap"

export type ReduxAction = {
	type: string,
	user?: User | null,
	id?: number | null,
	skipAuth?: boolean,
	orderItems?: ItemsMap<OrderItem[]>,
	order?: OrderInfo
}

export const setUser = (user: User | null): ReduxAction => {
	return {
		type: "user",
		user: user
	}
}

export const setActiveRestaurant = (id: number): ReduxAction => {
	return {
		type: "restaurant",
		id: id
	}
}

export const setStorageValues = (skipAuth: boolean, activeRestaurant?: number): ReduxAction => {
	return {
		type: "storage",
		id: activeRestaurant,
		skipAuth: skipAuth
	}
}

export const updateShoppingCart = (items: ItemsMap<OrderItem[]>): ReduxAction => {
	return {
		type: "updateCart",
		orderItems: items
	}
}

export const saveOrder = (info: OrderInfo) : ReduxAction => {
	return {
		type: "orderInfo",
		order: info
	}
}