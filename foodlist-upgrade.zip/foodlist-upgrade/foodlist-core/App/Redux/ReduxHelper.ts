import { store } from "@Redux/Reducer"
import { groupByKey, ItemsMap } from "@Models/ItemsMap"
import { Service } from "@Models/Service"
import { services } from './StateFormat/services'
import { updateShoppingCart, saveOrder, setUser } from "./Actions"
import { OrderItem } from "@Models/OrderItem"
import { OrderInfo } from "@Models/OrderInfo"
import { UserAddress } from "@Models/UserAddress"
import { deepCopy, stringDefined } from "@FoodListCore/Global/GlobalProps"
import { Dish } from "@Models/Dish"
import { StaticData } from "@FoodListCore/Network/StaticData"
import { StackNavigationProp } from "@react-navigation/stack"
import { RestaurantParamList } from "@FoodListCore/Flows/Restaurant"
import { Discount } from "@Models/Discount"
import { Platform } from "react-native"
import AsyncStorage from "@react-native-community/async-storage"
import { MenuSection } from "@Models/MenuSection"
import { joinArrays } from "@FoodListCommon/utils"
import { mapById } from "@FoodListCommon/index"

export const getCurrentUser = () => {
	return store.getState().currentUser
}

export const isCurrentUser = (id: number | null | undefined) => {
	if (id) {
		let currentUser = getCurrentUser()?.id
		if (currentUser) {
			return currentUser == id
		}
	}
	return false
}

export const userLogged = () => {
	if(getCurrentUser()) {
		return true
	}
	return false
}

/**
 * route: RouteProp<{ Tab: { restaurant_id?: number } }, "Tab"
 */
export const getActiveRestaurant = (navigation: StackNavigationProp<RestaurantParamList>) => {
	//console.log("nav state", navigation.dangerouslyGetState())
	const parentState = navigation.dangerouslyGetParent()?.dangerouslyGetState()
	//console.log("parent state", parentState)
	const parent = parentState?.routes[parentState.index]
	const { params  } = parent || {}
	//console.log('parent params', params, parentState?.routeNames);

	// @ts-ignore
	const { restaurant_id } = params || {}

	if(restaurant_id) {
		return restaurant_id
	}
	return store.getState().activeRestaurant
}

const getCartKey = (restaurant_id: number | string) => {
	return `fl_cart_${restaurant_id}`
}

export const saveCartToStorage = (restaurant_id: number | string, items: OrderItem[]) => {
	const minified = items.map<OrderItem>(({ dish, dish_id, ...values }) => ({
		dish_id: dish?.id || dish_id,
		...values,
	}))
	return AsyncStorage.setItem(getCartKey(restaurant_id), JSON.stringify(minified))
}

export const loadCartFromStorage = async (restaurant_id: number): Promise<Partial<OrderItem>[] | null> => {
	try {
		const value = await AsyncStorage.getItem(getCartKey(restaurant_id))
		return value ? JSON.parse(value) : null
	} catch (e) {
		console.log("loadCart", e)
	}
	return null
}

export const sendCartUpdate = () => {
	const items = store.getState().orderItems
	const copy = Object.keys(items).reduce<ItemsMap<OrderItem[]>>((acc, item) => {
		acc[item] = items[item]?.concat()
		if(Platform.OS == "web") {
			saveCartToStorage(item, acc[item] || [])
		}
		return acc
	}, {})
	store.dispatch(updateShoppingCart(copy))
}

export const activeRestaurantChart = (orderItems: ItemsMap<OrderItem[]>, navigation: StackNavigationProp<RestaurantParamList>) => {
	return orderItems[getActiveRestaurant(navigation)] || []
}

export const setActiveRestaurant = (id: number, navigation: StackNavigationProp<any>) => {
	//console.log("SET PARAMS", id, navigation.dangerouslyGetState())
	const parent = navigation.dangerouslyGetParent()
	parent?.setParams({
		restaurant_id: id
	})
}

export const getServices = () => {
	return store.getState()["services"]
}

export const getRestaurantName = (navigation: StackNavigationProp<RestaurantParamList>) => {
	const rest_id = getActiveRestaurant(navigation)
	return StaticData.restaurants.find(rest => {
		return rest.id == rest_id
	})?.name || StaticData.appName
}

export const mapServices = (services: string[] | undefined): Service[] => {
	let mappedServices: ItemsMap<Service> = {}
	getServices().forEach((item) => {
		mappedServices[item.infoKey] = item
	})
	return (services || []).map((item) => {
		return mappedServices[item] ?? { id: -1, key: "", infoKey: "", label_it: ""}
	})
}

export const initReduxTranslations = () => {
	const _services = getServices()
	services().forEach(item => _services.push(item))
}

export const getOrderItems = (restaurant_id: number): OrderItem[] => {
	const items = store.getState()["orderItems"]
	const restItems = items[restaurant_id]
	if(restItems) {
		return restItems
	} else {
		items[restaurant_id] = []
		return items[restaurant_id]!
	}
}

export const loadPreviousCart = async (restaurant_id: number, menu: MenuSection[]) => {
	//TODO: integrare updateCartDishDiscounts
	const items = await loadCartFromStorage(restaurant_id)
	if(items && items.length > 0) {
		const dishes = joinArrays(menu.map(section => section.dishes))
		const mappedDishes = mapById(dishes)

		const orderItems: OrderItem[] = []
		for(let i = 0; i < items.length; i++) {
			const item = items[i]
			if(item.dish_id) {
				const dish = mappedDishes[item.dish_id]
				if(dish) {
					//TODO: controllare se le opzioni inserite vanno bene
					orderItems.push({
						...item,
						quantity: item.quantity || 1,
						restaurant_id,
						local_id: i + 1,
						dish,
					})
				}
			}
		}
		const cart = store.getState().orderItems
		store.dispatch(updateShoppingCart({
			...cart,
			[restaurant_id]: orderItems,
		}))
	}
}

export const updateCartDishDiscounts = (rest_id: number, dish_discounts: Discount[]) => {
	const mappedDishDiscounts = groupByKey(dish_discounts || [], "dish_id")
	const oldItems = getOrderItems(rest_id)
	if(oldItems.length > 0) {
		oldItems.forEach(item => {
			if(item.dish) {
				item.dish.discounts = mappedDishDiscounts[item.dish.id]
			}
		})
		sendCartUpdate() //per aggiornare il prezzo su OrderButton
	}
}

export const getOrderItemProgressiveId = (restaurant_id: number) => {
	const items = getOrderItems(restaurant_id)
	if(items.length == 0) {
		return 1
	}
	const last = items[items.length - 1]
	return last.local_id + 1
}

export const addToCart = (orderItem: OrderItem, restaurant_id: number) => {
	const items = getOrderItems(restaurant_id)
	items.push(orderItem)
	sendCartUpdate()
}

export const addOrUpdateCart = (dish: Dish, restaurant_id: number, quantity: number = 1) => {
	const items = getOrderItems(restaurant_id)
	const updateItem = items.findIndex((item) => {
		return item.dish?.id == dish.id && !stringDefined(item.notes)
	})
	if(updateItem != -1) {
		items[updateItem].quantity += quantity
		sendCartUpdate()
	} else {
		addToCart({
			dish,
			quantity,
			local_id: getOrderItemProgressiveId(restaurant_id),
			restaurant_id
		}, restaurant_id)
	}
}

export const removeFromCart = (dish: Dish, restaurant_id: number, quantity = 1) => {
	const items = getOrderItems(restaurant_id)
	let updateItem = items.findIndex((item) => {
		return item.dish?.id == dish.id && !stringDefined(item.notes)
	})
	if(updateItem == -1) {
		//se sono già stati eliminati tutti quelli senza note inizio a eliminare anche quelli con le note
		updateItem = items.findIndex((item) => {
			return item.dish?.id == dish.id
		})
	}
	const item = items[updateItem]
	if(updateItem != -1) {
		const qta = item.quantity
		if(qta > quantity) {
			item.quantity -= quantity
			sendCartUpdate()
		} else {
			removeItemFromCart(item, restaurant_id)
		}
	}
	else {
		//console.log("non trovato")
	}
}

export const removeAllFromCart = (dish: Dish, restaurant_id: number) => {
	const items = getOrderItems(restaurant_id)
	let updateItem
	do {
		updateItem = items.findIndex((item) => {
			return item.dish?.id == dish.id
		})
		if(updateItem != -1) {
			items.splice(updateItem, 1)
		}
	} while(updateItem != -1)
	sendCartUpdate()
}

export const removeItemFromCart = (item: OrderItem, restaurant_id: number) => {
	const items = getOrderItems(restaurant_id)
	const index = items.indexOf(item)
	items.splice(index, 1)
	sendCartUpdate()
}

export const addAddress = (address: UserAddress) => {
	const user = getCurrentUser()
	if(!user) {
		console.warn("WARN!! add address: USER undefined")
		return
	}
	const addresses = user.addresses || []
	addresses.push(address)

	store.dispatch(setUser(deepCopy(user)))
}

export const removeAddress = (id: number) => {
	const user = getCurrentUser()
	if(!user) {
		console.warn("WARN!! remove address: USER undefined")
		return
	}
	const addresses = (user?.addresses || []).filter(val => {
		if(val.id == id) return false
		return true
	})
	user.addresses = addresses
	store.dispatch(setUser(deepCopy(user)))
}

export const resetCart = (restaurant_id: number) => {
	store.dispatch(updateShoppingCart({
		...store.getState().orderItems,
		[restaurant_id]: []
	}))
	if(Platform.OS == "web") {
		AsyncStorage.removeItem(getCartKey(restaurant_id))
	}
}