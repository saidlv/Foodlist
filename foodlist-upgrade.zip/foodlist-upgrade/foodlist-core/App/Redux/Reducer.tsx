import { createStore } from 'redux';
import { ReduxState, initialState } from './StateFormat';
import { ReduxAction } from './Actions';

const merge = (state: ReduxState, updates: Partial<ReduxState>): ReduxState => {
	let newState: Partial<ReduxState> = {}
	for (let key in state) {
		newState[key] = state[key]
	}
	for (let key in updates) {
		newState[key] = updates[key]
	}
	return newState as ReduxState
}

export const parseAction = (action: ReduxAction): {} | Partial<ReduxState> => {
	switch (action.type) {
		case 'user': return {
			currentUser: action.user
		}
		case 'restaurant': return {
			activeRestaurant: action.id,
			orderItems: []
		}
		case 'storage': return {
			activeRestaurant: action.id,
			ignoreLogin: action.skipAuth,
			hasSelectedRestaurant: action.id !== undefined
		}
		case 'updateCart': return {
			orderItems: action.orderItems
		}
		case 'orderInfo': return {
			orderInfo: action.order
		}
	}
	return {}
}

export const reducer = (state: ReduxState = initialState, action: ReduxAction) => {
	return merge(state, parseAction(action))
}

export const store = createStore(reducer)
