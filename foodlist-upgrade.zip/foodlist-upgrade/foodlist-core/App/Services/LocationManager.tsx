import { Platform } from "react-native"
import { getLocationPermission, PERMISSION_RESULTS } from '@FoodListCore/Services/PermissionManager';
import Geolocation, { GeoError } from 'react-native-geolocation-service';
import { openSettings } from 'react-native-permissions';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import AndroidOpenSettings from 'react-native-android-open-settings'
import { Location } from "@Models/Location";

export class LocationConfig {
	static rejectedGPS: boolean = false;
	static rejectedPermissions: boolean = false;
	static GPSStatus: number = 0;
}

export const LOCATION_CODES: {
	PERMISSION_DENIED: number,
	LOCATION_ERROR: number,
	NO_GPS_ACTIVE: number
} = {
	PERMISSION_DENIED: 0,
	LOCATION_ERROR: 1,
	NO_GPS_ACTIVE: 2
}

export const refreshLocationConfig = (): Promise<void> => {
	return new Promise(async (resolve, reject) => {
		let response = await getLocationPermission(LocationConfig.rejectedPermissions);

		//console.log('Permission result in refresh location config', response);
		if (response == PERMISSION_RESULTS.GRANTED) {
			LocationConfig.rejectedPermissions = false;
		}
		/* if(response == PERMISSION_RESULTS.DENIED || response == PERMISSION_RESULTS.BLOCKED) {
				//console.log('No permissions');
		} else {
				LocationConfig.rejectedPermissions = false;
		}   */

		//console.log('Current GPS status', LocationConfig.GPSStatus);
		if (LocationConfig.GPSStatus == 2 || LocationConfig.GPSStatus == 3) {
			//console.log('Resetting rejectedGPS to false');
			LocationConfig.rejectedGPS = false;
		}

		resolve();
	});
}

const _getCurrentLocation = (forcePopup?: boolean): Promise<Location> => {
	//console.log('Location config', LocationConfig.rejectedPermissions, LocationConfig.rejectedGPS);
	return new Promise(async (resolve: (result: Location) => void, reject: (err: { error: number, message?: GeoError }) => void) => {
		setTimeout(() => {
			if (LocationConfig.rejectedGPS && forcePopup != true) {
				reject({ error: LOCATION_CODES.NO_GPS_ACTIVE });
			} else {
				if (Platform.OS == 'android') {
					RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({ interval: 10000, fastInterval: 5000 })
						.then(data => {
							// The user has accepted to enable the location services
							// data can be :
							//  - "already-enabled" if the location services has been already enabled
							//  - "enabled" if user has clicked on OK button in the popup
							performGetCurrentLocation(resolve, reject);
						}).catch(err => {
							// The user has not accepted to enable the location services or something went wrong during the process
							// "err" : { "code" : "ERR00|ERR01|ERR02", "message" : "message"}
							// codes : 
							//  - ERR00 : The user has clicked on Cancel button in the popup
							//  - ERR01 : If the Settings change are unavailable
							//  - ERR02 : If the popup has failed to open
							if (err.code == "ERR00") {
								LocationConfig.rejectedGPS = true;
							}
							reject({ error: LOCATION_CODES.NO_GPS_ACTIVE });
						});
				} else {
					performGetCurrentLocation(resolve, reject);
				}
			}
		})
	});
}

const performGetCurrentLocation = (
	resolve: (result: Location) => void,
	reject: (err: { error: number, message?: GeoError }) => void
): void => {
	getLocationPermission(LocationConfig.rejectedPermissions).then(response => {
		if (LocationConfig.rejectedPermissions || ((response == PERMISSION_RESULTS.DENIED || response == PERMISSION_RESULTS.BLOCKED) /* && !LocationConfig.rejectedPermissions */)) {
			LocationConfig.rejectedPermissions = true;
			reject({ error: LOCATION_CODES.PERMISSION_DENIED });
		} else {
			getLocationPermission(LocationConfig.rejectedPermissions).then((response) => {
				if (response == PERMISSION_RESULTS.DENIED || response == PERMISSION_RESULTS.BLOCKED) {
					LocationConfig.rejectedPermissions = true;
					reject({ error: LOCATION_CODES.PERMISSION_DENIED });
				} else {
					Geolocation.getCurrentPosition(position => {
						let latitude = position.coords.latitude
						let longitude = position.coords.longitude
						//console.log('Resolving location:', latitude, longitude);
						resolve({
							latitude: latitude,
							longitude: longitude
						});
						//callback && callback(latitude, longitude)
					},
						(error) => {
							reject({ error: LOCATION_CODES.LOCATION_ERROR, message: error });
							//console.log(error.message)
						}, {
						enableHighAccuracy: true,
						timeout: 30000,
						maximumAge: 1000,
						showLocationDialog: false
					})
				}
			})
		}
	})
}

export const getCurrentLocation = _getCurrentLocation;

export const openLocationPermissionSettings = (): void => {
	if (Platform.OS == 'android') {
		AndroidOpenSettings.locationSourceSettings()
	} else {
		openSettings();
	}
}

export const openLocationSettings = (): void => {
	if (Platform.OS == 'android') {
		AndroidOpenSettings.locationSourceSettings()
	} else {
		openSettings();
	}
}
