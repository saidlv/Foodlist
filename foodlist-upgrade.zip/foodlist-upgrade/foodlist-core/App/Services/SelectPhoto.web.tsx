import { ImageForMultipart } from '@Models/ImageForMultipart';

export enum PICKER_TYPES {
	CAMERA = 0,
	LIBRARY = 1
}

export type PickedCB = (image: ImageForMultipart) => void

class SelectPhotoService {

	pickImage = (type: PICKER_TYPES, onImagePicked: PickedCB) => {

	}
}
export default SelectPhotoService;
