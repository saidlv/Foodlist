import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Platform, StyleSheet } from 'react-native';
import ImagePicker, { ImagePickerResponse, ImagePickerOptions } from 'react-native-image-picker';
import ImageResizer from 'react-native-image-resizer';
import Fs from 'react-native-fs';
import Permission from 'react-native-permissions';
import AndroidOpenSettings from 'react-native-android-open-settings'
import { getCameraPermissionStatus, getLibraryPermissionStatus, requestCameraPermission, requestLibraryPermission, PERMISSION_RESULTS, AndroidIOSPermissionStatus } from '@FoodListCore/Services/PermissionManager';
import { translate } from '@FoodListCore/I18n';
import { ImageForMultipart } from '@Models/ImageForMultipart';

export enum PICKER_TYPES {
	CAMERA = 0,
	LIBRARY = 1
}

type PermissionStatusResponse = {
	camera: AndroidIOSPermissionStatus,
	photo: AndroidIOSPermissionStatus
}

export type PickedCB = (image: ImageForMultipart) => void

class SelectPhotoService {
	private onImagePicked?: PickedCB

	pickImage = (type: PICKER_TYPES, onImagePicked: PickedCB) => {
		this.onImagePicked = onImagePicked
		this.tryPickImage(type)
	}
	
	private tryPickImage = async (type: PICKER_TYPES) => {
		const options: ImagePickerOptions = {
			title: translate("pickImage"),
			/* storageOptions: {
				skipBackup: true,
				path: 'images',
			}, */
			mediaType: "photo",
			noData: true,
			rotation: 360
		};

		let response = await this.getPermissionsStaus();
		if (this.permissionOk(response, type)) {
			this.startImagePicker(options, type);
		} else {
			let response = await this.requestPermissions(type);
			if (this.permissionOk(response, type)) {
				this.tryPickImage(type);
			} else {
				this.permissionAlert();
			}
		}
	}

	private getPermissionsStaus = () => {
		return new Promise<PermissionStatusResponse>(async (resolve) => {
      /* Permission.checkMultiple(['camera', 'photo']).then(response => {
        //('Camera permission', response.camera, 'Photo permission', response.photo);
        resolve(response);
      }); */
			let cameraPermission = await getCameraPermissionStatus();
			let libraryPermission = await getLibraryPermissionStatus();
			resolve({
				camera: cameraPermission,
				photo: libraryPermission
			});
		});
	}

	private requestPermissions = async (type: PICKER_TYPES) => {
		return new Promise<Partial<PermissionStatusResponse>>(async (resolve, reject) => {
			if (type == PICKER_TYPES.CAMERA) {
				let cameraPermission = await requestCameraPermission();
				resolve({ camera: cameraPermission });
			} else if (type == PICKER_TYPES.LIBRARY) {
				let photoPermission = await requestLibraryPermission();
				resolve({ photo: photoPermission });
			}
		});
	}

	private permissionOk = (response: Partial<PermissionStatusResponse>, type: PICKER_TYPES) => {
		if (type == PICKER_TYPES.CAMERA) return response.camera == PERMISSION_RESULTS.GRANTED;
		if (type == PICKER_TYPES.LIBRARY) return response.photo == PERMISSION_RESULTS.GRANTED;
	}

	private startImagePicker = (options: ImagePickerOptions, type: PICKER_TYPES) => {
		if (type == PICKER_TYPES.CAMERA) {
			ImagePicker.launchCamera(options, (response) => {
				// Same code as in above section!
				this.handlePickerResponse(response);
			});
		} else if (type == PICKER_TYPES.LIBRARY) {
			ImagePicker.launchImageLibrary(options, (response) => {
				// Same code as in above section!
				this.handlePickerResponse(response);
			});
		}
	}

	private handlePickerResponse = (response: ImagePickerResponse) => {
		if (response.didCancel) {
			// User cancelled image picker
		} else if (response.error) {
			console.log("error", response.error)
			//errore: response.error
			this.permissionAlert();
		} else {
			this.resize(response).then((response) => {
				this.onImagePicked?.(response)
        /*
        this.props.onImagePicked({
          fileName: response.fileName,
          uri: response.uri,
          type: response.type,
          fileSize: response.fileSize,
          isVertical: response.isVertical,
          latitude: response.latitude,
          longitude: response.longitude,
          timestamp: response.timestamp,
          height: response.height,
          width: response.width,
          path: response.path,
          originalRotation: response.originalRotation 
        });*/
			});
		}
	}

	private permissionAlert = () => {
		Alert.alert(translate("libraryPermissionTitle"), translate("libraryPermissionMessage"), [{
			text: translate("goToSettings"),
			onPress: () => {
				if (Platform.OS == "android") {
					AndroidOpenSettings.appDetailsSettings()
				} else {
					Permission.openSettings();
				}
			}
		}, {
			text: translate("actionClose"),
			onPress: () => { }
		}]);
	}

	private getResizePath() {
		return Platform.select({
			ios: Fs.MainBundlePath,
			android: Fs.DocumentDirectoryPath
		});
	}

	private resize(response: ImagePickerResponse): Promise<ImageForMultipart> {
		return new Promise((resolve, reject) => {
			const path = this.getResizePath();
			ImageResizer.createResizedImage(response.uri, 1200, 1200, 'JPEG', 50, 0, path).then(({ uri }) => {
				resolve({
					uri: uri,
					fileName: "image.jpeg",
					type: "image/jpg",
				})
			})
		})
	}
}
export default SelectPhotoService;
