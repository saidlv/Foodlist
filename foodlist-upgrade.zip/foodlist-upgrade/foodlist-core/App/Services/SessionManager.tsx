import AsyncStorage from "@react-native-community/async-storage"
import { setUser, setStorageValues } from '@FoodListCore/Redux/Actions'
import { store } from '@Redux/Reducer'
import { alert, isDefined } from '@FoodListCore/Global/GlobalProps'
import { User } from "@Models/User";
import { ReduxState } from "@Redux/StateFormat";
import { sha256 } from 'react-native-sha256';
import { Platform } from "react-native";

export type SupportedSocial = "google" | "facebook" | "apple" | "instagram"

export default class SessionManager {


	static AUTH_KEY = "foodlist_auth_token";
	static USER_KEY = "foodlist_auth_user"; //TODO: need to change value inside FoodList/App/Redux/StateFormat too
	static PASS_KEY = "foodlist_auth_password";
	static ACTIVE_RESTAURANT_KEY = "app_active_rest"
	static SKIP_AUTH_KEY = "app_skip_auth"
	static SECRET = "ZPbjxLYmk2pYETUbYkE6uO0QTT2IftiS"
	static SOCIAL_LOGIN_KEY = "logged_with_social"
	static APPLE_SIGNIN_USERID = "apple_signin_userid"
	static APPLE_SIGNIN_TOKEN = "apple_signin_foodlist-token"

	constructor() { }

	static getRouteNameFor(isLogged: boolean): "TabBarPage" | "MainAuthPage" {
		return isLogged ? "TabBarPage" : "MainAuthPage"
	}

	static async saveToken(token: string): Promise<void> {
		try {
			await this.setSkipAuth(false)
			await AsyncStorage.setItem(SessionManager.AUTH_KEY, token);
		} catch (error) {
			// Error saving data
		}
	}

	static async getSavedToken() {
		const token = await AsyncStorage.getItem(SessionManager.AUTH_KEY)
		//TODO: check if not expired
		return token
	}

	static async setCurrentPassword(password: string): Promise<void> {
		if(Platform.OS != "web") {
			return await AsyncStorage.setItem(SessionManager.PASS_KEY, password);
		}
	}

	static async setCurrentUser(user: User): Promise<void> {
		var userRaw = JSON.stringify(user);
		this.addUserToRedux(user)
		return await AsyncStorage.setItem(SessionManager.USER_KEY, userRaw);
	}

	static async setActiveRestaurant(id: number): Promise<void> {
		return await AsyncStorage.setItem(SessionManager.ACTIVE_RESTAURANT_KEY, id.toString())
	}

	static async setSkipAuth(skip: boolean): Promise<void> {
		store.dispatch(setStorageValues(skip, store.getState().activeRestaurant))
		return await AsyncStorage.setItem(SessionManager.SKIP_AUTH_KEY, skip ? "T" : "F")
	}

	static getMockUser() {
		return {
			"id": 2,
			"username": "leomessi",
			"email": "leo@fcbarcelona.es",
			"password": "cab40eee87c81cdaf414045bd2081bf9",
			"first_name": "Lionel Andrés",
			"last_name": "Messi Cuccittini",
			"photo": null,
			"phone": "+34 123456789",
			"date_of_birth": "1987-06-24",
			"gender": "M",
			"points": 0,
			"created_at": "2019-01-06T19:12:06.000Z",
			"updated_at": "2019-01-06T19:12:09.000Z",
			"user_level_id": 1,
			"reviews_count": 2,
			"followers": 1,
			"following": 0
		}
	}

	static async loadStorageToRedux() {
		if(Platform.OS != "web") {
			await AsyncStorage.removeItem(SessionManager.AUTH_KEY) //needed to make sure to get a new token on app startup
		}
		const skipAuth = await AsyncStorage.getItem(SessionManager.SKIP_AUTH_KEY)
		const restId = await AsyncStorage.getItem(SessionManager.ACTIVE_RESTAURANT_KEY)
		let id: number | undefined
		if(restId) {
			id = parseInt(restId)
		}
		store.dispatch(setStorageValues(skipAuth === "T", id))
		await this.getCurrentUser()
	}

	static async getCurrentUser(): Promise<User | null> {
		let reduxState: ReduxState = store.getState()
		if (isDefined(reduxState.currentUser) && reduxState.currentUser?.id != -1) {
			return reduxState.currentUser ?? null
		} else {
			const user = await AsyncStorage.getItem(SessionManager.USER_KEY);
			if (user == null) {
				this.addUserToRedux(null)
				return null;
			}
			const parsedUser = JSON.parse(user)
			this.addUserToRedux(parsedUser)
			return parsedUser;
		}
	}

	static async userWasLogged() {
		const socialLogin = await AsyncStorage.getItem(SessionManager.SOCIAL_LOGIN_KEY) as unknown as SupportedSocial | null
		if(socialLogin) return true

		const values = await Promise.all([SessionManager.getCurrentUser(), SessionManager.getCurrentPassword()])
		const user = values[0]
		const password = values[1]
		if (user && password && user.username) {
			return true
		}
		return false
	}

	static addUserToRedux = (parsedUser: User | null): void => {
		store.dispatch(setUser(parsedUser))
	}

	static async getCurrentPassword(): Promise<string | null> {
		return await AsyncStorage.getItem(SessionManager.PASS_KEY);
	}

	static async getAnonymousToken(secret: string, version: string) {
		const input = secret + "|" + version
		return await sha256(input)
    //return crypto.createHash('sha256').update(input).digest('hex');
	}

	static async _getToken(): Promise<string | null> {
		return (await SessionManager.getSavedToken()) ?? (await SessionManager.getAnonymousToken(SessionManager.SECRET, "1.0.0"))
	}

	static async saveSocialLogin(social: SupportedSocial) {
		await this.setSkipAuth(false)
		await AsyncStorage.setItem(this.SOCIAL_LOGIN_KEY, social)
	}

	static async saveAppleAuth(userId: string, long_lived_token: string) {
		await AsyncStorage.setItem(this.APPLE_SIGNIN_USERID, userId)
		await AsyncStorage.setItem(this.APPLE_SIGNIN_TOKEN, long_lived_token)
	}
	static async getAppleAuth() {
		return await Promise.all([AsyncStorage.getItem(this.APPLE_SIGNIN_USERID), AsyncStorage.getItem(this.APPLE_SIGNIN_TOKEN)])
	}

	static async logout(): Promise<void> {
		try {
			this.addUserToRedux(null)
			await AsyncStorage.removeItem(SessionManager.AUTH_KEY);
			await AsyncStorage.removeItem(SessionManager.USER_KEY);
			await AsyncStorage.removeItem(SessionManager.PASS_KEY);
			await AsyncStorage.removeItem(SessionManager.SOCIAL_LOGIN_KEY);
			await AsyncStorage.removeItem(SessionManager.APPLE_SIGNIN_USERID);
		} catch (error) {
			// Error saving data
		}
	}
}
