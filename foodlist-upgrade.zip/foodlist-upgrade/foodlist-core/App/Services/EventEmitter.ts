import { Any } from "@Models/Any"

export type EventListener = (...args: Any) => void
export type Unsubscribe = () => void

export const followEvent = (id: number) => {
	return "followChange/" + id
}

export const genericFollowEvents = () => {
	return "followChange"
}

export default class EventEmitter {
	events: {
		[index: string]: EventListener[] | undefined
	}

	constructor() {
		this.events = {}
	}

	on = (event: string, cb: EventListener): Unsubscribe => {
		if (!this.events[event]) {
			this.events[event] = []
		}
		this.events[event]!.push(cb)
		return () => {
			this.unsubscribe(event, cb)
		}
	}

	unsubscribe = (event: string, cb: EventListener) => {
		const listeners = this.events[event]
		if (listeners) {
			const index = listeners.indexOf(cb)
			if (index >= 0) {
				listeners.splice(index, 1)
				if (listeners.length == 0) {
					delete this.events[event]
				}
			}
		}
	}

	emit = (event: string, ...args: Any[]) => {
    /* //console.log("Active events: ", Object.keys(this.events).length)
    //console.log("Active listeners: ", Object.keys(this.events).map(key => { return this.events[key]?.length }))
    //console.log("Events", this.events) */
		setTimeout(() => {
			const listeners = this.events[event] ?? []
			//console.log("Firing " +listeners.length +" listeners")
			listeners.forEach(listener => {
				listener(...args)
			})

			const path = event.split("/")
			if(path.length > 1) {
				const genericEvent = path[0]
				const id = path[1]
				const genericListeners = this.events[genericEvent] ?? []
				genericListeners.forEach(listener => {
					listener(...args, id)
				})
			}
		})
	}

}