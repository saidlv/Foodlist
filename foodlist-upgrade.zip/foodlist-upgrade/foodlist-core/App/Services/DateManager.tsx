import 'moment/locale/it';
import { Time, RawTime } from '@Models/Time'
import { Day } from '@Models/Day'
import { Restaurant } from '@Models/Restaurant';
import { hasDelivery } from '@FoodListCore/Flows/Restaurant/integration-component';
import { translate } from '@FoodListCore/I18n';
export * from "@FoodListCommon/DateManager";
import * as D from "@FoodListCommon/DateManager"

type TimeResult = {
	open_now: boolean,
	time_string?: string | null,
	week?: Day[]
}

//Questo Controlla tramite le due fasce orarie SOLO se il locale è aperto adesso e se aperto setta quale tra le due fasce è quella attuale
//Per settare quale fascia è quella attuale modifica il valore tramite la referenza
export const isNow = (todayElement: Time | null, yesterdayLast?: Time | null): TimeResult => {
	const time = D.getMomentTime(D.todayHour(), true)//moment(todayHour(), format)

	const openingTime = D.getMomentTime(yesterdayLast?.from || "", true)
	const closingTime = D.getMomentTime(yesterdayLast?.to || "", true)
	const openingTimeToday = !!todayElement ? D.getMomentTime(todayElement.from, true) : null
	const closingTimeToday = !!todayElement ? D.getMomentTime(todayElement.to, true) : null

	if (!openingTimeToday || time < openingTimeToday) {
		if (yesterdayLast) {
			if (openingTime < closingTime) { //l'orario del giorno prima non finisce oggi
				return {
					open_now: false
				}
			} else {
				if (time < closingTime/* !time.isBetween(closingTime, openingTime) */) {
					yesterdayLast.isNow = true;
					return {
						open_now: true,
						time_string: "" + yesterdayLast.from + " - " + yesterdayLast.to
					}
				} else {
					return {
						open_now: false
					}
				}
			}
		} else {
			return {
				open_now: false
			}
		}
	} else if (openingTimeToday && closingTimeToday) {
		if (openingTimeToday < closingTimeToday) {
			if (time.isBetween(openingTimeToday, closingTimeToday)) {
				if(todayElement) {
					todayElement.isNow = true;
				}
				return {
					open_now: true,
					time_string: "" + todayElement?.from + " - " + todayElement?.to
				}
			}
		} else {
			if (!time.isBetween(closingTimeToday, openingTimeToday)) {
				if(todayElement) {
					todayElement.isNow = true;
				}
				return {
					open_now: true,
					time_string: "" + todayElement?.from + " - " + todayElement?.to
				}
			}
		}
	}
	return {
		open_now: false
	}
}

export const timesAvailable = (restaurant: Restaurant | null | undefined): boolean => {
	return (restaurant?.restaurant_hours || []).length > 0 || restaurant?.closed || false
}

//Analizza tutti gli orari e ritorna se è aperto ora, insieme alla stringa da visualizzare
export const isOpenNow = (restaurant: Restaurant | null): TimeResult | undefined => {
	const timeArray: RawTime[] = restaurant?.restaurant_hours || []
	let result: TimeResult = {
		open_now: false,
		time_string: "",
		week: []
	}

	let foundOpen = false

	if (timeArray.length != 0) {
		let times = D.formatWeekTimes(timeArray)
		let todayIndex = -1
		for (let index = 0; index < times.length; index++) {
			const element = times[index];
			if (element.isToday) {
				todayIndex = index
			}
		}

		if (todayIndex == -1) return {
			open_now: false,
			week: times
		}

		let tommorowIndex = (todayIndex + 1)
		let yesterdayIndex = (todayIndex - 1)

		if (yesterdayIndex == -1) {
			yesterdayIndex = 6
		}
		if (tommorowIndex == 7) {
			tommorowIndex = 0
		}

		const yesterday = times[yesterdayIndex]
		const today = times[todayIndex]
		const tommorow = times[tommorowIndex]

		const lastIndex = yesterday?.times?.length
		let yesterdayLast: Time | null = null

		if (lastIndex != 0) {
			yesterdayLast = yesterday?.times?.[lastIndex - 1]
		}

		for (let index = 0; index < today.times.length; index++) {
			const element = today.times[index];
			result = {
				...isNow(element, yesterdayLast),
				week: times,
			}
			if (result?.open_now) {
				foundOpen = true
				break
			}
		}

		if (!foundOpen) {
			result = {
				...isNow(null, yesterdayLast),
				week: times
			}
			if (result?.open_now) {
				foundOpen = true
			}
		}

		if (!foundOpen) {
			let found = false
			for (let index = 0; index < today.times.length; index++) {
				const element = today.times[index];
				if (D.todayHour() < element.from) {
					found = true
					result = {
						open_now: false,
						time_string: "APRE ALLE " + element.from,
						week: times
					}
					break;
				}
			}

			if (!found) {
				if (tommorow.times.length != 0) {
					result = {
						open_now: false,
						time_string: "APRE DOMANI ALLE " + tommorow.times[0].from,
						week: times
					}
				} else {
					result = {
						open_now: false,
						time_string: translate(restaurant && hasDelivery(restaurant) ? "closedTakeawayOnly" : "closed").toUpperCase(),
						week: times
					}
				}
			}
		}

		return result
	}
	return //orari non disponibili, né aperto né chiuso
}