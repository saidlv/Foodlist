import React, { ReactNode, ReactElement } from 'react';
import TouchableOpacity from '@FoodListCore/Components/TouchableFixed';
import { View, Alert, ViewStyle, StyleProp, Platform } from 'react-native';
import Icon from '@FoodListCore/Iconfont/FoodListIconfont';
import { Photo } from '@Models/Photo';
import { ImageSource } from '@Models/ImageSource';
import { Restaurant } from '@Models/Restaurant';
import { Dish } from '@Models/Dish';
import { Review } from '@Models/Review';
import { Notification } from '@Models/Notification';
import { ItemsMap } from '@Models/ItemsMap';
import { Any } from '@Models/Any';
import { translate } from '@FoodListCore/I18n';
import { StackNavigationProp } from '@react-navigation/stack';
import { IconName } from '@FoodListCore/Iconfont/IconName';
import { OrderItem } from '@Models/OrderItem';
import { UserAddress } from '@Models/UserAddress';
import { printDay as cPrintDay } from '@FoodListCommon/DateManager';
import { formatPrice as _formatPrice } from "@FoodListCommon/prices"
import appConfig from "@config/custom"
import { getCategoryDefaultImage } from "@FoodListCommon/images"
import { spacing } from './Constants';
import { DEFAULT_IMAGES_BASEURL } from './WebHelpers';
import _ from "underscore";
import { resolveHref } from '@FoodListCommon/utils';

export { colors, themeColors, fontSizes, spacing as margins, regex } from "./Constants"

export const termsLink = "https://foodlist.eu/documents/Termini_e_Condizioni.pdf";
export const privacyLink = "https://foodlist.eu/documents/Informativa_Privacy.pdf";
export const partnerTermsLink = "https://foodlist.eu/documents/Condizioni_generali_Partner.pdf";

/* Ritorna la stringa iso del locale corrente.
 * se withState = true ritorna anche le info dello stato (en-US, it-IT)
 * se false, ritorna solo il locale (en, it)
 */
/* export const currentLocale = (withState: boolean): string => {
	let locale
	if (Platform.OS == 'android') {
		locale = NativeModules.I18nManager.localeIdentifier
	} else {
		locale = NativeModules.SettingsManager.settings.AppleLocale || NativeModules.SettingsManager.settings.AppleLanguages[0]
	}


	if (withState) return locale;
	return locale.split("-")[0];
} */

export const useForceUpdate = () => {
	const [_, forceUpdate] = React.useState(false)
	return React.useCallback(() => {
		forceUpdate(s => !s)
	}, [])
}

export const upperFirstChar = (text: string) => {
	if(text && text.length > 0) {
		const head = text.substr(0, 1).toUpperCase()
		const tail = text.substr(1)
		return head + tail
	}
	return ""
}

export const length = (array: Any) => {
	if (array && Array.isArray(array)) {
		return array.length
	}
	return 0
}

export const printDay = (day: moment.Moment, format?: string) => {
	return cPrintDay(day, translate, format)
}

export const dishImage = (fileName: string, thumb: boolean): string => {
	return _image("reviews/dishes", fileName, thumb)
}

export const restaurantImage = (fileName: string, thumb: boolean): string => {
	return _image("reviews/restaurants", fileName, thumb)
}
export const _image = (prefix: string, fileName: string, thumb: boolean): string => {
	const number = fileName.substring(0, fileName.indexOf("."));
	const id = number.slice(-2);
	if (thumb) fileName.replace(".", "_thumb.");
	return "https://foodlist.eu/uploads/" + prefix + "/" + id + "/" + fileName;
}
export const returnIfTrue = <T extends Any>(val: T, fn: (val: T) => boolean): T | null => {
	if (fn(val)) return val;
	return null;
}


export const usernameErrorText = (text?: string): string => {
	if (stringDefined(text)) {
		if (text?.indexOf(" ") != -1) {
			return translate("dontInsertSpaces")
		}
		if (text?.indexOf("@") != -1) {
			return translate("dontInsertAt")
		}
		if (text?.length < 3) {
			return translate("atLeast3Chars")
		}
	}
	return translate("notValid")
}

export const resetNavigation = <T extends {}> (navigation: StackNavigationProp<T>, routeName: string & keyof T) => {
	navigation?.reset({
		index: 0,
		routes: [{
			name: routeName
		}]
	})
}
export const when = <T extends {}>(cond: boolean | undefined | null, style: StyleProp<T>): StyleProp<T | {}> => {
	return whenElse(cond, style, {});
}
export const whenElse = <T extends {}>(cond: boolean | undefined | null, style: StyleProp<T>, elseStyle: StyleProp<T>): StyleProp<T> => {
	if (cond) {
		return style
	}
	return elseStyle
}

export const iconStyle = {}
export const iconNamed = (name: IconName, onPress?: () => void, size = 17, color = "#fff", IconComponent = Icon): ReactElement => {
	if (onPress) {
		return (
			<TouchableOpacity onPress={onPress} style={{ height: "100%", alignItems: "center", justifyContent: "center" }}>
				<IconComponent style={{ marginHorizontal: spacing.iconsPadding }} name={name} size={size} color={color} />
			</TouchableOpacity>
		)
	} else {
		return <IconComponent name={name} size={size} color={color} />
	}
}

export const getSource = (item: Photo, thumb?: boolean): ImageSource => {
	return { uri: thumb ? item.thumbUrl : item.fullUrl, priority: thumb ? "high" : "low" }
}

export const getDishRestaurant = (dish: Dish | undefined | null): Restaurant | undefined => {
	return dish?.section?.orderings?.[0]?.menu?.restaurant
}

export const imagesRestaurant = (data: Restaurant | Dish | null, thumb?: boolean): ImageSource[] => {
	if(!data) return []
	let images: ImageSource[] = []
	if (data?.photos && data?.photos.length != 0) {
		data.photos.forEach(item => {
			images.push(getSource(item, thumb))
		})
	}
	if(images.length <= 1 && appConfig.showReviewImages) {
		if(data.review_photos) {
			data.review_photos.forEach(item => {
				images.push(getSource(item, thumb))
			})
		} else if(data.review_photo) {
			images.push(getSource(data.review_photo, thumb))
		}
	}
	if (images.length == 0 && "g_photo" in data && data.g_photo) {
		images.push(getSource(data.g_photo, thumb))
		//images.push(defaultRestaurantImage())
		const headerImage = getCategoryDefaultImage((data.restaurant_categories || []).map(c => c.label_it), data?.id)
		images.push(headerImage ? {
			uri: resolveHref(DEFAULT_IMAGES_BASEURL, headerImage),
		} : defaultRestaurantImage())
	}
	return images
}

export const defaultRestaurantImage = (): ImageSource => {
	if(Platform.OS == "web") {
		return {
			uri: resolveHref(DEFAULT_IMAGES_BASEURL, "ristorante.jpg"),
		}
	}
	return require('@FoodListCore/Assets/Images/ristorante.jpg')
}
export const defaultDishImage = (): ImageSource => {
	if(Platform.OS == "web") {
		return {
			uri: resolveHref(DEFAULT_IMAGES_BASEURL, "piatto.jpg"),
		}
	}
	return require('@FoodListCore/Assets/Images/piatto.jpg');
}

export const imageRestaurant = (data: Restaurant | null, thumb?: boolean): ImageSource => {
	return imagesRestaurant(data, thumb)?.[0] || defaultRestaurantImage()
}

export const imagesFood = imagesRestaurant

type GalleryImages = { images: ImageSource[], thumbImages: ImageSource[], isDefault?: boolean }

export const getGalleryImages = (item: Restaurant | Dish | null): GalleryImages | null => {
	const images = imagesRestaurant(item, false)
	if(images.length == 0) {
		return null
	}
	const thumbImages = imagesRestaurant(item, true)
	if(images.length > 1) {
		return { images: images.slice(1), thumbImages: thumbImages.slice(1) }
	}
	return { images, thumbImages }
}
export const getRestaurantGalleryImages = (item: Restaurant | null): GalleryImages => {
	return getGalleryImages(item) || { images: [defaultRestaurantImage()], thumbImages: [defaultRestaurantImage()], isDefault: true }
}
export const getDishGalleryImages = (item: Dish | null): GalleryImages => {
	return getGalleryImages(item) || { images: [defaultDishImage()], thumbImages: [defaultDishImage()], isDefault: true }
}

export const realImageFood = (data: Dish | null, thumb?: boolean): ImageSource | null => {
	return imagesFood(data, thumb)?.[0]
}

export const imageFood = (data: Dish | null, thumb?: boolean): ImageSource => {
	return realImageFood(data, thumb) || defaultDishImage()
}

export const backIcon = (navigation: StackNavigationProp<any>, action?: () => void): ReactNode => {
	return iconNamed("back-arrow", () => {
		if (action == undefined) {
			navigation.goBack()
		} else {
			action();
		}
	}, 14)
}

export const inlineIcons = (...icons: ReactElement[]): ReactElement => {
	return (
		<View style={{ height: "100%", flexDirection: "row" }}>
			{icons.map((item, index) => {
				if (icons[index].props) {
					icons[index].props.key = index
				}
				let style: ViewStyle = {
					overflow: 'hidden'
				}
				if (index == 0) {
					style.marginRight = -10
				} else if (index == icons.length - 1) {
					style.marginLeft = -10
				} else {
					style.marginLeft = -10
					style.marginRight = -10
				}
				return (
					<View key={index} style={{ overflow: 'hidden' }}>
						<View style={style}>{icons[index]}</View>
					</View>
				)
			})}
		</View>
	)
}

/* export const slideTransitionConfig = (): TransitionEvent | null => {
  if(Platform.OS === "android") {
    return {
      transitionSpec: {
        duration: 750,
        easing: Easing.out(Easing.poly(4)),
        timing: Animated.timing,
        useNativeDriver: true,
      },
      screenInterpolator: sceneProps => {
        const { layout, position, scene } = sceneProps

        const thisSceneIndex = scene.index
        const width = layout.initWidth

        const translateX = position.interpolate({
          inputRange: [thisSceneIndex - 1, thisSceneIndex],
          outputRange: [width, 0],
        })

        return { transform: [ { translateX } ] }
      },
    }
  }
  return null;
} */

export const formatPrice = _formatPrice

export const mapByKey = <T extends {}>(options: T[], key: string): ItemsMap<T> => {
	return options.reduce((accumulator: ItemsMap<T>, item) => {
		// @ts-ignore
		const _key = item[key]
		if (isDefined(_key)) {
			accumulator[_key?.toString()] = item
		}
		return accumulator
	}, {})
}

export const mapById = <T extends { id?: number }>(options: T[]): ItemsMap<T> => {
	return mapByKey(options, "id")
}

export const filterOrderItems = (orderItems: OrderItem[], restaurant_id: number) => {
	return orderItems.filter(item => {
		return item.restaurant_id == restaurant_id
	})
}

export const calculateMeanStar = (item: Review): number => {
	const rating_location = item.rating_location
	const rating_price = item.rating_price
	const rating_quality = item.rating_quality
	const rating_service = item.rating_service
	return (rating_location + rating_price + rating_quality + rating_service) / 4
}

export const deepCopy = <T extends {} | []>(obj: T): T => {
	return JSON.parse(JSON.stringify(obj))
}

export const isDefined = (item: Any): boolean => {
	return item != null && item != undefined
}

export const stringDefined = (item: Any) => {
	return isDefined(item) && typeof item == "string" && item.length > 0
}

export const addhttp = (url: string): string => {
	if (url && !/^(f|ht)tps?:\/\//i.test(url)) {
		url = "http://" + url;
	}
	return url;
}

export const restAddress = (rest: Restaurant): string => {
	let address = rest.address
	if(!address) return rest.full_address || rest.city

	if(rest.address && rest.house_number) {
		const num = " " + rest.house_number
		if(!address.endsWith(num)) {
			address = address + num
		}
	}
	return address + ", " + rest.city
}

export const formatUserAddress = (item: UserAddress) => {
	return item.city + ', ' + item.address + ' ' + (item.house_number || "")
}

export const userImage = (data?: { photos: Photo[] } | Photo | null, thumb?: boolean): ImageSource => {
	if (data) {
		if ('photos' in data && data.photos.length > 0) {
			return {
				uri: thumb ? data.photos[0].thumbUrl : data.photos[0].fullUrl
			}
		} else if (thumb && 'thumbUrl' in data && isDefined(data.thumbUrl)) {
			return { uri: data.thumbUrl }
		} else if ('fullUrl' in data && isDefined(data.fullUrl)) {
			return { uri: data.fullUrl }
		}
	}
	if(Platform.OS == "web") {
		return {
			uri: resolveHref(DEFAULT_IMAGES_BASEURL, "utente.jpg"),
		}
	}
	return require('@FoodListCore/Assets/Images/utente.jpg');
}

export const alert = (title: string, content: string, onPress?: () => void): void => {
	Alert.alert(title, content.toString(), [{ text: translate("ok"), onPress: onPress || (() => {}) }])
}

export const error = (content: string, debug_error?: string) => {
	let errorStr = content.toString()
	if(debug_error) {
		const detailError = debug_error.toString().replace("Error: ", "")
		alert(errorStr, detailError)
	} else {
		alert(translate("error"), errorStr)
	}
	/* if(__DEV__ && debug_error) {
		error += "\n"
		error += debug_error.toString()
	} */
}

export const showError = (debug_error?: string) => {
	return error(translate("errorEncountered"), debug_error)
}

export const showConfirm = (title: string, description: string, confirmCb: () => void, cancelCb?: () => void) => {
	Alert.alert(title, description, [{
		text: translate("confirm"),
		style: 'destructive',
		onPress: confirmCb
	}, {
		text: translate("cancel"),
		onPress: () => {
			cancelCb?.()
		}
	}]);
}

export const confirmExit = (exitCb: () => void, hasContent: boolean, description: string = translate("defaultQuitDesription")): void => {
	if (hasContent) {
		Alert.alert(translate("confirmExitTitle"), description, [{
			text: translate("quit"),
			style: 'destructive',
			onPress: exitCb
		}, {
			text: translate("cancel"),
			onPress: () => { }
		}]);
	} else {
		exitCb()
	}
}

export const getNotificationIdentifier = (notification: Notification) => {
	return notification.type + ":" + notification.id
}

export const getOrdersCount = (orderItems: OrderItem[]) => {
	return orderItems.reduce((acc, item) => {
		return acc + item.quantity
	}, 0)
}