import { resolveHref } from "@FoodListCommon/utils"
import { Platform, StyleSheet, useWindowDimensions } from "react-native"
import { colors, spacing } from "./Constants"
import { DEFAULT_IMAGES_BASEURL as __DEFAULT_IMAGES_BASEURL__, WEBAPP_BASEURL } from "./injectedConst"

export const DEFAULT_IMAGES_BASEURL = __DEFAULT_IMAGES_BASEURL__

export const fixLinkingPath = (path: string) => {
	return resolveHref(WEBAPP_BASEURL, path)
}
export const MAX_LIST_WIDTH = 750

export const useListWidth = () => {
	const windowWidth = useWindowDimensions().width
	return Platform.OS == "web" ? Math.min(windowWidth, MAX_LIST_WIDTH) : windowWidth
}

export const useCellWidth = () => {
	return useListWidth() - (spacing.pagePadding * 2)
}

export const usePageWidth = () => {
	const windowWidth = useWindowDimensions().width
	return Math.min(windowWidth, spacing.maxPageWidth)
}

export const CART_WIDTH = 350

export const useShowSideCart = () => {
	return useWindowDimensions().width > 800
}

export const webStyles = StyleSheet.create({
	listMaxWidth: {
		width: "100%",
		maxWidth: MAX_LIST_WIDTH,
		marginLeft: "auto",
		marginRight: "auto",
	},
	pageMaxWidth: {
		width: "100%",
		maxWidth: spacing.maxPageWidth,
		marginLeft: "auto",
		marginRight: "auto",
	},
})
