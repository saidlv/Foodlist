import { Any } from "@Models/Any";
const React = require('react');
const { Platform, Text } = require('react-native');

export default function enableFontPatch() {

	if(Platform.OS !== 'android') {
    return
  }

	const oldRender = Text.render;
	Text.render = function (...args: Any[]) {
		const origin = oldRender.call(this, ...args);
		return React.cloneElement(origin, {
			style: [{ fontFamily: "Roboto" }, origin.props.style]
		});
	};
}