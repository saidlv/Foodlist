import { Settings } from "react-native-fbsdk-next"
import { request } from "react-native-permissions"
import { showError } from "./GlobalProps"

export const initAppTrackingTransparency = () => {
	request("ios.permission.APP_TRACKING_TRANSPARENCY").then((res) => {
		if(res == "granted" || res == "unavailable") {
			Settings.setAdvertiserTrackingEnabled(true)
			Settings.initializeSDK()
		} else {
			Settings.setAdvertiserTrackingEnabled(false)
		}
	}).catch(showError)
}
