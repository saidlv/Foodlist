import { colors, margins } from '@FoodListCore/Global/GlobalProps';
import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
	buttonContainer: {
		//flex: 0,
		alignSelf: "stretch",
		justifyContent: 'flex-end',
		backgroundColor: colors.white,
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 8,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 0 },
		shadowOpacity: 0.25,
		shadowRadius: 3,
		borderTopWidth: Platform.select({
			android: 1,
			ios: 0,
		}),
		borderColor: colors.darkGreyBorder,
	},
	rounded: {
		borderRadius: 4,
	},
	rippleFix: {
		overflow: Platform.select({
			android: "hidden",
		}),
	},
	shadow: {
		...(Platform.select({
			web: {
				boxShadow: "0px 2px 4px #00000022",
			},
			ios: {
				shadowColor: colors.shadowColor,
				shadowOffset: {
					width: 0,
					height: 2,
				},
				shadowRadius: 4,
				shadowOpacity: 1,
			},
			android: {
				elevation: 2,
			},
		})),
		zIndex: 1000,
	},
	lightShadow: {
		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 1,
		},
		shadowOpacity: 0.2,
		shadowRadius: 3,
		elevation: 4,
	},
	deepShadow: {
		...(Platform.select({
			web: {
				boxShadow: "0px 1px 6px #00000050",
			},
			ios: {
				shadowColor: '#000',
				shadowOffset: {
					width: 0,
					height: 4,
				},
				shadowOpacity: 0.25,
				shadowRadius: 4,
			},
			android: {
				elevation: 4,
			},
		})),
	},
	hardShadow: {
		...(Platform.select({
			web: {
				boxShadow: "0px 1px 3px #00000044",
			},
			ios: {
				shadowColor: "#000",
				shadowOffset: {
					width: 0,
					height: 1,
				},
				shadowRadius: 3,
				shadowOpacity: 0.4,
			},
			android: {
				elevation: 5,
			},
		})),
	},
	borderVertical: {
		borderStyle: "solid",
		borderBottomWidth: 1,
		borderTopWidth: 1,
		borderColor: colors.greyBorder,
	},
	borderBottom: {
		borderStyle: "solid",
		borderBottomWidth: 1,
		borderColor: colors.greyBorder,
	},
	borderTop: {
		borderStyle: "solid",
		borderTopWidth: 1,
		borderColor: colors.greyBorder,
	},
	hidden: {
		maxWidth: 0,
		maxHeight: 0,
		flex: 0,
		opacity: 0,
	},
	noShadow: {
		elevation: 0,
		shadowOpacity: 0,
		shadowColor: colors.transparent,
		shadowOffset: {
			width: 0,
			height: 0,
		},
		shadowRadius: 0,
	},
	touchableInfo: {
		backgroundColor: colors.white,
		paddingHorizontal: margins.pagePadding,
		paddingVertical: 12,
		paddingLeft: 20,
		flexDirection: "row",
		alignItems: "center",
		justifyContent: "space-between",
	},
	roundedBox: {
		borderWidth: margins.hairlineWidth,
		borderColor: colors.greyBorder,
		borderRadius: 6,
		overflow: "hidden",
	},
})
