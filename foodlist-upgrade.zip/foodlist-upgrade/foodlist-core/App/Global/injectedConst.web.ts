
declare const __WEBAPP_BASEURL__: string
declare const __DEFAULT_IMAGES_BASEURL__: string

export const WEBAPP_BASEURL = __WEBAPP_BASEURL__ || ""
export const DEFAULT_IMAGES_BASEURL = __DEFAULT_IMAGES_BASEURL__ || ""