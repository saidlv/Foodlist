
import { colors as _colors } from '@FoodListCommon/utils'
import { ThemeColors } from '@config/app'
import { StyleSheet } from 'react-native';

export const colors = {
	..._colors,
	greyBackground: ThemeColors.backgroundColor || "#f6f8fa",
	blueMenu: ThemeColors.ovverrideBlueMenu || _colors.blueMenu,
}

export const themeColors = {
	inlineButtonIcons: ThemeColors.inlineButtonIcons || ThemeColors.primary,
	inlineButtonArrow: ThemeColors.inlineButtonArrow || colors.blackText,
	headerGradient: ThemeColors.headerGradient || ThemeColors.secondary,
	infoTabButtons: ThemeColors.infoTabButtons || ThemeColors.secondary,
	infoTabIcons: ThemeColors.infoTabIcons || colors.greyText,
	editTextIcons: ThemeColors.editTextIcons || colors.greyText,
	timesTint: ThemeColors.timesTint || colors.blueMenu,
	inlineSubMenuTint: ThemeColors.inlineSubMenuTint || colors.blueMenu,
	priceTint: ThemeColors.priceTint || colors.blueMenu,
	orderHeadersBackground: ThemeColors.orderHeadersBackground,
	orderHeadersText: ThemeColors.orderHeadersText,
	radioButtonsTint: ThemeColors.radioButtonsTint || colors.blueMenu,
	bookPageTint: ThemeColors.bookPageTint || colors.blueMenu,
	configureButtonTint: ThemeColors.configureButtonsTint || "#ddd",
	configureButtonText: ThemeColors.configureButtonsText || colors.dark,
	addToCartButtonTint: ThemeColors.addToCartButtonsTint || "#ddd",
	addToCartButtonText: ThemeColors.addToCartButtonsText || colors.dark,
	menuSectionHeaderTint: ThemeColors.menuSectionHeaderTint || ThemeColors.secondary,
	menuSectionHeaderText: ThemeColors.menuSectionHeaderText || colors.white,

	loginPage: ThemeColors.loginPage,

	lightStatusBar: ThemeColors.lightStatusBar ?? false,
	primary: ThemeColors.primary ?? colors.foodlist,
	secondary: ThemeColors.secondary ?? 'rgb(17, 25, 54)',
	topBarBackground: ThemeColors.topBarBackground ?? colors.white,
	topBarTintColor: ThemeColors.topBarTintColor ?? colors.black,
	bottomBarBackground: ThemeColors.bottomBarBackground ?? colors.white,
	bottomBarActiveTint: ThemeColors.bottomBarActiveTint ?? colors.foodlist,
	bottomBarInactiveTint: ThemeColors.bottomBarInactiveTint ?? colors.greyText,
}

export const fontSizes = {
	formButtonTitle: 18,
}

export const spacing = {
	pagePadding: ThemeColors.pagePadding || 15,
	iconsPadding: 20,
	vertical: 10,
	hairlineWidth: StyleSheet.hairlineWidth,
	maxPageWidth: 1200,
}

export const regex = {
	EMAIL: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
	CAP: /^\d{4,5}$/,
	PRICE: /^\d+(?:$|[\.,]\d{1,2}$)/,
	URL: /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:\/?#[\]@!\$&'\(\)\*\+,;=.%]+$/,
	HOUSE_NUMBER: /^[a-zA-Z\d\/\\\^\.\,\ \-]+$/,
	PHONE: /^\+?[\d\s]{3,}$/,
	USER_NAME: /^\w{1,}(\.|-|\w){1,}\w{1,}$/,
	PASSWORD: /^.{6,20}$/,
	EMAIL_OR_USERNAME: /^((\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+)|(\w{1,}(\.|\w){1,}\w{1,}))$/,
	NAME_SURNAME: /^[A-Za-zÀ-ÖØ-öø-ÿ\-']+(( )[A-Za-zÀ-ÖØ-öø-ÿ\-']+)+$/,
}
