
export const WEBAPP_BASEURL = ""
export const DEFAULT_IMAGES_BASEURL = "https://foodlist.eu/it/DefaultImages"
