import { Order } from "@Models/Order";
import { BookingInfo } from "@Models/BookingInfo";
import { ReviewPoints } from "@FoodListCore/Pages/ReviewOrderPage";

export type ProfileParamList = {
	Profile: {} | undefined
	Settings: {} | undefined
	EditProfile: {} | undefined
	MyOrders: {} | undefined
	OrderDetail: {
		order_id: number
		order: Order | null
		from_notification?: boolean
		review_points: ReviewPoints | undefined
	}
	AddressPage: {} | undefined
	AddAddressPage: {} | undefined
	BookingHistory: {} | undefined
	BookingHistoryDetail: {
		booking_id: number
		booking?: BookingInfo
	}
	ReviewOrder: {
		order: Order
		review_points: ReviewPoints | undefined
	}
	NotificationReviewOrder: {
		order: Order
		review_points: ReviewPoints | undefined
	}
}