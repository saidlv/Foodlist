import { StackNavigationProp } from "@react-navigation/stack"
import { RouteProp } from "@react-navigation/native"

export type AuthParamList = {
	SplashPage: {} | undefined
	LoginPage: {} | undefined
	CompleteSocialRegistration: {} | undefined
	ForgotPassword: {} | undefined
	App: {} | undefined
	SelectRestaurant: {} | undefined
}

export type AuthNavigation<T extends keyof AuthParamList> = StackNavigationProp<AuthParamList, T>
export type AuthRoute<T extends keyof AuthParamList> = RouteProp<AuthParamList, T>
//export type AuthStateRoute<Key extends keyof AuthParamList> = StateRoute<AuthParamList, Key>