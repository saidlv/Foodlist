export type MainParamList = {
	Profile: {} | undefined
	Settings: {} | undefined
}