import { DishType } from "@Models/DishType";
import { Dish } from "@Models/Dish";
import { OrderItem } from "@Models/OrderItem";
import { DisplayableDeliveryDay } from "@Models/DeliveryRoute";
import { TimeRange } from "@Models/TimeRange";
import { BookingOption } from "@Models/BookingOption";
import { BookingInfo } from "@Models/BookingInfo";
import { Restaurant } from "@Models/Restaurant";

export type RestaurantParamList = {
	Restaurant: {} | undefined
	Menu: {
		dish_types: DishType[]
		for_orders: false
	},
	OrderOnline: {
		dish_types: DishType[]
		for_orders: true
	},
	AddToOrder: {
		dish: Dish,
		orderItem?: OrderItem,
		onSave?: () => void
	},
	OrderSummary: {} | undefined,
	RegisterPage: {
		isDuringOrder: boolean //distingue Ordini da Prenotazioni tavoli
	}, //in realtà credo che dovrei farne una unica con quella di Auth
	AddPhoneNumber: {
		isDuringOrder: boolean
	},
	ConfirmCode: {
		countryCode: string
		phone: string
		isDuringOrder: boolean
	},
	OrderCheckout: {
		restaurant?: Restaurant & { open_now?: boolean }
	} | undefined,
	SelectOrderTime: {
		day: DisplayableDeliveryDay
		selectTime: (startHour: TimeRange) => void
	},
	AddressPage: {
		order: boolean
	} | undefined,
	AddAddressPage: {} | undefined,
	SendOrder: {
		order: boolean
	} | undefined,
	ForgotPassword: {} | undefined,
	DishInfo: {
		dish: Dish
	},
	PdfMenu: {
		pdf_url: string
		onDownload?: () => void
	},
	BookTable: {} | undefined,
	BookingCheckout: {
		bookingInfo: BookingInfo
	},
	BookingOptions: {
		options: BookingOption[],
		bookingInfo: BookingInfo
	}
}