
export type { ParamList as RestaurantParamList } from '@FoodListCore/Flows/Restaurant'
export { Routes as RestaurantRoutes } from '@FoodListCore/Flows/Restaurant'
export type { ParamList as UserParamList } from '@FoodListCore/Flows/Restaurant'
export { Routes as UserRoutes } from '@FoodListCore/Flows/User'