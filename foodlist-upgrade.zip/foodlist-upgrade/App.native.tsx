import I18nManager from '@App/I18n'
/** @format */
import React, { useEffect } from 'react';
import { StyleSheet } from 'react-native';
import { NavigationContainer, useLinking, NavigationState, PartialState, NavigationContainerRef, InitialState, DefaultTheme as NavigationDefaultTheme } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import LoginPage from '@Pages/LoginPage';
import SplashPage from '@Pages/SplashPageContainer';
import { colors, iconNamed } from '@Global/GlobalProps';
import { DefaultTheme, Provider as PaperProvider } from "react-native-paper"

//import { Client } from 'bugsnag-react-native';
//const bugsnag = new Client("1cafa0fcfd43e709654c21d6ee02d2c1");

import { store } from '@Redux/Reducer';
import { Provider } from 'react-redux';
import FirebaseAnalytics from "@Services/FirebaseAnalytics"
//import LocalNotification from 'react-native-local-notification';
import LocalNotification from '@Components/LocalNotification';
import { AuthParamList } from '@RouteParams/Auth';

import TabBarPages from './App/TabBarPages';
import { CommonRoutes } from './App/CommonRoutes'
import { getStateFromPath } from './App/DeepLinkingStates';
import { NetworkNavigation } from '@Network/NetworkManager';
import { shareBaseUrl } from '@App/Services/ShareManager';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import enableFontPatch from '@FoodListCore/Global/fixTextCutOff';
import { initAppTrackingTransparency } from '@FoodListCore/Global/ATTHelper';
import { BottomSheetModalProvider } from '@FoodListCore/Components/SheetPopup';

require("@FoodListCore/Global/CommonStuff/LocaleStringPolyfill")

const Stack = createStackNavigator<AuthParamList>()

const styles = StyleSheet.create({
	authBar: {
		backgroundColor: "transparent",
	}
})

type RouteName = string | null | undefined
function getCurrentRouteName(navigationState: NavigationState | PartialState<NavigationState>): RouteName {
	if (!navigationState) {
		return null;
	}
	const route = navigationState.routes[navigationState.index || 0];
	// dive into nested navigators
	if (route.state?.routes) {
		return getCurrentRouteName(route.state);
	}
	return route.name;
}
let prevRoute: RouteName = ''

enableFontPatch()

const paperTheme = {
	...DefaultTheme,
	colors: {
		...DefaultTheme.colors,
		primary: colors.foodlist,
		accent: colors.blueMenu,
		notification: colors.blueMenu,
	},
	dark: false
}

export default function App() {

	const ref = React.useRef<NavigationContainerRef>(null);

	const { getInitialState } = useLinking(ref, {
		//prefixes: ['https://foodlist.eu/share/'],
		prefixes: [shareBaseUrl],
		getStateFromPath: getStateFromPath
	});

	const [isReady, setIsReady] = React.useState(false);
	const [initialState, setInitialState] = React.useState<InitialState>();

	React.useEffect(() => {

		Promise.race([
			getInitialState(),
			new Promise<undefined>(resolve =>
				setTimeout(resolve, 150)
			),
		]).catch(e => {
			console.error(e);
		}).then(state => {
			if (state !== undefined) {
				setInitialState(state);
			}
			setIsReady(true);
		});

		I18nManager.init()
		initAppTrackingTransparency()
	}, [getInitialState]);

	if (!isReady) {
		return null;
	}

	return (
		<SafeAreaProvider>
		<Provider store={store}>
		<PaperProvider theme={paperTheme}>
		<BottomSheetModalProvider>
			<NavigationContainer
				initialState={initialState}
				ref={ref}
				onStateChange={(state) => {
					if (state) {
						let currentRoute = getCurrentRouteName(state)
						if (currentRoute && prevRoute != currentRoute) {
							prevRoute = currentRoute
							FirebaseAnalytics.setScreen(currentRoute);
						}
					}
				}}
			>
				<Stack.Navigator
					initialRouteName="SplashPage"
					screenOptions={{
						headerTintColor: colors.white,
						headerStyle: {
							backgroundColor: colors.foodlist,
							borderBottomWidth: 0,
							elevation: 0,
							shadowColor: 'transparent',
						}
					}}>
					<Stack.Screen
						name="SplashPage"
						component={SplashPage}
						options={{
							headerShown: false
						}}
					/>
					<Stack.Screen
						name="MainAuthPage"
						component={LoginPage}
						options={{
							//header: null,
							headerShown: false,
						}}
					/>

					{CommonRoutes()}

					<Stack.Screen
						name="TabBarPage"
						component={TabBarPages}
						options={{
							headerShown: false,
							gestureEnabled: false,
							title: "",
						}}
					/>
				</Stack.Navigator>
			</NavigationContainer>

			<LocalNotification
				ref={v => NetworkNavigation.notificationRef = v}
			/>
		</BottomSheetModalProvider>
		</PaperProvider>
		</Provider>
		</SafeAreaProvider>
	);
}