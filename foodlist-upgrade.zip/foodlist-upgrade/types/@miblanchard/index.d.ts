declare module '@miblanchard' {

}