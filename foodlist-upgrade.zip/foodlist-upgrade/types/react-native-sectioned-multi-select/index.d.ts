
declare module "react-native-sectioned-multi-select" {
  import * as React from 'react';
  import * as ReactNative from 'react-native';

  export interface SectionedMultiSelectProps<ItemType> {
    single?: boolean;
    selectedItems?: any[];
    items?: ItemType[];
    displayKey?: string;
    uniqueKey: string;
    subKey?: string;
    onSelectedItemsChange: (items: any[]) => void;
    showDropDowns?: boolean;
    showChips?: boolean;
    readOnlyHeadings?: boolean;
    selectText?: string;
    selectedText?: string | (() => void);
    renderSelectText?: (props: object) => void;
    confirmText?: string;
    hideConfirm?: boolean;
    styles?: Styles;
    colors?: {
      primary?: string;
      success?: string;
      cancel?: string;
      text?: string;
      subText?: string;
      selectToggleTextColor?: string;
      searchPlaceholderTextColor?: string;
      searchSelectionColor?: string;
      chipColor?: string;
      itemBackground?: string;
      subItemBackground?: string;
      disabled?: string;
    };
    searchPlaceholderText?: string;
    noResultsComponent?: (() => void) | JSX.Element;
    loadingComponent?: (() => void) | JSX.Element;
    loading?: boolean;
    subItemFontFamily?: object;
    itemFontFamily?: object;
    searchTextFontFamily?: object;
    confirmFontFamily?: object;
    showRemoveAll?: boolean;
    removeAllText?: string;
    modalSupportedOrientations?: ReactNative.ModalProps['supportedOrientations'];
    modalAnimationType?: string;
    modalWithSafeAreaView?: boolean;
    modalWithTouchable?: boolean;
    hideSearch?: boolean;
    footerComponent?: (() => void) | JSX.Element;
    stickyFooterComponent?: (() => void) | JSX.Element;
    selectToggleIconComponent?: (() => void) | JSX.Element;
    cancelIconComponent?: (() => void) | JSX.Element;
    searchIconComponent?: (() => void) | JSX.Element;
    selectedIconComponent?: (() => void) | JSX.Element;
    unselectedIconComponent?: (() => void) | JSX.Element;
    dropDownToggleIconUpComponent?: (() => void) | JSX.Element;
    dropDownToggleIconDownComponent?: (() => void) | JSX.Element;
    chipRemoveIconComponent?: (() => void) | JSX.Element;
    selectChildren?: boolean;
    highlightChildren?: boolean;
    onSelectedItemObjectsChange?: (items: ItemType[]) => void;
    itemNumberOfLines?: number;
    selectLabelNumberOfLines?: number;
    showCancelButton?: boolean;
    hideSelect?: boolean;
    onConfirm?: () => void;
    onCancel?: () => void;
    headerComponent?: (() => void) | JSX.Element;
    alwaysShowSelectText?: boolean;
    searchAdornment?: (searchText: string) => void;
    expandDropDowns?: boolean;
    animateDropDowns?: boolean;
    customLayoutAnimation?: object;
    filterItems?: (searchTerm: string) => void;
    onToggleSelector?: (selected: boolean) => void;
    noItemsComponent?: (() => void) | JSX.Element;
    customChipsRenderer?: (chipProperties: object) => void;
    chipsPosition?: 'top' | 'bottom';
    autoFocus?: boolean;
    iconKey?: string;
    disabled?: boolean;
    selectedIconOnLeft?: boolean;
    parentChipsRemoveChildren?: boolean;
    iconRenderer?: (() => void) | JSX.Element;
    itemsFlatListProps?: Omit<ReactNative.FlatListProps<T>, 'data' | 'renderItem'>;
    subItemsFlatListProps?: Omit<ReactNative.FlatListProps<T>, 'data' | 'renderItem'>;
  }
  export default class SectionedMultiSelect<ItemType> extends React.Component<
    SectionedMultiSelectProps<ItemType>
  > {
    _toggleSelector: () => void
  }
}