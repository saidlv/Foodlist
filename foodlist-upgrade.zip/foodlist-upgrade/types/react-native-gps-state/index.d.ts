declare module "react-native-gps-state" {
  export const NOT_DETERMINED = 0
  export const RESTRICTED = 1
  export const DENIED = 2
  export const AUTHORIZED = 3
  export const AUTHORIZED_ALWAYS = 3
  export const AUTHORIZED_WHENINUSE = 4

  export const getStatus: () => Promise<number>
  export const openAppDetails: () => void
	export const openLocationSettings: () => void
	export const isMarshmallowOrAbove: () => boolean
	export const isAuthorized: () => boolean
	export const isDenied: () => boolean
	export const isNotDetermined: () => boolean
  export const addListener: (callback: (status: number) => void) => void
	export const removeListener: () => void
	export const getStatus: () => Promise<number>
	export const requestAuthorization: (authType: number) => void
}